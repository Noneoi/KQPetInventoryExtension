package mmo.interfaces.petdragon
{
   public class PetDragonLevel
   {
      
      public static const S:int = 4;
      
      public static const A:int = 3;
      
      public static const B:int = 2;
      
      public static const C:int = 1;
      
      public function PetDragonLevel()
      {
         super();
      }
   }
}

