package mmo.interfaces.petdragon
{
   import mmo.region.Translator;
   
   public class PetDragonDefine
   {
      
      private var defineId:int;
      
      private var name:String;
      
      private var color:String;
      
      private var skillType:String;
      
      private var skillDescription:String;
      
      public function PetDragonDefine(param1:int, param2:String, param3:String, param4:String, param5:String)
      {
         super();
         this.defineId = param1;
         this.name = param2;
         this.color = param3;
         this.skillType = param4;
         this.skillDescription = param5;
      }
      
      public function getDefineId() : int
      {
         return this.defineId;
      }
      
      public function getName() : String
      {
         return Translator.translate(this.name);
      }
      
      public function getColor() : String
      {
         return this.color;
      }
      
      public function getSkillType() : String
      {
         return this.skillType;
      }
      
      public function getSkillDescription() : String
      {
         return Translator.translate(this.skillDescription);
      }
   }
}

