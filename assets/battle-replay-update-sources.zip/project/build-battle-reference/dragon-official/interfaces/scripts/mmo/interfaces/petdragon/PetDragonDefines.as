package mmo.interfaces.petdragon
{
   public class PetDragonDefines
   {
      
      public static const DRAGON_DEFINES:Object = {
         "1":new PetDragonDefine(1,"轮回界龙·傲","黄","复活","回合开始前出手，己阵两位阵亡精灵复活，拥有全属性和血量上限各[0.02*N]%。界龙能力值越高，复活精灵拥有的全属性和血量上限越高。"),
         "2":new PetDragonDefine(2,"业罚界龙·焚","红","攻击提升","回合开始前出手，己阵所有精灵物攻，魔攻，超攻，超物攻和超魔攻提升[0.02*N]%。界龙能力值越高，提升越多。"),
         "3":new PetDragonDefine(3,"灵御界龙·渊","蓝","血量上限提升","回合开始前出手，己阵血量上限最高的两位精灵血量和血量上限提升[0.04*N]%。界龙能力值越高，提升越多，最多可提升150000点血量和血量上限。"),
         "4":new PetDragonDefine(4,"织元界龙·腾","橙","全属性提升","回合开始前出手，使敌阵精灵降低0-[0.02*N]点气势，界龙能力值越高，降低气势越多，最多有效降低四位精灵气势"),
         "5":new PetDragonDefine(5,"生息界龙·念","绿","恢复气势","回合开始前出手，己阵所有精灵随机提升[0.0125*N]-[0.025*N]点气势。界龙能力值越高，提升气势越多。"),
         "6":new PetDragonDefine(6,"秘语界龙·灭","紫","伤害","回合开始前出手，对敌阵所有精灵随机造成[2*N]-[8*N]点伤害。界龙能力值越高，造成伤害越高。"),
         "7":new PetDragonDefine(7,"苍雷界龙·云","白","控制","回合开始前出手，使敌阵所有精灵均有[0.005*N]%- [0.02*N]%概率无法行动一回合，至少生效一次。界龙能力值越高，生效概率越高。")
      };
      
      public static const LEVEL_DEFINES:Object = {
         "1_1":new PetDragonLevelDefine(1,1,2000,1001),
         "1_2":new PetDragonLevelDefine(1,2,3000,2001),
         "1_3":new PetDragonLevelDefine(1,3,4000,3001),
         "1_4":new PetDragonLevelDefine(1,4,5000,4001),
         "2_1":new PetDragonLevelDefine(2,1,2000,1001),
         "2_2":new PetDragonLevelDefine(2,2,3000,2001),
         "2_3":new PetDragonLevelDefine(2,3,4000,3001),
         "2_4":new PetDragonLevelDefine(2,4,5000,4001),
         "3_1":new PetDragonLevelDefine(3,1,2000,1001),
         "3_2":new PetDragonLevelDefine(3,2,3000,2001),
         "3_3":new PetDragonLevelDefine(3,3,4000,3001),
         "3_4":new PetDragonLevelDefine(3,4,5000,4001),
         "4_1":new PetDragonLevelDefine(4,1,2000,1001),
         "4_2":new PetDragonLevelDefine(4,2,3000,2001),
         "4_3":new PetDragonLevelDefine(4,3,4000,3001),
         "4_4":new PetDragonLevelDefine(4,4,5000,4001),
         "5_1":new PetDragonLevelDefine(5,1,2000,1004),
         "5_2":new PetDragonLevelDefine(5,2,3000,2001),
         "5_3":new PetDragonLevelDefine(5,3,4000,3001),
         "5_4":new PetDragonLevelDefine(5,4,5000,4001),
         "6_1":new PetDragonLevelDefine(6,1,2000,1001),
         "6_2":new PetDragonLevelDefine(6,2,3000,2001),
         "6_3":new PetDragonLevelDefine(6,3,4000,3001),
         "6_4":new PetDragonLevelDefine(6,4,5000,4001),
         "7_1":new PetDragonLevelDefine(7,1,2000,1001),
         "7_2":new PetDragonLevelDefine(7,2,3000,2001),
         "7_3":new PetDragonLevelDefine(7,3,4000,3001),
         "7_4":new PetDragonLevelDefine(7,4,5000,4001)
      };
      
      public function PetDragonDefines()
      {
         super();
      }
   }
}

