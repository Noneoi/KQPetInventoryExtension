package mmo.interfaces.petdragon
{
   public class PetDragonGene
   {
      
      public var geneArray:Array;
      
      public function PetDragonGene(param1:String)
      {
         super();
         this.geneArray = param1.split("");
      }
      
      public function getGeneArray() : Array
      {
         return this.geneArray;
      }
      
      public function getGeneSequence() : String
      {
         return this.geneArray.join("");
      }
      
      public function isGlittery() : Boolean
      {
         return this.geneArray[0] == "a" && this.geneArray[1] == "a";
      }
      
      public function setGeneByArrar(param1:Array) : void
      {
         this.geneArray = param1;
      }
      
      public function setGeneBySequence(param1:Array) : void
      {
         this.geneArray = param1.split("");
      }
   }
}

