package mmo.formation.transformskill
{
   internal class TramsformEffectParam
   {
      
      private var _targetSelector:String;
      
      private var _targetSelectorParams:String;
      
      private var _effectType:String;
      
      private var _effectParams:String;
      
      public function TramsformEffectParam()
      {
         super();
      }
      
      internal static function parse(param1:String) : TramsformEffectParam
      {
         var _loc2_:TramsformEffectParam = new TramsformEffectParam();
         var _loc3_:Array = param1.split(":");
         _loc2_._effectType = _loc3_[0];
         _loc2_._effectParams = _loc3_[1];
         _loc2_._targetSelector = _loc3_[2];
         _loc2_._targetSelectorParams = _loc3_[3];
         return _loc2_;
      }
      
      public function get targetSelector() : String
      {
         return this._targetSelector;
      }
      
      public function get targetSelectorParams() : String
      {
         return this._targetSelectorParams;
      }
      
      public function get effectType() : String
      {
         return this._effectType;
      }
      
      public function get effectParams() : String
      {
         return this._effectParams;
      }
      
      public function toString() : String
      {
         return this._effectType + ":" + this._effectParams + ":" + this._targetSelector + ":" + this._targetSelectorParams;
      }
   }
}

