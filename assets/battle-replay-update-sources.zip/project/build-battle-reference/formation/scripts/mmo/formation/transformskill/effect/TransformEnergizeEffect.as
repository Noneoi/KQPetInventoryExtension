package mmo.formation.transformskill.effect
{
   import mmo.formation.transformskill.TransformSkillDefine;
   import mmo.interfaces.formation.FormationBase;
   
   public class TransformEnergizeEffect implements ITransformEffect
   {
      
      public function TransformEnergizeEffect()
      {
         super();
      }
      
      public function effect(param1:TransformSkillDefine, param2:FormationBase, param3:int, param4:int) : void
      {
      }
      
      public function resetAll(param1:FormationBase) : void
      {
      }
   }
}

