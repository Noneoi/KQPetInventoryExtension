package mmo.formation.transformskill.effect
{
   import mmo.formation.transformskill.TransformSkillDefine;
   import mmo.interfaces.formation.FormationBase;
   
   public interface ITransformEffect
   {
      
      function effect(param1:TransformSkillDefine, param2:FormationBase, param3:int, param4:int) : void;
      
      function resetAll(param1:FormationBase) : void;
   }
}

