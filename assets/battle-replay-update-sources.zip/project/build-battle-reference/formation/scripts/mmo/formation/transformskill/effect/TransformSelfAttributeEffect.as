package mmo.formation.transformskill.effect
{
   import mmo.formation.transformskill.TransformSkillDefine;
   import mmo.interfaces.formation.FormationBase;
   
   public class TransformSelfAttributeEffect implements ITransformEffect
   {
      
      public function TransformSelfAttributeEffect()
      {
         super();
      }
      
      public function effect(param1:TransformSkillDefine, param2:FormationBase, param3:int, param4:int) : void
      {
         param2.setAttr(param3,int(param1.getEffectFuncParam(param4)));
      }
      
      public function resetAll(param1:FormationBase) : void
      {
         param1.resetAttr();
      }
   }
}

