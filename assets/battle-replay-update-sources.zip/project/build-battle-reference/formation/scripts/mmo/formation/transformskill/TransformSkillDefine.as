package mmo.formation.transformskill
{
   import mmo.interfaces.formation.ITransformSkillDefine;
   import mmo.interfaces.formation.TransformSkillType;
   
   public class TransformSkillDefine implements ITransformSkillDefine
   {
      
      private var _id:int;
      
      private var _name:String;
      
      private var _desc:String;
      
      private var _autoEffectDesc:String;
      
      private var _effectParams:Vector.<TramsformEffectParam>;
      
      private var _autoEffectParams:Vector.<TramsformEffectParam>;
      
      private var _skillType:TransformSkillType;
      
      public function TransformSkillDefine(param1:int, param2:String, param3:String, param4:String, param5:Array, param6:Array, param7:int = 0)
      {
         var id:int = param1;
         var name:String = param2;
         var desc:String = param3;
         var autoEffectDesc:String = param4;
         var effectArr:Array = param5;
         var autoEffect:Array = param6;
         var skillType:int = param7;
         super();
         this._id = id;
         this._name = name;
         this._desc = desc;
         this._autoEffectDesc = autoEffectDesc;
         this._effectParams = new Vector.<TramsformEffectParam>();
         effectArr.forEach(function(... rest):void
         {
            _effectParams.push(TramsformEffectParam.parse(rest[0]));
         });
         this._autoEffectParams = new Vector.<TramsformEffectParam>();
         autoEffect.forEach(function(... rest):void
         {
            _autoEffectParams.push(TramsformEffectParam.parse(rest[0]));
         });
         this._skillType = TransformSkillType.valueOf(skillType);
      }
      
      public function get id() : int
      {
         return this._id;
      }
      
      public function get name() : String
      {
         return this._name;
      }
      
      public function get desc() : String
      {
         return this._desc;
      }
      
      public function get effectCnt() : int
      {
         return this._effectParams.length;
      }
      
      public function get autoEffectDesc() : String
      {
         return this._autoEffectDesc;
      }
      
      public function getSeletor(param1:int) : String
      {
         return this._effectParams[param1].targetSelector;
      }
      
      public function getSeletorParam(param1:int) : String
      {
         return this._effectParams[param1].targetSelectorParams;
      }
      
      public function getEffectType(param1:int) : String
      {
         return this._effectParams[param1].effectType;
      }
      
      public function getEffectFuncParam(param1:int) : String
      {
         return this._effectParams[param1].effectParams;
      }
      
      public function getAutoEffectSelector(param1:int) : String
      {
         return this._autoEffectParams[param1].targetSelector;
      }
      
      public function getAutoEffectSelectorParams(param1:int) : String
      {
         return this._autoEffectParams[param1].targetSelectorParams;
      }
      
      public function getAutoEffectType(param1:int) : String
      {
         return this._autoEffectParams[param1].effectType;
      }
      
      public function getAutoEffectParams(param1:int) : String
      {
         return this._autoEffectParams[param1].effectParams;
      }
      
      public function get hasAutoEffect() : Boolean
      {
         return this._autoEffectParams.length > 0;
      }
      
      public function effectToString(param1:int) : String
      {
         return this._effectParams[param1].toString();
      }
      
      public function get skillType() : TransformSkillType
      {
         return this._skillType;
      }
   }
}

