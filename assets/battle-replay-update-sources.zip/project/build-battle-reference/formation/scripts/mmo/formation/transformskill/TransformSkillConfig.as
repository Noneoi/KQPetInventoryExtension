package mmo.formation.transformskill
{
   import mmo.formation.transformskill.effect.ITransformEffect;
   import mmo.formation.transformskill.effect.TransformAttriuteEffect;
   import mmo.formation.transformskill.effect.TransformEnergizeEffect;
   import mmo.formation.transformskill.effect.TransformSelfAttributeEffect;
   import mmo.interfaces.formation.FormationBase;
   import mmo.interfaces.formation.ITransformSkillInfo;
   
   public class TransformSkillConfig
   {
      
      private static const DATA:Object = {
         "502737":new TransformSkillDefine(502737,"小乾坤转化技","将一只精灵变为神灵","增强全阵神灵精灵属性克制效果",["ARR_RACE_TYPE:26:ALL:"],["26::RaceTypeEffected:26@10026"],0),
         "502738":new TransformSkillDefine(502738,"乾坤转化技","将一只精灵变为神灵","增强全阵神灵精灵属性克制效果",["ARR_RACE_TYPE:26:ALL:"],["26::RaceTypeEffected:26@10026"],0),
         "502741":new TransformSkillDefine(502741,"荧惑转化技","将一只精灵变为神暗","增强全阵神暗精灵属性克制效果",["ARR_RACE_TYPE:24:ALL:"],["24::RaceTypeEffected:24@10024"],0),
         "502777":new TransformSkillDefine(502777,"干将莫邪转化技","将一只精灵变为神光","增强全阵神光精灵属性克制效果",["ARR_RACE_TYPE:25:ALL:"],["25::RaceTypeEffected:25@10025"],0),
         "502832":new TransformSkillDefine(502832,"路西法转化技","将一只精灵变为神火","增强全阵神火精灵属性克制效果",["ARR_RACE_TYPE:23:ALL:"],["23::RaceTypeEffected:23@10023"],0),
         "502885":new TransformSkillDefine(502885,"星龙王转化技","将一只精灵变为神水","增强全阵神水精灵属性克制效果",["ARR_RACE_TYPE:22:ALL:"],["22::RaceTypeEffected:22@10022"],0),
         "502934":new TransformSkillDefine(502934,"真龙转化技","将一只精灵变为神草","增强全阵神草精灵属性克制效果",["ARR_RACE_TYPE:21:ALL:"],["21::RaceTypeEffected:21@10021"],0),
         "502996":new TransformSkillDefine(502996,"白起转化技","将一只精灵变为神光","增强全阵神光精灵属性克制效果",["ARR_RACE_TYPE:25:ALL:"],["25::RaceTypeEffected:25@10025"],0),
         "503036":new TransformSkillDefine(503036,"乾坤转化技","将一只精灵变为神灵","增强全阵神灵精灵属性克制效果",["ARR_RACE_TYPE:26:ALL:"],["26::RaceTypeEffected:26@10026"],0),
         "503056":new TransformSkillDefine(503056,"路西法转化技","将一只精灵变为神火","增强全阵神火精灵属性克制效果",["ARR_RACE_TYPE:23:ALL:"],["23::RaceTypeEffected:23@10023"],0),
         "503093":new TransformSkillDefine(503093,"星龙王转化技","将一只精灵变为神水","增强全阵神水精灵属性克制效果",["ARR_RACE_TYPE:22:ALL:"],["22::RaceTypeEffected:22@10022"],0),
         "503098":new TransformSkillDefine(503098,"王者帝释天转化技","将一只精灵变为神水","增强全阵神水精灵属性克制效果",["ARR_RACE_TYPE:22:ALL:"],["22::RaceTypeEffected:22@10022"],0),
         "503133":new TransformSkillDefine(503133,"王者诺亚转化技","将一只精灵变为神光","增强全阵神光精灵属性克制效果",["ARR_RACE_TYPE:25:ALL:"],["25::RaceTypeEffected:25@10025"],0),
         "503162":new TransformSkillDefine(503162,"王修转化技","将一只精灵变为神暗","增强全阵神暗精灵属性克制效果",["ARR_RACE_TYPE:24:ALL:"],["24::RaceTypeEffected:24@10024"],0),
         "503180":new TransformSkillDefine(503180,"王者以撒转化技","将一只精灵变为神灵","增强全阵神灵精灵属性克制效果",["ARR_RACE_TYPE:26:ALL:"],["26::RaceTypeEffected:26@10026"],0),
         "503208":new TransformSkillDefine(503208,"王瑞转化技","将一只精灵变为神草","增强全阵神草精灵属性克制效果",["ARR_RACE_TYPE:21:ALL:"],["21::RaceTypeEffected:21@10021"],0),
         "503229":new TransformSkillDefine(503229,"昆吾转化技","将一只精灵变为神火","增强全阵神火精灵属性克制效果",["ARR_RACE_TYPE:23:ALL:"],["23::RaceTypeEffected:23@10023"],0),
         "503252":new TransformSkillDefine(503252,"王者龙炎转化技","将一只精灵变为神火","增强全阵神火精灵属性克制效果",["ARR_RACE_TYPE:23:ALL:"],["23::RaceTypeEffected:23@10023"],0),
         "503341":new TransformSkillDefine(503341,"诺雅转化技","将一只精灵变为神光","增强全阵神光精灵属性克制效果",["ARR_RACE_TYPE:25:ALL:"],["25::RaceTypeEffected:25@10025"],0),
         "503395":new TransformSkillDefine(503395,"多洛莉丝赋能技","赋予一只精灵特殊能力","",["ENERGIZE::ALL:"],[],1),
         "503397":new TransformSkillDefine(503397,"少林赋能技","赋予一只精灵特殊能力","额外效果",["ENERGIZE::ALL:"],[],1),
         "503412":new TransformSkillDefine(503412,"钻石启转化技","将一只精灵变为神光","增强全阵神光精灵属性克制效果",["ARR_RACE_TYPE:25:ALL:"],["25::RaceTypeEffected:25@10025"],0),
         "503468":new TransformSkillDefine(503468,"麒麟赋能技","赋予一只精灵特殊能力","",["ENERGIZE::ALL:"],[],1),
         "503464":new TransformSkillDefine(503464,"龙脉诺亚转化技","将一只精灵变为神光","增强全阵神光精灵属性克制效果",["ARR_RACE_TYPE:25:ALL:"],["25::RaceTypeEffected:25@10025"],0),
         "503590":new TransformSkillDefine(503590,"乾坤转化技","将一只精灵变为神灵","增强全阵神灵精灵属性克制效果",["ARR_RACE_TYPE:26:ALL:"],["26::RaceTypeEffected:26@10026"],0),
         "503624":new TransformSkillDefine(503624,"昆吾转化技","将一只精灵变为神火","增强全阵神火精灵属性克制效果",["ARR_RACE_TYPE:23:ALL:"],["23::RaceTypeEffected:23@10023"],0),
         "503629":new TransformSkillDefine(503629,"王者龙炎转化技","将一只精灵变为神火","增强全阵神火精灵属性克制效果",["ARR_RACE_TYPE:23:ALL:"],["23::RaceTypeEffected:23@10023"],0),
         "503626":new TransformSkillDefine(503626,"昆吾转化技","将一只精灵变为神火","增强全阵神火精灵属性克制效果",["ARR_RACE_TYPE:23:ALL:"],["23::RaceTypeEffected:23@10023"],0),
         "503696":new TransformSkillDefine(503696,"神幻诺雅转化技","将一只精灵变为神灵","增强全阵神幻精灵属性克制效果",["ARR_RACE_TYPE:28:ALL:"],["28::RaceTypeEffected:28@10028"],0),
         "503689":new TransformSkillDefine(503689,"展昭赋能技","赋予一只精灵特殊能力","额外效果",["ENERGIZE::ALL:"],[],1),
         "503724":new TransformSkillDefine(503724,"王者梦梦赋能技","赋予一只精灵特殊能力","",["ENERGIZE::ALL:"],[],1),
         "503727":new TransformSkillDefine(503727,"王者梦梦赋能技","赋予一只精灵特殊能力","",["ENERGIZE::ALL:"],[],1),
         "503764":new TransformSkillDefine(503764,"白起赋能技","赋予一只精灵特殊能力","额外效果",["ENERGIZE::ALL:"],[],1),
         "503765":new TransformSkillDefine(503765,"诺雅转化技","将一只精灵变为神光","增强全阵神光精灵属性克制效果",["ARR_RACE_TYPE:25:ALL:"],["25::RaceTypeEffected:25@10025"],0),
         "503785":new TransformSkillDefine(503785,"诺雅转化技","将一只精灵变为神光","增强全阵神光精灵属性克制效果",["ARR_RACE_TYPE:25:ALL:"],["25::RaceTypeEffected:25@10025"],0),
         "503835":new TransformSkillDefine(503835,"王者诺亚转化技","将一只精灵变为神光","增强全阵神光精灵属性克制效果",["ARR_RACE_TYPE:25:ALL:"],["25::RaceTypeEffected:25@10025"],0),
         "503856":new TransformSkillDefine(503856,"启转化技","将一只精灵变为神光","增强全阵神光精灵属性克制效果",["ARR_RACE_TYPE:25:ALL:"],["25::RaceTypeEffected:25@10025"],0),
         "503865":new TransformSkillDefine(503865,"王者以撒转化技","将一只精灵变为神灵","增强全阵神灵精灵属性克制效果",["ARR_RACE_TYPE:26:ALL:"],["26::RaceTypeEffected:26@10026"],0),
         "503886":new TransformSkillDefine(503886,"路西法转化技","将一只精灵变为神火","增强全阵神火精灵属性克制效果",["ARR_RACE_TYPE:23:ALL:"],["23::RaceTypeEffected:23@10023"],0),
         "503894":new TransformSkillDefine(503894,"伏妖赋能技","赋予一只精灵特殊能力","",["ENERGIZE::ALL:"],[],1),
         "503933":new TransformSkillDefine(503933,"星龙王转化技","将一只精灵变为神水","增强全阵神水精灵属性克制效果",["ARR_RACE_TYPE:22:ALL:"],["22::RaceTypeEffected:22@10022"],0),
         "503945":new TransformSkillDefine(503945,"启元王者帝释天转化技","将一只精灵变为神水","增强全阵神水精灵属性克制效果",["ARR_RACE_TYPE:22:ALL:"],["22::RaceTypeEffected:22@10022"],0),
         "504002":new TransformSkillDefine(504002,"真龙转化技","将一只精灵变为神草","增强全阵神草精灵属性克制效果",["ARR_RACE_TYPE:21:ALL:"],["21::RaceTypeEffected:21@10021"],0),
         "504015":new TransformSkillDefine(504015,"王瑞转化技","将一只精灵变为神草","增强全阵神草精灵属性克制效果",["ARR_RACE_TYPE:21:ALL:"],["21::RaceTypeEffected:21@10021"],0),
         "504031":new TransformSkillDefine(504031,"王修转化技","将一只精灵变为神暗","增强全阵神暗精灵属性克制效果",["ARR_RACE_TYPE:24:ALL:"],["24::RaceTypeEffected:24@10024"],0),
         "504051":new TransformSkillDefine(504051,"多洛莉丝赋能技","赋予一只精灵特殊能力","",["ENERGIZE::ALL:"],[],1),
         "504102":new TransformSkillDefine(504102,"东北虎赋能技","赋予一只精灵特殊能力","额外效果",["ENERGIZE::ALL:"],[],1),
         "504160":new TransformSkillDefine(504160,"元素极转化技","将一只精灵变为神无极","增强全阵神无极精灵天启技效果",["ARR_RACE_TYPE:27:ALL:"],["27::RaceTypeEffected:27@10027"],0),
         "504221":new TransformSkillDefine(504221,"启元龙脉诺亚转化技","将一只精灵变为神光","增强全阵神光精灵属性克制效果",["ARR_RACE_TYPE:25:ALL:"],["25::RaceTypeEffected:25@10025"],0),
         "504232":new TransformSkillDefine(504232,"神幻正理赋能技","赋予一只精灵特殊能力","",["ENERGIZE::ALL:"],[],1),
         "504252":new TransformSkillDefine(504252,"星迹银光王梦赋能","赋予一只精灵特殊能力","",["ENERGIZE::ALL:"],[],1),
         "504255":new TransformSkillDefine(504255,"星迹钻石王梦赋能","赋予一只精灵特殊能力","",["ENERGIZE::ALL:"],[],1),
         "504283":new TransformSkillDefine(504283,"星迹诺雅转化技","将一只精灵变为神光","增强全阵神光精灵属性克制效果",["ARR_RACE_TYPE:25:ALL:"],["25::RaceTypeEffected:25@10025"],0),
         "504305":new TransformSkillDefine(504305,"星迹诺雅转化技","将一只精灵变为神光","增强全阵神光精灵属性克制效果",["ARR_RACE_TYPE:25:ALL:"],["25::RaceTypeEffected:25@10025"],0),
         "504344":new TransformSkillDefine(504344,"星迹白起转化技","将一只精灵变为神光","增强全阵神光精灵属性克制效果",["ARR_RACE_TYPE:25:ALL:"],["25::RaceTypeEffected:25@10025"],0),
         "504412":new TransformSkillDefine(504412,"星迹王撒转化技","将一只精灵变为神灵","增强全阵神灵精灵属性克制效果",["ARR_RACE_TYPE:26:ALL:"],["26::RaceTypeEffected:26@10026"],0),
         "504413":new TransformSkillDefine(504413,"伊西多赋能技","赋予一只精灵特殊能力","",["ENERGIZE::ALL:"],[],1),
         "504464":new TransformSkillDefine(504464,"王者龙炎转化技","将一只精灵变为神火","增强全阵神火精灵属性克制效果",["ARR_RACE_TYPE:23:ALL:"],["23::RaceTypeEffected:23@10023"],0),
         "504470":new TransformSkillDefine(504470,"星迹路西法转化技","将一只精灵变为神火","增强全阵神火精灵属性克制效果",["ARR_RACE_TYPE:23:ALL:"],["23::RaceTypeEffected:23@10023"],0),
         "504507":new TransformSkillDefine(504507,"星迹卡拉转化技","将一只精灵变为神幻","增强全阵神幻精灵属性克制效果",["ARR_RACE_TYPE:28:ALL:"],["28::RaceTypeEffected:28@10028"],0),
         "504548":new TransformSkillDefine(504548,"星迹王诺转化技","将一只精灵变为神光","增强全阵神光精灵属性克制效果",["ARR_RACE_TYPE:25:ALL:"],["25::RaceTypeEffected:25@10025"],0),
         "504617":new TransformSkillDefine(504617,"王修转化技","将一只精灵变为神暗","增强全阵神暗精灵属性克制效果",["ARR_RACE_TYPE:24:ALL:"],["24::RaceTypeEffected:24@10024"],0),
         "504654":new TransformSkillDefine(504654,"反心人赋能","赋予一只精灵特殊能力","",["ENERGIZE::ALL:"],[],1),
         "504655":new TransformSkillDefine(504655,"耶梦加得转化技","将一只精灵变为神暗","增强全阵神暗精灵属性克制效果",["ARR_RACE_TYPE:24:ALL:"],["24::RaceTypeEffected:24@10024"],0),
         "504688":new TransformSkillDefine(504688,"星迹神幻诺雅转化技","将一只精灵变为神幻","增强全阵神幻精灵属性克制效果",["ARR_RACE_TYPE:28:ALL:"],["28::RaceTypeEffected:28@10028"],0),
         "504714":new TransformSkillDefine(504714,"星迹东北虎赋能技","赋予一只精灵特殊能力","",["ENERGIZE::ALL:"],[],1),
         "504725":new TransformSkillDefine(504725,"九九转化技","将一只精灵变为神草","增强全阵神草精灵属性克制效果",["ARR_RACE_TYPE:21:ALL:"],["21::RaceTypeEffected:21@10021"],0),
         "504745":new TransformSkillDefine(504745,"星迹昆吾转化技","将一只精灵变为神火","增强全阵神火精灵属性克制效果",["ARR_RACE_TYPE:23:ALL:"],["23::RaceTypeEffected:23@10023"],0),
         "504751":new TransformSkillDefine(504751,"星迹昆吾转化技","将一只精灵变为神火","增强全阵神火精灵属性克制效果",["ARR_RACE_TYPE:23:ALL:"],["23::RaceTypeEffected:23@10023"],0),
         "504830":new TransformSkillDefine(504830,"星迹界皇赋能技","赋予一只精灵特殊能力","",["ENERGIZE::ALL:"],[],1),
         "504867":new TransformSkillDefine(504867,"星迹黄金赋能技","赋予一只精灵特殊能力","",["ENERGIZE::ALL:"],[],1),
         "504874":new TransformSkillDefine(504874,"王者帝释天转化技","将一只精灵变为神水","增强全阵神水精灵属性克制效果",["ARR_RACE_TYPE:22:ALL:"],["22::RaceTypeEffected:22@10022"],0),
         "504882":new TransformSkillDefine(504882,"王者冰奇布转化技","将一只精灵变为神水","增强全阵神水精灵属性克制效果",["ARR_RACE_TYPE:22:ALL:"],["22::RaceTypeEffected:22@10022"],0),
         "504898":new TransformSkillDefine(504898,"星迹黄金挑战赋能","赋予一只精灵特殊能力","",["ENERGIZE::ALL:"],[],1),
         "504868":new TransformSkillDefine(504868,"星迹黄金赋能技","赋予一只精灵特殊能力","",["ENERGIZE::ALL:"],[],1),
         "504869":new TransformSkillDefine(504869,"星迹黄金赋能技","赋予一只精灵特殊能力","",["ENERGIZE::ALL:"],[],1),
         "504929":new TransformSkillDefine(504929,"星迹黑金王梦赋能","赋予一只精灵特殊能力","",["ENERGIZE::ALL:"],[],1),
         "504992":new TransformSkillDefine(504992,"多洛莉丝赋能技","赋予一只精灵特殊能力","",["ENERGIZE::ALL:"],[],1),
         "505045":new TransformSkillDefine(505045,"王瑞转化技","将一只精灵变为神草","增强全阵神草精灵属性克制效果",["ARR_RACE_TYPE:21:ALL:"],["21::RaceTypeEffected:21@10021"],0),
         "501464":new TransformSkillDefine(501464,"万象迷踪赋能技","赋予一只精灵特殊能力","",["ENERGIZE::ALL:"],[],1),
         "501477":new TransformSkillDefine(501477,"飞翼天闪赋能技","赋予一只精灵特殊能力","",["ENERGIZE::ALL:"],[],1),
         "501498":new TransformSkillDefine(501498,"地狱炎神赋能技","赋予一只精灵特殊能力","",["ENERGIZE::ALL:"],[],1),
         "501490":new TransformSkillDefine(501490,"疾刃阎罗赋能技","赋予一只精灵特殊能力","",["ENERGIZE::ALL:"],[],1),
         "501468":new TransformSkillDefine(501468,"灭魔光轮赋能技","赋予一只精灵特殊能力","",["ENERGIZE::ALL:"],[],1),
         "502843":new TransformSkillDefine(502843,"极赋能技","赋予一只精灵特殊能力","",["ENERGIZE::ALL:"],[],1),
         "505077":new TransformSkillDefine(505077,"星迹诺雅转化技","将一只精灵变为神光","增强全阵神光精灵属性克制效果",["ARR_RACE_TYPE:25:ALL:"],["25::RaceTypeEffected:25@10025"],0),
         "505131":new TransformSkillDefine(505131,"星迹空皇赋能技","赋予一只精灵特殊能力","",["ENERGIZE::ALL:"],[],1),
         "505135":new TransformSkillDefine(505135,"星迹神幻正理赋能技","赋予一只精灵特殊能力","",["ENERGIZE::ALL:"],[],1),
         "505157":new TransformSkillDefine(505157,"星迹元素极转化技","将一只精灵变为神无极","增强全阵神无极精灵",["ARR_RACE_TYPE:27:ALL:"],["27::RaceTypeEffected:27@10027"],0),
         "505180":new TransformSkillDefine(505180,"星迹龙诺转化技","将一只精灵变为神光","增强全阵神光精灵属性克制效果",["ARR_RACE_TYPE:25:ALL:"],["25::RaceTypeEffected:25@10025"],0),
         "505190":new TransformSkillDefine(505190,"星迹冥皇赋能技","赋予一只精灵特殊能力","",["ENERGIZE::ALL:"],[],1),
         "505264":new TransformSkillDefine(505264,"神运王者以撒转化技","将一只精灵变为神灵","增强全阵神灵精灵伤害与减伤",["ARR_RACE_TYPE:26:ALL:"],["26::RaceTypeEffected:26@10026"],0),
         "505315":new TransformSkillDefine(505315,"神运乾坤转化技","将一只精灵变为神灵","增强全阵神灵精灵伤害与减伤",["ARR_RACE_TYPE:26:ALL:"],["26::RaceTypeEffected:26@10026"],0),
         "505317":new TransformSkillDefine(505317,"神运伊西多赋能技","赋予一只精灵特殊能力","",["ENERGIZE::ALL:"],[],1),
         "505369":new TransformSkillDefine(505369,"神运钻石昆吾转化技","将一只精灵变为神火","增强全阵神火精灵伤害与减伤",["ARR_RACE_TYPE:23:ALL:"],["23::RaceTypeEffected:23@10023"],0),
         "505377":new TransformSkillDefine(505377,"神运黑金昆吾转化技","将一只精灵变为神火","增强全阵神火精灵伤害与减伤",["ARR_RACE_TYPE:23:ALL:"],["23::RaceTypeEffected:23@10023"],0),
         "505443":new TransformSkillDefine(505443,"神运王者龙炎转化技","将一只精灵变为神火","增强全阵神火精灵伤害与减伤",["ARR_RACE_TYPE:23:ALL:"],["23::RaceTypeEffected:23@10023"],0),
         "505466":new TransformSkillDefine(505466,"神幻王者赋能技","赋予一只精灵特殊能力","",["ENERGIZE::ALL:"],[],1),
         "505524":new TransformSkillDefine(505524,"神运九九转化技","将一只精灵变为神草","增强全阵神草精灵伤害与减伤",["ARR_RACE_TYPE:21:ALL:"],["21::RaceTypeEffected:21@10021"],0),
         "505549":new TransformSkillDefine(505549,"神运王梦赋能技","赋予一只精灵特殊能力","",["ENERGIZE::ALL:"],[],1),
         "505568":new TransformSkillDefine(505568,"神运钻石诺雅转化技","将一只精灵变为神光","增强全阵神光精灵伤害与减伤",["ARR_RACE_TYPE:25:ALL:"],["25::RaceTypeEffected:25@10025"],0),
         "505590":new TransformSkillDefine(505590,"神运黑金诺雅转化技","将一只精灵变为神光","增强全阵神光精灵伤害与减伤",["ARR_RACE_TYPE:25:ALL:"],["25::RaceTypeEffected:25@10025"],0),
         "505669":new TransformSkillDefine(505669,"神运王者诺亚转化技","将一只精灵变为神光","增强全阵神光精灵伤害与减伤",["ARR_RACE_TYPE:25:ALL:"],["25::RaceTypeEffected:25@10025"],0),
         "505753":new TransformSkillDefine(505753,"神运亚咪幻元技","将自身变换属性","",["SELF_RACE_TYPE:21:SELF:","SELF_RACE_TYPE:22:SELF:","SELF_RACE_TYPE:23:SELF:","SELF_RACE_TYPE:24:SELF:","SELF_RACE_TYPE:25:SELF:","SELF_RACE_TYPE:28:SELF:"],[],2),
         "505801":new TransformSkillDefine(505801,"神运启转化技","将一只精灵变为神光","增强全阵神光精灵伤害与减伤",["ARR_RACE_TYPE:25:ALL:"],["25::RaceTypeEffected:25@10025"],0),
         "505811":new TransformSkillDefine(505811,"神运钻石弥娅幻元技","将自身变换属性","",["SELF_RACE_TYPE:23:SELF:","SELF_RACE_TYPE:25:SELF:"],[],2),
         "505825":new TransformSkillDefine(505825,"神运黑金弥娅幻元技","将自身变换属性","",["SELF_RACE_TYPE:23:SELF:","SELF_RACE_TYPE:25:SELF:"],[],2),
         "505882":new TransformSkillDefine(505882,"神运神幻诺雅转化技","将一只精灵变为神幻","增强全阵神幻精灵伤害与减伤",["ARR_RACE_TYPE:28:ALL:"],["28::RaceTypeEffected:28@10028"],0),
         "505886":new TransformSkillDefine(505886,"神运神幻卡拉转化技","将一只精灵变为神幻","增强全阵神幻精灵伤害与减伤",["ARR_RACE_TYPE:28:ALL:"],["28::RaceTypeEffected:28@10028"],0),
         "505919":new TransformSkillDefine(505919,"神运王修转化技","将一只精灵变为神暗","增强全阵神暗精灵伤害与减伤",["ARR_RACE_TYPE:24:ALL:"],["24::RaceTypeEffected:24@10024"],0),
         "505931":new TransformSkillDefine(505931,"神运龙皇诺亚转化技","将一只精灵变为神光","增强全阵神光精灵伤害与减伤",["ARR_RACE_TYPE:25:ALL:"],["25::RaceTypeEffected:25@10025"],0),
         "506053":new TransformSkillDefine(506053,"奥奇幻元技","将自身变换属性","",["SELF_RACE_TYPE:21:SELF:","SELF_RACE_TYPE:22:SELF:","SELF_RACE_TYPE:23:SELF:","SELF_RACE_TYPE:24:SELF:","SELF_RACE_TYPE:25:SELF:"],[],2),
         "505972":new TransformSkillDefine(505972,"神运王者阿瑞斯转化技","将一只精灵变为神草","增强全阵神草精灵属性克制效果",["ARR_RACE_TYPE:21:ALL:"],["21::RaceTypeEffected:21@10021"],0),
         "505986":new TransformSkillDefine(505986,"神运路西法转化技","将一只精灵变为神火","增强全阵神火精灵伤害与减伤",["ARR_RACE_TYPE:23:ALL:"],["23::RaceTypeEffected:23@10023"],0),
         "506260":new TransformSkillDefine(506260,"神运王者帝释天转化技","将一只精灵变为神水","增强全阵神水精灵伤害与减伤",["ARR_RACE_TYPE:22:ALL:"],["22::RaceTypeEffected:22@10022"],0),
         "506371":new TransformSkillDefine(506371,"神运元素极转化技","将一只精灵变为神无极","增强全阵神无极精灵",["ARR_RACE_TYPE:27:ALL:"],["27::RaceTypeEffected:27@10027"],0),
         "506496":new TransformSkillDefine(506496,"灵初王梦赋能技","赋予一只精灵特殊能力","",["ENERGIZE::ALL:"],[],1),
         "506699":new TransformSkillDefine(506699,"灵初界皇赋能技","赋予一只精灵特殊能力","",["ENERGIZE::ALL:"],[],1),
         "506694":new TransformSkillDefine(506694,"灵初伊西多赋能技","赋予一只精灵特殊能力","",["ENERGIZE::ALL:"],[],1),
         "506861":new TransformSkillDefine(506861,"灵初元皇赋能技","赋予一只精灵特殊能力","",["ENERGIZE::ALL:"],[],1),
         "506951":new TransformSkillDefine(506951,"灵初界皇赋能技","赋予一只精灵特殊能力","",["ENERGIZE::ALL:"],[],1),
         "506960":new TransformSkillDefine(506960,"灵初伊西多赋能技","赋予一只精灵特殊能力","",["ENERGIZE::ALL:"],[],1),
         "506909":new TransformSkillDefine(506909,"灵初王修转化技","将一只精灵变为神暗","增强全阵神暗精灵伤害与减伤",["ARR_RACE_TYPE:24:ALL:"],["24::RaceTypeEffected:24@10024"],0),
         "506917":new TransformSkillDefine(506917,"灵初暗记忆赋能技","赋予一只精灵特殊能力","",["ENERGIZE::ALL:"],[],1),
         "506919":new TransformSkillDefine(506919,"灵初冥皇赋能技","赋予一只精灵特殊能力","",["ENERGIZE::ALL:"],[],1),
         "507006":new TransformSkillDefine(507006,"灵初王者以撒转化技","将一只精灵变为神灵","增强全阵神灵精灵伤害与减伤",["ARR_RACE_TYPE:26:ALL:"],["26::RaceTypeEffected:26@10026"],0),
         "507011":new TransformSkillDefine(507011,"灵初玄皇赋能技","赋予一只精灵特殊能力","",["ENERGIZE::ALL:"],[],1),
         "507096":new TransformSkillDefine(507096,"灵初奈非赋能技","赋予一只精灵特殊能力","",["ENERGIZE::ALL:"],[],1),
         "507148":new TransformSkillDefine(507148,"灵初王炎转化技","将一只精灵变为神火","增强全阵神火精灵伤害与减伤",["ARR_RACE_TYPE:23:ALL:"],["23::RaceTypeEffected:23@10023"],0),
         "507417":new TransformSkillDefine(507417,"灵初王梦赋能技","赋予一只精灵特殊能力","",["ENERGIZE::ALL:"],[],1),
         "507424":new TransformSkillDefine(507424,"灵初界皇赋能技","赋予一只精灵特殊能力","",["ENERGIZE::ALL:"],[],1),
         "507421":new TransformSkillDefine(507421,"灵初元皇赋能技","赋予一只精灵特殊能力","",["ENERGIZE::ALL:"],[],1),
         "507432":new TransformSkillDefine(507432,"灵初暗记忆赋能技","赋予一只精灵特殊能力","",["ENERGIZE::ALL:"],[],1),
         "507390":new TransformSkillDefine(507390,"灵初亚咪幻元技","将自身变换属性","",["SELF_RACE_TYPE:21:SELF:","SELF_RACE_TYPE:22:SELF:","SELF_RACE_TYPE:23:SELF:","SELF_RACE_TYPE:24:SELF:","SELF_RACE_TYPE:25:SELF:","SELF_RACE_TYPE:28:SELF:"],[],2),
         "507395":new TransformSkillDefine(507395,"灵初白起转化技","将一只精灵变为神光","增强全阵神光精灵伤害与减伤",["ARR_RACE_TYPE:25:ALL:"],["25::RaceTypeEffected:25@10025"],0),
         "507396":new TransformSkillDefine(507396,"灵初元素极转化技","将一只精灵变为神无极","增强全阵神无极精灵",["ARR_RACE_TYPE:27:ALL:"],["27::RaceTypeEffected:27@10027"],0),
         "507447":new TransformSkillDefine(507447,"灵初钻石诺雅幻元技","将自身变换属性","",["SELF_RACE_TYPE:24:SELF:","SELF_RACE_TYPE:26:SELF:"],[],2),
         "507471":new TransformSkillDefine(507471,"灵初黑金诺雅幻元技","将自身变换属性","",["SELF_RACE_TYPE:24:SELF:","SELF_RACE_TYPE:26:SELF:"],[],2),
         "507495":new TransformSkillDefine(507495,"灵初启转换技","将一只精灵变为神光","增强全阵神光精灵伤害与减伤",["ARR_RACE_TYPE:25:ALL:"],["25::RaceTypeEffected:25@10025"],0),
         "507516":new TransformSkillDefine(507516,"灵初乾坤转化技","将一只精灵变为神灵","增强全阵神灵精灵伤害与减伤",["ARR_RACE_TYPE:26:ALL:"],["26::RaceTypeEffected:26@10026"],0),
         "507394":new TransformSkillDefine(507394,"灵初亚咪幻元技","将自身变换属性","",["SELF_RACE_TYPE:21:SELF:","SELF_RACE_TYPE:22:SELF:","SELF_RACE_TYPE:23:SELF:","SELF_RACE_TYPE:24:SELF:","SELF_RACE_TYPE:25:SELF:","SELF_RACE_TYPE:27:SELF:","SELF_RACE_TYPE:28:SELF:"],[],2),
         "507517":new TransformSkillDefine(507517,"灵初王诺转换技","将一只精灵变为神光","增强全阵神光精灵伤害与减伤",["ARR_RACE_TYPE:25:ALL:"],["25::RaceTypeEffected:25@10025"],0),
         "507549":new TransformSkillDefine(507549,"灵初路西法转化技","将一只精灵变为神火","增强全阵神火精灵伤害与减伤",["ARR_RACE_TYPE:23:ALL:"],["23::RaceTypeEffected:23@10023"],0),
         "507552":new TransformSkillDefine(507552,"灵初钻石昆吾幻元技","将自身变换属性","",["SELF_RACE_TYPE:21:SELF:","SELF_RACE_TYPE:22:SELF:"],[],2),
         "507560":new TransformSkillDefine(507560,"灵初黑金昆吾幻元技","将自身变换属性","",["SELF_RACE_TYPE:21:SELF:","SELF_RACE_TYPE:22:SELF:"],[],2)
      };
      
      private static const EFFECT:Object = {
         "ARR_RACE_TYPE":new TransformAttriuteEffect(),
         "ENERGIZE":new TransformEnergizeEffect(),
         "SELF_RACE_TYPE":new TransformSelfAttributeEffect()
      };
      
      private static const TARGET:Object = {
         "ALL":targetAll,
         "RaceTypeEffected":targetAttr
      };
      
      public function TransformSkillConfig()
      {
         super();
      }
      
      public static function attrEqual(param1:int, param2:int) : Boolean
      {
         if(param1 < 0 || param2 < 0)
         {
            return false;
         }
         return param1 % 10000 == param2 % 10000;
      }
      
      public static function getTransformSkillDefine(param1:int) : TransformSkillDefine
      {
         return DATA[param1];
      }
      
      public static function effect(param1:Object) : FormationBase
      {
         var _loc2_:FormationBase = null;
         if(param1 is FormationBase)
         {
            _loc2_ = param1 as FormationBase;
         }
         else
         {
            _loc2_ = FormationBase.create(param1);
         }
         reset(_loc2_);
         if(_loc2_.canSelfTransformSkillEffect)
         {
            skillEffects(_loc2_,_loc2_.selfTransformSkillInfo);
         }
         if(_loc2_.canTransformSkillEffect)
         {
            skillEffects(_loc2_,_loc2_.transformSkillInfo);
         }
         return _loc2_;
      }
      
      public static function reset(param1:Object) : FormationBase
      {
         var _loc2_:FormationBase = null;
         if(param1 is FormationBase)
         {
            _loc2_ = param1 as FormationBase;
         }
         else
         {
            _loc2_ = FormationBase.create(param1);
         }
         skillResets(_loc2_,_loc2_.selfTransformSkillInfo);
         skillResets(_loc2_,_loc2_.transformSkillInfo);
         return _loc2_;
      }
      
      private static function skillEffects(param1:FormationBase, param2:ITransformSkillInfo) : FormationBase
      {
         var petId:int = 0;
         var effectArr:Array = null;
         var define:TransformSkillDefine = null;
         var formation:FormationBase = param1;
         var transformSkillInfo:ITransformSkillInfo = param2;
         var psArray:Array = formation.getPetSeries();
         var i:int = 0;
         while(i < psArray.length)
         {
            petId = int(psArray[i]);
            if(petId > 0)
            {
               effectArr = transformSkillInfo.getTransformEffect(petId);
               if(effectArr != null)
               {
                  define = getTransformSkillDefine(transformSkillInfo.transformSkill);
                  if(define == null)
                  {
                     throw new Error("Can not find TransformSkillDefine, id: " + transformSkillInfo.transformSkill);
                  }
                  effectArr.forEach(function(... rest):void
                  {
                     var _loc2_:int = int(rest[0]);
                     var _loc3_:String = define.getEffectType(_loc2_);
                     var _loc4_:ITransformEffect = EFFECT[_loc3_];
                     _loc4_.effect(define,formation,petId,_loc2_);
                  });
               }
            }
            i++;
         }
         return formation;
      }
      
      public static function skillResets(param1:FormationBase, param2:ITransformSkillInfo) : FormationBase
      {
         var resetFunc:Array;
         var define:TransformSkillDefine;
         var i:int;
         var effectType:String = null;
         var formation:FormationBase = param1;
         var transformSkillInfo:ITransformSkillInfo = param2;
         if(transformSkillInfo == null)
         {
            return formation;
         }
         resetFunc = [];
         define = getTransformSkillDefine(transformSkillInfo.transformSkill);
         if(define == null)
         {
            return formation;
         }
         i = 0;
         while(i < define.effectCnt)
         {
            effectType = define.getEffectType(i);
            if(resetFunc.indexOf(effectType) < 0)
            {
               resetFunc.push(effectType);
            }
            i++;
         }
         resetFunc.forEach(function(... rest):void
         {
            var _loc2_:ITransformEffect = EFFECT[rest[0]];
            _loc2_.resetAll(formation);
         });
         return formation;
      }
      
      public static function targetSelector(param1:int, param2:int, ... rest) : Boolean
      {
         var _loc4_:TransformSkillDefine = getTransformSkillDefine(param1);
         var _loc5_:Function = TARGET[_loc4_.getSeletor(param2)];
         return _loc5_.apply(null,[_loc4_,_loc4_.getSeletorParam(param2)].concat(rest));
      }
      
      public static function autoEffectTargetSelector(param1:int, param2:int, ... rest) : Boolean
      {
         var _loc4_:TransformSkillDefine = getTransformSkillDefine(param1);
         if(!_loc4_.hasAutoEffect)
         {
            return false;
         }
         var _loc5_:Function = TARGET[_loc4_.getAutoEffectSelector(param2)];
         return _loc5_.apply(null,[_loc4_,_loc4_.getAutoEffectSelectorParams(param2)].concat(rest));
      }
      
      private static function targetAll(param1:TransformSkillDefine, param2:String, ... rest) : Boolean
      {
         return true;
      }
      
      private static function targetAttr(param1:TransformSkillDefine, param2:String, ... rest) : Boolean
      {
         var _loc4_:int = int(rest[0]);
         var _loc5_:FormationBase = rest[1];
         var _loc6_:Array = param2.split("@");
         return _loc6_.indexOf(String(_loc5_.getAttr(_loc4_))) >= 0;
      }
   }
}

