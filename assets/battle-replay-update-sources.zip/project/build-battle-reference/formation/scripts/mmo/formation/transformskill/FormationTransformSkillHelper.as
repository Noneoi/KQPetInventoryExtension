package mmo.formation.transformskill
{
   import flash.display.InteractiveObject;
   import flash.display.MovieClip;
   import flash.display.Sprite;
   import mmo.common.DisplayUtil;
   import mmo.common.utils.tips.TipsManager;
   import mmo.interfaces.ServiceContainer;
   import mmo.interfaces.battleconfig.IBattleConfig;
   import mmo.interfaces.battleconfig.define.SkillDefine;
   import mmo.interfaces.formation.FormationBase;
   import mmo.interfaces.formation.FormationPetInfo;
   import mmo.interfaces.formation.ITransformSkillDefine;
   import mmo.interfaces.formation.TransformSkillType;
   import mmo.interfaces.interacthelper.IInteractHelper;
   
   public class FormationTransformSkillHelper
   {
      
      private static var battleConfig:IBattleConfig = null;
      
      public function FormationTransformSkillHelper()
      {
         super();
      }
      
      public static function setTransformSkillIcon(param1:InteractiveObject, param2:int, param3:int, param4:FormationBase, param5:int = -1, param6:Boolean = true) : Boolean
      {
         var _loc9_:IInteractHelper = null;
         var _loc10_:ITransformSkillDefine = null;
         var _loc7_:Boolean = false;
         var _loc8_:Array = [];
         param1.visible = param2 > 0 && param3 > 0;
         if(param1.visible)
         {
            _loc9_ = ServiceContainer.getService(IInteractHelper);
            _loc9_.clearFiltersWithTips(param1);
            if(!param4.canTransformSkillEffect && param5 <= 0 || Boolean(param4.canTransformSkillEffect) && param4.transformSkillInfo.transformer > 0 && param4.transformSkillInfo.transformer != param2 || Boolean(param4.canTransformSkillEffect) && param4.transformSkillInfo.transformer <= 0 && param3 != param5)
            {
               DisplayUtil.applyGray(param1);
               addTransformTips(param3,param1,_loc8_,param6);
            }
            else if(Boolean(param4.canTransformSkillEffect) && param4.transformSkillInfo.transformer > 0)
            {
               if(param4.transformSkillInfo.transformer == param2)
               {
                  _loc10_ = TransformSkillConfig.getTransformSkillDefine(param4.transformSkill);
                  _loc8_ = param4.transformSkillInfo.getAllEffectIndexs();
                  if(_loc10_.hasAutoEffect)
                  {
                     _loc8_.push(_loc10_.effectCnt);
                  }
                  addTransformTips(param4.transformSkill,param1,_loc8_,param6);
                  _loc7_ = true;
               }
            }
            else if(param3 == param5)
            {
               _loc10_ = TransformSkillConfig.getTransformSkillDefine(param5);
               if(_loc10_.hasAutoEffect)
               {
                  _loc8_.push(_loc10_.effectCnt);
               }
               addTransformTips(param3,param1,_loc8_,param6);
               _loc7_ = true;
            }
         }
         return _loc7_;
      }
      
      public static function addTransformTips(param1:int, param2:InteractiveObject, param3:Array, param4:Boolean) : void
      {
         var transformSkillId:int = param1;
         var target:InteractiveObject = param2;
         var effectArr:Array = param3;
         var canOperate:Boolean = param4;
         var addTipsByBattleConfig:Function = function():void
         {
            if(target == null)
            {
               return;
            }
            TipsManager.getInstance().removeTips(target);
            var _loc1_:SkillDefine = battleConfig.getSkillDefineById(transformSkillId);
            var _loc2_:TransformSkillDefine = TransformSkillConfig.getTransformSkillDefine(transformSkillId);
            var _loc3_:String = canOperate ? "<font color=\'#00FFFF\'>点击使用" + _loc2_.skillType.desc + "效果</font>" : "<font color=\'#00FFFF\'>" + _loc1_.name + "</font>";
            var _loc4_:String = "";
            var _loc5_:String = "";
            var _loc6_:Array = _loc1_.description.replace("<br>","\n").split("\n");
            var _loc7_:int = 0;
            while(_loc7_ < _loc6_.length)
            {
               _loc5_ += "\n" + _loc6_[_loc7_];
               if(effectArr.indexOf(_loc7_) >= 0)
               {
                  _loc5_ += "（已使用）";
               }
               else
               {
                  _loc5_ += "<font color=\'#FF0000\'>（未使用）</font>";
               }
               _loc7_++;
            }
            _loc4_ = _loc4_.concat(_loc2_.skillType == TransformSkillType.ENERGIZE_SKILL ? _loc5_.substr(1) : "技能效果：" + _loc5_);
            TipsManager.getInstance().addComplexTipsByRes(target,_loc3_,_loc4_,"mmo.stargod.CommonTips_res");
         };
         if(battleConfig == null)
         {
            ServiceContainer.tryGetService(IBattleConfig,function(param1:IBattleConfig, param2:Object):void
            {
               battleConfig = param1;
               addTipsByBattleConfig();
            });
         }
         else
         {
            addTipsByBattleConfig();
         }
      }
      
      public static function getDefaultTransformSkillId(param1:FormationBase, param2:Array = null) : int
      {
         var _loc4_:FormationPetInfo = null;
         var _loc7_:Array = null;
         var _loc8_:int = 0;
         var _loc9_:int = 0;
         var _loc3_:int = -1;
         var _loc5_:Array = [];
         if(param2 != null)
         {
            _loc7_ = param1.getPetSeries();
            _loc8_ = 0;
            while(_loc8_ < _loc7_.length)
            {
               _loc9_ = int(_loc7_[_loc8_]);
               if(_loc9_ > 0 && (_loc4_ = FormationBase.parse2FormationPetInfo(FormationBase.getPetFromArray(_loc9_,param2))) != null)
               {
                  _loc5_.push(_loc4_);
               }
               _loc8_++;
            }
         }
         else
         {
            _loc5_ = param1.getFormationPetArray(true);
         }
         var _loc6_:int = 0;
         while(_loc6_ < _loc5_.length)
         {
            _loc4_ = _loc5_[_loc6_];
            if(_loc4_.transformSkill > 0 && !TransformSkillConfig.getTransformSkillDefine(_loc4_.transformSkill).skillType.selfEffective)
            {
               _loc3_ = int(_loc4_.transformSkill);
               break;
            }
            _loc6_++;
         }
         return _loc3_;
      }
      
      public static function petIsAutoEffect(param1:int, param2:FormationBase, param3:int = 0) : Boolean
      {
         var _loc4_:int = param2.transformSkill > 0 ? int(param2.transformSkill) : getDefaultTransformSkillId(param2);
         if(_loc4_ <= 0)
         {
            return false;
         }
         return isAutoEffect(TransformSkillConfig.getTransformSkillDefine(_loc4_),param1,param2,param3);
      }
      
      public static function setAutoEffectIcon(param1:Sprite, param2:FormationBase) : void
      {
         var _loc5_:int = 0;
         var _loc6_:TransformSkillDefine = null;
         var _loc7_:int = 0;
         var _loc8_:int = 0;
         var _loc3_:Array = param2.getPetSeries();
         var _loc4_:int = param2.transformSkill > 0 ? int(param2.transformSkill) : getDefaultTransformSkillId(param2);
         if(_loc4_ <= 0)
         {
            _loc5_ = 0;
            while(_loc5_ < _loc3_.length)
            {
               setRes(param1["s" + _loc5_],false);
               _loc5_++;
            }
         }
         else
         {
            _loc6_ = TransformSkillConfig.getTransformSkillDefine(_loc4_);
            _loc7_ = 0;
            _loc8_ = 0;
            while(_loc8_ < _loc3_.length)
            {
               if(_loc3_[_loc8_] < 0 || !isAutoEffect(_loc6_,_loc3_[_loc8_],param2,_loc7_))
               {
                  setRes(param1["s" + _loc8_],false);
               }
               else
               {
                  setRes(param1["s" + _loc8_],true);
               }
               _loc8_++;
            }
         }
      }
      
      private static function setRes(param1:MovieClip, param2:Boolean) : void
      {
         if(param1)
         {
            param1.gotoAndStop(1);
            param1.visible = param2;
         }
      }
      
      public static function isAutoEffect(param1:TransformSkillDefine, param2:int, param3:FormationBase, param4:int = 0) : Boolean
      {
         return TransformSkillConfig.autoEffectTargetSelector(param1.id,param4,param2,param3);
      }
   }
}

