package mmo.interfaces.pettitle
{
   import com.adobe.utils.StringUtil;
   
   public class PetTitleData
   {
      
      private var _raceId:int;
      
      private var _titleIdMap:Object = {};
      
      public function PetTitleData()
      {
         super();
      }
      
      public static function parse(param1:Object) : PetTitleData
      {
         var data:PetTitleData = null;
         var petTitleArr:Array = null;
         var params:Object = param1;
         data = new PetTitleData();
         if(params["title"] is Array)
         {
            petTitleArr = params["title"];
         }
         else
         {
            petTitleArr = [params["title"]];
         }
         petTitleArr.forEach(function(param1:Object, ... rest):*
         {
            var _loc3_:int = int(param1["titleId"]);
            data._titleIdMap[_loc3_] = param1;
         });
         return data;
      }
      
      public function get firstTitleId() : int
      {
         return this.getTitleIds()[0];
      }
      
      public function getTitleIds() : Array
      {
         var _loc2_:* = undefined;
         var _loc1_:Array = [];
         for(_loc2_ in this._titleIdMap)
         {
            _loc1_.push(int(_loc2_));
         }
         return _loc1_;
      }
      
      public function get raceId() : int
      {
         return this._raceId;
      }
      
      public function getValues(param1:int = 0) : Array
      {
         var _loc3_:int = 0;
         var _loc2_:String = "";
         if(param1 == 0)
         {
            _loc3_ = int(this.getTitleIds()[0]);
            _loc2_ = this._titleIdMap[_loc3_]["content"];
         }
         else
         {
            _loc2_ = this._titleIdMap[param1]["content"];
         }
         return StringUtil.split2IntegerArray(_loc2_);
      }
      
      public function getExtIds(param1:int = 0) : Array
      {
         var _loc3_:int = 0;
         var _loc2_:Array = [];
         if(param1 == 0)
         {
            _loc3_ = int(this.getTitleIds()[0]);
            _loc2_ = this._titleIdMap[_loc3_]["extId"];
         }
         else
         {
            _loc2_ = this._titleIdMap[param1]["extId"];
         }
         if(Boolean(_loc2_) && _loc2_.length > 0)
         {
            return _loc2_.concat();
         }
         return [];
      }
   }
}

