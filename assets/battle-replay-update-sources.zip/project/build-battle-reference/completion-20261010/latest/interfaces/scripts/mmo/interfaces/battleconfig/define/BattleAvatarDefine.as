package mmo.interfaces.battleconfig.define
{
   public class BattleAvatarDefine
   {
      
      private var _Id:int;
      
      private var _registerPointX:int;
      
      private var _registerPointY:int;
      
      private var _topY:int;
      
      private var _centerY:int;
      
      private var _buttomY:int;
      
      private var _frontX:int;
      
      private var _centerX:int;
      
      private var _backX:int;
      
      private var _skillScale:Number;
      
      private var _bufferScale:Number;
      
      private var _addBlood:int;
      
      private var _offsetBloodY:Number;
      
      public function BattleAvatarDefine()
      {
         super();
      }
      
      public static function parseDefine(param1:XML) : BattleAvatarDefine
      {
         var _loc2_:BattleAvatarDefine = new BattleAvatarDefine();
         _loc2_._Id = param1.@id;
         _loc2_._registerPointX = param1.@register_point_x;
         _loc2_._registerPointY = param1.@register_point_y;
         _loc2_._topY = param1.@top_y;
         _loc2_._centerY = param1.@center_y;
         _loc2_._buttomY = param1.@buttom_y;
         _loc2_._frontX = param1.@front_x;
         _loc2_._centerX = param1.@center_x;
         _loc2_._backX = param1.@back_x;
         _loc2_._skillScale = param1.@skill_scale;
         _loc2_._bufferScale = param1.@buffer_scale;
         _loc2_._addBlood = int(param1.@addBlood);
         _loc2_._offsetBloodY = param1.@offsetBloodY == null ? 0 : Number(param1.@offsetBloodY);
         return _loc2_;
      }
      
      public function get Id() : int
      {
         return this._Id;
      }
      
      public function get registerPointX() : int
      {
         return this._registerPointX;
      }
      
      public function get registerPointY() : int
      {
         return this._registerPointY;
      }
      
      public function get topY() : int
      {
         return this._topY;
      }
      
      public function get centerY() : int
      {
         return this._centerY;
      }
      
      public function get buttomY() : int
      {
         return this._buttomY;
      }
      
      public function get frontX() : int
      {
         return this._frontX;
      }
      
      public function get centerX() : int
      {
         return this._centerX;
      }
      
      public function get backX() : int
      {
         return this._backX;
      }
      
      public function get skillScale() : Number
      {
         return this._skillScale;
      }
      
      public function get bufferScale() : Number
      {
         return this._bufferScale;
      }
      
      public function get addBlood() : int
      {
         return this._addBlood;
      }
      
      public function get offsetBloodY() : Number
      {
         return this._offsetBloodY;
      }
   }
}

