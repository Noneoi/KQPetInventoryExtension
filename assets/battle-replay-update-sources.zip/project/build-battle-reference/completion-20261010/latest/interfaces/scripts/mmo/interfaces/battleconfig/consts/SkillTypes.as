package mmo.interfaces.battleconfig.consts
{
   public class SkillTypes
   {
      
      public static const ID2CN:Array = ["近身","远程","物攻","魔攻","超杀技","伤害","恢复","召唤技","超必杀技","超物攻","超魔攻"];
      
      public static const CLOSE:int = 0;
      
      public static const REMOTE:int = 1;
      
      public static const PHYSICS:int = 2;
      
      public static const MAGIC:int = 3;
      
      public static const UNIQUE:int = 4;
      
      public static const DAMAGE:int = 5;
      
      public static const HEAL:int = 6;
      
      public static const SUMMON:int = 7;
      
      public static const SUPER_UNIQUE:int = 8;
      
      public static const SUPER_PHY:int = 9;
      
      public static const SUPER_MAGIC:int = 10;
      
      public function SkillTypes()
      {
         super();
      }
   }
}

