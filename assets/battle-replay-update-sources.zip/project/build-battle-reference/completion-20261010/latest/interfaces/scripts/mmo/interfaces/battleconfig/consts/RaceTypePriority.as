package mmo.interfaces.battleconfig.consts
{
   public class RaceTypePriority
   {
      
      public static const NORMAL:int = 1;
      
      public static const GOD:int = 2;
      
      public static const TRANSFORM:int = 3;
      
      public function RaceTypePriority()
      {
         super();
      }
   }
}

