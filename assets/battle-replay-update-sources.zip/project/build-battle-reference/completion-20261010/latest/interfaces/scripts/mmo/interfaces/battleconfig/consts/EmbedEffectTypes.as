package mmo.interfaces.battleconfig.consts
{
   public class EmbedEffectTypes
   {
      
      public static const MOVIE:int = 0;
      
      public static const NPC_DIALOG:int = 1;
      
      public static const CODE:int = 2;
      
      public function EmbedEffectTypes()
      {
         super();
      }
   }
}

