package mmo.interfaces.battleconfig.define
{
   public class HuanSkillDefine
   {
      
      public static const T_ZDL:int = 1;
      
      private var _id:int;
      
      private var _name:String;
      
      private var _typeToTakeEffect:int;
      
      private var _valueToTakeEffect:int;
      
      private var _tip:String;
      
      private var _icon:int;
      
      public function HuanSkillDefine()
      {
         super();
      }
      
      public static function parseDefine(param1:XML) : HuanSkillDefine
      {
         var _loc2_:HuanSkillDefine = new HuanSkillDefine();
         _loc2_._id = parseInt(param1.@id);
         _loc2_._name = String(param1.@name);
         _loc2_._typeToTakeEffect = parseInt(param1.@ttte);
         _loc2_._valueToTakeEffect = parseInt(param1.@vtte);
         _loc2_._tip = String(param1.@tip);
         _loc2_._icon = parseInt(param1.@icon);
         return _loc2_;
      }
      
      public function get id() : int
      {
         return this._id;
      }
      
      public function get name() : String
      {
         return this._name;
      }
      
      public function get tip() : String
      {
         return this._tip;
      }
      
      public function get icon() : int
      {
         return this._icon;
      }
      
      public function get typeToTakeEffect() : int
      {
         return this._typeToTakeEffect;
      }
      
      public function get typeIsZdl() : Boolean
      {
         return this.typeToTakeEffect == T_ZDL;
      }
      
      public function get valueToTakeEffect() : int
      {
         return this._valueToTakeEffect;
      }
   }
}

