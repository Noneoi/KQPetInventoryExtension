package mmo.interfaces.battleconfig.define
{
   import mmo.interfaces.battleconfig.consts.JobType;
   
   public class JobTypeDefine
   {
      
      private var _nId:int;
      
      private var _sName:String;
      
      private var _nJobIndex:int;
      
      private var _arrAttackDamageCoeffiicient:Array;
      
      private var _nJobType:int;
      
      private var _isSuperJob:Boolean;
      
      public function JobTypeDefine()
      {
         super();
      }
      
      public static function parseDefine(param1:XML, param2:int) : JobTypeDefine
      {
         var _loc6_:Number = NaN;
         var _loc3_:JobTypeDefine = new JobTypeDefine();
         _loc3_._nId = param1.@id;
         _loc3_._sName = param1.@nm;
         _loc3_._nJobType = param1.@jobType;
         _loc3_._nJobIndex = param2;
         _loc3_._arrAttackDamageCoeffiicient = [];
         var _loc4_:Array = String(param1.@jcs).split(",");
         var _loc5_:int = 0;
         while(_loc5_ < _loc4_.length)
         {
            _loc6_ = Number(_loc4_[_loc5_]);
            _loc3_._arrAttackDamageCoeffiicient.push(_loc6_);
            _loc5_++;
         }
         return _loc3_;
      }
      
      public function get id() : int
      {
         return this._nId;
      }
      
      public function get name() : String
      {
         return this._sName;
      }
      
      public function get jobIndex() : int
      {
         return this._nJobIndex;
      }
      
      public function get jobType() : int
      {
         return this._nJobType;
      }
      
      public function get isSuperJob() : Boolean
      {
         return this._nJobType == JobType.SUPER_JOB;
      }
      
      public function attackDamageCoeffiicients() : Array
      {
         return this._arrAttackDamageCoeffiicient;
      }
      
      public function getAttackDamageCoeffiicientByJobIndex(param1:int) : Number
      {
         return this._arrAttackDamageCoeffiicient[param1];
      }
      
      public function getAttackDamageCoeffiicientByJobDefine(param1:JobTypeDefine) : Number
      {
         return this.getAttackDamageCoeffiicientByJobIndex(param1.jobIndex);
      }
   }
}

