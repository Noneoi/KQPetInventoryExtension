package mmo.interfaces.battleconfig.define
{
   import mmo.interfaces.battleconfig.consts.SkillTypes;
   
   public class SkillDefine
   {
      
      private var _nId:int;
      
      private var _nSwfId:int;
      
      private var _sName:String;
      
      private var _sDescription:String;
      
      private var _nActionFrame:int;
      
      private var _nPos:int = 5;
      
      private var _nType:int;
      
      private var _nType2:int;
      
      private var _nJumpFrame:int = -1;
      
      private var _nEffectFrame:int = -1;
      
      private var _bShockScreen:Boolean = false;
      
      private var _bBlackScreen:Boolean = false;
      
      private var _isBossSkill:Boolean = false;
      
      private var _isHideOtherAvatar:Boolean = false;
      
      private var _hasLastEffect:Boolean = false;
      
      private var _isCentral:Boolean = false;
      
      private var _bFullEffect:Boolean = false;
      
      private var _playOrderType:int;
      
      private var _functionalType:String;
      
      private var _isSpine:Boolean = false;
      
      public function SkillDefine()
      {
         super();
      }
      
      public static function parseDefine(param1:XML, param2:SkillDescDefine) : SkillDefine
      {
         var _loc3_:SkillDefine = new SkillDefine();
         _loc3_._nId = int(param1.@id);
         _loc3_._sName = param2.name;
         _loc3_._sDescription = param2.description;
         _loc3_._functionalType = param2.functionalType;
         if(param1.@ef != undefined)
         {
            _loc3_._bFullEffect = int(param1.@ef) == 1;
         }
         if(param1.@swf == undefined)
         {
            _loc3_._nSwfId = _loc3_._nId;
         }
         else
         {
            _loc3_._nSwfId = int(param1.@swf);
         }
         _loc3_._nActionFrame = int(param1.@action);
         if(_loc3_._nActionFrame == 0)
         {
            throw new Error("Normal actionFrame>0 ,but now unexpected actionFrame:" + _loc3_._nActionFrame + " in skill-config, id=" + _loc3_._nId);
         }
         _loc3_._nPos = int(param1.@pos);
         if(_loc3_._nPos < 1 || _loc3_._nPos > 10)
         {
            throw new Error("Normal pos is [1-9],but now unexpected pos:" + _loc3_._nPos + " in skill-config, id=" + _loc3_._nId);
         }
         _loc3_._nType = SkillTypes.ID2CN.indexOf(param2.attackType);
         if(_loc3_._nType == SkillTypes.CLOSE)
         {
            _loc3_._nJumpFrame = param1.@jump;
         }
         _loc3_._nType2 = getSkillType2ByDesc(param2);
         _loc3_._nEffectFrame = param1.@effect;
         if(_loc3_._nEffectFrame == 0 && int(param1.@spine) != 1)
         {
            throw new Error("Normal effectFrame>0 ,but now unexpected effectFrame:" + _loc3_._nEffectFrame + " in skill-config, id=" + _loc3_._nId);
         }
         if(_loc3_._nEffectFrame == _loc3_._nJumpFrame)
         {
            throw new Error("can\'t be effectFrame==jumpFrame!Illegal override jump frame on skill-config, id=" + _loc3_._nId);
         }
         _loc3_._bShockScreen = int(param1.@shock) == 1;
         _loc3_._bBlackScreen = int(param1.@black) == 1;
         _loc3_._isBossSkill = param2.isBossSkill;
         _loc3_._isHideOtherAvatar = int(param1.@hideother) == 1;
         _loc3_._hasLastEffect = int(param1.@last) == 1;
         _loc3_._isCentral = int(param1.@central) == 1;
         _loc3_._playOrderType = int(param1.@playOrderType);
         _loc3_._isSpine = int(param1.@spine) == 1;
         return _loc3_;
      }
      
      public static function copyDefine(param1:*, param2:SkillDefine, param3:SkillDescDefine) : SkillDefine
      {
         var _loc4_:SkillDefine = new SkillDefine();
         _loc4_._nId = param1;
         _loc4_._sName = param3.name;
         _loc4_._sDescription = param3.description;
         _loc4_._functionalType = param3.functionalType;
         _loc4_._bFullEffect = param2._bFullEffect;
         _loc4_._nSwfId = param2._nSwfId;
         _loc4_._nActionFrame = param2._nActionFrame;
         _loc4_._nPos = param2._nPos;
         _loc4_._nType = param2._nType;
         _loc4_._nJumpFrame = param2._nJumpFrame;
         _loc4_._nType2 = param2._nType2;
         _loc4_._nEffectFrame = param2._nEffectFrame;
         _loc4_._bShockScreen = param2._bShockScreen;
         _loc4_._bBlackScreen = param2._bBlackScreen;
         _loc4_._isBossSkill = param2._isBossSkill;
         _loc4_._isHideOtherAvatar = param2._isHideOtherAvatar;
         _loc4_._hasLastEffect = param2._hasLastEffect;
         _loc4_._isCentral = param2._isCentral;
         _loc4_._playOrderType = param2._playOrderType;
         _loc4_._isSpine = param2._isSpine;
         return _loc4_;
      }
      
      private static function getSkillType2ByDesc(param1:SkillDescDefine) : int
      {
         var _loc2_:int = SkillTypes.ID2CN.indexOf(param1.skillBaseType);
         if(_loc2_ == SkillTypes.SUMMON || _loc2_ == SkillTypes.SUPER_UNIQUE || _loc2_ == SkillTypes.UNIQUE)
         {
            return _loc2_;
         }
         return SkillTypes.ID2CN.indexOf(param1.skillType);
      }
      
      public static function wrapDescOnly(param1:SkillDescDefine) : SkillDefine
      {
         var _loc2_:SkillDefine = new SkillDefine();
         _loc2_._nId = param1.id;
         _loc2_._sName = param1.name;
         _loc2_._sDescription = param1.description;
         _loc2_._isBossSkill = param1.isBossSkill;
         return _loc2_;
      }
      
      public static function checkSkillDefineAvailableInBattle(param1:SkillDefine) : Boolean
      {
         if(param1.actionFrame > 0 && param1.pos > 0 && (param1.effectFrame > 0 || param1.isSpine))
         {
            return true;
         }
         return false;
      }
      
      public static function checkIsAutoChessSkillId(param1:int) : Boolean
      {
         var _loc2_:String = param1.toString();
         if(_loc2_.length != 7)
         {
            return false;
         }
         var _loc3_:int = int(_loc2_.substr(0,1));
         var _loc4_:int = int(_loc2_.substr(1,1));
         if((_loc3_ == 1 || _loc3_ == 2) && (_loc4_ == 1 || _loc4_ == 2 || _loc4_ == 3))
         {
            return true;
         }
         return false;
      }
      
      public static function getOrigSkillId(param1:int) : int
      {
         if(!checkIsAutoChessSkillId(param1))
         {
            return param1;
         }
         var _loc2_:int = int(param1 / (100 * 10000));
         var _loc3_:int = param1 % 100000;
         return int(_loc2_ * (10 * 10000) + _loc3_);
      }
      
      public static function getRaceIdBySkillId(param1:int) : int
      {
         if(checkIsAutoChessSkillId(param1))
         {
            return param1 % 10000;
         }
         return int(param1.toString().substr(0,6)) % 10000;
      }
      
      public function get playOrderType() : int
      {
         return this._playOrderType;
      }
      
      public function get id() : int
      {
         return this._nId;
      }
      
      public function get swfId() : int
      {
         return this._nSwfId;
      }
      
      public function get name() : String
      {
         return this._sName;
      }
      
      public function get description() : String
      {
         return this._sDescription;
      }
      
      public function get actionFrame() : int
      {
         return this._nActionFrame;
      }
      
      public function get pos() : int
      {
         return this._nPos;
      }
      
      public function get isFullSceneEffect() : Boolean
      {
         return this._bFullEffect;
      }
      
      public function get type() : int
      {
         return this._nType;
      }
      
      public function get type2() : int
      {
         return this._nType2;
      }
      
      public function get jumpFrame() : int
      {
         return this._nJumpFrame;
      }
      
      public function get effectFrame() : int
      {
         return this._nEffectFrame;
      }
      
      public function get shockScreen() : Boolean
      {
         return this._bShockScreen;
      }
      
      public function get blackScreen() : Boolean
      {
         return this._bBlackScreen;
      }
      
      public function get isBossSkill() : Boolean
      {
         return this._isBossSkill;
      }
      
      public function get isHideOtherAvatar() : Boolean
      {
         return this._isHideOtherAvatar;
      }
      
      public function get hasLastEffect() : Boolean
      {
         return this._hasLastEffect;
      }
      
      public function get isCentral() : Boolean
      {
         return this._isCentral;
      }
      
      public function get isSpine() : Boolean
      {
         return this._isSpine;
      }
      
      public function get functionalType() : String
      {
         return this._functionalType;
      }
   }
}

