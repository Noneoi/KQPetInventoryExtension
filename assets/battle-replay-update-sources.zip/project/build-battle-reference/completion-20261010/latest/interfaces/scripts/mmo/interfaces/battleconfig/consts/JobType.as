package mmo.interfaces.battleconfig.consts
{
   public class JobType
   {
      
      public static const NORMAL:int = 0;
      
      public static const SUPER_JOB:int = 1;
      
      public static const SUPER_JOB_2:int = 2;
      
      public function JobType()
      {
         super();
      }
   }
}

