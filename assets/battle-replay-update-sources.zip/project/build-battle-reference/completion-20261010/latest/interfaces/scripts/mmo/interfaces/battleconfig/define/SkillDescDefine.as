package mmo.interfaces.battleconfig.define
{
   import mmo.interfaces.ServiceContainer;
   import mmo.interfaces.battleconfig.IBattleConfig;
   
   public class SkillDescDefine
   {
      
      private static var sBattleConfig:IBattleConfig = null;
      
      private var _nId:int;
      
      private var _sName:String;
      
      private var _sDescription:String;
      
      private var _isBossSkill:Boolean;
      
      private var _attackType:String;
      
      private var _skillBaseType:String;
      
      private var _skillType:String;
      
      private var _functionalType:String;
      
      public function SkillDescDefine()
      {
         super();
      }
      
      public static function parseDefine(param1:XML) : SkillDescDefine
      {
         var _loc2_:SkillDescDefine = new SkillDescDefine();
         _loc2_._nId = int(param1.@id);
         _loc2_._isBossSkill = int(param1.@bossSkill) == 1;
         _loc2_._attackType = String(param1.@attackType);
         _loc2_._skillBaseType = String(param1.@skillBaseType);
         _loc2_._skillType = String(param1.@skillType);
         _loc2_._functionalType = String(param1.@ft);
         return _loc2_;
      }
      
      public static function create(param1:int, param2:String, param3:String, param4:int, param5:String, param6:String, param7:String, param8:String) : SkillDescDefine
      {
         var _loc9_:SkillDescDefine = new SkillDescDefine();
         _loc9_._nId = param1;
         _loc9_._isBossSkill = param4 == 1;
         _loc9_._attackType = param5;
         _loc9_._skillBaseType = param6;
         _loc9_._skillType = param7;
         _loc9_._functionalType = param8;
         return _loc9_;
      }
      
      public function get skillType() : String
      {
         return this._skillType;
      }
      
      public function get skillBaseType() : String
      {
         return this._skillBaseType;
      }
      
      public function get attackType() : String
      {
         return this._attackType;
      }
      
      public function get id() : int
      {
         return this._nId;
      }
      
      public function get name() : String
      {
         if(sBattleConfig == null)
         {
            sBattleConfig = ServiceContainer.getService(IBattleConfig);
         }
         return sBattleConfig.getSkillName(this._nId);
      }
      
      public function get description() : String
      {
         if(sBattleConfig == null)
         {
            sBattleConfig = ServiceContainer.getService(IBattleConfig);
         }
         return sBattleConfig.getSkillDesc(this._nId);
      }
      
      public function get isBossSkill() : Boolean
      {
         return this._isBossSkill;
      }
      
      public function get functionalType() : String
      {
         return this._functionalType;
      }
   }
}

