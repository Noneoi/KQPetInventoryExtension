package mmo.interfaces.battleconfig.define
{
   import mmo.interfaces.battleconfig.entry.IBattleEntry;
   
   public class EntryDefine implements IBattleEntry
   {
      
      private var _name:String;
      
      private var _desc:String;
      
      private var _type:int;
      
      public function EntryDefine()
      {
         super();
      }
      
      public static function parseDefine(param1:XML) : EntryDefine
      {
         var _loc2_:EntryDefine = new EntryDefine();
         _loc2_._name = param1.@n;
         _loc2_._desc = param1.@d;
         _loc2_._type = parseInt(param1.@t);
         return _loc2_;
      }
      
      public function get name() : String
      {
         return this._name;
      }
      
      public function get desc() : String
      {
         return this._desc;
      }
      
      public function get type() : int
      {
         return this._type;
      }
   }
}

