package mmo.interfaces.battleconfig.define
{
   public class SkillExecuteDefine
   {
      
      public static const TYPE_NORMAL:int = 1;
      
      public static const TYPE_ATTACK_DISABLE:int = 2;
      
      private var _nExecuteCode:int;
      
      private var _sName:String;
      
      private var _nType:int;
      
      private var _nEffectId:int;
      
      public function SkillExecuteDefine()
      {
         super();
      }
      
      public static function parseDefine(param1:XML) : SkillExecuteDefine
      {
         var _loc2_:SkillExecuteDefine = new SkillExecuteDefine();
         _loc2_._nExecuteCode = param1.@code;
         _loc2_._sName = param1.@nm;
         _loc2_._nType = param1.@type;
         _loc2_._nEffectId = param1.@eid;
         return _loc2_;
      }
      
      public function get code() : int
      {
         return this._nExecuteCode;
      }
      
      public function get name() : String
      {
         return this._sName;
      }
      
      public function get type() : int
      {
         return this._nType;
      }
      
      public function get effectId() : int
      {
         return this._nEffectId;
      }
   }
}

