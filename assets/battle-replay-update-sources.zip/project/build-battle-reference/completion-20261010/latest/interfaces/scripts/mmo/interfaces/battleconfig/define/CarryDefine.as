package mmo.interfaces.battleconfig.define
{
   import mmo.common.utils.petrace.PetRaceUtil;
   
   public class CarryDefine
   {
      
      public static const TYPE_NORMAL:int = 4;
      
      public static const TYPE_ALMIGHTY:int = 8;
      
      public static const TYPE_SWALLOWER:int = 16;
      
      public static const ArrayTypeNames:Array = ["神使","召唤兽","不朽书灵"];
      
      private static const ArrayTypeIds:Array = [TYPE_NORMAL,TYPE_ALMIGHTY,TYPE_SWALLOWER];
      
      private var _carrierRaceId:int;
      
      private var _carriedPetRaceId:int;
      
      private var _battlePowerRate:Number;
      
      private var _skillDescription:String;
      
      private var _gimmick:String;
      
      private var _type:int = -1;
      
      public function CarryDefine()
      {
         super();
      }
      
      public static function getCarryTypeIndex(param1:int) : int
      {
         var _loc2_:int = ArrayTypeIds.indexOf(param1);
         if(_loc2_ < 0)
         {
            return 0;
         }
         return _loc2_;
      }
      
      public static function parseDefines(param1:XML) : Array
      {
         var _loc7_:CarryDefine = null;
         var _loc8_:int = 0;
         var _loc9_:int = 0;
         var _loc2_:Array = [];
         var _loc3_:int = parseInt(String(param1.@c).split("#")[0]);
         var _loc4_:int = parseInt(String(param1.@ced).split("#")[0]);
         var _loc5_:Array = PetRaceUtil.getAllSkinAndPetRaceIds([_loc3_]);
         var _loc6_:Array = PetRaceUtil.getAllSkinAndPetRaceIds([_loc4_]);
         for each(_loc8_ in _loc5_)
         {
            for each(_loc9_ in _loc6_)
            {
               _loc7_ = parseAttributeDefine(param1);
               _loc7_._carrierRaceId = _loc8_;
               _loc7_._carriedPetRaceId = _loc9_;
               _loc7_._type = param1.@type != null ? int(param1.@type) : -1;
               _loc2_.push(_loc7_);
            }
         }
         return _loc2_;
      }
      
      private static function parseAttributeDefine(param1:XML) : CarryDefine
      {
         var _loc2_:CarryDefine = new CarryDefine();
         _loc2_._skillDescription = String(param1.@sdes);
         _loc2_._battlePowerRate = Number(param1.@bpr);
         _loc2_._gimmick = String(param1.@gimmick);
         return _loc2_;
      }
      
      public function get carrierRaceId() : int
      {
         return this._carrierRaceId;
      }
      
      public function get carriedPetRaceId() : int
      {
         return this._carriedPetRaceId;
      }
      
      public function get skillDescription() : String
      {
         return this._skillDescription;
      }
      
      public function get gimmick() : String
      {
         return this._gimmick;
      }
      
      public function get type() : int
      {
         return this._type;
      }
   }
}

