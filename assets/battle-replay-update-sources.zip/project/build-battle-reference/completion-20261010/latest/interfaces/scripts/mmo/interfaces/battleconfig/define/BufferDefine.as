package mmo.interfaces.battleconfig.define
{
   import mmo.common.DateUtil;
   import mmo.interfaces.battle.consts.UserBattleConfig;
   
   public class BufferDefine
   {
      
      private var _nId:int;
      
      private var _nDisplayId:int;
      
      private var _sName:String;
      
      private var _nPosId:int;
      
      private var _bDisplayOnce:Boolean;
      
      private var _bDisableFlip:Boolean;
      
      private var _sUiMessage:String;
      
      private var _bHidden:Boolean;
      
      private var _sBuffEffect:String;
      
      private var _sBuffHarmSource:String;
      
      private var _nBuffWaitType:int;
      
      private var _nBuffWaitEndFrame:int;
      
      private var _bNeed2HidePlayerUi:Boolean;
      
      private var _isSpine:Boolean = false;
      
      public function BufferDefine()
      {
         super();
      }
      
      public static function parseDefine(param1:XML, param2:BufferDescDefine) : BufferDefine
      {
         var _loc3_:BufferDefine = new BufferDefine();
         _loc3_._nId = param1.@id;
         _loc3_._nDisplayId = param1.@did;
         _loc3_._nPosId = param1.@pos;
         _loc3_._bDisplayOnce = int(param1.@once) == 1;
         _loc3_._bDisableFlip = int(param1.@df) == 1;
         _loc3_._bHidden = int(param1.@hd) == 1;
         _loc3_._nBuffWaitType = int(param1.@buffWaitType);
         _loc3_._nBuffWaitEndFrame = int(param1.@buffWaitEndFrame);
         _loc3_._bNeed2HidePlayerUi = int(param1.@need2HidePlayerUi);
         _loc3_._isSpine = int(param1.@spine) == 1;
         _loc3_._sName = param2.name;
         _loc3_._sUiMessage = param2.uiMessage;
         _loc3_._sBuffEffect = param2.buffEffect;
         _loc3_._sBuffHarmSource = param2.buffHarmSource;
         return _loc3_;
      }
      
      public function get id() : int
      {
         return this._nId;
      }
      
      public function get displayId() : int
      {
         return this._nDisplayId;
      }
      
      public function get name() : String
      {
         return this._sName;
      }
      
      public function get posId() : int
      {
         return this._nPosId;
      }
      
      public function get disableFlip() : Boolean
      {
         return this._bDisableFlip;
      }
      
      public function get displayOnce() : Boolean
      {
         return this._bDisplayOnce;
      }
      
      public function get uiMessage() : String
      {
         return this._sUiMessage;
      }
      
      public function get hidden() : Boolean
      {
         return this._bHidden;
      }
      
      public function get buffEffect() : String
      {
         return this._sBuffEffect;
      }
      
      public function get isSkipWhenSimpleBattleRes() : Boolean
      {
         var _loc1_:Boolean = Boolean(DateUtil.isAfterTimeWithDelayClose("20210514 0:0:0"));
         if(_loc1_)
         {
            return this._sBuffEffect.indexOf(UserBattleConfig.BUFF_RES_CTRL_SIMPLE_DESC) != -1;
         }
         return false;
      }
      
      public function get buffHarmSource() : String
      {
         return this._sBuffHarmSource;
      }
      
      public function get buffWaitType() : int
      {
         return this._nBuffWaitType;
      }
      
      public function get buffWaitEndFrame() : int
      {
         return this._nBuffWaitEndFrame;
      }
      
      public function get need2HidePlayerUi() : Boolean
      {
         return this._bNeed2HidePlayerUi;
      }
      
      public function get isSpine() : Boolean
      {
         return this._isSpine;
      }
   }
}

