package mmo.interfaces.battleconfig.define
{
   import com.adobe.utils.StringUtil;
   import mmo.common.DateUtil;
   import mmo.interfaces.material.MaterialCommonData;
   import mmo.region.Translator;
   
   public class SummonDefine
   {
      
      private var _summonerRaceId:int;
      
      private var _summonedPetRaceId:int;
      
      private var _effect:int;
      
      private var _totalPrice:int;
      
      private var _material1:String;
      
      private var _material1Price:int;
      
      private var _material1PriceGold:int;
      
      private var _material1Des:String;
      
      private var _material2:String;
      
      private var _material2Price:int;
      
      private var _material2PriceGold:int;
      
      private var _material2Des:String;
      
      private var _description:String;
      
      private var _skillDescription:String;
      
      private var _summonerTeamId:int;
      
      private var _summonedPetTeamId:int;
      
      private var _isShow:Boolean;
      
      private var _startTime:Number;
      
      public function SummonDefine()
      {
         super();
      }
      
      public static function parseDefines(param1:XML) : Array
      {
         var define:SummonDefine = null;
         var summonerRaceId:int = 0;
         var summonedPetRaceId:int = 0;
         var params:XML = param1;
         var defineList:Array = [];
         var summonerRaceIdList:Array = String(params.@s).split("#").filter(function(param1:String, ... rest):Boolean
         {
            return !StringUtil.isNullOrEmpty(param1);
         });
         var summonedPetRaceIdList:Array = String(params.@sed).split("#").filter(function(param1:String, ... rest):Boolean
         {
            return !StringUtil.isNullOrEmpty(param1);
         });
         for each(summonerRaceId in summonerRaceIdList)
         {
            for each(summonedPetRaceId in summonedPetRaceIdList)
            {
               define = parseAttributeDefine(params);
               define._summonerRaceId = summonerRaceId;
               define._summonedPetRaceId = summonedPetRaceId;
               define._isShow = int(params.@isShow) == 1;
               if(params.@startTime == undefined)
               {
                  define._startTime = 0;
               }
               else
               {
                  define._startTime = DateUtil.parseDate(params.@startTime).time;
               }
               defineList.push(define);
            }
         }
         return defineList;
      }
      
      private static function parseAttributeDefine(param1:XML) : SummonDefine
      {
         var _loc2_:SummonDefine = new SummonDefine();
         _loc2_._effect = int(param1.@effect);
         _loc2_._totalPrice = int(param1.@tp);
         _loc2_._material1 = String(param1.@m1);
         _loc2_._material1Price = int(param1.@m1p);
         _loc2_._material1PriceGold = int(param1.@m1pg);
         _loc2_._material1Des = String(param1.@m1d);
         _loc2_._material2 = String(param1.@m2);
         _loc2_._material2Price = int(param1.@m2p);
         _loc2_._material2PriceGold = int(param1.@m2pg);
         _loc2_._material2Des = String(param1.@m2d);
         _loc2_._description = String(param1.@des);
         _loc2_._skillDescription = String(param1.@sdes);
         _loc2_._summonerTeamId = int(param1.@team);
         _loc2_._summonedPetTeamId = int(param1.@pt);
         return _loc2_;
      }
      
      public function get summonerRaceId() : int
      {
         return this._summonerRaceId;
      }
      
      public function get summonedPetRaceId() : int
      {
         return this._summonedPetRaceId;
      }
      
      public function get effect() : int
      {
         return this._effect;
      }
      
      public function get totalPrice() : int
      {
         return this._totalPrice;
      }
      
      public function get material1() : Array
      {
         return this.string2MaterialCommonDataArray(this._material1);
      }
      
      public function get material1Price() : int
      {
         return this._material1Price;
      }
      
      public function get material1PriceGold() : int
      {
         return this._material1PriceGold;
      }
      
      public function get material1Des() : String
      {
         return Translator.translate(this._material1Des);
      }
      
      public function get material2() : Array
      {
         return this.string2MaterialCommonDataArray(this._material2);
      }
      
      public function get material2Price() : int
      {
         return this._material2Price;
      }
      
      public function get material2PriceGold() : int
      {
         return this._material2PriceGold;
      }
      
      public function get material2Des() : String
      {
         return Translator.translate(this._material2Des);
      }
      
      public function get description() : String
      {
         return Translator.translate(this._description);
      }
      
      public function get skillDescription() : String
      {
         return Translator.translate(this._skillDescription);
      }
      
      public function get summonerTeamId() : int
      {
         return this._summonerTeamId;
      }
      
      public function get summonedPetTeamId() : int
      {
         return this._summonedPetTeamId;
      }
      
      public function get isShow() : Boolean
      {
         return this._isShow;
      }
      
      private function string2MaterialCommonDataArray(param1:String) : Array
      {
         var _loc2_:Array = [];
         if(param1 == "" || param1 == null)
         {
            return _loc2_;
         }
         var _loc3_:Array = param1.split("|");
         var _loc4_:int = 0;
         while(_loc4_ < _loc3_.length)
         {
            _loc2_.push(MaterialCommonData.parseStrToArray(_loc3_[_loc4_]));
            _loc4_++;
         }
         return _loc2_;
      }
   }
}

