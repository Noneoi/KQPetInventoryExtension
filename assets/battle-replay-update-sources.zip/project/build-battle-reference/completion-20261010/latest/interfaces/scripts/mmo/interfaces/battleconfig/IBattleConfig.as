package mmo.interfaces.battleconfig
{
   import mmo.interfaces.IService;
   import mmo.interfaces.battleconfig.define.ActionMovieDefine;
   import mmo.interfaces.battleconfig.define.BattleAvatarDefine;
   import mmo.interfaces.battleconfig.define.BufferDefine;
   import mmo.interfaces.battleconfig.define.BufferExecuteDefine;
   import mmo.interfaces.battleconfig.define.CarryDefine;
   import mmo.interfaces.battleconfig.define.EmbedDialogDefine;
   import mmo.interfaces.battleconfig.define.EntryDefine;
   import mmo.interfaces.battleconfig.define.JobTypeDefine;
   import mmo.interfaces.battleconfig.define.RaceTypeDefine;
   import mmo.interfaces.battleconfig.define.SkillDefine;
   import mmo.interfaces.battleconfig.define.SkillExecuteDefine;
   import mmo.interfaces.battleconfig.define.SummonDefine;
   import mmo.interfaces.battleconfig.entry.IBattleEntry;
   
   public interface IBattleConfig extends IService
   {
      
      function getSkillDefineById(param1:int) : SkillDefine;
      
      function getSkillName(param1:int) : String;
      
      function getSkillDesc(param1:int) : String;
      
      function getLastSkillDefineById(param1:int) : SkillDefine;
      
      function getEmbedEffectDefines(param1:int) : Array;
      
      function getEmbedDialogDefine(param1:int) : EmbedDialogDefine;
      
      function getSkillExecutDefine(param1:int) : SkillExecuteDefine;
      
      function getBufferDefineById(param1:int) : BufferDefine;
      
      function getPowerFullBuffId(param1:int) : int;
      
      function getDefaultPowerFullBuffId() : int;
      
      function getRaceTypeDefineById(param1:int) : RaceTypeDefine;
      
      function getJobTypeDefineById(param1:int) : JobTypeDefine;
      
      function get weakEffRestraintCoeff() : Number;
      
      function get strongEffRestraintCoeff() : Number;
      
      function get preDownloadFileList() : Array;
      
      function get preDownloadFileListSeq() : Array;
      
      function getBattleAvatarDefineById(param1:int) : BattleAvatarDefine;
      
      function get backgroundScenes() : Array;
      
      function get coolPetStoneBGInfo() : Object;
      
      function get changeAvatarIds() : Array;
      
      function getSummonDefine(param1:int, param2:int) : SummonDefine;
      
      function getSummonedPetDefineArray(param1:int) : Array;
      
      function getSummonerRaceIdArray() : Array;
      
      function getSummonerPetRaceIdArray() : Array;
      
      function isSummonEffect(param1:int, param2:int) : Boolean;
      
      function getSummonerTeamRaceIdArray(param1:int) : Array;
      
      function getBufferExecutDefine(param1:int) : BufferExecuteDefine;
      
      function getComboTargetSkillIds(param1:int, param2:Array) : int;
      
      function getCarryDefineArray(param1:int) : Array;
      
      function getCarryDefine(param1:int, param2:int) : CarryDefine;
      
      function getActionMovieDefineById(param1:int) : ActionMovieDefine;
      
      function getHuanDefine(param1:int) : Array;
      
      function getAlmightyDefine(param1:int) : Array;
      
      function getEntryDefine(param1:String) : EntryDefine;
      
      function getEntry(param1:String) : IBattleEntry;
   }
}

