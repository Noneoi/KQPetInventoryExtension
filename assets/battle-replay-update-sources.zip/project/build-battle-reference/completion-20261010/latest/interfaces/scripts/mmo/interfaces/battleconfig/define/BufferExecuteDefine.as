package mmo.interfaces.battleconfig.define
{
   public class BufferExecuteDefine
   {
      
      private var _executeBufferId:int;
      
      private var _actionResId:int;
      
      private var _skillId:int;
      
      private var _lightedSkillId:int;
      
      private var _initValue:int;
      
      private var _maxValue:int;
      
      private var _desc:String;
      
      public function BufferExecuteDefine()
      {
         super();
      }
      
      public static function parseDefine(param1:XML) : BufferExecuteDefine
      {
         var _loc2_:BufferExecuteDefine = new BufferExecuteDefine();
         _loc2_._executeBufferId = param1.@bufferId;
         _loc2_._actionResId = param1.@actionResId;
         _loc2_._skillId = param1.@skillId;
         _loc2_._lightedSkillId = param1.@lightedSkillId;
         _loc2_._initValue = param1.@initValue;
         _loc2_._maxValue = param1.@maxValue;
         _loc2_._desc = param1.@desc;
         return _loc2_;
      }
      
      public function get executeBufferId() : int
      {
         return this._executeBufferId;
      }
      
      public function get desc() : String
      {
         return this._desc;
      }
      
      public function get actionResId() : int
      {
         return this._actionResId;
      }
      
      public function get skillId() : int
      {
         return this._skillId;
      }
      
      public function get lightedSkillId() : int
      {
         return this._lightedSkillId;
      }
      
      public function get maxValue() : int
      {
         return this._maxValue;
      }
      
      public function get initValue() : int
      {
         return this._initValue;
      }
   }
}

