package mmo.interfaces.battleconfig.define
{
   import mmo.common.SplitUtil;
   
   public class EmbedEffectDefine
   {
      
      private var _nRaceId:int;
      
      private var _arrTiming:Array;
      
      private var _nType:int;
      
      private var _sUrl:String;
      
      private var _sParams:String;
      
      private var _arrSkillFilter:Array;
      
      private var _arrTaskFilter:Array;
      
      private var _arrWinerTeamIdFilter:Array;
      
      private var _arrGlobalVariableFilter:Array;
      
      private var _nLowerHpFilter:int;
      
      private var _nHigherHpFilter:int;
      
      private var _nRepeatCount:int;
      
      public function EmbedEffectDefine()
      {
         super();
      }
      
      public static function parseDefine(param1:XML, param2:Function) : EmbedEffectDefine
      {
         var _loc3_:EmbedEffectDefine = new EmbedEffectDefine();
         _loc3_._nRaceId = int(param1.@raceId);
         var _loc4_:Array = String(param1.@timing).split(",");
         _loc3_._arrTiming = param2.apply(null,[_loc4_]);
         _loc3_._nType = int(param1.@type);
         _loc3_._sUrl = String(param1.@url);
         _loc3_._sParams = String(param1.@params);
         setPropArrHelper(param1.@sf,_loc3_,"_arrSkillFilter");
         setPropArrHelper(param1.@tf,_loc3_,"_arrTaskFilter");
         setPropArrHelper(param1.@wf,_loc3_,"_arrWinerTeamIdFilter");
         setPropStringArrHelper(param1.@gv,_loc3_,"_arrGlobalVariableFilter");
         setPropValueHelper(param1.@lhf,_loc3_,"_nLowerHpFilter",100);
         setPropValueHelper(param1.@hhf,_loc3_,"_nHigherHpFilter",0);
         setPropValueHelper(param1.@rc,_loc3_,"_nRepeatCount",int.MAX_VALUE);
         return _loc3_;
      }
      
      private static function setPropStringArrHelper(param1:*, param2:EmbedEffectDefine, param3:String) : void
      {
         if(param1 == undefined || param1 == "")
         {
            param2[param3] = [];
         }
         else
         {
            param2[param3] = String(param1).split(",");
         }
      }
      
      private static function setPropArrHelper(param1:*, param2:EmbedEffectDefine, param3:String) : void
      {
         if(param1 == undefined || param1 == "")
         {
            param2[param3] = [];
         }
         else
         {
            param2[param3] = SplitUtil.splitToInt(param1,",");
         }
      }
      
      private static function setPropValueHelper(param1:*, param2:EmbedEffectDefine, param3:String, param4:int) : void
      {
         if(param1 == undefined || param1 == "")
         {
            param2[param3] = param4;
         }
         else
         {
            param2[param3] = int(param1);
         }
      }
      
      public function get raceId() : int
      {
         return this._nRaceId;
      }
      
      public function get timing() : Array
      {
         return this._arrTiming;
      }
      
      public function get type() : int
      {
         return this._nType;
      }
      
      public function get url() : String
      {
         return this._sUrl;
      }
      
      public function get params() : String
      {
         return this._sParams;
      }
      
      public function get skillFilter() : Array
      {
         return this._arrSkillFilter;
      }
      
      public function get taskFilter() : Array
      {
         return this._arrTaskFilter;
      }
      
      public function get winerTeamIdFilter() : Array
      {
         return this._arrWinerTeamIdFilter;
      }
      
      public function get globalVariableFilter() : Array
      {
         return this._arrGlobalVariableFilter;
      }
      
      public function get lowerHpFilter() : int
      {
         return this._nLowerHpFilter;
      }
      
      public function get higherHpFilter() : int
      {
         return this._nHigherHpFilter;
      }
      
      public function get repeatCount() : int
      {
         return this._nRepeatCount;
      }
   }
}

