package mmo.interfaces.battleconfig.define
{
   public class AlmightySkillDefine
   {
      
      private var _id:int;
      
      private var _heroSkillName:String;
      
      private var _heroSkillDesc:String;
      
      private var _summonSkillName:String;
      
      private var _summonSkillDesc:String;
      
      private var _psychicsSkillName:String;
      
      private var _psychicsSkillDesc:String;
      
      private var _psychicsCalledPetRaceId:int;
      
      public function AlmightySkillDefine()
      {
         super();
      }
      
      public static function parseDefine(param1:XML) : AlmightySkillDefine
      {
         var _loc2_:AlmightySkillDefine = new AlmightySkillDefine();
         _loc2_._id = parseInt(param1.@id);
         _loc2_._heroSkillName = String(param1.@hn);
         _loc2_._heroSkillDesc = String(param1.@hd);
         _loc2_._summonSkillName = String(param1.@sn);
         _loc2_._summonSkillDesc = String(param1.@sd);
         _loc2_._psychicsSkillName = String(param1.@pn);
         _loc2_._psychicsSkillDesc = String(param1.@pd);
         _loc2_._psychicsCalledPetRaceId = parseInt(param1.@psci);
         return _loc2_;
      }
      
      public function get id() : int
      {
         return this._id;
      }
      
      public function get heroSkillName() : String
      {
         return this._heroSkillName;
      }
      
      public function get heroSkillDesc() : String
      {
         return this._heroSkillDesc;
      }
      
      public function get summonSkillName() : String
      {
         return this._summonSkillName;
      }
      
      public function get summonSkillDesc() : String
      {
         return this._summonSkillDesc;
      }
      
      public function get psychicsSkillName() : String
      {
         return this._psychicsSkillName;
      }
      
      public function get psychicsSkillDesc() : String
      {
         return this._psychicsSkillDesc;
      }
      
      public function get psychicsCalledPetRaceId() : int
      {
         return this._psychicsCalledPetRaceId;
      }
   }
}

