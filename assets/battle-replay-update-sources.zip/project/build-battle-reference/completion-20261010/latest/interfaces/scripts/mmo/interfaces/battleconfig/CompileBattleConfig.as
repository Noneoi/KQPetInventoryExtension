package mmo.interfaces.battleconfig
{
   import mmo.interfaces.battleconfig.consts.EmbedEffectTypes;
   import mmo.interfaces.battleconfig.consts.JobAttackType;
   import mmo.interfaces.battleconfig.consts.JobType;
   import mmo.interfaces.battleconfig.consts.RaceTypePriority;
   import mmo.interfaces.battleconfig.consts.SkillTypes;
   import mmo.interfaces.battleconfig.define.AlmightySkillDefine;
   import mmo.interfaces.battleconfig.define.EmbedDialogDefine;
   import mmo.interfaces.battleconfig.define.EmbedEffectDefine;
   import mmo.interfaces.battleconfig.define.EntryDefine;
   import mmo.interfaces.battleconfig.define.HuanSkillDefine;
   import mmo.interfaces.battleconfig.entry.IBattleEntry;
   
   public class CompileBattleConfig
   {
      
      public function CompileBattleConfig()
      {
         super();
      }
      
      public static function compileMe() : void
      {
         var _loc1_:EmbedEffectTypes = null;
         var _loc2_:EmbedEffectDefine = null;
         var _loc3_:EmbedDialogDefine = null;
         var _loc4_:IBattleConfig = null;
         var _loc5_:IBattleConfigLegacy = null;
         var _loc6_:SkillTypes = null;
         var _loc7_:RaceTypePriority = null;
         var _loc8_:JobAttackType = null;
         var _loc9_:JobType = null;
         var _loc10_:HuanSkillDefine = null;
         var _loc11_:AlmightySkillDefine = null;
         var _loc12_:EntryDefine = null;
         var _loc13_:IBattleEntry = null;
      }
   }
}

