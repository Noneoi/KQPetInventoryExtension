package mmo.interfaces.battleconfig.define
{
   public class RaceTypeDefine
   {
      
      private var _nId:int;
      
      private var _sName:String;
      
      private var _priority:int;
      
      private var _arrRestraintCoeffiicient:Array;
      
      private var _map:Object = {};
      
      public function RaceTypeDefine()
      {
         super();
      }
      
      public static function parseDefine(param1:XML, param2:Object) : RaceTypeDefine
      {
         var _loc6_:Number = NaN;
         var _loc3_:RaceTypeDefine = new RaceTypeDefine();
         _loc3_._nId = param1.@id;
         _loc3_._sName = param1.@nm;
         _loc3_._arrRestraintCoeffiicient = [];
         _loc3_._priority = param1.@pri;
         var _loc4_:Array = String(param1.@rcs).split(",");
         var _loc5_:int = 0;
         while(_loc5_ < _loc4_.length)
         {
            _loc6_ = Number(_loc4_[_loc5_]);
            _loc3_._arrRestraintCoeffiicient.push(_loc6_);
            _loc5_++;
         }
         _loc3_._map = param2;
         return _loc3_;
      }
      
      public function get id() : int
      {
         return this._nId;
      }
      
      public function get name() : String
      {
         return this._sName;
      }
      
      public function get priority() : int
      {
         return this._priority;
      }
      
      public function restraintCoefficients() : Array
      {
         return this._arrRestraintCoeffiicient;
      }
      
      public function getRestraintCoefficientById(param1:*) : Number
      {
         var _loc2_:int = int(this._map[param1]);
         return this._arrRestraintCoeffiicient[_loc2_];
      }
      
      public function getRestraintCoefficientByType(param1:RaceTypeDefine) : Number
      {
         return this.getRestraintCoefficientById(param1.id);
      }
   }
}

