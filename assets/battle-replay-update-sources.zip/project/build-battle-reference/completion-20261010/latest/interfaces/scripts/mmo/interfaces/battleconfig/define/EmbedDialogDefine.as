package mmo.interfaces.battleconfig.define
{
   public class EmbedDialogDefine
   {
      
      private var _nId:int;
      
      private var _nNpcId:int;
      
      private var _nIconId:int;
      
      private var _bShowBtnOk:Boolean;
      
      private var _xmlContext:XML;
      
      public function EmbedDialogDefine()
      {
         super();
      }
      
      public static function parseDefine(param1:XML) : EmbedDialogDefine
      {
         var _loc2_:EmbedDialogDefine = new EmbedDialogDefine();
         _loc2_._nId = int(param1.@id);
         _loc2_._nNpcId = int(param1.@npcId);
         _loc2_._nIconId = int(param1.@iconId);
         _loc2_._bShowBtnOk = int(param1.@viewBtnOk) == 1;
         _loc2_._xmlContext = XML(param1.context);
         return _loc2_;
      }
      
      public function get id() : int
      {
         return this._nId;
      }
      
      public function get npcId() : int
      {
         return this._nNpcId;
      }
      
      public function get iconId() : int
      {
         return this._nIconId;
      }
      
      public function get showBtnOk() : Boolean
      {
         return this._bShowBtnOk;
      }
      
      public function get context() : XML
      {
         return this._xmlContext;
      }
   }
}

