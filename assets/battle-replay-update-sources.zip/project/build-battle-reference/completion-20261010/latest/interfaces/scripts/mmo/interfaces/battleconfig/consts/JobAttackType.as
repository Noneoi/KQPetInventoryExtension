package mmo.interfaces.battleconfig.consts
{
   public class JobAttackType
   {
      
      public static const PHYSICS:int = 1;
      
      public static const MAGIC:int = 2;
      
      public static const SUPER_PHYSICS:int = 3;
      
      public static const SUPER_MAGIC:int = 4;
      
      public function JobAttackType()
      {
         super();
      }
   }
}

