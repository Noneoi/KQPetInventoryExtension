package mmo.interfaces.battleconfig
{
   public interface IBattleConfigLegacy extends IBattleConfig
   {
      
      
   }
}

