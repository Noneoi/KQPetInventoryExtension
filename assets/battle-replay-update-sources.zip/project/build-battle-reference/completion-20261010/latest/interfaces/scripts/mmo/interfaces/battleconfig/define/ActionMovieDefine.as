package mmo.interfaces.battleconfig.define
{
   import com.adobe.utils.StringUtil;
   
   public class ActionMovieDefine
   {
      
      private var _id:int;
      
      private var _foreground:Array;
      
      private var _background:Array;
      
      private var _isSpine:Boolean;
      
      public function ActionMovieDefine()
      {
         super();
      }
      
      public static function parseDefine(param1:XML) : ActionMovieDefine
      {
         var params:XML = param1;
         var define:ActionMovieDefine = new ActionMovieDefine();
         define._id = int(params.@id);
         if(Boolean(params.@foreground))
         {
            define._foreground = String(params.@foreground).split(",").map(function(param1:String, param2:int, param3:Array):Array
            {
               return StringUtil.split2IntegerArray(param1,":");
            });
         }
         else
         {
            define._foreground = [];
         }
         if(Boolean(params.@background))
         {
            define._background = String(params.@background).split(",").map(function(param1:String, param2:int, param3:Array):Array
            {
               return StringUtil.split2IntegerArray(param1,":");
            });
         }
         else
         {
            define._background = [];
         }
         define._isSpine = int(params.@spine) == 1;
         return define;
      }
      
      public function get id() : int
      {
         return this._id;
      }
      
      public function get foreground() : Array
      {
         return this._foreground;
      }
      
      public function get background() : Array
      {
         return this._background;
      }
      
      public function get isSpine() : Boolean
      {
         return this._isSpine;
      }
   }
}

