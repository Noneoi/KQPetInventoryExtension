package mmo.interfaces.battleconfig.define
{
   public class BufferDescDefine
   {
      
      private var _nId:int;
      
      private var _sName:String;
      
      private var _sUiMessage:String;
      
      private var _sBuffEffect:String;
      
      private var _sBuffHarmSource:String;
      
      public function BufferDescDefine()
      {
         super();
      }
      
      public static function parseDefine(param1:XML) : BufferDescDefine
      {
         var _loc2_:BufferDescDefine = new BufferDescDefine();
         _loc2_._nId = param1.@id;
         _loc2_._sName = param1.@nm;
         _loc2_._sUiMessage = String(param1.@mess);
         _loc2_._sBuffEffect = String(param1.@beffect);
         _loc2_._sBuffHarmSource = String(param1.@bhs);
         return _loc2_;
      }
      
      public function get id() : int
      {
         return this._nId;
      }
      
      public function get name() : String
      {
         return this._sName;
      }
      
      public function get uiMessage() : String
      {
         return this._sUiMessage;
      }
      
      public function get buffEffect() : String
      {
         return this._sBuffEffect;
      }
      
      public function get buffHarmSource() : String
      {
         return this._sBuffHarmSource;
      }
   }
}

