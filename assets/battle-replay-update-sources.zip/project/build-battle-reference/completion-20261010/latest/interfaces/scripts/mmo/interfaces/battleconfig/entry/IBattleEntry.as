package mmo.interfaces.battleconfig.entry
{
   public interface IBattleEntry
   {
      
      function get name() : String;
      
      function get desc() : String;
   }
}

