package mmo.multipleformpet.control
{
   import mmo.interfaces.formation.FormationBase;
   import mmo.interfaces.formation.FormationPetInfo;
   import mmo.interfaces.pet.data.PetBriefInfo;
   import mmo.multipleformpet.config.MultipleFormPetConfig;
   import mmo.multipleformpet.config.MultipleFormPetFormDefine;
   import mmo.multipleformpet.model.MultipleFormPetClient;
   import mmo.play.dialog.InteractUtil;
   
   public class MultipleFormPetController
   {
      
      private static var _instance:MultipleFormPetController;
      
      private var _client:MultipleFormPetClient;
      
      public function MultipleFormPetController()
      {
         super();
         this._client = new MultipleFormPetClient();
      }
      
      public static function get instance() : MultipleFormPetController
      {
         if(_instance == null)
         {
            _instance = new MultipleFormPetController();
         }
         return _instance;
      }
      
      public function getSwitchPetRaceIds(param1:int) : Array
      {
         var _loc2_:MultipleFormPetFormDefine = MultipleFormPetConfig.getDefine(param1);
         if(_loc2_ == null)
         {
            return [];
         }
         return _loc2_.group;
      }
      
      public function switchForm(param1:int, param2:int, param3:int, param4:Function, param5:Function) : void
      {
         if(param3 <= 0)
         {
            param3 = this.selectTarget(param2);
         }
         this._client.switchForm(param1,param3,param4,param5);
      }
      
      public function customSwitchFormWithServer(param1:Object, param2:int, param3:String, param4:Object, param5:Function, param6:Function) : void
      {
         var sourceRaceId:int;
         var raceIdKey:String = null;
         var pet:Object = param1;
         var targetRaceId:int = param2;
         var cmd:String = param3;
         var params:Object = param4;
         var callback:Function = param5;
         var failCall:Function = param6;
         if(!pet.hasOwnProperty("raceId") && !pet.hasOwnProperty("r"))
         {
            throw new Error("can\'t find raceId or r in petObj");
         }
         raceIdKey = pet.hasOwnProperty("raceId") ? "raceId" : "r";
         sourceRaceId = int(pet[raceIdKey]);
         if(targetRaceId <= 0)
         {
            targetRaceId = this.selectTarget(sourceRaceId);
         }
         this._client.customSwitchForm(sourceRaceId,targetRaceId,cmd,params,function(param1:Object):void
         {
            pet[raceIdKey] = targetRaceId;
            InteractUtil.applyCallback(callback,[param1]);
         },failCall);
      }
      
      public function customSwitchForm(param1:Object, param2:int, param3:Array, param4:Function, param5:Array) : Object
      {
         var raceIdKey:String;
         var sourceRaceId:int;
         var petObj:Object = null;
         var j:int = 0;
         var formation:FormationBase = null;
         var oldSummonerId:int = 0;
         var newSummonerId:int = 0;
         var psArr:Array = null;
         var i:int = 0;
         var index:int = 0;
         var summoners:Array = null;
         var pet:Object = param1;
         var targetRaceId:int = param2;
         var petArray:Array = param3;
         var filter:Function = param4;
         var formationArr:Array = param5;
         if(!pet.hasOwnProperty("raceId") && !pet.hasOwnProperty("r"))
         {
            throw new Error("can\'t find raceId or r in petObj");
         }
         raceIdKey = pet.hasOwnProperty("raceId") ? "raceId" : "r";
         sourceRaceId = int(pet[raceIdKey]);
         if(targetRaceId <= 0)
         {
            targetRaceId = this.selectTarget(sourceRaceId);
         }
         petArray = petArray != null ? petArray : (formationArr != null && formationArr.length > 0 && formationArr[0].petArray != null ? formationArr[0].petArray : []);
         for each(petObj in petArray)
         {
            if(petObj[raceIdKey] == targetRaceId)
            {
               if(!(filter != null && !filter.apply(null,[petObj])))
               {
                  if(formationArr != null)
                  {
                     j = 0;
                     while(j < formationArr.length)
                     {
                        formation = formationArr[j];
                        oldSummonerId = pet.hasOwnProperty("summonerId") && pet.summonerId > 0 ? int(pet.summonerId) : 0;
                        newSummonerId = oldSummonerId;
                        if(petObj.hasOwnProperty("summonerId") && petObj.summonerId > 0)
                        {
                           newSummonerId = int(petObj.summonerId);
                        }
                        psArr = formation.getPetSeries();
                        if(newSummonerId != oldSummonerId)
                        {
                           index = psArr.indexOf(oldSummonerId);
                           if(index >= 0)
                           {
                              psArr[index] = newSummonerId;
                           }
                        }
                        if(newSummonerId == oldSummonerId && oldSummonerId > 0)
                        {
                           summoners = petArray.filter(function(param1:Object, param2:int, param3:Array):Boolean
                           {
                              return param1.id == oldSummonerId;
                           });
                           summoners.forEach(function(param1:Object, param2:int, param3:Array):void
                           {
                              if(param1 is FormationPetInfo)
                              {
                                 (param1 as FormationPetInfo).summonedPetFormationPetInfo = petObj as FormationPetInfo;
                                 (param1 as FormationPetInfo).summonedPetId = (petObj as FormationPetInfo).id;
                              }
                              else if(param1 is PetBriefInfo)
                              {
                                 (param1 as PetBriefInfo).setSummonedPetBriefInfo(petObj as PetBriefInfo);
                              }
                              else if(param1.hasOwnProperty("sppl"))
                              {
                                 param1["sppl"] = petObj;
                                 param1["sepi"] = petObj["id"];
                              }
                           });
                        }
                        i = 0;
                        while(i < psArr.length)
                        {
                           if(psArr[i] == pet.id)
                           {
                              psArr[i] = petObj.id;
                              break;
                           }
                           i++;
                        }
                        FormationBase.modifiyPs(formation,psArr.join("#"));
                        j++;
                     }
                  }
                  return petObj;
               }
            }
         }
         return null;
      }
      
      private function selectTarget(param1:int) : int
      {
         var _loc2_:MultipleFormPetFormDefine = MultipleFormPetConfig.getDefine(param1);
         if(_loc2_ == null)
         {
            throw new Error("can\'t find formconf by raceId:" + param1);
         }
         var _loc3_:Array = _loc2_.group;
         var _loc4_:int = _loc3_.indexOf(param1);
         _loc4_ = (_loc4_ + 1) % _loc3_.length;
         return _loc3_[_loc4_];
      }
   }
}

