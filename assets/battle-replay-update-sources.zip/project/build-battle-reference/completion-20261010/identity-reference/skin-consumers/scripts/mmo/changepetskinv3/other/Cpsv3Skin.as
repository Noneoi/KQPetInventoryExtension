package mmo.changepetskinv3.other
{
   import mmo.common.utils.dt.EnumSupport;
   import mmo.interfaces.changepetskin.IPetSkin;
   import mmo.interfaces.changepetskin.IPetSkinAvailablePet;
   import mmo.interfaces.material.MaterialCommonData;
   import mmo.interfaces.pet.data.IPetDictionaryDataService;
   import mmo.interfaces.pet.data.PetDictionaryDataItem;
   import mmo.play.compatible.H5;
   import mmo.play.globalfunctions.forSvc;
   
   public class Cpsv3Skin implements IPetSkin
   {
      
      private static const ENUM_SUPPORT:EnumSupport = new EnumSupport({"availablePets":Cpsv3AvailablePet.valuesFrom});
      
      private static const MAX_INTEGER:int = 999999;
      
      private static var sValue:Cpsv3Skin = null;
      
      private static var sValues:Vector.<Cpsv3Skin> = new Vector.<Cpsv3Skin>();
      
      private static var sMapOfRaceId:Object = null;
      
      private static var sMapForGroup:Object = null;
      
      private static var sMapForFusion:Object = null;
      
      private static var sMapForXChangeable:Object = null;
      
      private static const __STATIC_INIT__:* = (function():*
      {
         if(H5.yes)
         {
            return;
         }
         initStatic();
      })();
      
      private static var sPetDicDataSvc:IPetDictionaryDataService = null;
      
      private var _index:int;
      
      private var _name:String;
      
      private var _id:int;
      
      private var _sale:Boolean;
      
      private var _price:int;
      
      private var _show:Boolean;
      
      private var _new:Boolean;
      
      private var _voice:int;
      
      private var _poster:Boolean;
      
      private var _interactive:Boolean;
      
      private var _fuse:Array;
      
      private var _fuseFix:Boolean;
      
      private var _fuseAtLeast:int;
      
      private var _xPosterRes:Boolean;
      
      private var _xInteractivePosterRes:Boolean;
      
      private var _tryingCardId:int;
      
      private var _xChangeableInfo:String;
      
      private var _exchangingMaterialStr:String;
      
      private var _exchangingWeight:Number;
      
      private var _changeableRaceIds:Array;
      
      private var _changeableNames:Array;
      
      private var _changeableVoiceDiv:Array;
      
      private var _changeableWithMovie:Boolean;
      
      private var _availablePets:Vector.<Cpsv3AvailablePet>;
      
      private var _raceId:int = -1;
      
      private var _raceIdMin:int = 999999;
      
      private var _tagNum:int = -1;
      
      private var _dicDataItemCache:PetDictionaryDataItem = null;
      
      private var _exchangingMaterialCache:MaterialCommonData = null;
      
      private var _xChangeableDependentId:int = -1;
      
      private var _xChangeableName:String = null;
      
      private var _confTag:String;
      
      public function Cpsv3Skin(param1:Object)
      {
         var _loc2_:String = null;
         var _loc3_:Array = null;
         super();
         ENUM_SUPPORT.check();
         for(_loc2_ in param1)
         {
            this["_" + _loc2_] = ENUM_SUPPORT.initField(this,param1,_loc2_);
         }
         if(this._xChangeableInfo != null)
         {
            _loc3_ = this._xChangeableInfo.split("@");
            this._xChangeableDependentId = parseInt(_loc3_[1]);
            this._xChangeableName = _loc3_[0];
         }
      }
      
      public static function values() : Vector.<Cpsv3Skin>
      {
         return Cpsv3Skin.sValues.concat();
      }
      
      public static function valuesOuter() : Vector.<IPetSkin>
      {
         var _loc1_:Vector.<Cpsv3Skin> = Cpsv3Skin.sValues;
         if(H5.yes)
         {
            _loc1_ = _loc1_.concat();
         }
         return Vector.<IPetSkin>(_loc1_);
      }
      
      public static function valueOf(param1:int) : Cpsv3Skin
      {
         if(param1 >= 0 && param1 < Cpsv3Skin.sValues.length)
         {
            return Cpsv3Skin.sValues[param1];
         }
         return null;
      }
      
      public static function valueOfId(param1:int) : Cpsv3Skin
      {
         return Cpsv3Skin.valueOf(param1 - 1);
      }
      
      private static function enum__(param1:Object, param2:int, param3:Array) : Cpsv3Skin
      {
         ENUM_SUPPORT.lock = false;
         sValue = new Cpsv3Skin(param1);
         sValue._index = sValues.length;
         ENUM_SUPPORT.lock = true;
         sValues.push(sValue);
         return sValue;
      }
      
      public static function valueOfRaceId(param1:int) : Cpsv3Skin
      {
         var _loc2_:Cpsv3Skin = null;
         var _loc3_:Cpsv3AvailablePet = null;
         if(Cpsv3Skin.sMapOfRaceId == null)
         {
            Cpsv3Skin.sMapOfRaceId = {};
            for each(_loc2_ in Cpsv3Skin.sValues)
            {
               for each(_loc3_ in _loc2_._availablePets)
               {
                  Cpsv3Skin.sMapOfRaceId[_loc3_.raceId.toString()] = _loc2_;
               }
            }
         }
         return Cpsv3Skin.sMapOfRaceId[param1.toString()];
      }
      
      internal static function initStatic() : void
      {
         Cpsv3SkinConfig.SKIN_DEFINES.forEach(enum__);
      }
      
      public function get index() : int
      {
         return this._index;
      }
      
      public function get name() : String
      {
         return this._name;
      }
      
      public function get raceId() : int
      {
         var _loc1_:int = 0;
         if(this._raceId == -1)
         {
            _loc1_ = 0;
            while(_loc1_ < this._availablePets.length)
            {
               if(this._raceId < this._availablePets[_loc1_].raceId)
               {
                  this._raceId = this._availablePets[_loc1_].raceId;
               }
               _loc1_++;
            }
         }
         return this._raceId;
      }
      
      public function get raceIdMin() : int
      {
         var _loc1_:int = 0;
         if(this._raceIdMin == Cpsv3Skin.MAX_INTEGER)
         {
            _loc1_ = 0;
            while(_loc1_ < this._availablePets.length)
            {
               if(this._raceIdMin > this._availablePets[_loc1_].raceId)
               {
                  this._raceIdMin = this._availablePets[_loc1_].raceId;
               }
               _loc1_++;
            }
         }
         return this._raceIdMin;
      }
      
      public function get dicData() : PetDictionaryDataItem
      {
         if(Cpsv3Skin.sPetDicDataSvc == null)
         {
            Cpsv3Skin.sPetDicDataSvc = forSvc(IPetDictionaryDataService);
         }
         if(this._dicDataItemCache == null)
         {
            this._dicDataItemCache = Cpsv3Skin.sPetDicDataSvc.getDataItemByRaceId(this.raceId);
         }
         if(this._dicDataItemCache == null)
         {
            throw new Error("Can not find dict data, race id: " + this.raceId);
         }
         return this._dicDataItemCache;
      }
      
      public function get id() : int
      {
         return this._id;
      }
      
      public function get price() : int
      {
         return this._price;
      }
      
      public function get fuseAtLeast() : int
      {
         return this._fuseAtLeast;
      }
      
      public function get tryingCardId() : int
      {
         return this._tryingCardId;
      }
      
      public function get voiceNum() : int
      {
         return this._voice;
      }
      
      public function get exchangingMaterial() : MaterialCommonData
      {
         if(this._exchangingMaterialStr == null)
         {
            return null;
         }
         if(this._exchangingMaterialCache != null)
         {
            return this._exchangingMaterialCache;
         }
         return this._exchangingMaterialCache = new MaterialCommonData(this._exchangingMaterialStr);
      }
      
      public function get exchangingWeight() : Number
      {
         return this._exchangingWeight;
      }
      
      public function get changeableRaceIds() : Array
      {
         if(this._changeableRaceIds == null)
         {
            return null;
         }
         return this._changeableRaceIds.concat();
      }
      
      public function get changeableNames() : Array
      {
         if(this._changeableNames == null)
         {
            return null;
         }
         var _loc1_:Array = this._changeableNames.concat();
         _loc1_[0] = "战斗形态";
         return _loc1_;
      }
      
      public function get changeableVoiceDiv() : Array
      {
         if(this._changeableVoiceDiv == null)
         {
            return null;
         }
         return this._changeableVoiceDiv.concat();
      }
      
      public function get xChangeableDependentId() : int
      {
         return this._xChangeableDependentId;
      }
      
      public function get xChangeableName() : String
      {
         return this._xChangeableName;
      }
      
      private function getXChangeableP() : Vector.<Cpsv3Skin>
      {
         var _loc1_:int = 0;
         var _loc2_:Cpsv3Skin = null;
         var _loc3_:Cpsv3Skin = null;
         var _loc4_:Vector.<Cpsv3Skin> = null;
         if(Cpsv3Skin.sMapForXChangeable == null)
         {
            Cpsv3Skin.sMapForXChangeable = {};
            _loc1_ = 0;
            while(_loc1_ < Cpsv3Skin.sValues.length)
            {
               _loc2_ = Cpsv3Skin.sValues[_loc1_];
               if(!(_loc2_._xChangeableDependentId == -1 || !_loc2_.isShow()))
               {
                  _loc3_ = Cpsv3Skin.valueOfId(_loc2_._xChangeableDependentId);
                  _loc4_ = Cpsv3Skin.sMapForXChangeable[_loc3_.toString()];
                  if(_loc4_ == null)
                  {
                     _loc4_ = Cpsv3Skin.sMapForXChangeable[_loc3_.toString()] = new Vector.<Cpsv3Skin>();
                     _loc4_.push(_loc3_);
                  }
                  if(_loc4_.indexOf(_loc2_) == -1)
                  {
                     _loc4_.push(_loc2_);
                     Cpsv3Skin.sMapForXChangeable[_loc2_.toString()] = _loc4_;
                  }
               }
               _loc1_++;
            }
         }
         return Cpsv3Skin.sMapForXChangeable[this.toString()];
      }
      
      public function getXChangeable(param1:int = -1) : Vector.<Cpsv3Skin>
      {
         var _loc2_:Vector.<Cpsv3Skin> = this.getXChangeableP();
         if(_loc2_ == null)
         {
            return null;
         }
         _loc2_ = _loc2_.concat();
         if(param1 == -1)
         {
            return _loc2_;
         }
         var _loc3_:int = 0;
         while(_loc3_ < _loc2_.length)
         {
            if(_loc2_[_loc3_].findRaceId(param1) == -1)
            {
               _loc2_.splice(_loc3_,1);
               _loc3_--;
            }
            _loc3_++;
         }
         return _loc2_;
      }
      
      public function getXChangeableRaceIds(param1:int = -1) : Array
      {
         var _loc2_:Vector.<Cpsv3Skin> = this.getXChangeable(param1);
         if(_loc2_ == null)
         {
            return null;
         }
         var _loc3_:Array = new Array(_loc2_.length);
         var _loc4_:int = 0;
         while(_loc4_ < _loc3_.length)
         {
            if(param1 == -1)
            {
               _loc3_[_loc4_] = _loc2_[_loc4_].raceId;
            }
            else
            {
               _loc3_[_loc4_] = _loc2_[_loc4_].findRaceId(param1);
            }
            _loc4_++;
         }
         return _loc3_;
      }
      
      public function getXChangeableNames(param1:int = -1) : Array
      {
         var _loc2_:Vector.<Cpsv3Skin> = this.getXChangeable(param1);
         if(_loc2_ == null)
         {
            return null;
         }
         var _loc3_:Array = new Array(_loc2_.length);
         var _loc4_:int = 0;
         while(_loc4_ < _loc3_.length)
         {
            _loc3_[_loc4_] = _loc2_[_loc4_]._xChangeableName;
            _loc4_++;
         }
         _loc3_[0] = "本体";
         return _loc3_;
      }
      
      public function get availablePetsInner() : Vector.<Cpsv3AvailablePet>
      {
         return this._availablePets.concat();
      }
      
      public function get availablePets() : Vector.<IPetSkinAvailablePet>
      {
         var _loc1_:Vector.<Cpsv3AvailablePet> = this._availablePets;
         if(H5.yes)
         {
            _loc1_ = _loc1_.concat();
         }
         return Vector.<IPetSkinAvailablePet>(_loc1_);
      }
      
      public function get availablePetsNum() : int
      {
         return this._availablePets.length;
      }
      
      public function get groupInner() : Vector.<Cpsv3Skin>
      {
         var group:Vector.<Cpsv3Skin>;
         var i:int = 0;
         var idArr:Array = null;
         var groupT:Vector.<Cpsv3Skin> = null;
         var j:int = 0;
         var skin:Cpsv3Skin = null;
         if(this._fuse != null)
         {
            return Vector.<Cpsv3Skin>(this._fuse.map(function(... rest):Cpsv3Skin
            {
               return Cpsv3Skin.valueOfId(rest[0]);
            }));
         }
         if(Cpsv3Skin.sMapForGroup == null)
         {
            Cpsv3Skin.sMapForGroup = {};
            i = 0;
            while(i < Cpsv3SkinConfig.SKIN_GROUPS.length)
            {
               idArr = Cpsv3SkinConfig.SKIN_GROUPS[i];
               groupT = new Vector.<Cpsv3Skin>();
               j = 0;
               while(j < idArr.length)
               {
                  skin = Cpsv3Skin.valueOfId(idArr[j]);
                  if(skin.isShow())
                  {
                     groupT.push(skin);
                     Cpsv3Skin.sMapForGroup[skin.toString()] = groupT;
                  }
                  j++;
               }
               i++;
            }
         }
         group = null;
         if(this._xChangeableDependentId != -1)
         {
            group = Cpsv3Skin.sMapForGroup[Cpsv3Skin.valueOfId(this._xChangeableDependentId).toString()];
         }
         else
         {
            group = Cpsv3Skin.sMapForGroup[this.toString()];
         }
         if(group == null)
         {
            throw new Error("No group, id: " + this._id);
         }
         return group.concat();
      }
      
      public function get group() : Vector.<IPetSkin>
      {
         return Vector.<IPetSkin>(this.groupInner);
      }
      
      public function get confTag() : String
      {
         return this._confTag;
      }
      
      public function isSale() : Boolean
      {
         return this._sale;
      }
      
      public function isShow() : Boolean
      {
         return this._show;
      }
      
      public function isNew() : Boolean
      {
         return this._new;
      }
      
      public function isVoice() : Boolean
      {
         return this._voice > 0;
      }
      
      public function isPoster() : Boolean
      {
         return this._poster;
      }
      
      public function isInteractive() : Boolean
      {
         return this._interactive;
      }
      
      public function isFusionPoster() : Boolean
      {
         return this._fuse != null;
      }
      
      public function isNeedFixFusionPoster() : Boolean
      {
         return this._fuseFix;
      }
      
      public function isChangeableWithMovie() : Boolean
      {
         return this._changeableWithMovie;
      }
      
      public function isChangeable() : Boolean
      {
         return this._changeableRaceIds != null;
      }
      
      public function isXChangeable() : Boolean
      {
         return this.getXChangeableP() != null;
      }
      
      public function hasXPosterRes() : Boolean
      {
         return this._xPosterRes;
      }
      
      public function hasXInteractivePosterRes() : Boolean
      {
         return this._xInteractivePosterRes;
      }
      
      public function canTry() : Boolean
      {
         return Cpsv3Config.isTryingCardEnabled() && this._tryingCardId != -1;
      }
      
      public function getBattleDemo() : Object
      {
         return Cpsv3SkinConfigBattleDemo.getData(this);
      }
      
      public function getTagNum() : int
      {
         if(this._tagNum == -1)
         {
            this._tagNum = 0;
            if(this._voice > 0)
            {
               ++this._tagNum;
            }
            if(this._poster)
            {
               ++this._tagNum;
            }
            if(this._interactive)
            {
               ++this._tagNum;
            }
            if(this.isXChangeable())
            {
               ++this._tagNum;
            }
         }
         return this._tagNum;
      }
      
      public function getFusionPoster() : Cpsv3Skin
      {
         var _loc1_:int = 0;
         var _loc2_:Vector.<Cpsv3Skin> = null;
         var _loc3_:int = 0;
         if(Cpsv3Skin.sMapForFusion == null)
         {
            Cpsv3Skin.sMapForFusion = {};
            _loc1_ = 0;
            while(_loc1_ < Cpsv3Skin.sValues.length)
            {
               if(Cpsv3Skin.sValues[_loc1_].isFusionPoster())
               {
                  _loc2_ = Cpsv3Skin.sValues[_loc1_].groupInner;
                  _loc3_ = 0;
                  while(_loc3_ < _loc2_.length)
                  {
                     Cpsv3Skin.sMapForFusion[_loc2_[_loc3_].toString()] = Cpsv3Skin.sValues[_loc1_];
                     _loc3_++;
                  }
                  Cpsv3Skin.sMapForFusion[Cpsv3Skin.sValues[_loc1_].toString()] = Cpsv3Skin.sValues[_loc1_];
               }
               _loc1_++;
            }
         }
         return Cpsv3Skin.sMapForFusion[this.toString()];
      }
      
      public function getInteractiveHDPosterDriveInfo() : Object
      {
         return Cpsv3SkinConfigInteractiveHDPosterDriveInfo.getData(this);
      }
      
      public function findRaceId(param1:int) : int
      {
         var _loc2_:Cpsv3AvailablePet = null;
         for each(_loc2_ in this._availablePets)
         {
            if(_loc2_.raceIdNeed == param1)
            {
               return _loc2_.raceId;
            }
         }
         return -1;
      }
      
      public function findRaceIdNeed(param1:int) : int
      {
         var _loc2_:Cpsv3AvailablePet = null;
         for each(_loc2_ in this._availablePets)
         {
            if(_loc2_.raceId == param1)
            {
               return _loc2_.raceIdNeed;
            }
         }
         return -1;
      }
      
      public function toString() : String
      {
         return "[Cpsv3SkinGroup index: " + this._index + ", name: " + this._name + "]";
      }
   }
}

