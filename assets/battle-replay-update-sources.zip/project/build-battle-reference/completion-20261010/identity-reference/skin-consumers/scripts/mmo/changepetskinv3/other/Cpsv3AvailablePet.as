package mmo.changepetskinv3.other
{
   import flash.utils.getDefinitionByName;
   import mmo.common.utils.dt.EnumSupport;
   import mmo.interfaces.changepetskin.IPetSkinAvailablePet;
   import mmo.interfaces.pet.data.IPetDictionaryDataService;
   import mmo.interfaces.pet.data.PetDictionaryDataItem;
   import mmo.play.globalfunctions.forSvc;
   
   public class Cpsv3AvailablePet implements IPetSkinAvailablePet
   {
      
      private static const ENUM_SUPPORT:EnumSupport = new EnumSupport();
      
      private static var sPetDicDataSvc:IPetDictionaryDataService = null;
      
      private var _skin:Cpsv3Skin;
      
      private var _index:int;
      
      private var _no:int;
      
      private var _raceId:int;
      
      private var _raceIdNeed:int;
      
      public function Cpsv3AvailablePet(param1:Object)
      {
         var _loc2_:String = null;
         super();
         ENUM_SUPPORT.check();
         for(_loc2_ in param1)
         {
            this["_" + _loc2_] = ENUM_SUPPORT.initField(this,param1,_loc2_);
         }
      }
      
      internal static function valuesFrom(param1:Cpsv3Skin, param2:Array) : Vector.<Cpsv3AvailablePet>
      {
         Cpsv3AvailablePet.ENUM_SUPPORT.lock = false;
         var _loc3_:Vector.<Cpsv3AvailablePet> = new Vector.<Cpsv3AvailablePet>(param2.length);
         var _loc4_:int = 0;
         while(_loc4_ < _loc3_.length)
         {
            _loc3_[_loc4_] = new Cpsv3AvailablePet(param2[_loc4_]);
            _loc3_[_loc4_]._index = _loc4_;
            _loc3_[_loc4_]._skin = param1;
            _loc4_++;
         }
         Cpsv3AvailablePet.ENUM_SUPPORT.lock = true;
         return _loc3_;
      }
      
      public function get raceId() : int
      {
         return this._raceId;
      }
      
      public function get raceIdNeed() : int
      {
         return this._raceIdNeed;
      }
      
      public function get dicData() : PetDictionaryDataItem
      {
         if(Cpsv3AvailablePet.sPetDicDataSvc == null)
         {
            Cpsv3AvailablePet.sPetDicDataSvc = forSvc(IPetDictionaryDataService);
         }
         return Cpsv3AvailablePet.sPetDicDataSvc.getDataItemByRaceId(this._raceId);
      }
      
      public function get dicDataNeed() : PetDictionaryDataItem
      {
         if(Cpsv3AvailablePet.sPetDicDataSvc == null)
         {
            Cpsv3AvailablePet.sPetDicDataSvc = forSvc(IPetDictionaryDataService);
         }
         return Cpsv3AvailablePet.sPetDicDataSvc.getDataItemByRaceId(this._raceIdNeed);
      }
   }
}

