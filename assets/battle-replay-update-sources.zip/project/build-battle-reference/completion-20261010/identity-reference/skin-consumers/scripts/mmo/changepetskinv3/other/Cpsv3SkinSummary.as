package mmo.changepetskinv3.other
{
   import mmo.changepetskinv3.model.Cpsv3IModel;
   
   public class Cpsv3SkinSummary
   {
      
      private static var sSkins:Vector.<Cpsv3Skin> = null;
      
      public function Cpsv3SkinSummary()
      {
         super();
      }
      
      private static function getSkins() : Vector.<Cpsv3Skin>
      {
         if(Cpsv3SkinSummary.sSkins == null)
         {
            Cpsv3SkinSummary.sSkins = Cpsv3Skin.values();
         }
         return Cpsv3SkinSummary.sSkins;
      }
      
      public static function computeOwnedNum(param1:Cpsv3IModel) : int
      {
         var _loc5_:Cpsv3Skin = null;
         var _loc2_:int = 0;
         var _loc3_:Vector.<Cpsv3Skin> = Cpsv3SkinSummary.getSkins();
         var _loc4_:int = 0;
         while(_loc4_ < _loc3_.length)
         {
            _loc5_ = _loc3_[_loc4_];
            if(Cpsv3SkinSummary.isInclusiveForComputing(_loc5_) && param1.hasGotSkin(_loc5_))
            {
               _loc2_ += 1;
            }
            _loc4_++;
         }
         return _loc2_;
      }
      
      public static function computeTotalNum() : int
      {
         var _loc4_:Cpsv3Skin = null;
         var _loc1_:int = 0;
         var _loc2_:Vector.<Cpsv3Skin> = Cpsv3SkinSummary.getSkins();
         var _loc3_:int = 0;
         while(_loc3_ < _loc2_.length)
         {
            _loc4_ = _loc2_[_loc3_];
            if(Cpsv3SkinSummary.isInclusiveForComputing(_loc4_))
            {
               _loc1_ += 1;
            }
            _loc3_++;
         }
         return _loc1_;
      }
      
      private static function isInclusiveForComputing(param1:Cpsv3Skin) : Boolean
      {
         return param1.isShow() && !param1.isFusionPoster() && param1.xChangeableDependentId == -1;
      }
      
      public static function findOriginalRaceId(param1:int) : int
      {
         var _loc3_:int = 0;
         var _loc2_:Cpsv3Skin = Cpsv3Skin.valueOfRaceId(param1);
         if(_loc2_ == null)
         {
            if(Cpsv3SkinSummary.isAnySkinNeedThisRaceId(param1))
            {
               return param1;
            }
         }
         else
         {
            if(_loc2_.isFusionPoster())
            {
               return -1;
            }
            _loc3_ = _loc2_.findRaceIdNeed(param1);
            if(_loc3_ != -1)
            {
               return _loc3_;
            }
         }
         return -1;
      }
      
      private static function isAnySkinNeedThisRaceId(param1:int) : Boolean
      {
         var _loc4_:Cpsv3Skin = null;
         var _loc2_:Vector.<Cpsv3Skin> = Cpsv3SkinSummary.getSkins();
         var _loc3_:int = 0;
         while(_loc3_ < _loc2_.length)
         {
            _loc4_ = _loc2_[_loc3_];
            if(!_loc4_.isFusionPoster() && _loc4_.findRaceId(param1) != -1)
            {
               return true;
            }
            _loc3_++;
         }
         return false;
      }
      
      public static function getGroup(param1:int) : Vector.<Cpsv3Skin>
      {
         var _loc4_:Cpsv3Skin = null;
         var _loc2_:Vector.<Cpsv3Skin> = Cpsv3SkinSummary.getSkins();
         var _loc3_:int = 0;
         while(_loc3_ < _loc2_.length)
         {
            _loc4_ = _loc2_[_loc3_];
            if(!(_loc4_.isFusionPoster() || !_loc4_.isShow()))
            {
               if(_loc4_.findRaceId(param1) != -1)
               {
                  return _loc4_.groupInner;
               }
            }
            _loc3_++;
         }
         return null;
      }
      
      public static function getRaceIds(param1:int, param2:Boolean, param3:Boolean) : Array
      {
         var _loc8_:Cpsv3Skin = null;
         var _loc9_:int = 0;
         var _loc10_:Array = null;
         var _loc11_:int = 0;
         var _loc4_:int = Cpsv3SkinSummary.findOriginalRaceId(param1);
         if(_loc4_ == -1)
         {
            return null;
         }
         var _loc5_:Array = [];
         var _loc6_:Vector.<Cpsv3Skin> = Cpsv3SkinSummary.getSkins();
         var _loc7_:int = 0;
         while(_loc7_ < _loc6_.length)
         {
            _loc8_ = _loc6_[_loc7_];
            if(!_loc8_.isShow())
            {
               if(_loc8_.findRaceIdNeed(param1) != -1)
               {
                  return null;
               }
            }
            else
            {
               _loc9_ = _loc8_.findRaceId(_loc4_);
               if(_loc9_ != -1)
               {
                  _loc5_.push(_loc9_);
               }
               if(param3)
               {
                  _loc10_ = _loc8_.getXChangeableRaceIds(_loc4_);
                  if(_loc10_ != null)
                  {
                     _loc11_ = 1;
                     while(_loc11_ < _loc10_.length)
                     {
                        _loc5_.push(_loc10_[_loc11_]);
                        _loc11_++;
                     }
                  }
               }
            }
            _loc7_++;
         }
         if(_loc5_.length == 0)
         {
            return null;
         }
         if(!param2)
         {
            return _loc5_;
         }
         return [_loc4_].concat(_loc5_);
      }
   }
}

