package mmo.changepetskinv3.other.outer
{
   import mmo.changepetskinv3.other.Cpsv3Skin;
   import mmo.common.shareobject.LocalStore;
   import mmo.common.user.UserInfo;
   import mmo.interfaces.changepetskin.IPetSkin;
   import mmo.interfaces.changepetskin.IPetSkinMultiForm;
   
   public class Cpsv3SkinMultiFormImpl implements IPetSkinMultiForm
   {
      
      private var _base:Cpsv3Skin;
      
      public function Cpsv3SkinMultiFormImpl()
      {
         super();
      }
      
      public static function valueFrom(param1:Cpsv3Skin) : Cpsv3SkinMultiFormImpl
      {
         var _loc2_:Cpsv3SkinMultiFormImpl = new Cpsv3SkinMultiFormImpl();
         _loc2_._base = param1;
         return _loc2_;
      }
      
      public function get base() : IPetSkin
      {
         return this._base;
      }
      
      public function get changeableRaceIds() : Array
      {
         return this._base.changeableRaceIds;
      }
      
      public function get changeableRaceIdsExcludeBase() : Array
      {
         return this._base.changeableRaceIds.slice(1);
      }
      
      public function get changeableNames() : Array
      {
         return this._base.changeableNames;
      }
      
      public function isChangeableWithMovie() : Boolean
      {
         return this._base.isChangeableWithMovie();
      }
      
      public function getCurrentRaceId(param1:int) : int
      {
         var _loc2_:Array = this.changeableRaceIds;
         var _loc3_:String = this.getKey(param1);
         var _loc4_:Object = LocalStore.getValue(_loc3_,UserInfo.userName);
         if(_loc4_ == null)
         {
            return _loc2_[0];
         }
         var _loc5_:int = parseInt(String(_loc4_));
         if(_loc2_.indexOf(_loc5_) == -1)
         {
            return _loc2_[0];
         }
         return _loc5_;
      }
      
      public function setCurrentRaceId(param1:int, param2:int) : void
      {
         LocalStore.setValue(this.getKey(param1),String(param2),UserInfo.userName);
      }
      
      private function getKey(param1:int) : String
      {
         return "changepetskinv3_lslbioem_" + param1;
      }
   }
}

