package mmo.pettitle.movie
{
   import flash.display.MovieClip;
   
   [Embed(source="/_assets/assets.swf", symbol="symbol11")]
   public dynamic class TitleMovie32 extends MovieClip
   {
      
      public var spFont:MovieClip;
      
      public function TitleMovie32()
      {
         super();
      }
   }
}

