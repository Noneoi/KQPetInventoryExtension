package mmo.pettitle.movie
{
   import flash.display.MovieClip;
   
   [Embed(source="/_assets/assets.swf", symbol="symbol15")]
   public dynamic class TitleMovie38 extends MovieClip
   {
      
      public var spFont:MovieClip;
      
      public function TitleMovie38()
      {
         super();
      }
   }
}

