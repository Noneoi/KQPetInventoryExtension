package mmo.pettitle.movie
{
   import flash.display.MovieClip;
   
   [Embed(source="/_assets/assets.swf", symbol="symbol1")]
   public dynamic class TitleMovie8 extends MovieClip
   {
      
      public function TitleMovie8()
      {
         super();
      }
   }
}

