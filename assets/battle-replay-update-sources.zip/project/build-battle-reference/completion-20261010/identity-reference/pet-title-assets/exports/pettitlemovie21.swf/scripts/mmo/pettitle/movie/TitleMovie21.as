package mmo.pettitle.movie
{
   import flash.display.MovieClip;
   
   [Embed(source="/_assets/assets.swf", symbol="symbol10")]
   public dynamic class TitleMovie21 extends MovieClip
   {
      
      public var spFont:MovieClip;
      
      public function TitleMovie21()
      {
         super();
      }
   }
}

