package mmo.pettitle.movie
{
   import flash.display.MovieClip;
   
   [Embed(source="/_assets/assets.swf", symbol="symbol6")]
   public dynamic class TitleMovie27 extends MovieClip
   {
      
      public var spFont:MovieClip;
      
      public function TitleMovie27()
      {
         super();
      }
   }
}

