package mmo.pettitle.movie
{
   import flash.display.MovieClip;
   
   [Embed(source="/_assets/assets.swf", symbol="symbol16")]
   public dynamic class TitleMovie16 extends MovieClip
   {
      
      public var spFont:MovieClip;
      
      public function TitleMovie16()
      {
         super();
      }
   }
}

