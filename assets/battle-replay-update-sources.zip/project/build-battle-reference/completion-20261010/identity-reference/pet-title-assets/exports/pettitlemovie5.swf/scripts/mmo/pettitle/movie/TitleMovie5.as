package mmo.pettitle.movie
{
   import flash.display.MovieClip;
   
   [Embed(source="/_assets/assets.swf", symbol="symbol1")]
   public dynamic class TitleMovie5 extends MovieClip
   {
      
      public function TitleMovie5()
      {
         super();
      }
   }
}

