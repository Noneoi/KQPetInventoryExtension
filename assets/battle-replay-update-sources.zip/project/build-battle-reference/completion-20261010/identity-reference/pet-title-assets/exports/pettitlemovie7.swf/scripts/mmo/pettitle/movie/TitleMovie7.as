package mmo.pettitle.movie
{
   import flash.display.MovieClip;
   
   [Embed(source="/_assets/assets.swf", symbol="symbol1")]
   public dynamic class TitleMovie7 extends MovieClip
   {
      
      public function TitleMovie7()
      {
         super();
      }
   }
}

