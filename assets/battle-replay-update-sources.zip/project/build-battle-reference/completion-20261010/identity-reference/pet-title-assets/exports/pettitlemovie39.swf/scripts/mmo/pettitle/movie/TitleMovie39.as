package mmo.pettitle.movie
{
   import flash.display.MovieClip;
   
   [Embed(source="/_assets/assets.swf", symbol="symbol9")]
   public dynamic class TitleMovie39 extends MovieClip
   {
      
      public var spFont:MovieClip;
      
      public function TitleMovie39()
      {
         super();
      }
   }
}

