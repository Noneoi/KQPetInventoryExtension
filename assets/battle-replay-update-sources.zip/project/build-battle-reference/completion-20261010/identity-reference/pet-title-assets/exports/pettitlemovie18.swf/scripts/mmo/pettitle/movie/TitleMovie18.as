package mmo.pettitle.movie
{
   import flash.display.MovieClip;
   
   [Embed(source="/_assets/assets.swf", symbol="symbol14")]
   public dynamic class TitleMovie18 extends MovieClip
   {
      
      public var spFont:MovieClip;
      
      public function TitleMovie18()
      {
         super();
      }
   }
}

