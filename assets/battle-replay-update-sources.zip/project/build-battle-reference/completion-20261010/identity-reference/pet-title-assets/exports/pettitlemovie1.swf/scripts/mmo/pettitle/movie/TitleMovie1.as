package mmo.pettitle.movie
{
   import flash.display.MovieClip;
   
   [Embed(source="/_assets/assets.swf", symbol="symbol10")]
   public dynamic class TitleMovie1 extends MovieClip
   {
      
      public var spFont:MovieClip;
      
      public function TitleMovie1()
      {
         super();
      }
   }
}

