package mmo.pettitle
{
   import flash.display.Sprite;
   import flash.events.EventDispatcher;
   import flash.system.ApplicationDomain;
   import mmo.interfaces.InitServiceEvent;
   import mmo.interfaces.material.MaterialViewContainer;
   import mmo.interfaces.pettitle.IPetTitleService;
   import mmo.pettitle.config.PetTitleBattleDemoConfig;
   import mmo.play.dialog.InteractUtil;
   
   public class PetTitleService extends EventDispatcher implements IPetTitleService
   {
      
      public function PetTitleService()
      {
         super();
      }
      
      public function init() : void
      {
         dispatchEvent(new InitServiceEvent(InitServiceEvent.onInited,{}));
      }
      
      public function showMainPanel() : void
      {
      }
      
      public function showCollectionPanel(param1:int = 0) : void
      {
      }
      
      public function getTitleMovie(param1:int, param2:Number = 0, param3:Number = 0, param4:ApplicationDomain = null, param5:Function = null) : Sprite
      {
         var afterLoad:Function = null;
         var titleId:int = param1;
         var width:Number = param2;
         var height:Number = param3;
         var domain:ApplicationDomain = param4;
         var callback:Function = param5;
         afterLoad = function(param1:MaterialViewContainer):void
         {
            if(callback != null)
            {
               if(callback.length == 0)
               {
                  InteractUtil.applyCallback(callback);
               }
               else
               {
                  InteractUtil.applyCallback(callback,[param1]);
               }
            }
         };
         var movieUrl:String = "pettitle/movie/pettitlemovie" + titleId;
         var movieCls:String = "mmo.pettitle.movie.TitleMovie" + titleId;
         return new MaterialViewContainer(titleId,movieCls,movieUrl,afterLoad,null,width,height,true,domain);
      }
      
      public function playTitleBattleDemo(param1:int, param2:Function = null) : void
      {
         var _loc3_:Object = PetTitleBattleDemoConfig.BATTLE_DEMOS[param1.toString()];
         if(_loc3_ == null)
         {
            throw new Error("PetTitleBattleDemoConfig.as:称号" + param1 + "对应的战斗录像没有找到配置!");
         }
         PetTitleBattleDemoConfig.playBattle(_loc3_,param2);
      }
   }
}

