package mmo.formation
{
   import flash.display.MovieClip;
   import flash.display.Sprite;
   import flash.events.Event;
   import flash.system.ApplicationDomain;
   import flash.utils.getDefinitionByName;
   import mmo.common.ProgressFullSprite;
   import mmo.common.shareobject.LocalStore;
   import mmo.common.user.UserInfo;
   import mmo.common.utils.tips.TipsManager;
   import mmo.formation.config.FormationDiverseConfig;
   import mmo.formation.config.HeroSkillConfig;
   import mmo.formation.formationimage.FormationImageHelper;
   import mmo.formation.heroskill.FormationHeroSkillHelper;
   import mmo.formation.mainpanel.BattleItemPanel;
   import mmo.formation.mainpanel.MainPanel;
   import mmo.formation.mainv2.FormationMainPanel;
   import mmo.formation.mainv3.FormationMainPanelV3;
   import mmo.formation.study.StudyAndChallengePanel;
   import mmo.formation.study.StudyPanel;
   import mmo.formation.upgradepanel.UpgradePanel;
   import mmo.interfaces.IService;
   import mmo.interfaces.ServiceContainer;
   import mmo.interfaces.battleconfig.IBattleConfig;
   import mmo.interfaces.battleconfig.define.SkillDefine;
   import mmo.interfaces.formation.Formation;
   import mmo.interfaces.formation.FormationBase;
   import mmo.interfaces.formation.FormationEvent;
   import mmo.interfaces.formation.FormationImage;
   import mmo.interfaces.formation.FormationImageParams;
   import mmo.interfaces.formation.FormationPetInfo;
   import mmo.interfaces.formation.HeroSkillDefine;
   import mmo.interfaces.formation.IFormationService;
   import mmo.interfaces.formationpanel.IFormationPanelService;
   import mmo.interfaces.formationpanelv2.IFormationPanelServiceV2;
   import mmo.interfaces.formationpanelv3.IFormationPanelServiceV3;
   import mmo.interfaces.pet.data.IPetDataService;
   import mmo.interfaces.rentpet.IRentPetService;
   import mmo.interfaces.rentpet.RentPetInfo;
   import mmo.interfaces.rentpet.SystemRentPetType;
   import mmo.interfaces.task.ITaskHelper;
   import mmo.interfaces.task.ITaskService;
   import mmo.interfaces.task.TaskEvent;
   import mmo.interfaces.task.TaskEventDispatcher;
   import mmo.interfaces.task.data.UserTask;
   import mmo.loader.CustomLoader;
   import mmo.loader.CustomLoaderEvent;
   import mmo.loader.LoadingSpriteType;
   import mmo.loader.scheduler.ResPriority;
   import mmo.play.globalfunctions.forSvc;
   import mmo.play.log.Log;
   
   public class FormationManager
   {
      
      private static var _instance:FormationManager;
      
      private static const INIT_POOL_SIZE:int = 20;
      
      public var formationService:IFormationService = ServiceContainer.getService("FormationService") as IFormationService;
      
      private var taskArray:Array = [7,8,9,98,288,291,421,578];
      
      private var mainPanel:MainPanel;
      
      private var mHasTacticalMovieLoaded:Boolean = false;
      
      private var _currentTaskId:int;
      
      public function FormationManager(param1:SingletonEnforcer)
      {
         super();
      }
      
      public static function get instance() : FormationManager
      {
         if(_instance == null)
         {
            _instance = new FormationManager(new SingletonEnforcer());
         }
         return _instance;
      }
      
      private static function getPetBriefInfo(param1:int, param2:Boolean, param3:SystemRentPetType) : Object
      {
         return FormationBase.getPetBriefInfo(param1,param2,param3);
      }
      
      public function showMainPanel(param1:Boolean, param2:Boolean, param3:Array = null, param4:int = 0, param5:SystemRentPetType = null) : void
      {
         if(param1)
         {
            if(param4 == 0)
            {
               this.showMainPanelByTabId(1,param2,param3);
            }
            else if(param4 == 1)
            {
               this.showMainPanelV2(0,param2,param3,param5);
            }
            else if(param4 == 2)
            {
               this.showMainPanelV3(param2,param5);
            }
         }
         else
         {
            this.showBattleItemPanel();
         }
      }
      
      public function showMainPanelFlexibly() : void
      {
         if(FormationData.instance.isUsingV3Panel())
         {
            this.showMainPanelV3();
         }
         else
         {
            this.showMainPanelV2();
         }
      }
      
      public function showMainPanelFlexiblyPVP() : void
      {
         if(FormationData.instance.isUsingV3Panel())
         {
            this.showMainPanelV3(true,SystemRentPetType.PVP);
         }
         else
         {
            this.showMainPanelV2(0,true,null,SystemRentPetType.PVP);
         }
      }
      
      public function showBattleItemPanel(param1:int = 0) : void
      {
         var _loc2_:ApplicationDomain = new ApplicationDomain();
         new BattleItemPanel(param1,_loc2_).show(_loc2_);
      }
      
      public function showMainPanelV2(param1:int = 0, param2:Boolean = true, param3:Array = null, param4:SystemRentPetType = null) : void
      {
         var tabId:int = param1;
         var isShowBorrowedPet:Boolean = param2;
         var needShow:Array = param3;
         var borrowPetType:SystemRentPetType = param4;
         if(FormationDiverseConfig.isVersionOn() && FormationDiverseConfig.inDiverse(FormationData.instance.currentFormationId))
         {
            this.showMainPanelV3(isShowBorrowedPet,borrowPetType);
            return;
         }
         ProgressFullSprite.show();
         ServiceContainer.tryGetService(IFormationPanelServiceV2,function():void
         {
            ProgressFullSprite.close();
            var _loc1_:ApplicationDomain = new ApplicationDomain();
            new FormationMainPanel(_loc1_,tabId,isShowBorrowedPet,needShow,borrowPetType).show(_loc1_);
         });
      }
      
      public function showMainPanelV3(param1:Boolean = true, param2:SystemRentPetType = null) : void
      {
         var isShowBorrowedPet:Boolean = param1;
         var borrowPetType:SystemRentPetType = param2;
         if(!FormationDiverseConfig.isVersionOn())
         {
            this.showMainPanelV2(0,isShowBorrowedPet,null,borrowPetType);
            return;
         }
         ProgressFullSprite.show();
         forSvc(IFormationPanelServiceV3,function(param1:IFormationPanelServiceV3):void
         {
            ProgressFullSprite.close();
            new FormationMainPanelV3(isShowBorrowedPet,borrowPetType).showPanel();
         });
      }
      
      public function showMainPanelByTabId(param1:int, param2:Boolean = true, param3:Array = null) : void
      {
         var tabId:int = param1;
         var isShowBorrowedPet:Boolean = param2;
         var needShow:Array = param3;
         var downLoadList:Array = ["formation/mainpanel_res","formationpanel/formationpanel_res","formation/formation_tip"];
         downLoadList = this.checkLoadFormationCommon(downLoadList);
         var clsName:String = "mmo.formation.mainpanel.MainPanel_res";
         var callback:Function = function():void
         {
            var onLoadedService:Function;
            var SERVICE_NUM:* = new Namespace("");
            var semaphore:int = 0;
            ProgressFullSprite.show();
            SERVICE_NUM = 2;
            semaphore = 0;
            onLoadedService = function(param1:IService, param2:Object):void
            {
               ++semaphore;
               if(semaphore == SERVICE_NUM)
               {
                  ProgressFullSprite.close();
                  mainPanel = new MainPanel(tabId,isShowBorrowedPet,needShow);
                  mainPanel.addEventListener(Event.REMOVED_FROM_STAGE,onRemoveMainPanel);
                  mainPanel.show();
               }
            };
            ServiceContainer.tryGetService(IFormationPanelService,onLoadedService);
            ServiceContainer.tryGetService(IBattleConfig,onLoadedService);
         };
         this.loadRes(downLoadList,clsName,callback);
      }
      
      private function onRemoveMainPanel(param1:Event) : void
      {
         if(this.mainPanel != null)
         {
            this.mainPanel.removeEventListener(Event.REMOVED_FROM_STAGE,this.onRemoveMainPanel);
            this.mainPanel = null;
         }
      }
      
      public function removeMainPanel() : void
      {
         if(this.mainPanel == null)
         {
            return;
         }
         if(this.mainPanel.isShowing)
         {
            this.mainPanel.onClose(null);
         }
      }
      
      public function showStudyPanel() : void
      {
         var downLoadList:Array = ["formation/study_res"];
         var clsName:String = "mmo.formation.study.StudyPanel_res";
         var callback:Function = function():*
         {
            var _loc1_:StudyPanel = new StudyPanel();
            _loc1_.show();
         };
         this.loadRes(downLoadList,clsName,callback);
      }
      
      public function showUpgradePanel(param1:int) : void
      {
         var downLoadList:Array;
         var clsName:String;
         var callback:Function;
         var currentFormationId:int = param1;
         ProgressFullSprite.show();
         downLoadList = ["formation/upgradepanel_res"];
         downLoadList = this.checkLoadFormationCommon(downLoadList);
         clsName = "mmo.formation.upgradepanel.UpgradePanel_res";
         callback = function():*
         {
            var _loc1_:UpgradePanel = new UpgradePanel();
            _loc1_.show(currentFormationId);
            ProgressFullSprite.close();
         };
         this.loadRes(downLoadList,clsName,callback);
      }
      
      public function getFormationImageByParam(param1:FormationImageParams) : void
      {
         this.checkAndSetMyFormation(param1);
         param1.formation.updateFormationPetArray();
         FormationBase.fixFormation(param1.formation);
         FormationImageHelper.instance.getFormationImage(param1);
      }
      
      public function setFormationImage(param1:FormationImageParams) : void
      {
         this.checkAndSetMyFormation(param1);
         param1.formation.updateFormationPetArray();
         FormationBase.fixFormation(param1.formation);
         FormationImageHelper.instance.setFormationImage(param1);
      }
      
      public function checkAndSetMyFormation(param1:FormationImageParams) : void
      {
         var _loc2_:Array = null;
         var _loc3_:Array = null;
         var _loc4_:int = 0;
         var _loc5_:int = 0;
         var _loc6_:Object = null;
         if(param1.myFormationId > 0)
         {
            param1.formation = FormationData.instance.getMyFormation(param1.myFormationId);
            param1.formation = (param1.formation as Formation).clone();
         }
         else
         {
            param1.formation = param1.formation.cloneBase();
         }
         if(param1.myFormationId > 0 || param1.formation.petArray == null)
         {
            _loc2_ = [];
            _loc3_ = param1.formation.getPetSeries();
            _loc4_ = 0;
            while(_loc4_ < _loc3_.length)
            {
               _loc5_ = int(_loc3_[_loc4_]);
               if(_loc5_ > 0)
               {
                  _loc6_ = getPetBriefInfo(_loc5_,param1.isShowRentPet,param1.rentPetType);
                  (_loc6_) && _loc2_.push(_loc6_);
               }
               _loc4_++;
            }
            param1.formation.petArray = _loc2_;
         }
         if(param1.myFormationId > 0 && !param1.isShowRentPet)
         {
            FormationHelper.removeRentPetFromPs(param1.formation as Formation,param1.formation.petArray);
         }
      }
      
      public function setOtherFormationImage(param1:Sprite, param2:int, param3:int, param4:String, param5:Array, param6:int = 0, param7:Boolean = false, param8:Boolean = false, param9:Boolean = false, param10:int = 0, param11:Object = null) : void
      {
         var _loc14_:* = undefined;
         var _loc12_:FormationImageParams = new FormationImageParams();
         var _loc13_:Object = {};
         if(param11 != null)
         {
            for(_loc14_ in param11)
            {
               _loc13_[_loc14_] = param11[_loc14_];
            }
         }
         _loc13_["id"] = param2;
         _loc13_["level"] = param3;
         _loc13_["ps"] = param4;
         _loc13_["pets"] = param5;
         _loc13_["heroSkill"] = param6;
         _loc13_["psychiscSkill"] = param10;
         _loc12_.container = param1;
         _loc12_.needHpGray = param7;
         _loc12_.needHpBar = param8;
         _loc12_.iconReversal = param9;
         _loc12_.isAddToImg = true;
         _loc12_.isShowPsychicsSkill = param10 > 0;
         _loc12_.isShowHeroSkill = param6 > 0;
         _loc12_.formation = FormationBase.create(_loc13_);
         FormationImageHelper.instance.setFormationImage(_loc12_);
      }
      
      private function checkLoadFormationCommon(param1:Array) : Array
      {
         if(!ApplicationDomain.currentDomain.hasDefinition("mmo.formation.FormationImage_res"))
         {
            param1.push("formation/formationcommon_res");
         }
         return param1;
      }
      
      private function loadRes(param1:Array, param2:String, param3:Function, param4:Object = null) : void
      {
         var customLoader:CustomLoader = null;
         var fun:Function = null;
         var downLoadList:Array = param1;
         var className:String = param2;
         var callback:Function = param3;
         var params:Object = param4;
         if(ApplicationDomain.currentDomain.hasDefinition(className))
         {
            callback.apply(null,params);
            return;
         }
         ProgressFullSprite.show();
         customLoader = new CustomLoader(ResPriority.NORMAL,false,ApplicationDomain.currentDomain);
         fun = function(param1:CustomLoaderEvent):void
         {
            customLoader.removeEventListener(CustomLoaderEvent.onLoadCompleted,fun);
            callback.apply(null,params);
            ProgressFullSprite.close();
         };
         customLoader.addEventListener(CustomLoaderEvent.onLoadCompleted,fun);
         customLoader.load(downLoadList,LoadingSpriteType.NONE);
      }
      
      public function getFormationImage(param1:Sprite, param2:int, param3:int) : void
      {
         var container:Sprite = param1;
         var id:int = param2;
         var level:int = param3;
         var downLoadList:Array = [];
         downLoadList = this.checkLoadFormationCommon(downLoadList);
         var callback:Function = function():*
         {
            var _loc1_:Sprite = new FormationImage(id,level);
            container.addChild(_loc1_);
            formationService.dispatchEvent(new FormationEvent(FormationEvent.DOWNLOAD_FORMATIONIMAGE_SUC,null));
         };
         if(downLoadList.length == 0)
         {
            callback.apply();
         }
         else
         {
            this.loadRes(downLoadList,"mmo.formation.FormationImage_res",callback);
         }
      }
      
      public function showTacticalZoneMov() : void
      {
         var downLoadList:Array = null;
         var clsName:String = null;
         var key:String = "tacticalZoneMov";
         var localObject:Object = LocalStore.getValue(key,UserInfo.userName);
         if(localObject == null)
         {
            this.mHasTacticalMovieLoaded = false;
            LocalStore.setValue(key,true,UserInfo.userName);
            downLoadList = ["formation/studymovie_res"];
            clsName = "mmo.formation.StudyMovie_res";
            this.loadRes(downLoadList,clsName,function():*
            {
               var cls:Class = getDefinitionByName(clsName) as Class;
               var mov:MovieClip = new cls();
               var taskHelper:ITaskHelper = ServiceContainer.getService(ITaskHelper);
               taskHelper.playMovie(mov,function():*
               {
                  TaskEventDispatcher.instance.dispatchEvent(new TaskEvent(TaskEvent.ON_TACTICALZONE_MOV_FINISH,{}));
               },0,0);
            });
         }
         else
         {
            this.mHasTacticalMovieLoaded = true;
         }
      }
      
      public function showStudyAndChallengePanel(param1:int) : void
      {
         var formationId:int = param1;
         var downLoadList:Array = ["formation/study_res"];
         var clsName:String = "mmo.formation.study.StudyPanel_res";
         var callback:Function = function():*
         {
            var _loc1_:StudyAndChallengePanel = new StudyAndChallengePanel(taskArray,formationId);
            _loc1_.show();
            startStudyTask(formationId);
         };
         this.loadRes(downLoadList,clsName,callback);
      }
      
      private function startStudyTask(param1:int) : void
      {
         var _loc2_:ITaskService = ServiceContainer.getService(ITaskService) as ITaskService;
         var _loc3_:int = int(this.taskArray[param1 - 1]);
         var _loc4_:UserTask = _loc2_.getUserTask(_loc3_);
         if(_loc4_ == null)
         {
            ProgressFullSprite.show(false);
            this._currentTaskId = _loc3_;
            TaskEventDispatcher.instance.addEventListener(TaskEvent.ON_USER_TASK_ADD,this.onUserTaskAdd);
            _loc2_.startTask(_loc3_);
         }
      }
      
      private function onUserTaskAdd(param1:TaskEvent) : void
      {
         var _loc2_:UserTask = UserTask(param1.params.t);
         if(_loc2_.taskId == this._currentTaskId)
         {
            ProgressFullSprite.close();
            TaskEventDispatcher.instance.removeEventListener(TaskEvent.ON_USER_TASK_ADD,this.onUserTaskAdd);
         }
      }
      
      public function hasTacticalZoneMovieLoaded() : Boolean
      {
         return this.mHasTacticalMovieLoaded;
      }
      
      public function isHeroSkillEffect(param1:int, param2:int, param3:Array, param4:Function = null) : Boolean
      {
         var _loc5_:Array = HeroSkillConfig.getHeroSkillDefinesById(param2);
         var _loc6_:int = 0;
         while(_loc6_ < _loc5_.length)
         {
            if(FormationHeroSkillHelper.instance.isEffect(param1,_loc5_[_loc6_],param3,param4))
            {
               return true;
            }
            _loc6_++;
         }
         return false;
      }
      
      public function isHeroSkillShow(param1:int, param2:int, param3:Array, param4:Function = null) : Boolean
      {
         var _loc5_:Array = HeroSkillConfig.getShowHeroSkillDefinesById(param2);
         var _loc6_:int = 0;
         while(_loc6_ < _loc5_.length)
         {
            if(FormationHeroSkillHelper.instance.isEffect(param1,_loc5_[_loc6_],param3,param4))
            {
               return true;
            }
            _loc6_++;
         }
         return false;
      }
      
      public function getHeroSkillTips(param1:int, param2:IBattleConfig, param3:Array = null, param4:Function = null, param5:Boolean = true) : String
      {
         var defines:Array;
         var hasMulti:Boolean;
         var skillDefine:SkillDefine;
         var description:String = null;
         var descriptionArr:Array = null;
         var map:Object = null;
         var i:int = 0;
         var obj:Object = null;
         var define:HeroSkillDefine = null;
         var desc:String = null;
         var heroSkillId:int = param1;
         var battleConfig:IBattleConfig = param2;
         var petList:Array = param3;
         var attributeFunc:Function = param4;
         var withEffect:Boolean = param5;
         if(petList == null)
         {
            petList = [];
            withEffect = false;
         }
         else
         {
            petList = FormationHeroSkillHelper.toInputPetArray(petList);
         }
         defines = HeroSkillConfig.getShowHeroSkillDefinesById(heroSkillId);
         hasMulti = defines.some(function(param1:HeroSkillDefine, ... rest):Boolean
         {
            return param1.isMutilSkill;
         });
         skillDefine = battleConfig.getSkillDefineById(heroSkillId);
         if(hasMulti)
         {
            description = "";
            descriptionArr = skillDefine.description.split("\n@\n");
            descriptionArr = descriptionArr.map(function(param1:String, ... rest):Object
            {
               var _loc3_:* = param1.split("^");
               return {
                  "mutilIndex":_loc3_[0],
                  "desc":_loc3_[1]
               };
            });
            map = {};
            defines.forEach(function(param1:HeroSkillDefine, ... rest):void
            {
               map[param1.mutilIndex] = param1;
            });
            i = 0;
            while(i < descriptionArr.length)
            {
               obj = descriptionArr[i];
               define = map[obj["mutilIndex"]];
               if(map.hasOwnProperty(define.mutilIndex.toString()))
               {
                  desc = obj["desc"];
                  if(!define.isBase && withEffect)
                  {
                     if(FormationHeroSkillHelper.instance.heroSkillCanEffect(define,petList,attributeFunc))
                     {
                        description += desc.replace("@触发@","<font color=\'#FF0000\'>【已触发】</font>");
                     }
                     else
                     {
                        desc = desc.replace("@触发@","【未触发】").replace(/color=\'#[0-9a-zA-Z]+\'/g,"color=\'#CCCCCC\'");
                        description += "<font color=\'#CCCCCC\'>" + desc + "</font>";
                     }
                  }
                  else
                  {
                     description += desc.replace("@触发@","");
                  }
                  if(descriptionArr.length - 1 != i)
                  {
                     description += "\n" + "------------------";
                  }
                  description += "\n";
               }
               i++;
            }
            return description;
         }
         return skillDefine.description;
      }
      
      public function addV2FormationTips(param1:Sprite, param2:FormationPetInfo = null, param3:Object = null) : void
      {
         var downLoadList:Array;
         var clsName:String;
         var callback:Function;
         var icon:Sprite = param1;
         var formationPetInfo:FormationPetInfo = param2;
         var extObject:Object = param3;
         var eventParams:Object = {
            "icon":icon,
            "formationPetInfo":formationPetInfo,
            "extObject":extObject,
            "source":"addV2FormationTips",
            "cancel":false
         };
         this.formationService.dispatchEvent(new FormationEvent(FormationEvent.ON_ADD_FORMATION_TIPS,eventParams));
         if(eventParams["cancel"] == true)
         {
            return;
         }
         TipsManager.getInstance().removeTips(icon);
         downLoadList = ["formation/formation_tip"];
         clsName = "mmo.formation.NewFormationTipRes";
         callback = function():void
         {
            var _loc1_:String = null;
            var _loc2_:String = null;
            var _loc3_:String = null;
            var _loc4_:FormationTipsHelperV2 = null;
            var _loc5_:Boolean = false;
            var _loc6_:int = 0;
            var _loc7_:Boolean = false;
            if(formationPetInfo == null)
            {
               if(extObject != null && extObject.hasOwnProperty("name"))
               {
                  _loc1_ = extObject["name"];
                  _loc2_ = extObject["level"];
                  _loc3_ = _loc1_;
                  if(_loc2_ != null)
                  {
                     _loc3_ = _loc3_ + " Lv" + _loc2_;
                  }
                  TipsManager.getInstance().addTips(icon,_loc3_);
               }
            }
            else
            {
               _loc4_ = new FormationTipsHelperV2();
               _loc5_ = extObject != null ? Boolean(extObject["notShowSkill"]) : true;
               _loc6_ = extObject != null && extObject.hasOwnProperty("extraAttribute") ? int(extObject["extraAttribute"]) : -1;
               _loc7_ = extObject != null && extObject.hasOwnProperty("isShowCarryPanel") ? Boolean(extObject["isShowCarryPanel"]) : false;
               _loc4_.buildTipsHelper(icon,formationPetInfo,_loc6_,_loc7_);
               _loc4_.updateTips(_loc5_);
            }
         };
         this.loadRes(downLoadList,clsName,callback);
      }
      
      public function addFormationTips(param1:Sprite, param2:FormationPetInfo = null, param3:Boolean = false, param4:Object = null) : void
      {
         var downLoadList:Array;
         var clsName:String;
         var callback:Function;
         var icon:Sprite = param1;
         var formationPetInfo:FormationPetInfo = param2;
         var hasBuffTips:Boolean = param3;
         var extObject:Object = param4;
         var eventParams:Object = {
            "icon":icon,
            "formationPetInfo":formationPetInfo,
            "extObject":extObject,
            "source":"addFormationTips",
            "cancel":false
         };
         this.formationService.dispatchEvent(new FormationEvent(FormationEvent.ON_ADD_FORMATION_TIPS,eventParams));
         if(eventParams["cancel"] == true)
         {
            return;
         }
         Log.d("FormationManager","addFormationTips()");
         TipsManager.getInstance().removeTips(icon);
         downLoadList = ["formation/formation_tip"];
         clsName = "mmo.formation.NewFormationTipRes";
         callback = function():*
         {
            var _loc1_:String = null;
            var _loc2_:String = null;
            var _loc3_:String = null;
            var _loc4_:Array = null;
            var _loc5_:Array = null;
            var _loc6_:int = 0;
            var _loc7_:Boolean = false;
            var _loc8_:FormationTipsHelper = null;
            var _loc9_:int = 0;
            if(formationPetInfo == null)
            {
               if(extObject != null && extObject.hasOwnProperty("name"))
               {
                  _loc1_ = extObject["name"];
                  _loc2_ = extObject["level"];
                  _loc3_ = _loc1_;
                  if(_loc2_ != null)
                  {
                     _loc3_ = _loc3_ + " Lv" + _loc2_;
                  }
                  TipsManager.getInstance().addTips(icon,_loc3_);
               }
            }
            else if(extObject != null)
            {
               _loc4_ = extObject["formationPetInfoArray"];
               _loc5_ = extObject["psArray"];
               _loc6_ = int(extObject["formationId"]);
               _loc7_ = Boolean(extObject["notShowSkill"]);
               _loc8_ = new FormationTipsHelper();
               if(_loc5_ == null)
               {
                  _loc5_ = [];
               }
               _loc9_ = extObject.hasOwnProperty("extraAttribute") ? int(extObject["extraAttribute"]) : -1;
               _loc8_.buildTipsHelper(icon,formationPetInfo,false,_loc4_,_loc9_);
               _loc8_.updateTips(_loc5_,_loc6_,true,_loc7_);
            }
         };
         this.loadRes(downLoadList,clsName,callback);
      }
      
      public function showTips(param1:Sprite, param2:FormationPetInfo) : void
      {
         var _loc4_:String = null;
         if(param2 == null)
         {
            return;
         }
         if(param2.maxHp == 0)
         {
            return;
         }
         var _loc3_:* = FormationPetInfo.getFormationPetInfoDetailTip(param2);
         _loc4_ = param2.name;
         TipsManager.getInstance().removeTips(param1);
         TipsManager.getInstance().addComplexTipsByRes(param1,_loc4_,_loc3_,"mmo.stargod.CommonTips_res");
      }
      
      public function isPetOnCurrentFormation(param1:int) : Boolean
      {
         var _loc2_:IPetDataService = ServiceContainer.getService(IPetDataService);
         var _loc3_:Array = _loc2_.getMyPets();
         var _loc4_:Array = [];
         var _loc5_:int = 0;
         while(_loc5_ < _loc3_.length)
         {
            _loc4_.push(FormationHelper.petBriefInfo2formationPetInfo(_loc3_[_loc5_]));
            _loc5_++;
         }
         var _loc6_:IRentPetService = ServiceContainer.getService(IRentPetService);
         var _loc7_:RentPetInfo = _loc6_.getRentPetInfo();
         if(_loc7_ != null)
         {
            _loc4_.push(FormationHelper.petBriefInfo2formationPetInfo(_loc7_.getBriefInfo()));
         }
         var _loc8_:int = FormationData.instance.currentFormationId;
         var _loc9_:int = FormationData.instance.currentFormationPlanId;
         return this.isPetOnFormation(param1,_loc4_,FormationData.instance.getMyFormation(_loc8_,_loc9_).ps);
      }
      
      private function isPetOnFormation(param1:int, param2:Array, param3:String) : Boolean
      {
         var _loc7_:int = 0;
         var _loc8_:FormationPetInfo = null;
         var _loc4_:Array = param3.split("#");
         var _loc5_:Array = this.handlePetList(param2);
         var _loc6_:int = 0;
         while(_loc6_ < _loc4_.length)
         {
            _loc7_ = parseInt(_loc4_[_loc6_]);
            if(_loc7_ > 0)
            {
               _loc8_ = this.getFormationPetInfoByPetId(_loc7_,_loc5_);
               if(_loc8_ != null && _loc8_.raceId == param1)
               {
                  return true;
               }
            }
            _loc6_++;
         }
         return false;
      }
      
      private function handlePetList(param1:Array) : Array
      {
         var _loc4_:FormationPetInfo = null;
         var _loc5_:FormationPetInfo = null;
         var _loc2_:Array = [];
         var _loc3_:int = 0;
         while(_loc3_ < param1.length)
         {
            _loc4_ = param1[_loc3_];
            if(_loc4_.summonedPetId > 0 && _loc4_.summonedPetFormationPetInfo == null)
            {
               _loc4_.summonedPetFormationPetInfo = this.getPetInArr(_loc4_.summonedPetId,param1);
            }
            if(_loc4_.summonerId > 0 && _loc4_.summonerRaceId < 0)
            {
               _loc5_ = this.getPetInArr(_loc4_.summonerId,param1);
               if(_loc5_ != null)
               {
                  _loc4_.summonerRaceId = _loc5_.raceId;
               }
            }
            _loc2_.push(_loc4_);
            _loc3_++;
         }
         return _loc2_;
      }
      
      private function getPetInArr(param1:int, param2:Array) : FormationPetInfo
      {
         var _loc4_:FormationPetInfo = null;
         var _loc3_:int = 0;
         while(_loc3_ < param2.length)
         {
            _loc4_ = param2[_loc3_];
            if(_loc4_.id == param1)
            {
               return _loc4_;
            }
            _loc3_++;
         }
         return null;
      }
      
      private function getFormationPetInfoByPetId(param1:int, param2:Array) : FormationPetInfo
      {
         var _loc3_:int = 0;
         while(_loc3_ < param2.length)
         {
            if(FormationPetInfo(param2[_loc3_]).id == param1)
            {
               return param2[_loc3_];
            }
            if(FormationPetInfo(param2[_loc3_]).summonedPetFormationPetInfo != null && FormationPetInfo(param2[_loc3_]).summonedPetFormationPetInfo.id == param1)
            {
               return FormationPetInfo(param2[_loc3_]).summonedPetFormationPetInfo;
            }
            _loc3_++;
         }
         return null;
      }
   }
}

class SingletonEnforcer
{
   
   public function SingletonEnforcer()
   {
      super();
   }
}
