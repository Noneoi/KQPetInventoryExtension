package mmo.formation.config
{
   import mmo.interfaces.formation.FormationTeamBuff;
   import mmo.interfaces.formation.FormationTeamBuffEffect;
   import mmo.interfaces.formation.FormationTeamBuffFormationEffect;
   
   public class FormationTeamBuffConfig
   {
      
      public static const buffs:Object = {
         1:new FormationTeamBuff(1,"梦之队精灵",[[192],[193],[198],[208],[215],[990]],[new FormationTeamBuffEffect(2,["物防+300,魔防+300"]),new FormationTeamBuffEffect(3,["物防+300,魔防+300,物攻+300,魔攻+300"]),new FormationTeamBuffEffect(4,["物防+300,魔防+300,物攻+300,魔攻+300,超攻+400"]),new FormationTeamBuffEffect(5,["物防+300,魔防+300,物攻+300,魔攻+300,超攻+400,生命+500"])]),
         2:new FormationTeamBuff(2,"铁三角",[[120001,120002,120003],[120004,120005,120006],[120007,120008,120009]],[new FormationTeamBuffEffect(3,["物攻+200,生命+200","物攻+500,生命+500"])]),
         3:new FormationTeamBuff(3,"奥运宝贝",[[120236],[120248],[120233],[120214],[120230]],[new FormationTeamBuffEffect(2,["生命+300,物防+300,魔防+300"]),new FormationTeamBuffEffect(3,["生命+500,物防+400,魔防+400"]),new FormationTeamBuffEffect(4,["生命+1000,物防+500,魔防+500"]),new FormationTeamBuffEffect(5,["生命+1500,物防+600,魔防+600"])]),
         4:new FormationTeamBuff(4,"伊莫团队",[[340],[341],[342],[354],[355],[367],[411],[412],[413],[414],[415],[416],[640],[641]],[new FormationTeamBuffEffect(2,["觉醒概率+5%,物防+400,魔防+300"]),new FormationTeamBuffEffect(3,["觉醒概率+10%,物防+400,魔防+300,物攻+300,魔攻+400"]),new FormationTeamBuffEffect(4,["觉醒概率+15%,物防+400,魔防+300,物攻+300,魔攻+400,超防+400"]),new FormationTeamBuffEffect(5,["觉醒概率+20%,物防+400,魔防+300,物攻+300,魔攻+400,超防+400,生命+500"])]),
         5:new FormationTeamBuff(5,"铁木阵",[[443,442],[445,444]],[new FormationTeamBuffEffect(2,["生命+2000,格挡率+30%"])]),
         6:new FormationTeamBuff(6,"威震天下",[[474,473,472],[483,482,481],[488,487,486],[491,490,489],[494,493,492]],[new FormationTeamBuffEffect(2,["减伤5%,魔防+200,生命+200"]),new FormationTeamBuffEffect(3,["减伤10%,魔防+300,生命+300"]),new FormationTeamBuffEffect(4,["减伤15%,魔防+500,生命+500"]),new FormationTeamBuffEffect(5,["减伤20%,魔防+800,生命+800"])]),
         7:new FormationTeamBuff(7,"星辉守护者团队",[[553,552],[555,554],[557,556],[559,558],[561,560],[563,562],[803,802],[567,566],[569,568],[571,570],[573,572]],[new FormationTeamBuffEffect(2,["星辉概率+10%,物攻+200,魔攻+200,生命+200"]),new FormationTeamBuffEffect(3,["星辉概率+15%,物攻+300,魔攻+300,物防+300,生命+300"]),new FormationTeamBuffEffect(4,["星辉概率+20%,物攻+400,魔攻+400,物防+400,魔防+400,生命+400"]),new FormationTeamBuffEffect(5,["星辉概率+30%,物攻+600,魔攻+600,物防+600,魔防+600,生命+1200"])]),
         8:new FormationTeamBuff(8,"不差钱团队",[[609,608],[611,610]],[new FormationTeamBuffEffect(2,["伤害+20%"])]),
         9:new FormationTeamBuff(9,"守护星之队",[[597],[600],[617],[620],[639]],[new FormationTeamBuffEffect(2,["暴击率+2%,生命+100"]),new FormationTeamBuffEffect(3,["暴击率+4%,魔攻+200,生命+200"]),new FormationTeamBuffEffect(4,["暴击率+6%,魔攻+300,格挡率+4%,生命+300"]),new FormationTeamBuffEffect(5,["暴击率+10%,魔攻+500,格挡率+8%,闪避+5%,生命+600"])]),
         10:new FormationTeamBuff(10,"金银二将",[[660,659,658],[663,662,661]],[new FormationTeamBuffEffect(2,["生命+1000,魔攻+500,物攻+500"])]),
         11:new FormationTeamBuff(11,"龙城六灵",[[697,696],[706,705],[716,715],[735,734],[741,740],[743,742]],[new FormationTeamBuffEffect(2,["生命+200,物攻+200,物防+200"]),new FormationTeamBuffEffect(3,["生命+300,物攻+300,物防+300,魔防+300"]),new FormationTeamBuffEffect(4,["生命+500,物攻+400,物防+400,魔攻+400,魔防+400"]),new FormationTeamBuffEffect(5,["生命+800,物攻+500,物防+500,魔攻+500,魔防+500,超防+500,超攻+500"])]),
         12:new FormationTeamBuff(12,"创世团队",[[795],[794,793],[763,762],[771,770],[782,781]],[new FormationTeamBuffEffect(2,["进入创世领域概率+10%,生命+200"]),new FormationTeamBuffEffect(3,["进入创世领域概率+30%,生命+400"]),new FormationTeamBuffEffect(4,["进入创世领域概率+50%,生命+700"]),new FormationTeamBuffEffect(5,["进入创世领域概率+70%,生命+1000"])]),
         13:new FormationTeamBuff(13,"克斯军团",[[172,171,170],[266,265,264],[580,579,578],[655,654,653],[807,806],[814,813],[936,935]],[new FormationTeamBuffEffect(2,["物攻+200,魔攻+200,生命+200"]),new FormationTeamBuffEffect(3,["物攻+300,魔攻+300,生命+400,物防+300"]),new FormationTeamBuffEffect(4,["物攻+400,魔攻+400,生命+600,物防+400,魔防+400"]),new FormationTeamBuffEffect(5,["物攻+500,魔攻+500,生命+800,物防+500,魔防+500"])]),
         14:new FormationTeamBuff(14,"奥义·梦之队",[[804],[819],[832],[834],[841],[991]],[new FormationTeamBuffEffect(2,["物防+300,魔防+300,生命+300"]),new FormationTeamBuffEffect(3,["物防+400,魔防+400,物攻+400,魔攻+400,生命+400"]),new FormationTeamBuffEffect(4,["物防+500,魔防+500,物攻+500,魔攻+500,超攻+500,生命+500"]),new FormationTeamBuffEffect(5,["物防+600,魔防+600,物攻+600,魔攻+600,超攻+600,生命+1000,伤害+10%"])]),
         15:new FormationTeamBuff(15,"磁铁兄弟",[[889,888],[874,873]],[new FormationTeamBuffEffect(2,["生命+1000,物攻+500,物防+500"])]),
         16:new FormationTeamBuff(16,"圣骑战队",[[867],[872],[898],[911],[920],[1507]],[new FormationTeamBuffEffect(2,["每次出手恢复自身气势5点"]),new FormationTeamBuffEffect(3,["每次出手恢复自身气势10点"]),new FormationTeamBuffEffect(4,["每次出手恢复自身气势15点"]),new FormationTeamBuffEffect(5,["每次出手恢复自身气势20点"])]),
         17:new FormationTeamBuff(17,"超级主宠战队",[[934],[941],[953],[1003],[1083]],[new FormationTeamBuffEffect(2,["生命+300,物防+300,魔防+300"]),new FormationTeamBuffEffect(3,["生命+600,物防+400,魔防+400,物攻+400"]),new FormationTeamBuffEffect(4,["生命+1000,物防+600,魔防+600,物攻+600,超攻+600"]),new FormationTeamBuffEffect(5,["生命+1500,物防+800,魔防+800,物攻+800,超攻+800,超防+800"])],[new FormationTeamBuffFormationEffect(1,5,"战队特技:当超级主宠战队5只精灵在格挡阵时,生命+1000")]),
         18:new FormationTeamBuff(18,"忍者神喵队",[[955],[956],[964],[965],[957],[978]],[new FormationTeamBuffEffect(2,["对BOSS伤害增加30%"]),new FormationTeamBuffEffect(3,["对BOSS伤害增加40%"]),new FormationTeamBuffEffect(4,["对BOSS伤害增加50%"]),new FormationTeamBuffEffect(5,["对BOSS伤害增加60%"])]),
         19:new FormationTeamBuff(19,"机甲兄弟",[[963,962],[1008,1007],[1053,1052]],[new FormationTeamBuffEffect(2,["对BOSS伤害增加20%"]),new FormationTeamBuffEffect(3,["对BOSS伤害增加30%"])]),
         20:new FormationTeamBuff(20,"圣界守护团",[[1012],[1016],[1027],[1030],[1041],[1051]],[new FormationTeamBuffEffect(2,["生命+300,物攻+300,物防+300"]),new FormationTeamBuffEffect(3,["生命+500,物攻+400,物防+400,魔攻+400,魔防+400"]),new FormationTeamBuffEffect(4,["生命+800,物攻+500,物防+500,魔攻+500,魔防+500,超攻+500"]),new FormationTeamBuffEffect(5,["生命+1000,物攻+600,物防+600,魔攻+600,魔防+600,超攻+600,超防+600"])]),
         21:new FormationTeamBuff(21,"心之战甲团队",[[1070],[1078],[1089],[1127],[1157]],[new FormationTeamBuffEffect(2,["对BOSS伤害增加30%"]),new FormationTeamBuffEffect(3,["对BOSS伤害增加40%"]),new FormationTeamBuffEffect(4,["对BOSS伤害增加50%"]),new FormationTeamBuffEffect(5,["对BOSS伤害增加60%"])]),
         22:new FormationTeamBuff(22,"冰火双狮",[[1093,1092],[1082,1081]],[new FormationTeamBuffEffect(2,["生命+1000,物攻+600,超攻+600"])]),
         23:new FormationTeamBuff(23,"侠客二人组",[[1175,1174],[1182,1181]],[new FormationTeamBuffEffect(2,["生命+600,物攻+600"])]),
         24:new FormationTeamBuff(24,"马到成功",[[1102,1101],[1180,1179],[1340],[1372],[1433]],[new FormationTeamBuffEffect(2,["对BOSS伤害增加30%"]),new FormationTeamBuffEffect(3,["对BOSS伤害增加40%"]),new FormationTeamBuffEffect(4,["对BOSS伤害增加50%"]),new FormationTeamBuffEffect(5,["对BOSS伤害增加70%"])]),
         25:new FormationTeamBuff(25,"神使团队",[[1249],[1260],[1289],[1298],[1316]],[new FormationTeamBuffEffect(2,["生命+1500,物攻+800"]),new FormationTeamBuffEffect(3,["生命+1500,物攻+800,物防+800"]),new FormationTeamBuffEffect(4,["生命+1500,物攻+800,物防+800,超攻+800"]),new FormationTeamBuffEffect(5,["生命+1500,物攻+800,物防+800,超攻+800,超防+800"])]),
         26:new FormationTeamBuff(26,"学霸团队",[[1281],[1291],[1311],[1321],[1330]],[new FormationTeamBuffEffect(2,["对BOSS伤害增加30%"]),new FormationTeamBuffEffect(3,["对BOSS伤害增加40%"]),new FormationTeamBuffEffect(4,["对BOSS伤害增加50%"]),new FormationTeamBuffEffect(5,["对BOSS伤害增加70%"])]),
         27:new FormationTeamBuff(27,"神属奥义梦之队",[[1343],[1349],[1355],[1364],[1370],[1388]],[new FormationTeamBuffEffect(2,["物防+300,魔防+300,生命+300"]),new FormationTeamBuffEffect(3,["物防+400,魔防+400,物攻+400,魔攻+400,生命+400"]),new FormationTeamBuffEffect(4,["物防+500,魔防+500,物攻+500,魔攻+500,超攻+500,生命+500"]),new FormationTeamBuffEffect(5,["物防+600,魔防+600,物攻+600,魔攻+600,超攻+600,生命+1000,减伤+10%"])]),
         28:new FormationTeamBuff(28,"神属梦2队",[[1381],[1383],[1385],[1402],[1411]],[new FormationTeamBuffEffect(2,["物防+300,魔防+300,生命+300"]),new FormationTeamBuffEffect(3,["物防+400,魔防+400,物攻+400,魔攻+400,生命+400"]),new FormationTeamBuffEffect(4,["物防+500,魔防+500,物攻+500,魔攻+500,超攻+500,生命+500"]),new FormationTeamBuffEffect(5,["物防+600,魔防+600,物攻+600,魔攻+600,超攻+600,生命+1000,伤害+10%"])]),
         29:new FormationTeamBuff(29,"神属冰火双狮团队",[[1391],[1409]],[new FormationTeamBuffEffect(2,["生命+1200,物攻+800,超攻+800"])]),
         30:new FormationTeamBuff(30,"神属圣骑战队",[[1464],[1468],[1477],[1490],[1498],[1508]],[new FormationTeamBuffEffect(2,["生命+500，每次出手恢复自身气势5点"]),new FormationTeamBuffEffect(3,["生命+1000，每次出手恢复自身气势10点"]),new FormationTeamBuffEffect(4,["生命+1500，每次出手恢复自身气势15点"]),new FormationTeamBuffEffect(5,["生命+2000，每次出手恢复自身气势20点"])]),
         31:new FormationTeamBuff(31,"神属忍者神喵团队",[[1526],[1527],[1537],[1547],[1552],[1557]],[new FormationTeamBuffEffect(2,["对BOSS伤害增加35%"]),new FormationTeamBuffEffect(3,["对BOSS伤害增加45%"]),new FormationTeamBuffEffect(4,["对BOSS伤害增加55%"]),new FormationTeamBuffEffect(5,["对BOSS伤害增加65%"])]),
         32:new FormationTeamBuff(32,"神属守护星团队",[[1584],[1588],[1592],[1600],[1604]],[new FormationTeamBuffEffect(2,["生命+200，暴击率+2%"]),new FormationTeamBuffEffect(3,["生命+300，暴击率+4%，魔攻+200"]),new FormationTeamBuffEffect(4,["生命+400，暴击率+6%，魔攻+300，格挡率+4%"]),new FormationTeamBuffEffect(5,["生命+800，格挡率+8%，暴击率+10%，闪避+5%，魔攻+500"])]),
         33:new FormationTeamBuff(33,"神属铁木阵",[[1611],[1615]],[new FormationTeamBuffEffect(2,["生命+2500,格挡率+35%"])]),
         34:new FormationTeamBuff(34,"天罡四方团队",[[1583],[1587],[1599],[1614],[1619]],[new FormationTeamBuffEffect(4,["全阵精灵生命增加3000点，随机提升30%物攻，魔攻和超攻中的一种"]),new FormationTeamBuffEffect(5,["全阵精灵生命增加3000点，随机提升30%物攻，魔攻和超攻中的一种"])]),
         35:new FormationTeamBuff(35,"战羊一族团队",[[1605],[1624],[1646],[1647],[1648]],[new FormationTeamBuffEffect(2,["对BOSS伤害增加35%"]),new FormationTeamBuffEffect(3,["对BOSS伤害增加45%"]),new FormationTeamBuffEffect(4,["对BOSS伤害增加55%"]),new FormationTeamBuffEffect(5,["对BOSS伤害增加75%"])]),
         36:new FormationTeamBuff(36,"超进化梦之队",[[1718],[1721],[1723],[1725],[1728],[1732]],[new FormationTeamBuffEffect(2,["物防+300,魔防+300,生命+300"]),new FormationTeamBuffEffect(3,["物防+400,魔防+400,物攻+400,魔攻+400,生命+400"]),new FormationTeamBuffEffect(4,["物防+500,魔防+500,物攻+500,魔攻+500,超攻+500,生命+500"]),new FormationTeamBuffEffect(5,["物防+600,魔防+600,物攻+600,魔攻+600,超攻+600,生命+1000,减伤10%"])])
      };
      
      public function FormationTeamBuffConfig()
      {
         super();
      }
   }
}

