package mmo.interfaces.formation
{
   public class FormationTeamBuff
   {
      
      public var buffId:int;
      
      public var buffName:String;
      
      public var petArray:Array = [];
      
      public var formationEffectArray:Array = [];
      
      public var effectArray:Array = [];
      
      public var effectIndex:int;
      
      public function FormationTeamBuff(param1:int, param2:String, param3:Array, param4:Array, param5:Array = null, param6:int = 0)
      {
         super();
         this.buffId = param1;
         this.buffName = param2;
         this.petArray = param3;
         this.effectArray = param4;
         this.formationEffectArray = param5;
         this.effectIndex = param6;
      }
   }
}

