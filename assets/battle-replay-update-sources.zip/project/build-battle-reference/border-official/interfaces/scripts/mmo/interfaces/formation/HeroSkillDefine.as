package mmo.interfaces.formation
{
   import mmo.common.utils.petrace.PetRaceUtil;
   import mmo.interfaces.ServiceContainer;
   import mmo.interfaces.pet.data.IPetDictionaryDataService;
   import mmo.interfaces.pet.data.PetDictionaryDataItem;
   import mmo.interfaces.pet.data.PetJob;
   
   public class HeroSkillDefine implements IHeroSkillDefine
   {
      
      private var _zhandouli1:Number;
      
      private var _zhandouli2:Number;
      
      private var _cls:String;
      
      private var _clsParams:String;
      
      private var _preCls:String;
      
      private var _preClsParams:String;
      
      private var _preIncludeSummonPet:String;
      
      private var _id:int;
      
      private var _type:int;
      
      private var _isShow:Boolean;
      
      private var _mutilIndex:int;
      
      public function HeroSkillDefine(param1:int, param2:Number, param3:Number, param4:int, param5:String, param6:String, param7:int, param8:String = null, param9:String = null, param10:String = null, param11:int = 0)
      {
         super();
         this._zhandouli1 = param2;
         this._zhandouli2 = param3;
         this._cls = param5;
         this._clsParams = param6;
         this._preCls = param8;
         this._preClsParams = param9;
         this._preIncludeSummonPet = param10;
         this._id = param1;
         this._type = param4;
         this._isShow = Boolean(param7);
         this._mutilIndex = param11;
      }
      
      public function get id() : int
      {
         return this._id;
      }
      
      public function get isShow() : Boolean
      {
         return this._isShow;
      }
      
      public function get type() : int
      {
         return this._type;
      }
      
      public function isSuper() : Boolean
      {
         var _loc1_:int = this._id % 10000;
         var _loc2_:IPetDictionaryDataService = ServiceContainer.getService(IPetDictionaryDataService);
         var _loc3_:PetDictionaryDataItem = _loc2_.getDataItemByRaceId(_loc1_);
         if(_loc3_ == null)
         {
            return false;
         }
         return _loc3_.jobE == PetJob.GOD_PHYSICS_SUPER_HERO || _loc3_.jobE == PetJob.GOD_MAGIC_SUPER_HERO || _loc3_.jobE2 == PetJob.GOD_PHYSICS_SUPER_HERO || _loc3_.jobE2 == PetJob.GOD_MAGIC_SUPER_HERO;
      }
      
      public function get zhandouli1() : Number
      {
         return this._zhandouli1;
      }
      
      public function get zhandouli2() : Number
      {
         return this._zhandouli2;
      }
      
      public function get cls() : String
      {
         return this._cls;
      }
      
      public function get clsParams() : String
      {
         var _loc1_:int = 0;
         var _loc2_:Array = null;
         if(this._cls == "RaceEffected")
         {
            _loc1_ = parseInt(String(this._clsParams).split(",")[0]);
            _loc2_ = PetRaceUtil.getAllSkinAndPetRaceIds([_loc1_]);
            return _loc2_.join(",");
         }
         return this._clsParams;
      }
      
      public function get preCls() : String
      {
         return this._preCls;
      }
      
      public function get preClsParams() : String
      {
         return this._preClsParams;
      }
      
      public function get preIncludeSummonPet() : String
      {
         return this._preIncludeSummonPet;
      }
      
      public function get mutilIndex() : int
      {
         return this._mutilIndex;
      }
      
      public function get isMutilSkill() : Boolean
      {
         return this._mutilIndex > 0;
      }
      
      public function get isBase() : Boolean
      {
         return this._mutilIndex == 1;
      }
   }
}

