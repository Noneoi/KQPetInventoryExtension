package mmo.interfaces.formation
{
   public class FormationTeamBuffEffect
   {
      
      public var petNum:int;
      
      public var effect:Array;
      
      public function FormationTeamBuffEffect(param1:int, param2:Array)
      {
         super();
         this.petNum = param1;
         this.effect = param2;
      }
   }
}

