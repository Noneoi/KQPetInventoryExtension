package mmo.interfaces.formation
{
   public class FormationTeamBuffFormationEffect
   {
      
      public var formationId:int;
      
      public var petNum:int;
      
      public var effect:String;
      
      public function FormationTeamBuffFormationEffect(param1:int, param2:int, param3:String)
      {
         super();
         this.formationId = param1;
         this.petNum = param2;
         this.effect = param3;
      }
   }
}

