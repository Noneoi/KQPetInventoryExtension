package mmo.interfaces.formation
{
   public class PsychicsSkillDefine extends HeroSkillDefine
   {
      
      private var _nPsychicsCalledPetRaceId:int;
      
      public function PsychicsSkillDefine(param1:int, param2:Number, param3:Number, param4:int, param5:String, param6:String, param7:int, param8:String = null, param9:String = null, param10:String = null, param11:int = 0)
      {
         this._nPsychicsCalledPetRaceId = param11;
         super(param1,param2,param3,param4,param5,param6,param7,param8,param9,param10);
      }
      
      public function get psychicsCalledPetRaceId() : int
      {
         return this._nPsychicsCalledPetRaceId;
      }
   }
}

