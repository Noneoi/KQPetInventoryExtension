package mmo.interfaces.battle.data
{
   public class BufferItemResult
   {
      
      protected var _itemId:int;
      
      protected var _teamId:int;
      
      protected var _sourcePlayerName:String;
      
      protected var _sourcePlayerId:int;
      
      protected var _itemTargetResults:Array = [];
      
      public function BufferItemResult()
      {
         super();
      }
      
      public static function parseServerResponce(param1:Object) : BufferItemResult
      {
         var _loc5_:Object = null;
         var _loc6_:BufferItemTargetResult = null;
         if(param1 == null)
         {
            return null;
         }
         var _loc2_:BufferItemResult = new BufferItemResult();
         _loc2_._itemId = int(param1.i);
         _loc2_._teamId = int(param1.c.ti);
         _loc2_._sourcePlayerName = String(param1.c.pn);
         _loc2_._sourcePlayerId = int(param1.c.pi);
         var _loc3_:Array = param1.c.tl;
         var _loc4_:int = 0;
         while(_loc4_ < _loc3_.length)
         {
            _loc5_ = _loc3_[_loc4_];
            _loc6_ = BufferItemTargetResult.parseServerResponce(_loc5_);
            _loc2_._itemTargetResults.push(_loc6_);
            _loc4_++;
         }
         return _loc2_;
      }
      
      public function get itemId() : int
      {
         return this._itemId;
      }
      
      public function get teamId() : int
      {
         return this._teamId;
      }
      
      public function get sourcePlayerName() : String
      {
         return this._sourcePlayerName;
      }
      
      public function get sourcePlayerId() : int
      {
         return this._sourcePlayerId;
      }
      
      public function get itemTargetResults() : Array
      {
         return this._itemTargetResults;
      }
   }
}

