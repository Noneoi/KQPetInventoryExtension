package mmo.interfaces.battle.data
{
   public class CatchPetInfo
   {
      
      private var _nId:int;
      
      private var _nRaceId:int;
      
      private var _sName:String;
      
      private var _nLevel:int;
      
      private var _nGift:int;
      
      private var _nGender:int;
      
      private var _starGodPower:int;
      
      private var _starGodSlotSeq:String;
      
      public function CatchPetInfo()
      {
         super();
      }
      
      public static function parseServerResponce(param1:Object) : CatchPetInfo
      {
         var _loc2_:CatchPetInfo = new CatchPetInfo();
         _loc2_._nId = param1.id;
         _loc2_._nRaceId = param1.r;
         _loc2_._sName = param1.n;
         _loc2_._nLevel = param1.lv;
         _loc2_._nGift = param1.gt;
         _loc2_._nGender = param1.g;
         _loc2_._starGodPower = param1.sgp;
         _loc2_._starGodSlotSeq = param1.sgs;
         return _loc2_;
      }
      
      public function get id() : int
      {
         return this._nId;
      }
      
      public function get raceId() : int
      {
         return this._nRaceId;
      }
      
      public function get name() : String
      {
         return this._sName;
      }
      
      public function get level() : int
      {
         return this._nLevel;
      }
      
      public function get gift() : int
      {
         return this._nGift;
      }
      
      public function get gender() : int
      {
         return this._nGender;
      }
      
      public function get starGodPower() : int
      {
         return this._starGodPower;
      }
      
      public function get starGodSlotSeq() : String
      {
         return this._starGodSlotSeq;
      }
   }
}

