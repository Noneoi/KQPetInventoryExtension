package mmo.interfaces.battle.data
{
   public class SkillNumUnitNothing extends SkillNumUnitTiming
   {
      
      public function SkillNumUnitNothing()
      {
         super();
      }
      
      public static function parseServerResponce(param1:Object) : SkillNumUnitNothing
      {
         var _loc2_:SkillNumUnitNothing = new SkillNumUnitNothing();
         parseServerResponceNothing(_loc2_,param1);
         return _loc2_;
      }
      
      protected static function parseServerResponceNothing(param1:SkillNumUnitNothing, param2:Object) : void
      {
         parseServerResponceTiming(param1,param2);
      }
   }
}

