package mmo.interfaces.battle.data
{
   import mmo.common.SplitUtil;
   
   public class BufferItemTargetResult
   {
      
      protected var _hit:Boolean;
      
      protected var _buffIds:Array = [];
      
      protected var _maxHp:int;
      
      protected var _curHp:int;
      
      protected var _teamId:int;
      
      protected var _playerName:String;
      
      protected var _playerId:int;
      
      protected var _characterId:int;
      
      public function BufferItemTargetResult()
      {
         super();
      }
      
      public static function parseServerResponce(param1:Object) : BufferItemTargetResult
      {
         if(param1 == null)
         {
            return null;
         }
         var _loc2_:BufferItemTargetResult = new BufferItemTargetResult();
         _loc2_._hit = param1.h;
         _loc2_._buffIds = SplitUtil.splitToInt(String(param1.bs),",");
         _loc2_._maxHp = param1.mhp;
         _loc2_._curHp = param1.chp;
         _loc2_._teamId = param1.ti;
         _loc2_._playerName = param1.pn;
         _loc2_._playerId = param1.pi;
         _loc2_._characterId = param1.ci;
         return _loc2_;
      }
      
      public function get hit() : Boolean
      {
         return this._hit;
      }
      
      public function get buffIds() : Array
      {
         return this._buffIds;
      }
      
      public function get maxHp() : int
      {
         return this._maxHp;
      }
      
      public function get curHp() : int
      {
         return this._curHp;
      }
      
      public function get teamId() : int
      {
         return this._teamId;
      }
      
      public function get playerName() : String
      {
         return this._playerName;
      }
      
      public function get playerId() : int
      {
         return this._playerId;
      }
      
      public function get characterId() : int
      {
         return this._characterId;
      }
   }
}

