package mmo.interfaces.battle.data
{
   public class LeagueArsenalResult
   {
      
      private var _buffId:int;
      
      private var _buffLv:int;
      
      private var _cnt:int;
      
      public function LeagueArsenalResult()
      {
         super();
      }
      
      public static function parseServerResponce(param1:Object) : LeagueArsenalResult
      {
         if(param1 == null)
         {
            return null;
         }
         var _loc2_:LeagueArsenalResult = new LeagueArsenalResult();
         _loc2_._buffId = param1["wi"];
         _loc2_._buffLv = param1["bl"];
         _loc2_._cnt = param1["num"];
         return _loc2_;
      }
      
      public function get cnt() : int
      {
         return this._cnt;
      }
      
      public function get buffId() : int
      {
         return this._buffId;
      }
      
      public function get buffLv() : int
      {
         return this._buffLv;
      }
   }
}

