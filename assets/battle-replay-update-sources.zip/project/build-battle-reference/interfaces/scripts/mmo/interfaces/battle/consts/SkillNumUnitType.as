package mmo.interfaces.battle.consts
{
   public class SkillNumUnitType
   {
      
      public static const TRANSFORM:int = 1;
      
      public static const VALUE_UPDATE:int = 2;
      
      public static const SUMMON:int = 3;
      
      public static const BUFF_STATE_CHANGE:int = 4;
      
      public static const SELF_REPLICATION:int = 5;
      
      public static const TRANSFORM_ATTR:int = 6;
      
      public static const BUFF_ADDING:int = 100;
      
      public static const BUFF_LAYERS_CHANGE:int = 101;
      
      public function SkillNumUnitType()
      {
         super();
      }
   }
}

