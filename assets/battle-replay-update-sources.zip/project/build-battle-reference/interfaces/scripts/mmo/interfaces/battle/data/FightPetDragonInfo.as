package mmo.interfaces.battle.data
{
   import com.adobe.utils.StringUtil;
   import mmo.interfaces.petdragon.PetDragonDefine;
   import mmo.interfaces.petdragon.PetDragonDefines;
   import mmo.interfaces.petdragon.PetDragonGene;
   import mmo.interfaces.petdragon.PetDragonInfo;
   import mmo.interfaces.petdragon.PetDragonLevel;
   import mmo.interfaces.petdragon.PetDragonLevelDefine;
   
   public class FightPetDragonInfo
   {
      
      private var dragonId:int;
      
      private var defineId:int;
      
      private var level:int;
      
      private var skillValue:int;
      
      private var executeBufferId:int;
      
      private var gene:PetDragonGene;
      
      private var computedSkillDescription:String = "";
      
      public function FightPetDragonInfo()
      {
         super();
      }
      
      public static function parseInfo(param1:Object) : FightPetDragonInfo
      {
         var _loc2_:FightPetDragonInfo = new FightPetDragonInfo();
         _loc2_.dragonId = param1["di"];
         _loc2_.defineId = param1["dfi"];
         _loc2_.level = param1["q"];
         _loc2_.skillValue = param1["nv"];
         _loc2_.gene = new PetDragonGene(param1["ge"] == null ? "" : param1["ge"]);
         _loc2_.executeBufferId = param1["dbfi"];
         return _loc2_;
      }
      
      public function getDragonId() : int
      {
         return this.dragonId;
      }
      
      public function getDefineId() : int
      {
         return this.defineId;
      }
      
      public function getName() : String
      {
         var _loc1_:PetDragonDefine = PetDragonDefines.DRAGON_DEFINES[this.defineId];
         return _loc1_.getName();
      }
      
      public function getLevel() : int
      {
         return this.level;
      }
      
      public function getExecuteBufferId() : int
      {
         return this.executeBufferId;
      }
      
      public function getLevelDescription() : String
      {
         switch(this.level)
         {
            case PetDragonLevel.S:
               return "S";
            case PetDragonLevel.A:
               return "A";
            case PetDragonLevel.B:
               return "B";
            case PetDragonLevel.C:
               return "C";
            default:
               return "";
         }
      }
      
      public function getGene() : PetDragonGene
      {
         return this.gene;
      }
      
      public function getSkillValue() : int
      {
         return this.skillValue;
      }
      
      public function isGlittery() : Boolean
      {
         return this.gene.isGlittery();
      }
      
      public function getSkillDescription() : String
      {
         var _loc1_:PetDragonDefine = null;
         var _loc2_:String = null;
         var _loc3_:RegExp = null;
         var _loc4_:int = 0;
         var _loc5_:int = 0;
         var _loc6_:String = null;
         var _loc7_:int = 0;
         if(StringUtil.isNullOrEmpty(this.computedSkillDescription))
         {
            _loc1_ = PetDragonDefines.DRAGON_DEFINES[this.defineId];
            _loc2_ = _loc1_.getSkillDescription();
            _loc3_ = /N/g;
            _loc2_ = _loc2_.replace(_loc3_,this.skillValue);
            _loc4_ = _loc2_.indexOf("[");
            _loc5_ = _loc2_.indexOf("]");
            while(_loc4_ != -1 && _loc5_ != -1)
            {
               _loc6_ = _loc2_.substring(_loc4_ + 1,_loc5_);
               _loc7_ = int(StringUtil.computeString(_loc6_));
               _loc2_ = _loc2_.replace("[" + _loc6_ + "]",_loc7_);
               _loc4_ = _loc2_.indexOf("[");
               _loc5_ = _loc2_.indexOf("]");
            }
            this.computedSkillDescription = _loc2_;
         }
         return this.computedSkillDescription;
      }
      
      public function getDragonPower() : int
      {
         var _loc5_:Number = NaN;
         var _loc1_:int = int(PetDragonLevelDefine.LEVEL_POWERS[this.level - 1]);
         var _loc2_:String = this.defineId + "_" + this.level;
         var _loc3_:PetDragonLevelDefine = PetDragonDefines.LEVEL_DEFINES[_loc2_];
         var _loc4_:int = (this.skillValue - _loc3_.getMinSkillValue()) / (_loc3_.getMaxSkillValue() - _loc3_.getMinSkillValue()) * 2000;
         if(this.isGlittery())
         {
            _loc5_ = 1.5;
         }
         else
         {
            _loc5_ = 1;
         }
         return (_loc1_ + _loc4_) * _loc5_;
      }
      
      public function clone() : FightPetDragonInfo
      {
         var _loc1_:FightPetDragonInfo = new FightPetDragonInfo();
         _loc1_.defineId = this.getDefineId();
         _loc1_.dragonId = this.getDragonId();
         _loc1_.level = this.getLevel();
         _loc1_.skillValue = this.getSkillValue();
         _loc1_.gene = this.getGene();
         _loc1_.executeBufferId = this.getExecuteBufferId();
         return _loc1_;
      }
      
      public function covert2PetDragonInfo() : PetDragonInfo
      {
         var _loc1_:Object = {};
         _loc1_["di"] = this.getDefineId();
         _loc1_["dfi"] = this.getDefineId();
         _loc1_["q"] = this.getLevel();
         _loc1_["nv"] = this.getSkillValue();
         _loc1_["ge"] = this.getGene().getGeneSequence();
         _loc1_["if"] = true;
         return PetDragonInfo.parseInfo(_loc1_);
      }
   }
}

