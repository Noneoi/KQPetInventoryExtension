package mmo.interfaces.battle.data
{
   public class CardFaceResult
   {
      
      private var _teamId:int;
      
      private var _serverId:int;
      
      private var _extData:String;
      
      public function CardFaceResult()
      {
         super();
      }
      
      public static function parseServerResponse(param1:Object) : CardFaceResult
      {
         var _loc2_:CardFaceResult = new CardFaceResult();
         _loc2_._teamId = param1["p"];
         _loc2_._serverId = param1["id"];
         _loc2_._extData = param1["c"];
         return _loc2_;
      }
      
      public function get teamId() : int
      {
         return this._teamId;
      }
      
      public function get serverId() : int
      {
         return this._serverId;
      }
      
      public function get extData() : String
      {
         return this._extData;
      }
   }
}

