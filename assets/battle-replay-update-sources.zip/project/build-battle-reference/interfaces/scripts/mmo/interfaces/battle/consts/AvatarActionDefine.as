package mmo.interfaces.battle.consts
{
   public class AvatarActionDefine
   {
      
      public static const STAND:int = 1;
      
      public static const BE_HIT:int = 2;
      
      public static const NORMAL_SKILL:int = 3;
      
      public static const UNIQUE_SKILL:int = 4;
      
      public function AvatarActionDefine()
      {
         super();
      }
   }
}

