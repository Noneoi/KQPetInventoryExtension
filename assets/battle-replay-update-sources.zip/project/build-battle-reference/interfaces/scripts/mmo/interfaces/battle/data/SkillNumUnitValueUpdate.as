package mmo.interfaces.battle.data
{
   public class SkillNumUnitValueUpdate extends SkillNumUnitTiming
   {
      
      protected var _nCurHp:int;
      
      protected var _nMaxHp:int;
      
      protected var _nOldCurHp:int;
      
      protected var _nOldMaxHp:int;
      
      public function SkillNumUnitValueUpdate()
      {
         super();
      }
      
      public static function parseServerResponce(param1:Object) : SkillNumUnitValueUpdate
      {
         var _loc2_:SkillNumUnitValueUpdate = new SkillNumUnitValueUpdate();
         parseServerResponceValueUpdate(_loc2_,param1);
         return _loc2_;
      }
      
      protected static function parseServerResponceValueUpdate(param1:SkillNumUnitValueUpdate, param2:Object) : void
      {
         parseServerResponceTiming(param1,param2);
         param1._nCurHp = int(param2["new_curv"]);
         param1._nMaxHp = int(param2["new_maxv"]);
         param1._nOldCurHp = int(param2["old_curv"]);
         param1._nOldMaxHp = int(param2["old_maxv"]);
      }
      
      public function get oldMaxHp() : int
      {
         return this._nOldMaxHp;
      }
      
      public function get oldCurHp() : int
      {
         return this._nOldCurHp;
      }
      
      public function get changedCurHp() : int
      {
         return this._nCurHp - this._nOldCurHp;
      }
      
      public function get changedMaxHp() : int
      {
         return this._nMaxHp - this._nOldMaxHp;
      }
      
      public function get curHp() : int
      {
         return this._nCurHp;
      }
      
      public function get maxHp() : int
      {
         return this._nMaxHp;
      }
   }
}

