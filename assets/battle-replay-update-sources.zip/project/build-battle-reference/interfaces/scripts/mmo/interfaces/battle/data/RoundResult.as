package mmo.interfaces.battle.data
{
   import mmo.interfaces.battleconfig.define.SkillExecuteDefine;
   
   public class RoundResult
   {
      
      private static const NORMAL_ROUND_RESULT:int = 1;
      
      protected var _nSourceTeamId:int;
      
      protected var _nSourcePlayerName:String;
      
      protected var _nSourceCharacterId:int;
      
      protected var _nSkillId:int;
      
      protected var _nSkillExecuteCode:int;
      
      protected var _bIsOverRoundLimit:Boolean;
      
      protected var _sourceSkillNumResult:SkillNumResult;
      
      protected var _arrTargetSkillResults:Array;
      
      protected var _arrTargetRepresenterResults:Array;
      
      protected var _nRoundNum:int;
      
      protected var _nPlayerRoundNum:int;
      
      protected var _isLastRound:Boolean = false;
      
      protected var _executeBufferId:int;
      
      protected var _executePetDragonIds:Array;
      
      private var _battleUnit:BattleUnit;
      
      private var _isFillWithMaxChangeSetId:Boolean = false;
      
      protected var _roundQueue:RoundQueue;
      
      protected var _bIsFromNormalQueue:Boolean = false;
      
      public function RoundResult()
      {
         super();
         this._roundQueue = new RoundQueue();
      }
      
      public static function parseServerResponce(param1:Object, param2:BattleUnit, param3:Boolean) : RoundResult
      {
         if(param1.orrt == NORMAL_ROUND_RESULT || param1.orrt == null)
         {
            return parseNormalRoundResult(param1,param2,param3);
         }
         return parseRepresenterServerResponce(param1,param2,param3);
      }
      
      public static function parseRepresenterServerResponce(param1:Object, param2:BattleUnit, param3:Boolean) : RoundResult
      {
         var _loc5_:Object = null;
         var _loc6_:SkillResult = null;
         var _loc4_:RoundResult = new RepresentRoundResult();
         _loc4_._nSourceTeamId = param1.cti ^ (param3 ? 1 : 0);
         _loc4_._nSourcePlayerName = param1.cpn;
         _loc4_._nSourceCharacterId = RepresentRoundResult.REPRESENTER_SOURCE_CHARACTER_ID;
         _loc4_._executeBufferId = param1.epbi;
         _loc4_._executePetDragonIds = param1.eps || [];
         _loc4_._nSkillId = 100001;
         _loc4_._nSkillExecuteCode = 1;
         _loc4_._bIsOverRoundLimit = param1.isor;
         _loc4_._sourceSkillNumResult = SkillNumResult.emptySkillNumResult;
         _loc4_._arrTargetSkillResults = [];
         for each(_loc5_ in param1.trl)
         {
            _loc6_ = SkillResult.parseServerResponce(_loc5_,param3);
            _loc4_._arrTargetSkillResults.push(_loc6_);
         }
         _loc4_._arrTargetRepresenterResults = [];
         for each(_loc5_ in param1.prl)
         {
            _loc6_ = SkillResult.parseServerResponce(_loc5_,param3);
            _loc4_._arrTargetRepresenterResults.push(_loc6_);
         }
         _loc4_._nRoundNum = param1.csn;
         _loc4_._nPlayerRoundNum = param1.hasOwnProperty("pr") ? int(param1.pr) : 0;
         _loc4_._battleUnit = param2;
         return _loc4_;
      }
      
      private static function parseNormalRoundResult(param1:Object, param2:BattleUnit, param3:Boolean) : RoundResult
      {
         var _loc5_:Object = null;
         var _loc6_:SkillResult = null;
         var _loc4_:RoundResult = new RoundResult();
         _loc4_._nSourceTeamId = param1.cti ^ (param3 ? 1 : 0);
         _loc4_._nSourcePlayerName = param1.cpn;
         _loc4_._nSourceCharacterId = param1.cci;
         _loc4_._nSkillId = param1.si;
         _loc4_._nSkillExecuteCode = param1.ses;
         _loc4_._bIsOverRoundLimit = param1.isor;
         _loc4_._sourceSkillNumResult = SkillNumResult.parseServerResponce(param1.cn);
         _loc4_._arrTargetSkillResults = [];
         _loc4_._arrTargetRepresenterResults = [];
         for each(_loc5_ in param1.trl)
         {
            _loc6_ = SkillResult.parseServerResponce(_loc5_,param3);
            _loc4_._arrTargetSkillResults.push(_loc6_);
         }
         for each(_loc5_ in param1.prl)
         {
            _loc6_ = SkillResult.parseServerResponce(_loc5_,param3);
            _loc4_._arrTargetRepresenterResults.push(_loc6_);
         }
         _loc4_._nRoundNum = param1.csn;
         _loc4_._nPlayerRoundNum = param1.hasOwnProperty("pr") ? int(param1.pr) : 0;
         _loc4_._battleUnit = param2;
         if(param1.hasOwnProperty("fbs"))
         {
            _loc4_._bIsFromNormalQueue = param1.fbs;
         }
         return _loc4_;
      }
      
      public function reverseToCounterResult(param1:int) : RoundResult
      {
         var _loc2_:RoundResult = new RoundResult();
         var _loc3_:SkillResult = this.counterAttackTargetSkillResult;
         _loc2_._nSourceTeamId = _loc3_.targetTeamId;
         _loc2_._nSourcePlayerName = _loc3_.targetPlayerName;
         _loc2_._nSourceCharacterId = _loc3_.targetCharacterId;
         _loc2_._nSkillId = param1;
         _loc2_._nSkillExecuteCode = SkillExecuteDefine.TYPE_NORMAL;
         _loc2_._bIsOverRoundLimit = this._bIsOverRoundLimit;
         if(_loc3_.numResult != null)
         {
            _loc2_._sourceSkillNumResult = _loc3_.numResult.reverseToCounterNumResult();
         }
         _loc2_._arrTargetSkillResults = [SkillResult.genCounterResult(this._nSourceTeamId,this._nSourcePlayerName,this._nSourceCharacterId,this._sourceSkillNumResult)];
         _loc2_._arrTargetRepresenterResults = [];
         _loc2_._battleUnit = null;
         return _loc2_;
      }
      
      private function get counterAttackTargetSkillResult() : SkillResult
      {
         var _loc1_:SkillResult = null;
         for each(_loc1_ in this._arrTargetSkillResults)
         {
            if(_loc1_.counter)
            {
               return _loc1_;
            }
         }
         return this._arrTargetSkillResults[0];
      }
      
      public function get sourceTeamId() : int
      {
         return this._nSourceTeamId;
      }
      
      public function get sourcePlayerName() : String
      {
         return this._nSourcePlayerName;
      }
      
      public function get sourceCharacterId() : int
      {
         return this._nSourceCharacterId;
      }
      
      public function get skillId() : int
      {
         var _loc1_:FighterInfo = null;
         if(this._battleUnit != null && this._nSourceCharacterId != RepresentRoundResult.REPRESENTER_SOURCE_CHARACTER_ID)
         {
            _loc1_ = this._battleUnit.battleFlow.battleResult.battleInfo.getTeamInfoById(this._nSourceTeamId).getPlayerInfoByName(this._nSourcePlayerName).getFighterInfoById(this._nSourceCharacterId);
            if(_loc1_.raceId != _loc1_.raceIdIgnoreTesting)
            {
               return int(String(this._nSkillId).replace(String(_loc1_.raceIdIgnoreTesting),String(_loc1_.raceId)));
            }
         }
         return this._nSkillId;
      }
      
      public function get skillExecuteCode() : int
      {
         return this._nSkillExecuteCode;
      }
      
      public function get isOverRoundLimit() : Boolean
      {
         return this._bIsOverRoundLimit;
      }
      
      public function get sourceSkillNumResult() : SkillNumResult
      {
         return this._sourceSkillNumResult;
      }
      
      public function get targetSkillResults() : Array
      {
         return this._arrTargetSkillResults;
      }
      
      public function get roundNum() : int
      {
         return this._nRoundNum;
      }
      
      public function get playerRoundNum() : int
      {
         return this._nPlayerRoundNum;
      }
      
      public function get isLastRound() : Boolean
      {
         return this._isLastRound;
      }
      
      public function set isLastRound(param1:Boolean) : void
      {
         this._isLastRound = param1;
      }
      
      public function set skillId(param1:int) : void
      {
         this._nSkillId = param1;
      }
      
      public function get targetRepresenterResults() : Array
      {
         return this._arrTargetRepresenterResults;
      }
      
      public function get executeBufferId() : int
      {
         return this._executeBufferId;
      }
      
      public function get executePetDragonIds() : Array
      {
         return this._executePetDragonIds;
      }
      
      public function fillWithMaxChangeSetId() : void
      {
         var _loc1_:SkillResult = null;
         var _loc2_:SkillResult = null;
         this._isFillWithMaxChangeSetId = true;
         this._sourceSkillNumResult.fillWithMaxChangeSetId();
         for each(_loc1_ in this._arrTargetSkillResults)
         {
            _loc1_.fillWithMaxChangeSetId();
         }
         for each(_loc2_ in this._arrTargetRepresenterResults)
         {
            _loc2_.fillWithMaxChangeSetId();
         }
      }
      
      public function get isFillWithMaxChangeSetId() : Boolean
      {
         return this._isFillWithMaxChangeSetId;
      }
      
      public function makeAllInSameChangeSetId() : void
      {
         var _loc1_:SkillResult = null;
         var _loc2_:SkillResult = null;
         this._sourceSkillNumResult.makeAllInSameChangeSetId();
         for each(_loc1_ in this._arrTargetSkillResults)
         {
            _loc1_.makeAllInSameChangeSetId();
         }
         for each(_loc2_ in this._arrTargetRepresenterResults)
         {
            _loc2_.makeAllInSameChangeSetId();
         }
      }
      
      public function get queue() : RoundQueue
      {
         return this._roundQueue;
      }
      
      public function assignQueue(param1:RoundQueue) : void
      {
         this._roundQueue = param1;
      }
      
      public function get isFromNormalQueue() : Boolean
      {
         return this._bIsFromNormalQueue;
      }
   }
}

