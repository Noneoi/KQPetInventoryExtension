package mmo.interfaces.battle.avatar
{
   import flash.display.MovieClip;
   import flash.display.Sprite;
   import flash.geom.Point;
   import flash.geom.Rectangle;
   import mmo.interfaces.IDispose;
   
   public interface IBattleAvatar extends IDispose
   {
      
      function flip() : void;
      
      function get x() : Number;
      
      function get y() : Number;
      
      function get avatarBound() : Rectangle;
      
      function getAvatarPos(param1:int) : Point;
      
      function hideBufferLayer() : void;
      
      function showBufferLayer() : void;
      
      function hideEffectLayer() : void;
      
      function showEffectLayer() : void;
      
      function getBloodLayer() : Sprite;
      
      function getBufferLayer() : Sprite;
      
      function getBufferLayer2() : Sprite;
      
      function get mcAction() : MovieClip;
      
      function fadeOut(param1:Function) : void;
      
      function showUp() : void;
      
      function summonDisappear() : void;
      
      function summonAppear() : void;
      
      function getBuffMcByBuffId(param1:int) : MovieClip;
      
      function updateAttr() : void;
   }
}

