package mmo.interfaces.battle.data
{
   public class BarrageResult
   {
      
      private var _teamId:int;
      
      private var _serverId:int;
      
      public function BarrageResult()
      {
         super();
      }
      
      public static function parseServerResponce(param1:Object) : BarrageResult
      {
         var _loc2_:BarrageResult = new BarrageResult();
         _loc2_._teamId = param1["p"];
         _loc2_._serverId = param1["i"];
         return _loc2_;
      }
      
      public function get teamId() : int
      {
         return this._teamId;
      }
      
      public function get serverId() : int
      {
         return this._serverId;
      }
   }
}

