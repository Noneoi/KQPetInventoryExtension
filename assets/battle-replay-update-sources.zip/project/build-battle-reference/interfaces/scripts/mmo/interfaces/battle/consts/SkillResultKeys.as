package mmo.interfaces.battle.consts
{
   public class SkillResultKeys
   {
      
      public static const TARGET_TEAM_ID:String = "tti";
      
      public static const TARGET_PLAYER_NAME:String = "tpn";
      
      public static const TARGET_CHARACTER_ID:String = "tci";
      
      public static const HIT:String = "ishit";
      
      public static const IMMUNITY:String = "isIm";
      
      public static const BLOCK:String = "isbl";
      
      public static const CRITICAL:String = "iscr";
      
      public static const COUNTER:String = "issb";
      
      public static const EFFECT:String = "isse";
      
      public static const PRE_DAMAGE:String = "pred";
      
      public static const IN_DAMAGE:String = "ind";
      
      public static const POST_DAMAGE:String = "postd";
      
      public static const HEAL:String = "heal";
      
      public static const COUNTER_DAMAGE:String = "cntd";
      
      public static const NEW_TARGET_BUFF:String = "ntb";
      
      public static const DROP_TARGET_BUFF:String = "dtb";
      
      public static const NEW_SOURCE_BUFF:String = "nsb";
      
      public static const DROP_SOURCE_BUFF:String = "dsb";
      
      public function SkillResultKeys()
      {
         super();
      }
   }
}

