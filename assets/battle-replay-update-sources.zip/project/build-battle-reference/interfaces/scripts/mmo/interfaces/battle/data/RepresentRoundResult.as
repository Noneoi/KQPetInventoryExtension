package mmo.interfaces.battle.data
{
   public class RepresentRoundResult extends RoundResult
   {
      
      public static const REPRESENTER_SOURCE_CHARACTER_ID:int = int.MAX_VALUE;
      
      public static const REPRESENTER_INI_POS_X:int = 2;
      
      public static const REPRESENTER_INT_POS_Y:int = 2;
      
      public static const REPRESENTER_NAME:String = "虚拟的Fighter代表";
      
      public function RepresentRoundResult()
      {
         super();
      }
   }
}

