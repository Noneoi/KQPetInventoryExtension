package mmo.interfaces.battle.data
{
   import mmo.interfaces.battle.consts.SkillResultKeys;
   
   public class SkillResult
   {
      
      private var _nTargetTeamId:int;
      
      private var _nTargetPlayerName:String;
      
      private var _nTargerCharacterId:int;
      
      private var _bMiss:Boolean;
      
      private var _bImmunity:Boolean;
      
      private var _bBlock:Boolean;
      
      private var _bCritical:Boolean;
      
      private var _bCounter:Boolean;
      
      private var _bEffect:Boolean;
      
      private var _skillNumResult:SkillNumResult;
      
      public function SkillResult()
      {
         super();
      }
      
      public static function parseServerResponce(param1:Object, param2:Boolean) : SkillResult
      {
         var _loc3_:SkillResult = new SkillResult();
         _loc3_._nTargetTeamId = param1[SkillResultKeys.TARGET_TEAM_ID] ^ (param2 ? 1 : 0);
         _loc3_._nTargetPlayerName = param1[SkillResultKeys.TARGET_PLAYER_NAME];
         _loc3_._nTargerCharacterId = param1[SkillResultKeys.TARGET_CHARACTER_ID] == null ? RepresentRoundResult.REPRESENTER_SOURCE_CHARACTER_ID : int(param1[SkillResultKeys.TARGET_CHARACTER_ID]);
         _loc3_._bMiss = !param1[SkillResultKeys.HIT];
         _loc3_._bImmunity = param1[SkillResultKeys.IMMUNITY];
         _loc3_._bBlock = param1[SkillResultKeys.BLOCK];
         _loc3_._bCritical = param1[SkillResultKeys.CRITICAL];
         _loc3_._bCounter = param1[SkillResultKeys.COUNTER];
         _loc3_._bEffect = param1[SkillResultKeys.EFFECT];
         _loc3_._skillNumResult = SkillNumResult.parseServerResponce(param1.tn);
         return _loc3_;
      }
      
      public static function genCounterResult(param1:int, param2:String, param3:int, param4:SkillNumResult) : SkillResult
      {
         var _loc5_:SkillResult = new SkillResult();
         _loc5_._nTargetTeamId = param1;
         _loc5_._nTargetPlayerName = param2;
         _loc5_._nTargerCharacterId = param3;
         _loc5_._bMiss = false;
         _loc5_._bImmunity = false;
         _loc5_._bBlock = false;
         _loc5_._bCritical = false;
         _loc5_._bCounter = false;
         _loc5_._bEffect = true;
         if(param4 != null)
         {
            _loc5_._skillNumResult = param4.reverseToCounterNumResult();
         }
         return _loc5_;
      }
      
      public function get targetTeamId() : int
      {
         return this._nTargetTeamId;
      }
      
      public function get targetPlayerName() : String
      {
         return this._nTargetPlayerName;
      }
      
      public function get targetCharacterId() : int
      {
         return this._nTargerCharacterId;
      }
      
      public function get miss() : Boolean
      {
         return this._bMiss;
      }
      
      public function get immunity() : Boolean
      {
         return this._bImmunity;
      }
      
      public function get block() : Boolean
      {
         return this._bBlock;
      }
      
      public function get critical() : Boolean
      {
         return this._bCritical;
      }
      
      public function get counter() : Boolean
      {
         return this._bCounter;
      }
      
      public function get effect() : Boolean
      {
         return this._bEffect;
      }
      
      public function get numResult() : SkillNumResult
      {
         return this._skillNumResult;
      }
      
      public function fillWithMaxChangeSetId() : void
      {
         this._skillNumResult.fillWithMaxChangeSetId();
      }
      
      public function makeAllInSameChangeSetId() : void
      {
         this._skillNumResult.makeAllInSameChangeSetId();
      }
   }
}

