package mmo.interfaces.battle.data
{
   import mmo.common.user.UserInfo;
   import mmo.loader.common.datastructures.HashMap;
   
   public class BattleInfo
   {
      
      private var _sSceneName:String;
      
      private var _bExchangedTeamId:Boolean;
      
      private var _mapId2Team:HashMap;
      
      public function BattleInfo(param1:String, param2:Boolean)
      {
         super();
         this._sSceneName = param1;
         this._bExchangedTeamId = param2;
         this._mapId2Team = new HashMap();
      }
      
      public static function parseServerResponce(param1:Object, param2:Boolean) : BattleInfo
      {
         var _loc6_:Object = null;
         var _loc7_:TeamInfo = null;
         var _loc3_:String = param1.sn;
         var _loc4_:Boolean = param2 && param1.team[1].players[0].name === UserInfo.nickName;
         var _loc5_:BattleInfo = new BattleInfo(_loc3_,_loc4_);
         for each(_loc6_ in param1.team)
         {
            _loc7_ = TeamInfo.parseServerResponce(_loc6_,_loc4_);
            _loc5_.registerTeam(_loc7_);
         }
         return _loc5_;
      }
      
      public function get sceneName() : String
      {
         return this._sSceneName;
      }
      
      public function set sceneName(param1:String) : void
      {
         this._sSceneName = param1;
      }
      
      public function get exchangedTeamId() : Boolean
      {
         return this._bExchangedTeamId;
      }
      
      public function registerTeam(param1:TeamInfo) : void
      {
         this._mapId2Team.add(param1.teamId,param1);
      }
      
      public function getTeamInfoById(param1:int) : TeamInfo
      {
         return this._mapId2Team.getValue(param1);
      }
      
      public function get teamInfos() : Array
      {
         return this._mapId2Team.getValues();
      }
      
      public function get hasPetDragonInBattle() : Boolean
      {
         var _loc1_:TeamInfo = null;
         for each(_loc1_ in this.teamInfos)
         {
            if(_loc1_.hasPetDragonInBattle)
            {
               return true;
            }
         }
         return false;
      }
   }
}

