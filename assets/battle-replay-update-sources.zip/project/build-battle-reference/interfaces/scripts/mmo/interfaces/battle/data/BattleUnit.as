package mmo.interfaces.battle.data
{
   public class BattleUnit
   {
      
      private var _sAPlayerName:String;
      
      private var _sBPlayerName:String;
      
      private var _nBattleLineIndex:int;
      
      private var _bIsReallyFight:Boolean;
      
      private var _shiftResult:ShiftResult;
      
      private var _arrRoundResults:Array;
      
      private var _battleFlow:BattleFlow;
      
      public function BattleUnit()
      {
         super();
      }
      
      public static function parseServerResponce(param1:Object, param2:BattleFlow, param3:Boolean) : BattleUnit
      {
         var _loc7_:RoundResult = null;
         var _loc8_:int = 0;
         var _loc9_:SkillResult = null;
         var _loc10_:RoundResult = null;
         var _loc4_:BattleUnit = new BattleUnit();
         _loc4_._sAPlayerName = param3 ? param1.pbn : param1.pan;
         _loc4_._sBPlayerName = param3 ? param1.pan : param1.pbn;
         _loc4_._nBattleLineIndex = param1.bfn;
         _loc4_._bIsReallyFight = param1.isf;
         _loc4_._shiftResult = ShiftResult.parseServerRespnoce(param1.pr,param3);
         _loc4_._arrRoundResults = [];
         _loc4_._battleFlow = param2;
         var _loc5_:Array = param1.rl;
         var _loc6_:int = 0;
         while(_loc6_ < _loc5_.length)
         {
            _loc7_ = RoundResult.parseServerResponce(_loc5_[_loc6_],_loc4_,param3);
            if(_loc6_ == _loc5_.length - 1)
            {
               _loc7_.isLastRound = true;
               _loc8_ = 0;
               while(_loc8_ < _loc7_.targetSkillResults.length)
               {
                  _loc9_ = _loc7_.targetSkillResults[_loc8_];
                  if(_loc9_.counter)
                  {
                     _loc7_.isLastRound = false;
                  }
                  _loc8_++;
               }
            }
            if(_loc6_ == 0)
            {
               _loc7_.assignQueue(RoundQueue.parseServerResponseNext(_loc5_[_loc6_]));
            }
            else
            {
               _loc10_ = _loc4_._arrRoundResults[_loc4_._arrRoundResults.length - 1];
               _loc7_.assignQueue(RoundQueue.parseServerResponseNext(_loc5_[_loc6_],_loc10_.queue));
            }
            _loc4_._arrRoundResults.push(_loc7_);
            _loc6_++;
         }
         return _loc4_;
      }
      
      public function get aPlayerName() : String
      {
         return this._sAPlayerName;
      }
      
      public function get bPlayerName() : String
      {
         return this._sBPlayerName;
      }
      
      public function get battleLineIndex() : int
      {
         return this._nBattleLineIndex;
      }
      
      public function get isReallyFight() : Boolean
      {
         return this._bIsReallyFight;
      }
      
      public function get shiftResult() : ShiftResult
      {
         return this._shiftResult;
      }
      
      public function get roundResults() : Array
      {
         return this._arrRoundResults;
      }
      
      public function get battleFlow() : BattleFlow
      {
         return this._battleFlow;
      }
   }
}

