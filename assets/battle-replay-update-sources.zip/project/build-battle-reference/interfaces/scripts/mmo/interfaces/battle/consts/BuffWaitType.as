package mmo.interfaces.battle.consts
{
   public class BuffWaitType
   {
      
      public static const NO_WAIT:int = 0;
      
      public static const WAIT_MUTI_ONCE_ON_ONE_FIGHTER:int = 1;
      
      public static const WAIT_MUTI_CONTINUE_ON_ONE_FIGHTER:int = 2;
      
      public static const WAIT_AND_FORCE_SHOW_FIGHTER:int = 3;
      
      public function BuffWaitType()
      {
         super();
      }
   }
}

