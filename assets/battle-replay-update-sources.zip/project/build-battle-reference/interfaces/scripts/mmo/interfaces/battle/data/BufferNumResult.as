package mmo.interfaces.battle.data
{
   public class BufferNumResult
   {
      
      private var _nEffect:int;
      
      private var _nBufferId:int;
      
      private var _nChangeSetId:int;
      
      public function BufferNumResult()
      {
         super();
      }
      
      public static function parseServerResponce(param1:String) : BufferNumResult
      {
         var _loc2_:BufferNumResult = new BufferNumResult();
         var _loc3_:Array = param1.split("_");
         _loc2_._nBufferId = int(_loc3_[0]);
         _loc2_._nEffect = int(_loc3_[1]);
         _loc2_._nChangeSetId = int(_loc3_[2]);
         return _loc2_;
      }
      
      public function get changeSetId() : int
      {
         return this._nChangeSetId;
      }
      
      public function get bufferId() : int
      {
         return this._nBufferId;
      }
      
      public function get effect() : int
      {
         return this._nEffect;
      }
   }
}

