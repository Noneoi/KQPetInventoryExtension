package mmo.interfaces.battle.data
{
   import mmo.common.SplitUtil;
   
   public class SkillNumUnitTransform extends SkillNumUnitTiming
   {
      
      protected var _nOrgRaceId:int;
      
      protected var _nOrgFaceId:int;
      
      protected var _nCurRaceId:int;
      
      protected var _nCurFaceId:int;
      
      protected var _nNormalSkillId:int;
      
      protected var _nUniqueSkillId:int;
      
      protected var _nSuperUniqueSkillId:int;
      
      protected var _nRaceTypeIds:Array;
      
      public function SkillNumUnitTransform()
      {
         super();
      }
      
      public static function parseServerResponce(param1:Object) : SkillNumUnitTransform
      {
         var _loc2_:SkillNumUnitTransform = new SkillNumUnitTransform();
         parseServerResponceTransform(_loc2_,param1);
         return _loc2_;
      }
      
      protected static function parseServerResponceTransform(param1:SkillNumUnitTransform, param2:Object) : void
      {
         parseServerResponceTiming(param1,param2);
         param1._nOrgFaceId = int(param2["or"]);
         param1._nOrgFaceId = int(param2["of"]);
         param1._nCurRaceId = int(param2["cr"]);
         param1._nCurFaceId = int(param2["cf"]);
         param1._nNormalSkillId = int(param2["cn"]);
         param1._nUniqueSkillId = SplitUtil.splitToInt(param2["cu"],",")[0];
         param1._nRaceTypeIds = SplitUtil.splitToInt(param2["ca"],",");
         param1._nSuperUniqueSkillId = int(param2["scu"]);
      }
      
      public function get orgRaceId() : int
      {
         return this._nOrgRaceId;
      }
      
      public function get orgFaceId() : int
      {
         return this._nOrgFaceId;
      }
      
      public function get curRaceId() : int
      {
         return this._nCurRaceId;
      }
      
      public function get curFaceId() : int
      {
         return this._nCurFaceId;
      }
      
      public function get normalSkillId() : int
      {
         return this._nNormalSkillId;
      }
      
      public function get uniqueSkillId() : int
      {
         return this._nUniqueSkillId;
      }
      
      public function get superUniqueSkillId() : int
      {
         return this._nSuperUniqueSkillId;
      }
      
      public function get raceTypeIds() : Array
      {
         return this._nRaceTypeIds;
      }
   }
}

