package mmo.interfaces.battle.data
{
   public class SkillNumUnitSummon extends SkillNumUnitTiming
   {
      
      protected var _nTeamId:int;
      
      protected var _nPlayerName:String;
      
      protected var _nFighterId:int;
      
      public function SkillNumUnitSummon()
      {
         super();
      }
      
      public static function parseServerResponce(param1:Object) : SkillNumUnitSummon
      {
         var _loc2_:SkillNumUnitSummon = new SkillNumUnitSummon();
         parseServerResponceTransform(_loc2_,param1);
         return _loc2_;
      }
      
      protected static function parseServerResponceTransform(param1:SkillNumUnitSummon, param2:Object) : void
      {
         parseServerResponceTiming(param1,param2);
         param1._nFighterId = int(param2["ci"]);
         param1._nTeamId = int(param2["ti"]);
         param1._nPlayerName = String(param2["pn"]);
      }
      
      public function get teamId() : int
      {
         return this._nTeamId;
      }
      
      public function get playerName() : String
      {
         return this._nPlayerName;
      }
      
      public function get fighterId() : int
      {
         return this._nFighterId;
      }
   }
}

