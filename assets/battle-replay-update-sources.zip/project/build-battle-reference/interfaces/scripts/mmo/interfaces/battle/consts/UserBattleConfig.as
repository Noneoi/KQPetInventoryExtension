package mmo.interfaces.battle.consts
{
   public class UserBattleConfig
   {
      
      public static const SIMPLE_RES_CTRL_NO:int = 0;
      
      public static const SIMPLE_RES_CTRL_ENEMY_ONLY:int = 1;
      
      public static const SIMPLE_RES_CTRL_ALL:int = 2;
      
      public static const BUFF_RES_CTRL_PSY_DESC:String = "通灵技特效";
      
      public static const BUFF_RES_CTRL_HERO_DESC:String = "英雄技特效";
      
      public static const BUFF_RES_CTRL_OTHER_DESC:String = "其他技能特效";
      
      public static const BUFF_RES_CTRL_SIMPLE_DESC:String = "简版不显示";
      
      public static const SHOW_BUFF_BATTLE_RES_PSY:String = "show_buff_battle_res_psy";
      
      public static const SHOW_BUFF_BATTLE_RES_HERO:String = "show_buff_battle_res_hero";
      
      public static const SHOW_ACTION_SEQUENCE:String = "show_action_seq";
      
      public static const SHOW_BUFF_BATTLE_RES_OTHER:String = "show_buff_battle_res_other";
      
      public function UserBattleConfig()
      {
         super();
      }
   }
}

