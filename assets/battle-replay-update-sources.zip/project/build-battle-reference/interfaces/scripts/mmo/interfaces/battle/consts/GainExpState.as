package mmo.interfaces.battle.consts
{
   public class GainExpState
   {
      
      public static const EXP_ONLY:int = 0;
      
      public static const LEVEL_UP:int = 1;
      
      public static const EVOLUTION:int = 2;
      
      public function GainExpState()
      {
         super();
      }
   }
}

