package mmo.interfaces.battle.data
{
   import mmo.loader.common.datastructures.HashMap;
   
   public class SkillNumResult
   {
      
      private static const DELIM:String = ",";
      
      public static const beforeHps_Key:String = "beforeHps";
      
      public static const beforeSps_Key:String = "beforeSps";
      
      public static const beforePowers_Key:String = "beforePowers";
      
      public static const beforeNumUnit_Key:String = "beforeNumUnit";
      
      public static const beforeDisplayBuff_Key:String = "beforeDisplayBuff";
      
      private static const BEFORE_KEYS:Array = [beforeHps_Key,beforeSps_Key,beforePowers_Key,beforeNumUnit_Key,beforeDisplayBuff_Key];
      
      public static const afterHps_Key:String = "afterHps";
      
      public static const afterSps_Key:String = "afterSps";
      
      public static const afterPowers_Key:String = "afterPowers";
      
      public static const afterNumUnit_Key:String = "afterNumUnit";
      
      public static const afterDisplayBuff_Key:String = "afterDisplayBuff";
      
      public static const BEFORE_EMPTY:String = "before_empty";
      
      public static const AFTER_EMPTY:String = "after_empty";
      
      private static const AFTER_KEYS:Array = [afterHps_Key,afterSps_Key,afterPowers_Key,afterNumUnit_Key,afterDisplayBuff_Key];
      
      private static var sDebug:int = -1;
      
      private var _arrBeforeBufferEffectHps:Array;
      
      private var _arrAfterBufferEffectHps:Array;
      
      private var _arrBeforeBufferEffectPowers:Array;
      
      private var _arrAfterBufferEffectPowers:Array;
      
      private var _arrBeforeBufferEffectSps:Array;
      
      private var _arrAfterBufferEffectSps:Array;
      
      private var _arrAttackHps:Array;
      
      private var _arrCounterHps:Array;
      
      private var _arrAttackSps:Array;
      
      private var _arrCounterSps:Array;
      
      private var _arrAttackPowers:Array;
      
      private var _arrCounterPowers:Array;
      
      private var _arrBeforeBuffNew:Array;
      
      private var _arrAfterBuffNew:Array;
      
      private var _arrBeforeBuffDelete:Array;
      
      private var _arrAfterBuffDelete:Array;
      
      private var _arrBeforeDisplayBuff:Array;
      
      private var _arrAfterDisplayBuff:Array;
      
      private var _curChangeSetIdx:int;
      
      private var _beforeChangeSetIds:Array;
      
      private var _afterChangeSetIds:Array;
      
      private var _changeSetId2BeforeDataMap:HashMap;
      
      private var _changeSetId2AfterDataMap:HashMap;
      
      private var _nFinalHp:Number;
      
      private var _nFinalPower:int;
      
      private var _nFinalSp:Number;
      
      private var _arrBeforeSkillNumUnit:Array;
      
      private var _arrAfterSkillNumUnit:Array;
      
      public function SkillNumResult()
      {
         super();
      }
      
      public static function get emptySkillNumResult() : SkillNumResult
      {
         var _loc1_:SkillNumResult = new SkillNumResult();
         _loc1_._arrBeforeBufferEffectHps = [];
         _loc1_._arrAfterBufferEffectHps = [];
         _loc1_._arrBeforeBufferEffectPowers = [];
         _loc1_._arrAfterBufferEffectPowers = [];
         _loc1_._arrAttackHps = [];
         _loc1_._arrCounterHps = [];
         _loc1_._arrAttackPowers = [];
         _loc1_._arrCounterPowers = [];
         _loc1_._arrBeforeBuffNew = [];
         _loc1_._arrAfterBuffNew = [];
         _loc1_._arrBeforeBuffDelete = [];
         _loc1_._arrAfterBuffDelete = [];
         _loc1_._arrBeforeDisplayBuff = [];
         _loc1_._arrAfterDisplayBuff = [];
         _loc1_._nFinalHp = 100;
         _loc1_._nFinalPower = 0;
         _loc1_._arrBeforeSkillNumUnit = [];
         _loc1_._arrAfterSkillNumUnit = [];
         _loc1_._beforeChangeSetIds = [];
         _loc1_._changeSetId2BeforeDataMap = new HashMap();
         _loc1_._afterChangeSetIds = [];
         _loc1_._changeSetId2AfterDataMap = new HashMap();
         return _loc1_;
      }
      
      public static function parseServerResponce(param1:Object) : SkillNumResult
      {
         var _loc5_:Array = null;
         var _loc6_:Object = null;
         var _loc7_:SkillNumUnitTiming = null;
         var _loc8_:int = 0;
         var _loc9_:Object = null;
         var _loc10_:int = 0;
         var _loc11_:Object = null;
         if(param1 == null)
         {
            return null;
         }
         var _loc2_:SkillNumResult = new SkillNumResult();
         _loc2_._arrBeforeBufferEffectHps = parseBufferEffect(param1.bb_hps,DELIM);
         _loc2_._arrAfterBufferEffectHps = parseBufferEffect(param1.ab_hps,DELIM);
         _loc2_._arrBeforeBufferEffectPowers = parseBufferEffect(param1.bb_vgs,DELIM);
         _loc2_._arrAfterBufferEffectPowers = parseBufferEffect(param1.ab_vgs,DELIM);
         _loc2_._arrBeforeBufferEffectSps = parseBufferEffect(param1.bb_shps,DELIM);
         _loc2_._arrAfterBufferEffectSps = parseBufferEffect(param1.ab_shps,DELIM);
         _loc2_._arrAttackHps = mySpilt(param1.att_hps,DELIM);
         _loc2_._arrCounterHps = mySpilt(param1.sb_hps,DELIM);
         _loc2_._arrAttackSps = mySpilt(param1.att_shps,DELIM);
         _loc2_._arrCounterSps = mySpilt(param1.sb_shps,DELIM);
         _loc2_._arrAttackPowers = mySpilt(param1.att_vgs,DELIM);
         _loc2_._arrCounterPowers = mySpilt(param1.sb_vgs,DELIM);
         _loc2_._arrBeforeBuffNew = mySpilt(param1.ba_bfs,DELIM);
         _loc2_._arrAfterBuffNew = mySpilt(param1.aa_bfs,DELIM);
         _loc2_._arrBeforeBuffDelete = mySpilt(param1.bc_bfs,DELIM);
         _loc2_._arrAfterBuffDelete = mySpilt(param1.ac_bfs,DELIM);
         _loc2_._arrBeforeDisplayBuff = split2strArr(param1.bd_bfs,DELIM);
         _loc2_._arrAfterDisplayBuff = split2strArr(param1.ad_bfs,DELIM);
         _loc2_._nFinalHp = param1.ahp;
         _loc2_._nFinalPower = param1.avg;
         _loc2_._nFinalSp = param1.ashp;
         _loc2_._arrBeforeSkillNumUnit = [];
         _loc2_._arrAfterSkillNumUnit = [];
         if(param1.hasOwnProperty("rl"))
         {
            _loc5_ = param1["rl"];
            for each(_loc6_ in _loc5_)
            {
               _loc7_ = SkillNumUnitFactory.getSkillNumUnitTiming(_loc6_);
               if(_loc7_.timing == SkillNumUnitTiming.TIMING_BEFORE_SKILL)
               {
                  _loc2_._arrBeforeSkillNumUnit.push(_loc7_);
               }
               else if(_loc7_.timing == SkillNumUnitTiming.TIMING_AFTER_SKILL)
               {
                  _loc2_._arrAfterSkillNumUnit.push(_loc7_);
               }
            }
         }
         _loc2_._beforeChangeSetIds = [];
         _loc2_._changeSetId2BeforeDataMap = new HashMap();
         _loc2_._beforeChangeSetIds = calcChangeSetIds(_loc2_._arrBeforeBufferEffectHps,_loc2_._arrBeforeBufferEffectSps,_loc2_._arrBeforeBufferEffectPowers,_loc2_._arrBeforeDisplayBuff,_loc2_._arrBeforeSkillNumUnit);
         var _loc3_:int = 0;
         while(_loc3_ < _loc2_._beforeChangeSetIds.length)
         {
            _loc8_ = int(_loc2_._beforeChangeSetIds[_loc3_]);
            _loc9_ = new Object();
            _loc9_[beforeHps_Key] = filterSameChangeSetResult(_loc2_._arrBeforeBufferEffectHps,_loc8_);
            _loc9_[beforeSps_Key] = filterSameChangeSetResult(_loc2_._arrBeforeBufferEffectSps,_loc8_);
            _loc9_[beforePowers_Key] = filterSameChangeSetResult(_loc2_._arrBeforeBufferEffectPowers,_loc8_);
            _loc9_[beforeNumUnit_Key] = filterSameChangeSetResult(_loc2_._arrBeforeSkillNumUnit,_loc8_);
            _loc9_[beforeDisplayBuff_Key] = filterSameChangeSetResult(_loc2_._arrBeforeDisplayBuff,_loc8_);
            _loc2_._changeSetId2BeforeDataMap.add(_loc8_,_loc9_);
            _loc3_++;
         }
         _loc2_._afterChangeSetIds = [];
         _loc2_._changeSetId2AfterDataMap = new HashMap();
         _loc2_._afterChangeSetIds = calcChangeSetIds(_loc2_._arrAfterBufferEffectHps,_loc2_._arrAfterBufferEffectSps,_loc2_._arrAfterBufferEffectPowers,_loc2_._arrAfterDisplayBuff,_loc2_._arrAfterSkillNumUnit);
         var _loc4_:int = 0;
         while(_loc4_ < _loc2_._afterChangeSetIds.length)
         {
            _loc10_ = int(_loc2_._afterChangeSetIds[_loc4_]);
            _loc11_ = new Object();
            _loc11_[afterHps_Key] = filterSameChangeSetResult(_loc2_._arrAfterBufferEffectHps,_loc10_);
            _loc11_[afterSps_Key] = filterSameChangeSetResult(_loc2_._arrAfterBufferEffectSps,_loc10_);
            _loc11_[afterPowers_Key] = filterSameChangeSetResult(_loc2_._arrAfterBufferEffectPowers,_loc10_);
            _loc11_[afterNumUnit_Key] = filterSameChangeSetResult(_loc2_._arrAfterSkillNumUnit,_loc10_);
            _loc11_[afterDisplayBuff_Key] = filterSameChangeSetResult(_loc2_._arrAfterDisplayBuff,_loc10_);
            _loc2_._changeSetId2AfterDataMap.add(_loc10_,_loc11_);
            _loc4_++;
         }
         return _loc2_;
      }
      
      private static function calcChangeSetIds(param1:Array, param2:Array, param3:Array, param4:Array, param5:Array) : Array
      {
         var _loc7_:BufferNumResult = null;
         var _loc8_:BufferNumResult = null;
         var _loc9_:BufferNumResult = null;
         var _loc10_:String = null;
         var _loc11_:SkillNumUnit = null;
         var _loc12_:int = 0;
         var _loc6_:Array = [];
         for each(_loc7_ in param1)
         {
            _loc6_.push(_loc7_.changeSetId);
         }
         for each(_loc8_ in param2)
         {
            if(_loc6_.indexOf(_loc8_.changeSetId) == -1)
            {
               _loc6_.push(_loc8_.changeSetId);
            }
         }
         for each(_loc9_ in param3)
         {
            if(_loc6_.indexOf(_loc9_.changeSetId) == -1)
            {
               _loc6_.push(_loc9_.changeSetId);
            }
         }
         for each(_loc10_ in param4)
         {
            _loc12_ = int(_loc10_.split("_")[2]);
            if(_loc6_.indexOf(_loc12_) == -1)
            {
               _loc6_.push(_loc12_);
            }
         }
         for each(_loc11_ in param5)
         {
            if(_loc6_.indexOf(_loc11_.changeSetId) == -1)
            {
               _loc6_.push(_loc11_.changeSetId);
            }
         }
         _loc6_.sort(Array.NUMERIC);
         return _loc6_;
      }
      
      private static function getObjectWithKeys(param1:Array) : Object
      {
         var _loc4_:String = null;
         var _loc2_:Object = new Object();
         var _loc3_:int = 0;
         while(_loc3_ < param1.length)
         {
            _loc4_ = param1[_loc3_];
            _loc2_[_loc4_] = [];
            _loc3_++;
         }
         return _loc2_;
      }
      
      private static function domakeAllInSameChangeSetId(param1:HashMap, param2:Object) : void
      {
         var _loc4_:String = null;
         var _loc5_:Array = null;
         var _loc6_:int = 0;
         var _loc7_:int = 0;
         var _loc8_:Object = null;
         var _loc9_:int = 0;
         var _loc10_:String = null;
         var _loc3_:Array = [];
         for(_loc4_ in param2)
         {
            _loc3_.push(_loc4_);
         }
         _loc5_ = param1.getKeys();
         _loc6_ = 0;
         while(_loc6_ < _loc5_.length)
         {
            _loc7_ = int(_loc5_[_loc6_]);
            _loc8_ = param1.getValue(_loc7_);
            _loc9_ = 0;
            while(_loc9_ < _loc3_.length)
            {
               _loc10_ = _loc3_[_loc9_];
               param2[_loc10_] = param2[_loc10_].concat(_loc8_[_loc10_]);
               _loc9_++;
            }
            param1.remove(_loc7_);
            _loc6_++;
         }
         param1.add(1,param2);
      }
      
      private static function getMaxValueInArr(param1:Array) : int
      {
         var _loc2_:int = 0;
         var _loc3_:int = 0;
         while(_loc3_ < param1.length)
         {
            if(param1[_loc3_] > _loc2_)
            {
               _loc2_ = int(param1[_loc3_]);
            }
            _loc3_++;
         }
         return _loc2_;
      }
      
      private static function filterSameChangeSetResult(param1:Array, param2:int) : Array
      {
         var _loc4_:* = undefined;
         var _loc5_:int = 0;
         var _loc3_:Array = [];
         for each(_loc4_ in param1)
         {
            if(_loc4_ is String)
            {
               _loc5_ = parseInt(_loc4_.split("_")[2]);
            }
            else
            {
               _loc5_ = int(_loc4_.changeSetId);
            }
            if(param2 == _loc5_)
            {
               _loc3_.push(_loc4_);
            }
         }
         return _loc3_;
      }
      
      private static function parseBufferEffect(param1:String, param2:String) : Array
      {
         var _loc6_:BufferNumResult = null;
         if(param1 == "" || param1 == null)
         {
            return [];
         }
         var _loc3_:Array = param1.split(param2);
         var _loc4_:Array = [];
         var _loc5_:int = 0;
         while(_loc5_ < _loc3_.length)
         {
            _loc6_ = BufferNumResult.parseServerResponce(_loc3_[_loc5_]);
            _loc4_[_loc5_] = _loc6_;
            _loc5_++;
         }
         return _loc4_;
      }
      
      private static function mySpilt(param1:String, param2:String) : Array
      {
         if(param1 == "" || param1 == null)
         {
            return [];
         }
         var _loc3_:Array = param1.split(param2);
         var _loc4_:Array = [];
         var _loc5_:int = 0;
         while(_loc5_ < _loc3_.length)
         {
            _loc4_[_loc5_] = parseFloat(_loc3_[_loc5_]);
            _loc5_++;
         }
         return _loc4_;
      }
      
      private static function split2strArr(param1:String, param2:String) : Array
      {
         if(param1 == "" || param1 == null)
         {
            return [];
         }
         var _loc3_:Array = param1.split(param2);
         var _loc4_:Array = [];
         var _loc5_:int = 0;
         while(_loc5_ < _loc3_.length)
         {
            _loc4_[_loc5_] = _loc3_[_loc5_];
            _loc5_++;
         }
         return _loc4_;
      }
      
      public function get changeSetId2AfterDataMap() : HashMap
      {
         return this._changeSetId2AfterDataMap;
      }
      
      public function get changeSetId2BeforeDataMap() : HashMap
      {
         return this._changeSetId2BeforeDataMap;
      }
      
      public function fillWithMaxChangeSetId() : void
      {
         var _loc5_:Object = null;
         var _loc6_:Object = null;
         var _loc1_:int = getMaxValueInArr(this._beforeChangeSetIds);
         var _loc2_:int = 0;
         while(_loc2_ <= _loc1_)
         {
            if(this._beforeChangeSetIds.indexOf(_loc2_) == -1)
            {
               this._beforeChangeSetIds.push(_loc2_);
               _loc5_ = new Object();
               _loc5_[beforeHps_Key] = [];
               _loc5_[beforeSps_Key] = [];
               _loc5_[beforePowers_Key] = [];
               _loc5_[beforeNumUnit_Key] = [];
               _loc5_[beforeDisplayBuff_Key] = [];
               _loc5_[BEFORE_EMPTY] = [1];
               this._changeSetId2BeforeDataMap.add(_loc2_,_loc5_);
            }
            _loc2_++;
         }
         var _loc3_:int = getMaxValueInArr(this._afterChangeSetIds);
         _loc3_ = _loc1_ > _loc3_ ? _loc1_ : _loc3_;
         var _loc4_:int = 0;
         while(_loc4_ < _loc3_)
         {
            if(this._afterChangeSetIds.indexOf(_loc4_) == -1)
            {
               this._afterChangeSetIds.push(_loc4_);
               _loc6_ = new Object();
               _loc6_[afterHps_Key] = [];
               _loc6_[afterSps_Key] = [];
               _loc6_[afterPowers_Key] = [];
               _loc6_[afterNumUnit_Key] = [];
               _loc6_[afterDisplayBuff_Key] = [];
               _loc6_[AFTER_EMPTY] = [1];
               this._changeSetId2AfterDataMap.add(_loc4_,_loc6_);
            }
            _loc4_++;
         }
         this._beforeChangeSetIds.sort(Array.NUMERIC);
         this._afterChangeSetIds.sort(Array.NUMERIC);
      }
      
      public function makeAllInSameChangeSetId() : void
      {
         this._beforeChangeSetIds = [];
         this._beforeChangeSetIds.push(1);
         var _loc1_:Object = getObjectWithKeys(BEFORE_KEYS);
         domakeAllInSameChangeSetId(this._changeSetId2BeforeDataMap,_loc1_);
         this._afterChangeSetIds = [];
         this._afterChangeSetIds.push(1);
         var _loc2_:Object = getObjectWithKeys(AFTER_KEYS);
         domakeAllInSameChangeSetId(this._changeSetId2AfterDataMap,_loc2_);
      }
      
      public function reverseToCounterNumResult() : SkillNumResult
      {
         var _loc1_:SkillNumResult = new SkillNumResult();
         _loc1_._arrAttackHps = this.counterHps.concat();
         _loc1_._arrAttackSps = this.counterSps.concat();
         _loc1_._arrAttackPowers = this.counterPowers.concat();
         _loc1_._arrAfterBufferEffectPowers = this.afterPowers.concat();
         _loc1_._arrBeforeBufferEffectHps = [];
         _loc1_._arrAfterBufferEffectHps = [];
         _loc1_._arrBeforeBufferEffectSps = [];
         _loc1_._arrAfterBufferEffectSps = [];
         _loc1_._arrBeforeBufferEffectPowers = [];
         _loc1_._arrCounterHps = [];
         _loc1_._arrCounterSps = [];
         _loc1_._arrCounterPowers = [];
         _loc1_._arrBeforeBuffNew = [];
         _loc1_._arrAfterBuffNew = [];
         _loc1_._arrBeforeBuffDelete = [];
         _loc1_._arrAfterBuffDelete = [];
         _loc1_._nFinalHp = this._nFinalHp;
         _loc1_._nFinalSp = this._nFinalSp;
         _loc1_._nFinalPower = this._nFinalPower;
         _loc1_._arrBeforeSkillNumUnit = [];
         _loc1_._arrAfterSkillNumUnit = [];
         _loc1_._arrBeforeDisplayBuff = [];
         _loc1_._arrAfterDisplayBuff = [];
         _loc1_._beforeChangeSetIds = [];
         _loc1_._afterChangeSetIds = [];
         _loc1_._changeSetId2BeforeDataMap = new HashMap();
         _loc1_._changeSetId2AfterDataMap = new HashMap();
         return _loc1_;
      }
      
      public function get beforeHps() : Array
      {
         return this.getArrByProName(beforeHps_Key);
      }
      
      public function get beforeSps() : Array
      {
         return this.getArrByProName(beforeSps_Key);
      }
      
      public function get attackHps() : Array
      {
         return this._arrAttackHps;
      }
      
      public function get attackSps() : Array
      {
         return this._arrAttackSps;
      }
      
      public function get counterHps() : Array
      {
         return this._arrCounterHps;
      }
      
      public function get counterSps() : Array
      {
         return this._arrCounterSps;
      }
      
      public function get afterHps() : Array
      {
         return this.getArrByProName(afterHps_Key);
      }
      
      public function get afterSps() : Array
      {
         return this.getArrByProName(afterSps_Key);
      }
      
      public function get beforePowers() : Array
      {
         return this.getArrByProName(beforePowers_Key);
      }
      
      public function get attackPowers() : Array
      {
         return this._arrAttackPowers;
      }
      
      public function get counterPowers() : Array
      {
         return this._arrCounterPowers;
      }
      
      public function get afterPowers() : Array
      {
         return this.getArrByProName(afterPowers_Key);
      }
      
      public function get afterDisplayBuff() : Array
      {
         return this.getArrByProName(afterDisplayBuff_Key);
      }
      
      public function get beforeDisplayBuff() : Array
      {
         return this.getArrByProName(beforeDisplayBuff_Key);
      }
      
      public function get arrBeforeDisplayBuff() : Array
      {
         return this._arrBeforeDisplayBuff.concat();
      }
      
      public function get arrAfterDisplayBuff() : Array
      {
         return this._arrAfterDisplayBuff.concat();
      }
      
      public function getIsEmpty(param1:Boolean = true) : Boolean
      {
         if(param1)
         {
            if(this._curChangeSetIdx >= this._beforeChangeSetIds.length || this._beforeChangeSetIds.length == 0)
            {
               return true;
            }
            return Boolean(this.getArrByProName(BEFORE_EMPTY)) && this.getArrByProName(BEFORE_EMPTY).length == 1;
         }
         if(this._curChangeSetIdx >= this._afterChangeSetIds.length || this._afterChangeSetIds.length == 0)
         {
            return true;
         }
         return Boolean(this.getArrByProName(AFTER_EMPTY)) && this.getArrByProName(AFTER_EMPTY).length == 1;
      }
      
      public function get beforeBuffNew() : Array
      {
         return this._arrBeforeBuffNew;
      }
      
      public function get afterBuffNew() : Array
      {
         return this._arrAfterBuffNew;
      }
      
      public function get beforeBuffDelete() : Array
      {
         return this._arrBeforeBuffDelete;
      }
      
      public function get afterBuffDelete() : Array
      {
         return this._arrAfterBuffDelete;
      }
      
      public function get finalHp() : Number
      {
         return this._nFinalHp;
      }
      
      public function get finalPower() : int
      {
         return this._nFinalPower;
      }
      
      public function get beforeNumUnit() : Array
      {
         return this.getArrByProName(beforeNumUnit_Key);
      }
      
      public function get afterNumUnit() : Array
      {
         return this.getArrByProName(afterNumUnit_Key);
      }
      
      public function get allBeforeNumUnit() : Array
      {
         return this._arrBeforeSkillNumUnit;
      }
      
      public function get allAfterNumUnit() : Array
      {
         return this._arrAfterSkillNumUnit;
      }
      
      public function get curChangeSetIdx() : int
      {
         return this._curChangeSetIdx;
      }
      
      public function set curChangeSetIdx(param1:int) : void
      {
         this._curChangeSetIdx = param1;
      }
      
      public function getAllChangeSetIdArrValueByProName(param1:String) : Array
      {
         var _loc3_:Object = null;
         var _loc4_:int = 0;
         var _loc5_:int = 0;
         var _loc6_:int = 0;
         var _loc2_:Array = [];
         if(param1.indexOf("before") != -1)
         {
            _loc4_ = int(this._beforeChangeSetIds.length);
            _loc5_ = 0;
            while(_loc5_ < _loc4_)
            {
               _loc3_ = this._changeSetId2BeforeDataMap.getValue(this._beforeChangeSetIds[_loc5_]);
               if(_loc3_ != null)
               {
                  _loc2_ = _loc2_.concat(_loc3_[param1]);
               }
               _loc5_++;
            }
         }
         else
         {
            _loc4_ = int(this._afterChangeSetIds.length);
            _loc6_ = 0;
            while(_loc6_ < _loc4_)
            {
               _loc3_ = this._changeSetId2AfterDataMap.getValue(this._afterChangeSetIds[_loc6_]);
               if(_loc3_ != null)
               {
                  _loc2_ = _loc2_.concat(_loc3_[param1]);
               }
               _loc6_++;
            }
         }
         return _loc2_;
      }
      
      private function getArrByProName(param1:String) : Array
      {
         var _loc3_:int = 0;
         var _loc4_:Object = null;
         var _loc2_:Array = [];
         if(param1.indexOf("before") != -1)
         {
            if(this._curChangeSetIdx < this._beforeChangeSetIds.length)
            {
               _loc3_ = int(this._beforeChangeSetIds[this._curChangeSetIdx]);
               _loc4_ = this._changeSetId2BeforeDataMap.getValue(_loc3_);
            }
         }
         else if(this._curChangeSetIdx < this._afterChangeSetIds.length)
         {
            _loc3_ = int(this._afterChangeSetIds[this._curChangeSetIdx]);
            _loc4_ = this._changeSetId2AfterDataMap.getValue(_loc3_);
         }
         if(_loc4_ != null)
         {
            _loc2_ = _loc4_[param1];
         }
         return _loc2_;
      }
   }
}

