package mmo.interfaces.battle.data
{
   public class SkillNumUnitBuffChangedState extends SkillNumUnitTiming
   {
      
      protected var _nBuffId:int;
      
      protected var _nOldValue:int;
      
      protected var _nCurValue:int;
      
      protected var _nChangedValue:int;
      
      protected var _nMaxValue:int;
      
      protected var _bIsSkillEffected:Boolean;
      
      public function SkillNumUnitBuffChangedState()
      {
         super();
      }
      
      public static function parseServerResponce(param1:Object) : SkillNumUnitBuffChangedState
      {
         var _loc2_:SkillNumUnitBuffChangedState = new SkillNumUnitBuffChangedState();
         parseServerResponceValueUpdate(_loc2_,param1);
         return _loc2_;
      }
      
      protected static function parseServerResponceValueUpdate(param1:SkillNumUnitBuffChangedState, param2:Object) : void
      {
         parseServerResponceTiming(param1,param2);
         param1._nBuffId = int(param2["pbid"]);
         param1._nOldValue = int(param2["prob"]);
         param1._nCurValue = int(param2["proa"]);
         param1._nChangedValue = int(param2["vc"]);
         param1._nMaxValue = int(param2["mp"]);
         param1._bIsSkillEffected = param2.hasOwnProperty("isse") ? Boolean(param2["isse"]) : false;
      }
      
      public function get maxValue() : int
      {
         return this._nMaxValue;
      }
      
      public function get changedValue() : int
      {
         return this._nChangedValue;
      }
      
      public function get curValue() : int
      {
         return this._nCurValue;
      }
      
      public function get oldValue() : int
      {
         return this._nOldValue;
      }
      
      public function get buffId() : int
      {
         return this._nBuffId;
      }
      
      public function get isSkillEffected() : Boolean
      {
         return this._bIsSkillEffected;
      }
   }
}

