package mmo.interfaces.battle.data
{
   import mmo.interfaces.battle.service.BattleParams;
   import mmo.interfaces.battle.service.BattleType;
   import mmo.interfaces.material.MaterialCommonData;
   
   public class BattleResult
   {
      
      private var _nVersion:int;
      
      private var _battleInfo:BattleInfo;
      
      private var _battleFlow:BattleFlow;
      
      private var _arrBuffers:Array;
      
      private var _itemResult:UseItemResult;
      
      private var _catchPetResult:CatchPetResult;
      
      private var _gainExpResult:GainExpResult;
      
      private var _extraExpResult:ExtExpResult;
      
      private var _npcBlessResult:NpcBlessResult;
      
      private var _arrDropItemData:Array;
      
      private var _arrExtraBonusData:Array;
      
      private var _nWinerTeamId:int;
      
      private var _nBattleType:int;
      
      private var _nickName:String;
      
      private var _userName:String;
      
      private var _teamLeaderName:String;
      
      private var _teamLeaderNickName:String;
      
      private var _battleId:Number;
      
      private var _replay:Boolean;
      
      private var _battleParams:BattleParams;
      
      private var _skipAppearWaitTime:int;
      
      private var _skipBattleLimitObj:*;
      
      private var _skipBattleSpecialPetObj:*;
      
      private var _flashToH5Info:BattleFlashToH5Info;
      
      public function BattleResult()
      {
         super();
      }
      
      public static function parseServerResponce(param1:Object, param2:BattleParams = null) : BattleResult
      {
         var _loc5_:Boolean = false;
         var _loc6_:int = 0;
         var _loc7_:Boolean = false;
         var _loc3_:BattleResult = new BattleResult();
         _loc3_._nVersion = param1.ver != null ? int(param1.ver) : 0;
         _loc3_._flashToH5Info = new BattleFlashToH5Info();
         _loc3_._flashToH5Info.oriBrData = param1;
         if(param1.or != null)
         {
            _loc5_ = Boolean(param2) && param2.fixedMeToLeft;
            _loc3_._battleInfo = BattleInfo.parseServerResponce(param1.or,_loc5_);
         }
         if(param1.fr != null)
         {
            _loc3_._battleFlow = BattleFlow.parseServerResponce(param1.fr,_loc3_);
         }
         if(param1.ir != null)
         {
            _loc3_._itemResult = UseItemResult.parseServerResponce(param1.ir);
         }
         _loc3_._catchPetResult = CatchPetResult.parseServerResponce(param1["1cr"]);
         _loc3_._gainExpResult = GainExpResult.parseServerResponce(param1["1er"]);
         _loc3_._arrDropItemData = MaterialCommonData.parseStrToArray(param1["1di"]);
         _loc3_._arrExtraBonusData = MaterialCommonData.parseStrToArray(param1["1xb"]);
         _loc3_._extraExpResult = ExtExpResult.paserServerResponce(param1["1ea"]);
         _loc3_._npcBlessResult = NpcBlessResult.parseServerResponce(param1["1nb"]);
         if(param1["1bt"] == undefined)
         {
            _loc3_._nBattleType = BattleType.UNDEFINED;
         }
         else
         {
            _loc3_._nBattleType = int(param1["1bt"]);
         }
         var _loc4_:String = String(param1.abs);
         if(_loc4_ == null || _loc4_ == "")
         {
            _loc3_._arrBuffers = [];
         }
         else
         {
            _loc3_._arrBuffers = _loc4_.split(",");
         }
         _loc3_._nWinerTeamId = int(param1.win) ^ (_loc3_.battleInfo.exchangedTeamId ? 1 : 0);
         _loc3_._nickName = param1["nn"];
         _loc3_._userName = param1["un"];
         _loc3_._teamLeaderName = param1["lun"];
         _loc3_._teamLeaderNickName = param1["lnn"];
         _loc3_._battleId = param1["bi"];
         _loc3_._replay = param1["pve"];
         _loc3_._battleParams = param2;
         _loc3_._skipAppearWaitTime = param1["swt"];
         _loc3_._skipBattleLimitObj = {};
         if(param1["wft"] != null)
         {
            _loc6_ = int(param1["wft"]);
            _loc3_._skipBattleLimitObj["wft"] = _loc6_;
         }
         _loc3_._skipBattleSpecialPetObj = {};
         if(param1["sk"] != null)
         {
            _loc7_ = Boolean(param1["sk"]);
            _loc3_._skipBattleSpecialPetObj["sk"] = _loc7_;
         }
         return _loc3_;
      }
      
      public function get version() : int
      {
         return this._nVersion;
      }
      
      public function get battleInfo() : BattleInfo
      {
         return this._battleInfo;
      }
      
      public function get battleFlow() : BattleFlow
      {
         return this._battleFlow;
      }
      
      public function get buffersNeeded() : Array
      {
         return this._arrBuffers;
      }
      
      public function get itemResult() : UseItemResult
      {
         return this._itemResult;
      }
      
      public function get catchPetResult() : CatchPetResult
      {
         return this._catchPetResult;
      }
      
      public function get gainExpResult() : GainExpResult
      {
         return this._gainExpResult;
      }
      
      public function get extraExpResult() : ExtExpResult
      {
         return this._extraExpResult;
      }
      
      public function get npcBlessResult() : NpcBlessResult
      {
         return this._npcBlessResult;
      }
      
      public function get dropItemDatas() : Array
      {
         return this._arrDropItemData;
      }
      
      public function get extraBonusDatas() : Array
      {
         return this._arrExtraBonusData;
      }
      
      public function get winerTeamId() : int
      {
         return this._nWinerTeamId;
      }
      
      public function get battleType() : int
      {
         return this._nBattleType;
      }
      
      public function get nickName() : String
      {
         return this._nickName;
      }
      
      public function get userName() : String
      {
         return this._userName;
      }
      
      public function get teamLeaderName() : String
      {
         return this._teamLeaderName;
      }
      
      public function get teamLeaderNickName() : String
      {
         return this._teamLeaderNickName;
      }
      
      public function get battleId() : Number
      {
         return this._battleId;
      }
      
      public function get replay() : Boolean
      {
         return this._replay;
      }
      
      public function get battleParams() : BattleParams
      {
         return this._battleParams;
      }
      
      public function get skipAppearWaitTime() : int
      {
         return this._skipAppearWaitTime;
      }
      
      public function get skipBattleLimitObj() : Object
      {
         return this._skipBattleLimitObj;
      }
      
      public function get skipBattleSpecialPetObj() : Object
      {
         return this._skipBattleSpecialPetObj;
      }
      
      public function get flashToH5Info() : BattleFlashToH5Info
      {
         return this._flashToH5Info;
      }
   }
}

