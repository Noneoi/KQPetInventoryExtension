package mmo.interfaces.battle.consts
{
   import mmo.interfaces.battle.avatar.AvatarPosTypes;
   import mmo.loader.common.datastructures.HashMap;
   
   public class AvatarEffectIds
   {
      
      public static const ATTACK_DISABLE:int = 1;
      
      public static const CLOSE_ATTACK_DISABLE:int = 1;
      
      public static const REMOTE_ATTACK_DISABLE:int = 1;
      
      public static const MAGIC_ATTACK_DISABLE:int = 1;
      
      public static const MISS:int = 5;
      
      public static const BLOCK:int = 6;
      
      public static const CRITICAL:int = 7;
      
      public static const COUNTER:int = 8;
      
      public static const IMMUNITY:int = 9;
      
      public static const BLOCK_EFFECT:int = 10;
      
      public static const REVIVE:int = 21;
      
      public static const STRONG_EFFECT:int = 10000;
      
      public static const WEAK_EFFECT:int = 10001;
      
      public static const UNIQUE_SKILL_EFFECT:int = 10002;
      
      public static const UNIQUE_SKILL_EFFECT_BLACK:int = 10003;
      
      public static const STRONG_EFFECT_GRASS:int = 10021;
      
      public static const STRONG_EFFECT_WATER:int = 10022;
      
      public static const STRONG_EFFECT_FIRE:int = 10023;
      
      public static const STRONG_EFFECT_DARK:int = 10024;
      
      public static const STRONG_EFFECT_LIGHT:int = 10025;
      
      public static const STRONG_EFFECT_SOUL:int = 10026;
      
      public static const STRONG_EFFECT_WUJI:int = 10027;
      
      public static const STRONG_EFFECT_FANTASY:int = 10028;
      
      public static const STRONG_EFFECT_GRASS_T:int = 20021;
      
      public static const STRONG_EFFECT_WATER_T:int = 20022;
      
      public static const STRONG_EFFECT_FIRE_T:int = 20023;
      
      public static const STRONG_EFFECT_DARK_T:int = 20024;
      
      public static const STRONG_EFFECT_LIGHT_T:int = 20025;
      
      public static const STRONG_EFFECT_SOUL_T:int = 20026;
      
      public static const STRONG_EFFECT_WUJI_T:int = 20027;
      
      public static const STRONG_EFFECT_FANTASY_T:int = 20028;
      
      public static const SUPER_JOB_ATTACK:int = 30000;
      
      public static const SUPER_JOB_ATTACKED:int = 30001;
      
      public static const TIAN_QI_EFFECT:int = 40000;
      
      public static const TIAN_QI_EFFECT_GRASS:int = 40021;
      
      public static const TIAN_QI_EFFECT_WATER:int = 40022;
      
      public static const TIAN_QI_EFFECT_FIRE:int = 40023;
      
      public static const TIAN_QI_EFFECT_DARK:int = 40024;
      
      public static const TIAN_QI_EFFECT_LIGHT:int = 40025;
      
      public static const TIAN_QI_EFFECT_SOUL:int = 40026;
      
      public static const TIAN_QI_EFFECT_WUJI:int = 40027;
      
      public static const TIAN_QI_EFFECT_FANTASY:int = 40028;
      
      public static var effectIdToAvatarPos:HashMap = new HashMap();
      
      effectIdToAvatarPos.add(ATTACK_DISABLE,AvatarPosTypes.TOP);
      effectIdToAvatarPos.add(CLOSE_ATTACK_DISABLE,AvatarPosTypes.TOP);
      effectIdToAvatarPos.add(REMOTE_ATTACK_DISABLE,AvatarPosTypes.TOP);
      effectIdToAvatarPos.add(MAGIC_ATTACK_DISABLE,AvatarPosTypes.TOP);
      effectIdToAvatarPos.add(MISS,AvatarPosTypes.FRONT);
      effectIdToAvatarPos.add(BLOCK,AvatarPosTypes.FRONT);
      effectIdToAvatarPos.add(CRITICAL,AvatarPosTypes.TOP_FRONT);
      effectIdToAvatarPos.add(COUNTER,AvatarPosTypes.BACK);
      effectIdToAvatarPos.add(IMMUNITY,AvatarPosTypes.CENTER);
      effectIdToAvatarPos.add(BLOCK_EFFECT,AvatarPosTypes.CENTER);
      effectIdToAvatarPos.add(REVIVE,AvatarPosTypes.CENTER);
      effectIdToAvatarPos.add(STRONG_EFFECT,AvatarPosTypes.REGISTER_POINT);
      effectIdToAvatarPos.add(STRONG_EFFECT_GRASS,AvatarPosTypes.REGISTER_POINT);
      effectIdToAvatarPos.add(STRONG_EFFECT_WATER,AvatarPosTypes.REGISTER_POINT);
      effectIdToAvatarPos.add(STRONG_EFFECT_FIRE,AvatarPosTypes.REGISTER_POINT);
      effectIdToAvatarPos.add(STRONG_EFFECT_DARK,AvatarPosTypes.REGISTER_POINT);
      effectIdToAvatarPos.add(STRONG_EFFECT_LIGHT,AvatarPosTypes.REGISTER_POINT);
      effectIdToAvatarPos.add(STRONG_EFFECT_SOUL,AvatarPosTypes.REGISTER_POINT);
      effectIdToAvatarPos.add(STRONG_EFFECT_WUJI,AvatarPosTypes.REGISTER_POINT);
      effectIdToAvatarPos.add(STRONG_EFFECT_FANTASY,AvatarPosTypes.REGISTER_POINT);
      effectIdToAvatarPos.add(WEAK_EFFECT,AvatarPosTypes.REGISTER_POINT);
      effectIdToAvatarPos.add(UNIQUE_SKILL_EFFECT,AvatarPosTypes.CENTER);
      effectIdToAvatarPos.add(SUPER_JOB_ATTACK,AvatarPosTypes.TOP);
      effectIdToAvatarPos.add(SUPER_JOB_ATTACKED,AvatarPosTypes.FRONT);
      effectIdToAvatarPos.add(STRONG_EFFECT_GRASS_T,AvatarPosTypes.REGISTER_POINT);
      effectIdToAvatarPos.add(STRONG_EFFECT_WATER_T,AvatarPosTypes.REGISTER_POINT);
      effectIdToAvatarPos.add(STRONG_EFFECT_FIRE_T,AvatarPosTypes.REGISTER_POINT);
      effectIdToAvatarPos.add(STRONG_EFFECT_DARK_T,AvatarPosTypes.REGISTER_POINT);
      effectIdToAvatarPos.add(STRONG_EFFECT_LIGHT_T,AvatarPosTypes.REGISTER_POINT);
      effectIdToAvatarPos.add(STRONG_EFFECT_SOUL_T,AvatarPosTypes.REGISTER_POINT);
      effectIdToAvatarPos.add(STRONG_EFFECT_WUJI_T,AvatarPosTypes.REGISTER_POINT);
      effectIdToAvatarPos.add(STRONG_EFFECT_FANTASY_T,AvatarPosTypes.REGISTER_POINT);
      effectIdToAvatarPos.add(TIAN_QI_EFFECT_GRASS,AvatarPosTypes.BUTTOM);
      effectIdToAvatarPos.add(TIAN_QI_EFFECT_WATER,AvatarPosTypes.BUTTOM);
      effectIdToAvatarPos.add(TIAN_QI_EFFECT_FIRE,AvatarPosTypes.BUTTOM);
      effectIdToAvatarPos.add(TIAN_QI_EFFECT_DARK,AvatarPosTypes.BUTTOM);
      effectIdToAvatarPos.add(TIAN_QI_EFFECT_LIGHT,AvatarPosTypes.BUTTOM);
      effectIdToAvatarPos.add(TIAN_QI_EFFECT_SOUL,AvatarPosTypes.BUTTOM);
      effectIdToAvatarPos.add(TIAN_QI_EFFECT_WUJI,AvatarPosTypes.BUTTOM);
      effectIdToAvatarPos.add(TIAN_QI_EFFECT_FANTASY,AvatarPosTypes.BUTTOM);
      
      public function AvatarEffectIds()
      {
         super();
      }
   }
}

