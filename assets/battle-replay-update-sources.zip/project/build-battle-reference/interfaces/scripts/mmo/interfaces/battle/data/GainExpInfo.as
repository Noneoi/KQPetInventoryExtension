package mmo.interfaces.battle.data
{
   import mmo.interfaces.battle.consts.GainExpState;
   import mmo.interfaces.pet.data.PetBattleProperty;
   import mmo.interfaces.pet.data.PetBriefInfo;
   import mmo.region.Translator;
   
   public class GainExpInfo
   {
      
      private var _nId:int;
      
      private var _nFaceId:int;
      
      private var _sPetName:String;
      
      private var _nLevel:int;
      
      private var _nBattlePower:int;
      
      private var _nExpGain:int;
      
      private var _nGainState:int;
      
      private var _nCurExp:int;
      
      private var _nNextExp:int;
      
      private var _orgFaceId:int;
      
      private var _orgPetInfo:PetBattleProperty;
      
      private var _newPetInfo:PetBattleProperty;
      
      private var _bDoubleExp:Boolean;
      
      private var _nDeltaBattlePower:int;
      
      private var _nCurLevelExp:int;
      
      public function GainExpInfo()
      {
         super();
      }
      
      public static function parseServerResponce(param1:Object) : GainExpInfo
      {
         var _loc2_:GainExpInfo = new GainExpInfo();
         _loc2_._nId = int(param1.id);
         _loc2_._sPetName = Translator.translate(param1.n);
         _loc2_._nFaceId = int(param1.fr);
         _loc2_._nLevel = int(param1.lv);
         _loc2_._nBattlePower = int(param1.zdl);
         _loc2_._nExpGain = int(param1.ge);
         _loc2_._nGainState = int(param1.le);
         _loc2_._nCurExp = int(param1.ce);
         _loc2_._nNextExp = int(param1.ne);
         _loc2_._bDoubleExp = Boolean(param1.de);
         _loc2_._nCurLevelExp = int(param1.cle);
         if(_loc2_._nGainState != GainExpState.EXP_ONLY)
         {
            _loc2_._orgFaceId = int(param1.fro);
            _loc2_._orgPetInfo = new PetBattleProperty(param1.fpo);
            _loc2_._newPetInfo = new PetBattleProperty(param1.fpn);
         }
         _loc2_._nDeltaBattlePower = int(param1.zdld);
         return _loc2_;
      }
      
      public static function useForEvolution(param1:PetBriefInfo, param2:PetBriefInfo) : GainExpInfo
      {
         var _loc3_:GainExpInfo = new GainExpInfo();
         _loc3_._sPetName = param1.name;
         _loc3_._nLevel = param1.level;
         _loc3_._nFaceId = param1.faceId;
         _loc3_._orgFaceId = param2.faceId;
         return _loc3_;
      }
      
      public function get id() : int
      {
         return this._nId;
      }
      
      public function get faceId() : int
      {
         return this._nFaceId;
      }
      
      public function get petName() : String
      {
         return this._sPetName;
      }
      
      public function get level() : int
      {
         return this._nLevel;
      }
      
      public function get battlePower() : int
      {
         return this._nBattlePower;
      }
      
      public function get exp() : int
      {
         return this._nExpGain;
      }
      
      public function get state() : int
      {
         return this._nGainState;
      }
      
      public function get curExp() : int
      {
         return this._nCurExp;
      }
      
      public function get nextExp() : int
      {
         return this._nNextExp;
      }
      
      public function get orgFaceId() : int
      {
         return this._orgFaceId;
      }
      
      public function get orgPetInfo() : PetBattleProperty
      {
         return this._orgPetInfo;
      }
      
      public function get newPetInfo() : PetBattleProperty
      {
         return this._newPetInfo;
      }
      
      public function get doubleExp() : Boolean
      {
         return this._bDoubleExp;
      }
      
      public function get deltaBattlePower() : int
      {
         return this._nDeltaBattlePower;
      }
      
      public function get curLevelExp() : int
      {
         return this._nCurLevelExp;
      }
   }
}

