package mmo.interfaces.battle.data
{
   public class ShiftResult
   {
      
      private var _arrShiftActions:Array = [];
      
      private var _arrDeleteActions:Array = [];
      
      public function ShiftResult()
      {
         super();
      }
      
      public static function parseServerRespnoce(param1:Object, param2:Boolean) : ShiftResult
      {
         var _loc4_:Object = null;
         var _loc5_:Object = null;
         var _loc6_:ShiftAction = null;
         var _loc7_:DeleteAction = null;
         var _loc3_:ShiftResult = new ShiftResult();
         for each(_loc4_ in param1.ml)
         {
            _loc6_ = ShiftAction.parseServerResponce(_loc4_,param2);
            _loc3_._arrShiftActions.push(_loc6_);
         }
         for each(_loc5_ in param1.dl)
         {
            _loc7_ = DeleteAction.parseServerResponce(_loc5_,param2);
            _loc3_._arrDeleteActions.push(_loc7_);
         }
         return _loc3_;
      }
      
      public function get shiftActions() : Array
      {
         return this._arrShiftActions;
      }
      
      public function get deleteActions() : Array
      {
         return this._arrDeleteActions;
      }
   }
}

