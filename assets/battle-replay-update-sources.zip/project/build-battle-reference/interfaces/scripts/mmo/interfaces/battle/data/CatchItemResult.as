package mmo.interfaces.battle.data
{
   public class CatchItemResult extends AbstractItemResult
   {
      
      public function CatchItemResult()
      {
         super();
      }
      
      public static function parseServerResponce(param1:Object) : CatchItemResult
      {
         if(param1 == null)
         {
            return null;
         }
         var _loc2_:CatchItemResult = new CatchItemResult();
         _loc2_.setAbstractProperties(param1);
         return _loc2_;
      }
   }
}

