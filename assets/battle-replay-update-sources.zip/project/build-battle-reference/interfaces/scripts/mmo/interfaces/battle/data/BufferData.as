package mmo.interfaces.battle.data
{
   public class BufferData
   {
      
      private var _bufferId:int;
      
      private var _initValue:int;
      
      private var _maxValue:int;
      
      public function BufferData()
      {
         super();
      }
      
      public static function parseServerResponce(param1:Object) : BufferData
      {
         var _loc2_:BufferData = new BufferData();
         _loc2_._bufferId = param1.pbid;
         _loc2_._initValue = param1.cp;
         _loc2_._maxValue = param1.mp;
         return _loc2_;
      }
      
      public function get maxValue() : int
      {
         return this._maxValue;
      }
      
      public function get initValue() : int
      {
         return this._initValue;
      }
      
      public function get bufferId() : int
      {
         return this._bufferId;
      }
   }
}

