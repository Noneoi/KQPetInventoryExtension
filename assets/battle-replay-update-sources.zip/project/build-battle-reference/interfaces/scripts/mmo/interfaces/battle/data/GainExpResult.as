package mmo.interfaces.battle.data
{
   public class GainExpResult
   {
      
      private var _arrGainExpInfo:Array;
      
      public function GainExpResult()
      {
         super();
      }
      
      public static function parseServerResponce(param1:Array) : GainExpResult
      {
         var _loc4_:Object = null;
         var _loc5_:GainExpInfo = null;
         if(param1 == null)
         {
            return null;
         }
         var _loc2_:GainExpResult = new GainExpResult();
         _loc2_._arrGainExpInfo = new Array();
         var _loc3_:int = 0;
         while(_loc3_ < param1.length)
         {
            _loc4_ = param1[_loc3_];
            _loc5_ = GainExpInfo.parseServerResponce(_loc4_);
            _loc2_._arrGainExpInfo.push(_loc5_);
            _loc3_++;
         }
         return _loc2_;
      }
      
      public function get gainExpInfoList() : Array
      {
         return this._arrGainExpInfo;
      }
   }
}

