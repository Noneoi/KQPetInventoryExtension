package mmo.interfaces.battle.data
{
   import com.adobe.utils.StringUtil;
   import mmo.common.SplitUtil;
   import mmo.interfaces.ServiceContainer;
   import mmo.interfaces.pet.data.IPetDictionaryDataService;
   import mmo.interfaces.pet.data.PetDictionaryDataItem;
   import mmo.interfaces.pettitle.PetTitleData;
   import mmo.region.Translator;
   
   public class FighterInfo
   {
      
      public static const TESTING_MAP_RACE_ID:int = 9999;
      
      public static const TESTING_MAP_FACE_ID:int = 9999;
      
      private static var _petDictService:IPetDictionaryDataService = ServiceContainer.getService(IPetDictionaryDataService);
      
      private var _nMaxPower:int = 100;
      
      private var _id:int;
      
      private var _sName:String;
      
      private var _sCustomName:String;
      
      private var _nRaceId:int;
      
      private var _nFaceId:int;
      
      private var _oRaceId:int;
      
      private var _oFaceId:int;
      
      private var _nLevel:int;
      
      private var _nCurHp:Number;
      
      private var _nMaxHp:Number;
      
      private var _nCurSp:Number;
      
      private var _nCurPower:int;
      
      private var _nNormalSkill:int;
      
      private var _nUniqueSkill:int;
      
      private var _nSuperUniqueSkill:int;
      
      private var _arrRaceTypeIds:Array;
      
      private var _nJobId:int;
      
      private var _nInitPosX:int;
      
      private var _nInitPosY:int;
      
      private var _arrInitBuffIds:Array;
      
      private var _bSummoned:Boolean;
      
      private var _bSummonedCallOut:Boolean;
      
      private var _bSelfReplication:Boolean;
      
      private var _bSelfReplicationCalledOut:Boolean;
      
      private var _isChaser:Boolean = false;
      
      private var _belong2PlayerIndex:int;
      
      private var _petTitleData:PetTitleData;
      
      private var _transFromRaceId:int = -1;
      
      public function FighterInfo()
      {
         super();
      }
      
      public static function get representFighterInfo() : FighterInfo
      {
         var _loc1_:FighterInfo = new FighterInfo();
         _loc1_._id = RepresentRoundResult.REPRESENTER_SOURCE_CHARACTER_ID;
         _loc1_._sName = RepresentRoundResult.REPRESENTER_NAME;
         _loc1_._nRaceId = 1;
         _loc1_._nFaceId = 1;
         _loc1_._nLevel = 100;
         _loc1_._nCurHp = 100;
         _loc1_._nMaxHp = 100;
         _loc1_._nCurSp = 0;
         _loc1_._nCurPower = 0;
         _loc1_._bSummoned = false;
         _loc1_._nNormalSkill = 100001;
         _loc1_._nUniqueSkill = 200001;
         _loc1_._arrRaceTypeIds = [];
         _loc1_._nInitPosX = RepresentRoundResult.REPRESENTER_INI_POS_X;
         _loc1_._nInitPosY = RepresentRoundResult.REPRESENTER_INT_POS_Y;
         _loc1_._arrInitBuffIds = [];
         return _loc1_;
      }
      
      public static function parseServerResponce(param1:Object) : FighterInfo
      {
         var _loc2_:FighterInfo = new FighterInfo();
         _loc2_._id = param1.id;
         _loc2_._sName = Translator.translate(param1.name);
         _loc2_._sCustomName = StringUtil.isNullOrEmpty(param1.customName) ? null : param1.customName;
         _loc2_._nRaceId = param1.raceId;
         _loc2_._nFaceId = param1.faceId;
         _loc2_._oRaceId = param1.hasOwnProperty("oRaceId") ? int(param1.oRaceId) : _loc2_._nRaceId;
         _loc2_._oFaceId = param1.hasOwnProperty("oFaceId") ? int(param1.oFaceId) : _loc2_._nFaceId;
         _loc2_._nLevel = param1.lvl;
         _loc2_._nCurHp = param1.hp;
         _loc2_._nMaxHp = param1.maxHp;
         _loc2_._nCurSp = param1.hasOwnProperty("shp") ? Number(param1.shp) : 0;
         _loc2_._nCurPower = param1.vigour;
         _loc2_._bSummoned = param1.ics;
         _loc2_._bSummonedCallOut = param1.hasOwnProperty("is") ? Boolean(param1["is"]) : false;
         _loc2_._bSelfReplication = param1.ias;
         _loc2_._bSelfReplicationCalledOut = param1.ibs;
         _loc2_._nNormalSkill = param1.nskill;
         _loc2_._nUniqueSkill = param1.uskills;
         _loc2_._nSuperUniqueSkill = param1.suskill;
         _loc2_._arrRaceTypeIds = SplitUtil.splitToInt(param1.attr,",");
         _loc2_._nInitPosX = param1.x;
         _loc2_._nInitPosY = param1.y;
         _loc2_._arrInitBuffIds = [];
         if(param1.hasOwnProperty("bfs") && param1.bfs != "")
         {
            _loc2_._arrInitBuffIds = SplitUtil.splitToInt(param1.bfs,",");
         }
         var _loc3_:PetDictionaryDataItem = _petDictService.getDataItemByRaceId(_loc2_._nRaceId);
         if(param1.hasOwnProperty("icr"))
         {
            _loc2_._isChaser = param1["icr"];
         }
         _loc2_._nJobId = _loc3_.job;
         _loc2_._nMaxPower = _loc3_.maxPower;
         if(param1["title"] != null)
         {
            _loc2_._petTitleData = PetTitleData.parse(param1);
         }
         else
         {
            _loc2_._petTitleData = null;
         }
         return _loc2_;
      }
      
      public function get isSelfReplicationCalledOut() : Boolean
      {
         return this._bSelfReplicationCalledOut;
      }
      
      public function set isSelfReplicationCalledOut(param1:Boolean) : void
      {
         this._bSelfReplicationCalledOut = param1;
      }
      
      public function get needShowSelfReplication() : Boolean
      {
         return this._bSelfReplication && (this._bSelfReplicationCalledOut && this._nCurHp > 0);
      }
      
      public function get isSelfReplication() : Boolean
      {
         return this._bSelfReplication;
      }
      
      public function set isSelfReplication(param1:Boolean) : void
      {
         this._bSelfReplication = param1;
      }
      
      public function get belong2PlayerIndex() : int
      {
         return this._belong2PlayerIndex;
      }
      
      public function set belong2PlayerIndex(param1:int) : void
      {
         this._belong2PlayerIndex = param1;
      }
      
      public function get name() : String
      {
         if(this._sCustomName != null)
         {
            return this._sCustomName;
         }
         return this._sName;
      }
      
      public function get id() : int
      {
         return this._id;
      }
      
      public function get raceId() : int
      {
         if(this.isTesting())
         {
            return TESTING_MAP_RACE_ID;
         }
         return this._nRaceId;
      }
      
      public function get raceIdIgnoreTesting() : int
      {
         return this._nRaceId;
      }
      
      public function get faceId() : int
      {
         if(this.isTesting())
         {
            return TESTING_MAP_FACE_ID;
         }
         return this._nFaceId;
      }
      
      public function get originalRaceId() : int
      {
         return this._oRaceId;
      }
      
      public function get originalFaceId() : int
      {
         return this._oFaceId;
      }
      
      public function set raceId(param1:int) : void
      {
         this._nRaceId = param1;
         var _loc2_:PetDictionaryDataItem = _petDictService.getDataItemByRaceId(this._nRaceId);
         this._nJobId = _loc2_.job;
         this._nMaxPower = _loc2_.maxPower;
      }
      
      public function set faceId(param1:int) : void
      {
         this._nFaceId = param1;
      }
      
      public function get level() : int
      {
         return this._nLevel;
      }
      
      public function get curHp() : Number
      {
         return this._nCurHp;
      }
      
      public function set curHp(param1:Number) : void
      {
         this._nCurHp = param1;
      }
      
      public function get maxHp() : Number
      {
         return this._nMaxHp;
      }
      
      public function set maxHp(param1:Number) : void
      {
         this._nMaxHp = param1;
      }
      
      public function get curSp() : Number
      {
         return this._nCurSp;
      }
      
      public function set curSp(param1:Number) : void
      {
         this._nCurSp = param1;
      }
      
      public function get curPower() : int
      {
         return this._nCurPower;
      }
      
      public function set curPower(param1:int) : void
      {
         this._nCurPower = param1;
      }
      
      public function get maxPower() : int
      {
         return this._nMaxPower;
      }
      
      public function get normalSkill() : int
      {
         if(this.isTesting())
         {
            return 100000 + TESTING_MAP_RACE_ID;
         }
         return this._nNormalSkill;
      }
      
      public function set normalSkill(param1:int) : void
      {
         this._nNormalSkill = param1;
      }
      
      public function get uniqueSkill() : int
      {
         if(this.isTesting())
         {
            return 200000 + TESTING_MAP_RACE_ID;
         }
         return this._nUniqueSkill;
      }
      
      public function set uniqueSkill(param1:int) : void
      {
         this._nUniqueSkill = param1;
      }
      
      public function get superUniqueSkill() : int
      {
         return this._nSuperUniqueSkill;
      }
      
      public function set superUniqueSkill(param1:int) : void
      {
         this._nSuperUniqueSkill = param1;
      }
      
      public function get raceTypeIds() : Array
      {
         return this._arrRaceTypeIds;
      }
      
      public function get jobTypeId() : int
      {
         return this._nJobId;
      }
      
      public function set raceTypeIds(param1:Array) : void
      {
         this._arrRaceTypeIds = param1;
      }
      
      public function get initPosX() : int
      {
         return this._nInitPosX;
      }
      
      public function get initPosY() : int
      {
         return this._nInitPosY;
      }
      
      public function get initBufferIds() : Array
      {
         return this._arrInitBuffIds;
      }
      
      public function get isSummoned() : Boolean
      {
         return this._bSummoned;
      }
      
      public function get isSummonedCallOut() : Boolean
      {
         return this._bSummonedCallOut;
      }
      
      public function set bSummonedCallOut(param1:Boolean) : void
      {
         this._bSummonedCallOut = param1;
      }
      
      public function get isChaser() : Boolean
      {
         return this._isChaser;
      }
      
      public function get petTitleData() : PetTitleData
      {
         return this._petTitleData;
      }
      
      private function isTesting() : Boolean
      {
         return _petDictService.getDataItemByRaceId(this._nRaceId).desc == "内测";
      }
      
      public function get transFromRaceId() : int
      {
         return this._transFromRaceId;
      }
      
      public function set transFromRaceId(param1:int) : void
      {
         this._transFromRaceId = param1;
      }
      
      public function getShowRaceIdWithOrigin() : int
      {
         if(this._transFromRaceId > 0)
         {
            return this._transFromRaceId;
         }
         return this._nRaceId;
      }
   }
}

