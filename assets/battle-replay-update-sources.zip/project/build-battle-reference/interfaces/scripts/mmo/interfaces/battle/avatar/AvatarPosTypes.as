package mmo.interfaces.battle.avatar
{
   public class AvatarPosTypes
   {
      
      public static const REGISTER_POINT:int = 10;
      
      public static const CENTER:int = 5;
      
      public static const TOP:int = 8;
      
      public static const TOP_FRONT:int = 9;
      
      public static const FRONT:int = 6;
      
      public static const BUTTOM_FRONT:int = 3;
      
      public static const BUTTOM:int = 2;
      
      public static const BUTTOM_BACK:int = 1;
      
      public static const BACK:int = 4;
      
      public static const TOP_BACK:int = 7;
      
      public static const FULL_SCREEN_BACK:int = 11;
      
      public static const FULL_SCREEN_FRONT:int = 12;
      
      public static const COLUMN_FONT:int = 13;
      
      public static const FIRST_COLUMN_FONT:int = 14;
      
      public static const FLOOR_REGISTER_POINT:int = 15;
      
      public static const RESPONSE2MOUSE_FULL_SCREEN_FRONT:int = 16;
      
      public static const ATTR_ICON:int = 17;
      
      public static const FULL_SCREEN_BACK_CENTER:int = 18;
      
      public static const FULL_SCREEN_FRONT_CENTER:int = 19;
      
      public function AvatarPosTypes()
      {
         super();
      }
   }
}

