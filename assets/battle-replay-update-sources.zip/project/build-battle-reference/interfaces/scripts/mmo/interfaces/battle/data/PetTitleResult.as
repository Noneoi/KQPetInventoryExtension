package mmo.interfaces.battle.data
{
   import mmo.interfaces.pettitle.PetTitleData;
   
   public class PetTitleResult
   {
      
      private var _teamId:int;
      
      private var _petTitles:Vector.<PetTitleData>;
      
      public function PetTitleResult()
      {
         super();
      }
      
      public static function parseServerResponce(param1:Object) : PetTitleResult
      {
         var petTitles:Array;
         var result:PetTitleResult = null;
         var obj:Object = param1;
         result = new PetTitleResult();
         result._teamId = obj["p"];
         petTitles = obj["petTitles"];
         result._petTitles = new Vector.<PetTitleData>();
         petTitles.forEach(function(param1:Object, param2:int, param3:*):*
         {
            result._petTitles[param2] = PetTitleData.parse(param1);
         });
         return result;
      }
      
      public function get teamId() : int
      {
         return this._teamId;
      }
      
      public function get petTitles() : Vector.<PetTitleData>
      {
         return this._petTitles;
      }
   }
}

