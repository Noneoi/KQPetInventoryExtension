package mmo.interfaces.battle
{
   import mmo.interfaces.battle.avatar.AvatarPosTypes;
   import mmo.interfaces.battle.avatar.IBattleAvatar;
   import mmo.interfaces.battle.bonus.BattleBonusInfo;
   import mmo.interfaces.battle.bonus.BattleBonusUnit;
   import mmo.interfaces.battle.command.IBattleCommand;
   import mmo.interfaces.battle.command.IEmbedCommand;
   import mmo.interfaces.battle.consts.AvatarActionDefine;
   import mmo.interfaces.battle.consts.AvatarEffectIds;
   import mmo.interfaces.battle.consts.BattleResultConst;
   import mmo.interfaces.battle.consts.BuffWaitType;
   import mmo.interfaces.battle.consts.FormationConsts;
   import mmo.interfaces.battle.consts.SkillNumUnitType;
   import mmo.interfaces.battle.consts.SkillResultKeys;
   import mmo.interfaces.battle.consts.UserBattleConfig;
   import mmo.interfaces.battle.data.BattleFlashToH5Info;
   import mmo.interfaces.battle.data.BattleFlow;
   import mmo.interfaces.battle.data.BattleInfo;
   import mmo.interfaces.battle.data.BattleResult;
   import mmo.interfaces.battle.data.BattleUnit;
   import mmo.interfaces.battle.data.BufferData;
   import mmo.interfaces.battle.data.BufferNumResult;
   import mmo.interfaces.battle.data.CatchPetInfo;
   import mmo.interfaces.battle.data.DeleteAction;
   import mmo.interfaces.battle.data.FightPetDragonInfo;
   import mmo.interfaces.battle.data.FighterInfo;
   import mmo.interfaces.battle.data.PlayerInfo;
   import mmo.interfaces.battle.data.RoundResult;
   import mmo.interfaces.battle.data.ShiftAction;
   import mmo.interfaces.battle.data.ShiftResult;
   import mmo.interfaces.battle.data.SkillInfo;
   import mmo.interfaces.battle.data.SkillNumResult;
   import mmo.interfaces.battle.data.SkillNumUnit;
   import mmo.interfaces.battle.data.SkillNumUnitBuffChangedState;
   import mmo.interfaces.battle.data.SkillNumUnitFactory;
   import mmo.interfaces.battle.data.SkillNumUnitTiming;
   import mmo.interfaces.battle.data.SkillNumUnitTransform;
   import mmo.interfaces.battle.data.SkillNumUnitValueUpdate;
   import mmo.interfaces.battle.data.SkillResult;
   import mmo.interfaces.battle.data.TeamInfo;
   import mmo.interfaces.battle.embed.IEmbedCode;
   import mmo.interfaces.battle.entity.IBattle;
   import mmo.interfaces.battle.entity.IBattleSequential;
   import mmo.interfaces.battle.entity.IBattleTeam;
   import mmo.interfaces.battle.events.BattleEvent;
   import mmo.interfaces.battle.events.BattlePetDragonEvent;
   import mmo.interfaces.battle.events.BattleSeqEvent;
   import mmo.interfaces.battle.events.BattleSyncEvent;
   import mmo.interfaces.battle.factory.IBattleFactory;
   import mmo.interfaces.battle.fighter.IBattleFighter;
   import mmo.interfaces.battle.player.IBattlePlayer;
   import mmo.interfaces.battle.service.BattleResultVersion;
   import mmo.interfaces.battle.service.BattleServiceEvent;
   import mmo.interfaces.battle.service.BattleType;
   import mmo.interfaces.battle.service.IBattleService;
   import mmo.interfaces.battle.word.BattleWordInfo;
   import mmo.interfaces.battle.word.BattleWordResult;
   
   public class CompileBattle
   {
      
      public function CompileBattle()
      {
         super();
      }
      
      public static function compileMe() : void
      {
         var _loc1_:IBattleAvatar = null;
         var _loc2_:AvatarPosTypes = null;
         var _loc3_:BattleBonusInfo = null;
         var _loc4_:BattleBonusUnit = null;
         var _loc5_:IBattleCommand = null;
         var _loc6_:IEmbedCommand = null;
         var _loc7_:AvatarActionDefine = null;
         var _loc8_:AvatarEffectIds = null;
         var _loc9_:FormationConsts = null;
         var _loc10_:SkillResultKeys = null;
         var _loc11_:SkillNumUnitType = null;
         var _loc12_:BuffWaitType = null;
         var _loc13_:BattleFlashToH5Info = null;
         var _loc14_:BattleFlow = null;
         var _loc15_:BattleInfo = null;
         var _loc16_:BattleResult = null;
         var _loc17_:BattleUnit = null;
         var _loc18_:BufferNumResult = null;
         var _loc19_:DeleteAction = null;
         var _loc20_:FighterInfo = null;
         var _loc21_:PlayerInfo = null;
         var _loc22_:RoundResult = null;
         var _loc23_:ShiftAction = null;
         var _loc24_:ShiftResult = null;
         var _loc25_:SkillInfo = null;
         var _loc26_:SkillNumResult = null;
         var _loc27_:SkillResult = null;
         var _loc28_:TeamInfo = null;
         var _loc29_:CatchPetInfo = null;
         var _loc30_:SkillNumUnit = null;
         var _loc31_:SkillNumUnitTiming = null;
         var _loc32_:SkillNumUnitValueUpdate = null;
         var _loc33_:SkillNumUnitTransform = null;
         var _loc34_:SkillNumUnitFactory = null;
         var _loc35_:IEmbedCode = null;
         var _loc36_:IBattle = null;
         var _loc37_:IBattleSequential = null;
         var _loc38_:BattleEvent = null;
         var _loc39_:BattleSeqEvent = null;
         var _loc40_:BattleSyncEvent = null;
         var _loc41_:IBattleFighter = null;
         var _loc42_:IBattleFactory = null;
         var _loc43_:IBattlePlayer = null;
         var _loc44_:BattleType = null;
         var _loc45_:IBattleService = null;
         var _loc46_:BattleServiceEvent = null;
         var _loc47_:BattleResultVersion = null;
         var _loc48_:BattleResultConst = null;
         var _loc49_:IBattleTeam = null;
         var _loc50_:BattleWordInfo = null;
         var _loc51_:BattleWordResult = null;
         var _loc52_:BattlePetDragonEvent = null;
         var _loc53_:FightPetDragonInfo = null;
         var _loc54_:BufferData = null;
         var _loc55_:SkillNumUnitBuffChangedState = null;
         var _loc56_:UserBattleConfig = null;
      }
   }
}

