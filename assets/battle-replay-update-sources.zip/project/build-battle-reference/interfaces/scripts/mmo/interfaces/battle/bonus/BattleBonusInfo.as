package mmo.interfaces.battle.bonus
{
   public class BattleBonusInfo
   {
      
      private var _arrBonus:Array;
      
      public function BattleBonusInfo()
      {
         super();
      }
      
      public static function getBattleBonus(param1:Array) : Array
      {
         var _loc3_:Object = null;
         var _loc4_:int = 0;
         var _loc5_:int = 0;
         var _loc6_:BattleBonusUnit = null;
         var _loc2_:Array = [];
         for each(_loc3_ in param1)
         {
            _loc4_ = int(_loc3_.id);
            _loc5_ = int(_loc3_.n);
            _loc6_ = new BattleBonusUnit(_loc4_,_loc5_);
            _loc2_.push(_loc6_);
         }
         return _loc2_;
      }
      
      public function get bonus() : Array
      {
         return this._arrBonus;
      }
   }
}

