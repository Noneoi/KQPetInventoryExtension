package mmo.interfaces.battle.data
{
   public class LoadingStyleResult
   {
      
      private var _teamId:int;
      
      private var _serverId:int;
      
      public function LoadingStyleResult()
      {
         super();
      }
      
      public static function parseServerResponse(param1:Object) : LoadingStyleResult
      {
         var _loc2_:LoadingStyleResult = new LoadingStyleResult();
         _loc2_._teamId = param1["p"];
         _loc2_._serverId = param1["id"];
         return _loc2_;
      }
      
      public function get teamId() : int
      {
         return this._teamId;
      }
      
      public function get serverId() : int
      {
         return this._serverId;
      }
   }
}

