package mmo.interfaces.battle.data
{
   public class RoundQueue
   {
      
      private var _arrLeft:Array;
      
      private var _arrRight:Array;
      
      private var _diffLeft:Boolean;
      
      private var _diffRight:Boolean;
      
      public function RoundQueue()
      {
         super();
         this._arrLeft = [];
         this._arrRight = [];
         this._diffLeft = false;
         this._diffRight = false;
      }
      
      public static function parseServerResponseNext(param1:Object, param2:RoundQueue = null) : RoundQueue
      {
         var _loc3_:RoundQueue = param2 != null ? param2.inherit() : new RoundQueue();
         if(param1.hasOwnProperty("seqa"))
         {
            _loc3_._arrLeft = param1["seqa"];
            _loc3_._diffLeft = true;
         }
         if(param1.hasOwnProperty("seqb"))
         {
            _loc3_._arrRight = param1["seqb"];
            _loc3_._diffRight = true;
         }
         return _loc3_;
      }
      
      private function inherit() : RoundQueue
      {
         var _loc1_:RoundQueue = new RoundQueue();
         _loc1_._arrLeft = this._arrLeft.concat();
         _loc1_._arrRight = this._arrRight.concat();
         return _loc1_;
      }
      
      public function getArr(param1:int) : Array
      {
         return param1 == 0 ? this._arrLeft.concat() : this._arrRight.concat();
      }
      
      public function hayAnyDifference(param1:int) : Boolean
      {
         return param1 == 0 ? this._diffLeft : this._diffRight;
      }
   }
}

