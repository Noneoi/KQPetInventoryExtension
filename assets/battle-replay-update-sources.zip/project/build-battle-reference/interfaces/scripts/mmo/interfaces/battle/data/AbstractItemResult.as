package mmo.interfaces.battle.data
{
   import mmo.common.SplitUtil;
   
   public class AbstractItemResult
   {
      
      protected var _nItemId:int;
      
      protected var _nSourceTeamId:int;
      
      protected var _sSourcePlayerName:String;
      
      protected var _nTargetTeamId:int;
      
      protected var _sTargetPlayerName:String;
      
      protected var _arrTargetFighter:Array;
      
      protected var _arrHitFighter:Array;
      
      public function AbstractItemResult()
      {
         super();
      }
      
      public function get itemId() : int
      {
         return this._nItemId;
      }
      
      public function get sourceTeamId() : int
      {
         return this._nSourceTeamId;
      }
      
      public function get sourcePlayerName() : String
      {
         return this._sSourcePlayerName;
      }
      
      public function get targetTeamId() : int
      {
         return this._nTargetTeamId;
      }
      
      public function get targetPlayerName() : String
      {
         return this._sTargetPlayerName;
      }
      
      public function get targetFighters() : Array
      {
         return this._arrTargetFighter;
      }
      
      public function get hitFitghters() : Array
      {
         return this._arrHitFighter;
      }
      
      public function setAbstractProperties(param1:Object) : void
      {
         this._nItemId = int(param1.ii);
         this._nSourceTeamId = int(param1.cti);
         this._sSourcePlayerName = String(param1.cpn);
         this._nTargetTeamId = int(param1.tti);
         this._sTargetPlayerName = String(param1.tpn);
         this._arrTargetFighter = SplitUtil.splitToInt(String(param1.tcs),",");
         this._arrHitFighter = SplitUtil.splitToInt(String(param1.hcs),",");
      }
   }
}

