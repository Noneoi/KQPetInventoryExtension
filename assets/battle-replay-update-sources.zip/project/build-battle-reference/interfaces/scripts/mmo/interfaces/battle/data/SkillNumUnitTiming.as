package mmo.interfaces.battle.data
{
   public class SkillNumUnitTiming extends SkillNumUnit
   {
      
      public static const TIMING_BEFORE_SKILL:int = 1;
      
      public static const TIMING_AFTER_SKILL:int = 2;
      
      protected var _nTiming:int = 1;
      
      public function SkillNumUnitTiming()
      {
         super();
      }
      
      public static function parseServerResponce(param1:Object) : SkillNumUnitTiming
      {
         var _loc2_:SkillNumUnitTiming = new SkillNumUnitTiming();
         parseServerResponceTiming(_loc2_,param1);
         return _loc2_;
      }
      
      protected static function parseServerResponceTiming(param1:SkillNumUnitTiming, param2:Object) : void
      {
         parseServerResponceBase(param1,param2);
         param1._nTiming = int(param2["o"]);
      }
      
      public function get timing() : int
      {
         return this._nTiming;
      }
   }
}

