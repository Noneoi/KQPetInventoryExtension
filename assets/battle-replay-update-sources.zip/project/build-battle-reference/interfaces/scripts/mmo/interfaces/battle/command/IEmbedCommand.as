package mmo.interfaces.battle.command
{
   import mmo.util.command.ISceneCommand;
   
   public interface IEmbedCommand extends ISceneCommand
   {
      
      function get exeTiming() : Array;
      
      function get repeatCount() : int;
      
      function skip(param1:Object) : void;
      
      function pass(param1:Object) : void;
   }
}

