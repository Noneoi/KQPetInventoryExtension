package mmo.interfaces.battle.consts
{
   public class BattleResultConst
   {
      
      public static var resultMap:Object;
      
      public static const SUCCESS:BattleResultConst = new BattleResultConst(1,"成功");
      
      public static const HALF_INCOME_TIME:BattleResultConst = new BattleResultConst(2,"防沉迷收益减半");
      
      public static const ZERO_INCOME_TIME:BattleResultConst = new BattleResultConst(3,"防沉迷收益停止");
      
      public static const FORMATION_LEARNED:BattleResultConst = new BattleResultConst(10,"阵型已学");
      
      public static const FORMATION_NOT_LEARNED:BattleResultConst = new BattleResultConst(11,"阵型未学");
      
      public static const FORMATION_REACH_MAX_LEVEL:BattleResultConst = new BattleResultConst(12,"阵型满级");
      
      public static const FORMATION_POSITION_SEQUENCE_EVIL:BattleResultConst = new BattleResultConst(13,"阵型位置序列有误");
      
      public static const FORMATION_MONEY_NOT_ENOUGH:BattleResultConst = new BattleResultConst(14,"阵型升级，金币不足");
      
      public static const FORMATION_CDING:BattleResultConst = new BattleResultConst(15,"阵型升级CD中");
      
      public static const FORMATION_CD_OVER:BattleResultConst = new BattleResultConst(16,"阵型升级CD完成");
      
      public static const FORMATION_DIAMOND_NOT_ENOUGH:BattleResultConst = new BattleResultConst(17,"钻石不足");
      
      public static const BATTLE_NOT_AT_SAME_SCENE:BattleResultConst = new BattleResultConst(20,"不在同一场景");
      
      public static const BATTLE_BUILD_FAIL:BattleResultConst = new BattleResultConst(21,"战斗创建失败");
      
      public static const BATTLE_FIGHT_FAIL:BattleResultConst = new BattleResultConst(22,"战斗计算失败");
      
      public static const BATTLE_CREEP_CAN_NOT_FIGHT:BattleResultConst = new BattleResultConst(23,"不能与该怪战斗");
      
      public static const BATTLE_TARGET_NOT_BUDDY:BattleResultConst = new BattleResultConst(24,"目标不是好友");
      
      public static const BATTLE_TIMES_LIMIT:BattleResultConst = new BattleResultConst(25,"次数限制");
      
      public static const BATTLE_ENERGY_NOT_ENOUGH:BattleResultConst = new BattleResultConst(26,"能量不足");
      
      public static const BATTLE_TARGET_FOMRATION_IS_EMPTY:BattleResultConst = new BattleResultConst(27,"目标攻击阵型为空");
      
      public static const BATTLE_STILL_CD:BattleResultConst = new BattleResultConst(28,"你还在战斗中");
      
      public static const BATTLE_FOMRATION_IS_EMPTY:BattleResultConst = new BattleResultConst(29," 阵型为空");
      
      public static const PET_PACK_SEQUENCE_EVIL:BattleResultConst = new BattleResultConst(31,"背包序列有误");
      
      public static const PET_PACK_SEQUENCE_IS_TARGET:BattleResultConst = new BattleResultConst(32,"当前背包序列即为目标序列");
      
      public static const PET_NOT_EXIST_OR_NOT_IN_PACK:BattleResultConst = new BattleResultConst(33,"宠物不存在或者不在背包中");
      
      public static const PET_PROPERTY_VALUE_IS_MAX:BattleResultConst = new BattleResultConst(34,"宠物属性已经最大，不能强化");
      
      public static const PET_MONEY_NOT_ENOUGH:BattleResultConst = new BattleResultConst(35,"金币不足");
      
      public static const NOT_FREE_HEAL_ROOM:BattleResultConst = new BattleResultConst(36,"不是免费治疗场景");
      
      public static const PET_PLACE_WRONG:BattleResultConst = new BattleResultConst(37,"宠物位置错误");
      
      public static const PET_CURRENT_STATE_HAS_BEEN:BattleResultConst = new BattleResultConst(38,"当前已经是目标状态");
      
      public static const PET_MATERIAL_NOT_ENOUGH:BattleResultConst = new BattleResultConst(39,"材料不足");
      
      public static const PET_TRAINING_FULL:BattleResultConst = new BattleResultConst(40,"宠物可锻炼数量已满");
      
      public static const PET_TRAINING_FORM_NOT_INIT:BattleResultConst = new BattleResultConst(41,"尚未设置锻炼阵型");
      
      public static const PET_TRAINING_POSITION_SEQUENCE_EVIL:BattleResultConst = new BattleResultConst(42,"宠物锻炼序列有误");
      
      public static const PET_PACK_CAN_NOT_EMPTY:BattleResultConst = new BattleResultConst(43,"宠物背包不能为空");
      
      public static const PET_REACH_MAX_LEVEL:BattleResultConst = new BattleResultConst(44,"宠物已经满级");
      
      public static const PET_CAN_NOT_BE_FREE_LEVEL80:BattleResultConst = new BattleResultConst(45,"高于80级的宠不能放生");
      
      public static const WZWD_PET_CAN_NOT_BE_FREE:BattleResultConst = new BattleResultConst(46,"王者无敌宠不能放生");
      
      public static const GOOD_FRIENDSHIP_CAN_NOT_BE_FREE:BattleResultConst = new BattleResultConst(47,"感情深厚不能放生的宠");
      
      public static const STAR_GOD_MESSENGR_STATE_NOT_LIGHT:BattleResultConst = new BattleResultConst(61,"星神使者未亮起");
      
      public static const STAR_GOD_HUNT_UP_BIN_IS_FULL:BattleResultConst = new BattleResultConst(62,"猎取仓满了");
      
      public static const STAR_GOD_MONEY_NOT_ENOUGH:BattleResultConst = new BattleResultConst(63,"金币不足");
      
      public static const STAR_GOD_PACK_IS_FULL:BattleResultConst = new BattleResultConst(64,"星神背包满了");
      
      public static const STAR_GOD_ADD_MONEY_FAIL:BattleResultConst = new BattleResultConst(65,"出售星神加金币失败（达到每日上限）");
      
      public static const STAR_GOD_PET_NOT_EXIST:BattleResultConst = new BattleResultConst(66,"宠物不存在或者不在背包中");
      
      public static const STAR_GOD_SLOT_ID_EVIL:BattleResultConst = new BattleResultConst(67,"指定的星神槽位置有误（未开启、位置上已有星神）");
      
      public static const STAR_GOD_NOT_OWN:BattleResultConst = new BattleResultConst(68,"星神未拥有");
      
      public static const STAR_GOD_PLACE_LIMIT:BattleResultConst = new BattleResultConst(69,"目前星神所在位置不允许该操作");
      
      public static const STAR_GOD_HAS_EQUIP_SAME_TYPE:* = new BattleResultConst(70,"已装备同类型星神");
      
      public static const STAR_GOD_COLLECTION_IS_FULL:BattleResultConst = new BattleResultConst(72,"星神收藏满了");
      
      public static const STAR_GOD_PACK_NUM_NOT_FIT_AUTO_FUSION:BattleResultConst = new BattleResultConst(73,"星神背包数量不适合一键合成（数量小于或等于1）");
      
      public static const STAR_GOD_REACH_MAX_LEVEL:BattleResultConst = new BattleResultConst(74,"星神已经满级");
      
      public static const STAR_GOD_NO_VIP:BattleResultConst = new BattleResultConst(75,"不是vip");
      
      public static const HATCH_IS_HATCHING:BattleResultConst = new BattleResultConst(81,"孵化器有蛋在孵化中");
      
      public static const HATCH_PET_EGG_NOT_ENOUGH:BattleResultConst = new BattleResultConst(82,"宠物蛋不足");
      
      public static const HATCH_IS_NOT_HATCHING:BattleResultConst = new BattleResultConst(83,"孵化器没有在孵化中");
      
      public static const HATCH_CAN_NOT_GAIN_PET_EGG_WHILE_CANCEL:BattleResultConst = new BattleResultConst(84,"取消孵化时，无法获得宠物蛋");
      
      public static const HATCH_MONEY_NOT_ENOUGH:BattleResultConst = new BattleResultConst(85,"金币（RMB）不足");
      
      public static const HATCH_PET_NOT_EXIST_IN_HATCHER:BattleResultConst = new BattleResultConst(86,"该孵化器没有孵化好的宠物 ");
      
      public static const PRE_GUARDER_NOT_BEAT:BattleResultConst = new BattleResultConst(91,"有前提守护者没有打");
      
      public static const ORIGINAL_GUARDER_NOT_BEAT:BattleResultConst = new BattleResultConst(92,"有初级守护者没有打");
      
      public static const GUARDER_NOT_EXIST:BattleResultConst = new BattleResultConst(93,"守护者不存在");
      
      public static const ZHANDOULI_NOT_ENOUGH:BattleResultConst = new BattleResultConst(94,"当前战斗力小于打该守护者所需的最小战斗力");
      
      public static const PRE_CHAPTER_GUARDER_NOT_BEAT:BattleResultConst = new BattleResultConst(95,"有之前的章节的守护者没有打");
      
      public static const GUARDER_NOT_IN_RIGHT_SCENE:BattleResultConst = new BattleResultConst(96,"该守护者不在此场景中");
      
      public static const PLAYER_IS_NULL:BattleResultConst = new BattleResultConst(100,"玩家不在线");
      
      public static const PARAM_ERROR:BattleResultConst = new BattleResultConst(101,"参数不对");
      
      public static const DEFINE_NOT_EXIST:BattleResultConst = new BattleResultConst(102,"定义不存在");
      
      public static const EXCEPTION:BattleResultConst = new BattleResultConst(103,"异常");
      
      public static const SAVE_DATA_FAIL:BattleResultConst = new BattleResultConst(104,"持久化保存数据失败");
      
      public static const GENERATE_ID_FAIL:BattleResultConst = new BattleResultConst(105,"ID生成失败");
      
      public static const TARGET_USER_NOT_EXIST:BattleResultConst = new BattleResultConst(106,"目标不存在");
      
      public static const AUTO_FIGHT_SCENE_NOT_SUPPORT:BattleResultConst = new BattleResultConst(201,"当前场景不能自动战斗");
      
      public static const AUTO_FIGHT_ZHAN_DOU_LI_NOT_ENOUGH:BattleResultConst = new BattleResultConst(202,"战斗力不足");
      
      public static const AUTO_FIGHT_NOT_ENOUGH_OR_NOT_OPEN:BattleResultConst = new BattleResultConst(203,"自动战斗次数不够或者为开启");
      
      public static const GROUP_PRACTICE_PET_NOT_FIT:BattleResultConst = new BattleResultConst(210,"精灵不适合主宠Buff锻炼");
      
      public static const GROUP_PRACTICE_HAS_LADE_SAME_KIND:BattleResultConst = new BattleResultConst(211,"已装备同类型主宠");
      
      public static const GROUP_PRACTICE_IN_PROCESS_OF_PRACTICING:BattleResultConst = new BattleResultConst(212,"正在锻炼");
      
      public static const GROUP_PRACTICE_PET_NOT_PRACTICE:BattleResultConst = new BattleResultConst(213,"精灵没在主宠Buff锻炼中");
      
      public static const GROUP_PRACTICE_FINISH_TODAY_PRACTICE:BattleResultConst = new BattleResultConst(214,"已经完成今天的锻炼");
      
      public static const GROUP_PRACTICE_FINISH_ALL_PRACTICE:BattleResultConst = new BattleResultConst(215,"已经完成所有锻炼");
      
      public static const GROUP_PRACTICE_MAIN_PET_NOT_ENOUGH:BattleResultConst = new BattleResultConst(216,"主宠不足");
      
      public static const GROUP_PRACTICE_DIAMOND_NOT_ENOUGH:BattleResultConst = new BattleResultConst(217,"钻石不足");
      
      public static const GROUP_PRACTICE_IDLESSE:BattleResultConst = new BattleResultConst(218,"空闲中");
      
      public static const CAN_NOT_FIGHT_THE_CREEP_WHEN_IN_A_TEAM:BattleResultConst = new BattleResultConst(224,"组队状态下不能与该怪战斗");
      
      private var _id:int;
      
      private var _desc:String;
      
      public function BattleResultConst(param1:int, param2:String)
      {
         super();
         this._id = param1;
         this._desc = param2;
         if(resultMap == null)
         {
            resultMap = {};
         }
         resultMap[this._id] = this;
      }
      
      public static function getResultConstById(param1:int) : BattleResultConst
      {
         return resultMap[param1];
      }
      
      public function get resultId() : int
      {
         return this._id;
      }
      
      public function get desc() : String
      {
         return this._desc;
      }
   }
}

