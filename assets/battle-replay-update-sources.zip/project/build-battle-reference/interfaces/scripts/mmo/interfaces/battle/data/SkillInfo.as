package mmo.interfaces.battle.data
{
   public class SkillInfo
   {
      
      private var _sName:String = "default";
      
      private var _nId:int = -1;
      
      private var _sDescription:String;
      
      public function SkillInfo(param1:int, param2:String, param3:String)
      {
         super();
         this._nId = param1;
         this._sName = param2;
         this._sDescription = param3;
      }
      
      public function get name() : String
      {
         return this._sName;
      }
      
      public function get id() : int
      {
         return this._nId;
      }
      
      public function get description() : String
      {
         return this._sDescription;
      }
   }
}

