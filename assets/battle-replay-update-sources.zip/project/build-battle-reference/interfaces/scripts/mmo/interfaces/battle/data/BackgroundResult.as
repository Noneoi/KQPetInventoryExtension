package mmo.interfaces.battle.data
{
   public class BackgroundResult
   {
      
      private var _teamId:int;
      
      private var _serverId:int;
      
      public function BackgroundResult()
      {
         super();
      }
      
      public static function parseServerResponse(param1:Object) : BackgroundResult
      {
         var _loc2_:BackgroundResult = new BackgroundResult();
         _loc2_._teamId = param1["p"];
         _loc2_._serverId = param1["id"];
         return _loc2_;
      }
      
      public function get teamId() : int
      {
         return this._teamId;
      }
      
      public function get serverId() : int
      {
         return this._serverId;
      }
   }
}

