package mmo.interfaces.battle.data
{
   public class ShiftAction
   {
      
      private var _nTeamId:int;
      
      private var _sPlayerName:String;
      
      private var _nXTo:int;
      
      private var _nYTo:int;
      
      public function ShiftAction()
      {
         super();
      }
      
      public static function parseServerResponce(param1:Object, param2:Boolean) : ShiftAction
      {
         var _loc3_:ShiftAction = new ShiftAction();
         _loc3_._nTeamId = param1.teamId ^ (param2 ? 1 : 0);
         _loc3_._sPlayerName = param1.player;
         _loc3_._nXTo = param1.x_to;
         _loc3_._nYTo = param1.y_to;
         return _loc3_;
      }
      
      public function get teamId() : int
      {
         return this._nTeamId;
      }
      
      public function get playerName() : String
      {
         return this._sPlayerName;
      }
      
      public function get xTo() : int
      {
         return this._nXTo;
      }
      
      public function get yTo() : int
      {
         return this._nYTo;
      }
   }
}

