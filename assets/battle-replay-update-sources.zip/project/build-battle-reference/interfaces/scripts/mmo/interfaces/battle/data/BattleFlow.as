package mmo.interfaces.battle.data
{
   public class BattleFlow
   {
      
      private var _arrBattleUnits:Array = [];
      
      private var _battleResult:BattleResult;
      
      public function BattleFlow()
      {
         super();
      }
      
      public static function parseServerResponce(param1:Array, param2:BattleResult) : BattleFlow
      {
         var _loc5_:Object = null;
         var _loc6_:BattleUnit = null;
         var _loc3_:BattleFlow = new BattleFlow();
         var _loc4_:int = 0;
         while(_loc4_ < param1.length)
         {
            _loc5_ = param1[_loc4_];
            _loc6_ = BattleUnit.parseServerResponce(_loc5_,_loc3_,param2.battleInfo.exchangedTeamId);
            _loc3_._arrBattleUnits.push(_loc6_);
            _loc4_++;
         }
         _loc3_._battleResult = param2;
         return _loc3_;
      }
      
      public function get battleUnits() : Array
      {
         return this._arrBattleUnits;
      }
      
      public function get battleResult() : BattleResult
      {
         return this._battleResult;
      }
   }
}

