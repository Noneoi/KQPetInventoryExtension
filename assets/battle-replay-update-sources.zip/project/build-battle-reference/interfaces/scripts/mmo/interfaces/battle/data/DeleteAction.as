package mmo.interfaces.battle.data
{
   public class DeleteAction
   {
      
      private var _nTeamId:int;
      
      private var _sPlayerName:String;
      
      public function DeleteAction()
      {
         super();
      }
      
      public static function parseServerResponce(param1:Object, param2:Boolean) : DeleteAction
      {
         var _loc3_:DeleteAction = new DeleteAction();
         _loc3_._nTeamId = param1.teamId ^ (param2 ? 1 : 0);
         _loc3_._sPlayerName = param1.player;
         return _loc3_;
      }
      
      public function get teamId() : int
      {
         return this._nTeamId;
      }
      
      public function get playerName() : String
      {
         return this._sPlayerName;
      }
   }
}

