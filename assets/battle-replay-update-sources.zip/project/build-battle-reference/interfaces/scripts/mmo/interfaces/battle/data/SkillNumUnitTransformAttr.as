package mmo.interfaces.battle.data
{
   import mmo.common.SplitUtil;
   
   public class SkillNumUnitTransformAttr extends SkillNumUnitTiming
   {
      
      private var _nRaceTypeIds:Array;
      
      public function SkillNumUnitTransformAttr()
      {
         super();
      }
      
      public static function parseServerResponce(param1:Object) : SkillNumUnitTransformAttr
      {
         var _loc2_:SkillNumUnitTransformAttr = new SkillNumUnitTransformAttr();
         parseServerResponceTransformAttr(_loc2_,param1);
         return _loc2_;
      }
      
      protected static function parseServerResponceTransformAttr(param1:SkillNumUnitTransformAttr, param2:Object) : void
      {
         parseServerResponceTiming(param1,param2);
         param1._nRaceTypeIds = SplitUtil.splitToInt(param2["ca"],",");
      }
      
      public function get raceTypeIds() : Array
      {
         return this._nRaceTypeIds;
      }
   }
}

