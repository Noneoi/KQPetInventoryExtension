package mmo.interfaces.battle.consts
{
   public class FormationConsts
   {
      
      public static const MAX_ROW_COUNT:int = 3;
      
      public static const MAX_COLUME_COUNT:int = 3;
      
      public function FormationConsts()
      {
         super();
      }
   }
}

