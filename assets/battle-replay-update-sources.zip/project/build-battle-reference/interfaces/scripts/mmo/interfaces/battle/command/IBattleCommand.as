package mmo.interfaces.battle.command
{
   import mmo.util.command.ISceneCommand;
   
   public interface IBattleCommand extends ISceneCommand
   {
      
      function pushCommand(param1:*) : void;
      
      function pushParallelCommand(param1:Array) : void;
      
      function unshiftCommand(param1:*) : void;
      
      function unshiftParallelCommand(param1:Array) : void;
      
      function insertCommand(param1:*, param2:*) : void;
      
      function insertParallelCommand(param1:Array, param2:*) : void;
      
      function removeCommand(param1:*) : void;
      
      function removeParallelCommand(param1:Array) : void;
   }
}

