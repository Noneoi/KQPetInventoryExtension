package mmo.interfaces.battle.data
{
   public class CatchPetResult
   {
      
      private var _nBattleId:Number;
      
      private var _arrCatchPetInfos:Array;
      
      public function CatchPetResult()
      {
         super();
      }
      
      public static function parseServerResponce(param1:Object) : CatchPetResult
      {
         var _loc4_:Object = null;
         var _loc5_:CatchPetInfo = null;
         if(param1 == null)
         {
            return null;
         }
         var _loc2_:CatchPetResult = new CatchPetResult();
         _loc2_._nBattleId = param1.bid;
         _loc2_._arrCatchPetInfos = new Array();
         var _loc3_:Array = param1.cl;
         for each(_loc4_ in _loc3_)
         {
            _loc5_ = CatchPetInfo.parseServerResponce(_loc4_);
            _loc2_._arrCatchPetInfos.push(_loc5_);
         }
         return _loc2_;
      }
      
      public function get battleId() : Number
      {
         return this._nBattleId;
      }
      
      public function get catchPetInfos() : Array
      {
         return this._arrCatchPetInfos;
      }
   }
}

