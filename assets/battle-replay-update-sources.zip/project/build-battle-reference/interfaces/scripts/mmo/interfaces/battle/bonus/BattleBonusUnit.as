package mmo.interfaces.battle.bonus
{
   public class BattleBonusUnit
   {
      
      private var _nTypeId:int;
      
      private var _nNum:int;
      
      public function BattleBonusUnit(param1:int, param2:int)
      {
         super();
         this._nTypeId = param1;
         this._nNum = param2;
      }
      
      public function get typeId() : int
      {
         return this._nTypeId;
      }
      
      public function get num() : int
      {
         return this._nNum;
      }
   }
}

