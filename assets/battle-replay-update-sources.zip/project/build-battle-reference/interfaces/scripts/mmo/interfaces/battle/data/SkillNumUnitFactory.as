package mmo.interfaces.battle.data
{
   import mmo.interfaces.battle.consts.SkillNumUnitType;
   
   public class SkillNumUnitFactory
   {
      
      public function SkillNumUnitFactory()
      {
         super();
      }
      
      public static function getSkillNumUnitTiming(param1:Object) : SkillNumUnitTiming
      {
         var _loc2_:int = int(param1[SkillNumUnit.TYPE_KEY]);
         switch(_loc2_)
         {
            case SkillNumUnitType.TRANSFORM:
               return SkillNumUnitTransform.parseServerResponce(param1);
            case SkillNumUnitType.VALUE_UPDATE:
               return SkillNumUnitValueUpdate.parseServerResponce(param1);
            case SkillNumUnitType.SUMMON:
               return SkillNumUnitSummon.parseServerResponce(param1);
            case SkillNumUnitType.BUFF_STATE_CHANGE:
               return SkillNumUnitBuffChangedState.parseServerResponce(param1);
            case SkillNumUnitType.SELF_REPLICATION:
               return SkillNumUnitReplication.parseServerResponce(param1);
            case SkillNumUnitType.TRANSFORM_ATTR:
               return SkillNumUnitTransformAttr.parseServerResponce(param1);
            case SkillNumUnitType.BUFF_ADDING:
            case SkillNumUnitType.BUFF_LAYERS_CHANGE:
               return SkillNumUnitNothing.parseServerResponce(param1);
            default:
               throw new Error("Unexpected SkillNumUnitType");
         }
      }
   }
}

