package mmo.interfaces.battle.data
{
   public class NpcBlessResult
   {
      
      private var _nNpcId:int;
      
      private var _nLeftNum:int;
      
      public function NpcBlessResult()
      {
         super();
      }
      
      public static function parseServerResponce(param1:Object) : NpcBlessResult
      {
         if(param1 == null)
         {
            return null;
         }
         var _loc2_:NpcBlessResult = new NpcBlessResult();
         _loc2_._nNpcId = int(param1.n);
         _loc2_._nLeftNum = int(param1.t);
         return _loc2_;
      }
      
      public function get npcId() : int
      {
         return this._nNpcId;
      }
      
      public function get leftNum() : int
      {
         return this._nLeftNum;
      }
   }
}

