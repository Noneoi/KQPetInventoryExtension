package mmo.interfaces.battle.data
{
   public class SkillNumUnit
   {
      
      public static const TYPE_KEY:String = "t";
      
      public static const CHANGE_SET:String = "changeset";
      
      protected var _nType:int;
      
      protected var _nChangeSet:int;
      
      public function SkillNumUnit()
      {
         super();
      }
      
      public static function parseServerResponce(param1:Object) : SkillNumUnit
      {
         var _loc2_:SkillNumUnit = new SkillNumUnit();
         parseServerResponceBase(_loc2_,param1);
         return _loc2_;
      }
      
      protected static function parseServerResponceBase(param1:SkillNumUnit, param2:Object) : void
      {
         param1._nType = int(param2[TYPE_KEY]);
         param1._nChangeSet = int(param2[CHANGE_SET]);
      }
      
      public function get changeSetId() : int
      {
         return this._nChangeSet;
      }
      
      public function get type() : int
      {
         return this._nType;
      }
   }
}

