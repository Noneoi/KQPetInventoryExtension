package mmo.interfaces.battle.data
{
   import com.adobe.utils.StringUtil;
   import mmo.loader.common.datastructures.HashMap;
   
   public class PlayerInfo
   {
      
      public static const PLAYER_TYPE_USER:int = 0;
      
      public static const PLAYER_TYPE_AI:int = 1;
      
      public static const PLAYER_TYPE_TEAM:int = 2;
      
      private var _nPlayerId:int;
      
      private var _sPlayerName:String;
      
      private var _sPlayerNickName:String;
      
      private var _nInitPosX:int;
      
      private var _nInitPosY:int;
      
      private var _nFormationId:int;
      
      private var _nFormationLevel:int;
      
      private var _nPlayerType:int;
      
      private var _nBattlePower:int;
      
      private var _nPlayerSpeed:int;
      
      private var _mapId2Fighter:HashMap;
      
      private var _nCurX:int;
      
      private var _nCurY:int;
      
      private var _heroSkillId:int;
      
      private var _bIsDead:Boolean;
      
      private var _realName:String;
      
      private var _forceShowClothes:String;
      
      private var _mapId2PetDragon:HashMap;
      
      private var _fightPetDragonInfos:Array;
      
      private var _psychicsBuffData:BufferData;
      
      private var _init2addPlayerBuffs:Array;
      
      private var _leagueArsenalResult:LeagueArsenalResult;
      
      public function PlayerInfo(param1:int, param2:String, param3:int, param4:int, param5:int, param6:int, param7:int, param8:int, param9:int, param10:int)
      {
         super();
         this._nPlayerId = param1;
         this._sPlayerName = param2;
         this._nFormationId = param3;
         this._nFormationLevel = param4;
         this._nPlayerType = param5;
         this._nBattlePower = param6;
         this._nPlayerSpeed = param7;
         this._nInitPosX = param8;
         this._nInitPosY = param9;
         this._mapId2Fighter = new HashMap();
         this._nCurX = param8;
         this._nCurX = param9;
         this._heroSkillId = param10;
         this._bIsDead = false;
         this._init2addPlayerBuffs = [];
         this._fightPetDragonInfos = [];
      }
      
      public static function parseServerResponce(param1:Object) : PlayerInfo
      {
         var _loc13_:Object = null;
         var _loc14_:Array = null;
         var _loc15_:int = 0;
         var _loc16_:Object = null;
         var _loc17_:Object = null;
         var _loc18_:FighterInfo = null;
         var _loc19_:FightPetDragonInfo = null;
         var _loc2_:int = int(param1.id);
         var _loc3_:String = param1.name;
         var _loc4_:int = int(param1.fp);
         var _loc5_:int = int(param1.sp);
         var _loc6_:int = int(param1.fm);
         var _loc7_:int = int(param1.fl);
         var _loc8_:int = int(param1.type);
         var _loc9_:int = int(param1.x);
         var _loc10_:int = int(param1.y);
         var _loc11_:int = int(param1.hs);
         var _loc12_:PlayerInfo = new PlayerInfo(_loc2_,_loc3_,_loc6_,_loc7_,_loc8_,_loc4_,_loc5_,_loc9_,_loc10_,_loc11_);
         _loc12_.realName = param1.rn;
         _loc12_.forceShowClothes = param1.fsc;
         for each(_loc13_ in param1.cts)
         {
            _loc18_ = FighterInfo.parseServerResponce(_loc13_);
            _loc12_.registerFighter(_loc18_);
         }
         _loc14_ = param1.drs;
         for each(_loc16_ in _loc14_)
         {
            _loc19_ = FightPetDragonInfo.parseInfo(_loc16_);
            _loc12_._fightPetDragonInfos[_loc15_] = _loc19_;
            _loc15_++;
         }
         _loc17_ = param1.ppbf;
         if(Boolean(_loc17_))
         {
            _loc12_._psychicsBuffData = BufferData.parseServerResponce(_loc17_);
         }
         if(param1.pcbfs != null)
         {
            _loc12_._init2addPlayerBuffs = StringUtil.split2IntegerArray(String(param1.pcbfs));
         }
         if(param1["ea"] != null)
         {
            _loc12_._leagueArsenalResult = LeagueArsenalResult.parseServerResponce(param1["ea"]["1uw"]);
         }
         return _loc12_;
      }
      
      public function get leagueArsenalResult() : LeagueArsenalResult
      {
         return this._leagueArsenalResult;
      }
      
      public function get init2addPlayerBuffs() : Array
      {
         return this._init2addPlayerBuffs;
      }
      
      public function get psychicsBuffData() : BufferData
      {
         return this._psychicsBuffData;
      }
      
      public function get playerId() : int
      {
         return this._nPlayerId;
      }
      
      public function get playerName() : String
      {
         return this._sPlayerName;
      }
      
      public function get playNickName() : String
      {
         return this._sPlayerNickName;
      }
      
      public function get formationId() : int
      {
         return this._nFormationId;
      }
      
      public function get formationLevel() : int
      {
         return this._nFormationLevel;
      }
      
      public function get playerType() : int
      {
         return this._nPlayerType;
      }
      
      public function get battlePower() : int
      {
         return this._nBattlePower;
      }
      
      public function get playerSpeed() : int
      {
         return this._nPlayerSpeed;
      }
      
      public function get initPosX() : int
      {
         return this._nInitPosX;
      }
      
      public function get initPosY() : int
      {
         return this._nInitPosY;
      }
      
      public function registerFighter(param1:FighterInfo) : void
      {
         this._mapId2Fighter.add(param1.id,param1);
      }
      
      public function get fighterInfos() : Array
      {
         return this._mapId2Fighter.getValues();
      }
      
      public function getFighterInfoById(param1:int) : FighterInfo
      {
         return this._mapId2Fighter.getValue(param1);
      }
      
      public function get curX() : int
      {
         return this._nCurX;
      }
      
      public function setCurX(param1:int) : void
      {
         this._nCurX = param1;
      }
      
      public function get curY() : int
      {
         return this._nCurY;
      }
      
      public function setCurY(param1:int) : void
      {
         this._nCurY = param1;
      }
      
      public function get isDead() : Boolean
      {
         return this._bIsDead;
      }
      
      public function setIsDead(param1:Boolean) : void
      {
         this._bIsDead = param1;
      }
      
      public function get heroSkillId() : int
      {
         return this._heroSkillId;
      }
      
      public function set realName(param1:String) : void
      {
         this._realName = param1;
      }
      
      public function get realName() : String
      {
         return this._realName;
      }
      
      public function set forceShowClothes(param1:String) : void
      {
         this._forceShowClothes = param1;
      }
      
      public function get forceShowClothes() : String
      {
         return this._forceShowClothes;
      }
      
      public function get fightPetDragonInfos() : Array
      {
         return this._fightPetDragonInfos;
      }
      
      public function get hasPetDragonInBattle() : Boolean
      {
         var _loc2_:FightPetDragonInfo = null;
         var _loc1_:int = 0;
         while(_loc1_ < this._fightPetDragonInfos.length)
         {
            _loc2_ = this._fightPetDragonInfos[_loc1_];
            if(_loc2_ != null && _loc2_.getDragonId() > 0)
            {
               return true;
            }
            _loc1_++;
         }
         return false;
      }
   }
}

