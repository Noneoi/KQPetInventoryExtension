package mmo.interfaces.battle.data
{
   public class BattleFlashToH5Info
   {
      
      private static const SplitChar:String = "#";
      
      public var userName:String = "";
      
      public var vipLv:int = 0;
      
      public var baiXingLv:int = 0;
      
      public var player0AvatarStr:String = "";
      
      public var player1AvatarStr:String = "";
      
      public var filterEffectRaceIds:Array = [];
      
      public var simpleResType:int = 0;
      
      public var oriBrData:Object = null;
      
      public function BattleFlashToH5Info()
      {
         super();
      }
      
      public static function parseData(param1:String) : BattleFlashToH5Info
      {
         var _loc3_:int = 0;
         var _loc2_:BattleFlashToH5Info = new BattleFlashToH5Info();
         _loc3_ = param1.indexOf(SplitChar);
         if(_loc3_ < 0)
         {
            return null;
         }
         _loc2_.userName = param1.substr(0,_loc3_);
         param1 = param1.substring(_loc3_ + 1);
         _loc3_ = param1.indexOf(SplitChar);
         if(_loc3_ < 0)
         {
            return null;
         }
         _loc2_.vipLv = int(param1.substr(0,_loc3_));
         param1 = param1.substring(_loc3_ + 1);
         _loc3_ = param1.indexOf(SplitChar);
         if(_loc3_ < 0)
         {
            return null;
         }
         _loc2_.baiXingLv = int(param1.substr(0,_loc3_));
         param1 = param1.substring(_loc3_ + 1);
         _loc3_ = param1.indexOf(SplitChar);
         if(_loc3_ < 0)
         {
            return null;
         }
         _loc2_.player0AvatarStr = param1.substr(0,_loc3_);
         param1 = param1.substring(_loc3_ + 1);
         _loc3_ = param1.indexOf(SplitChar);
         if(_loc3_ < 0)
         {
            return null;
         }
         _loc2_.player1AvatarStr = param1.substr(0,_loc3_);
         param1 = param1.substring(_loc3_ + 1);
         _loc3_ = param1.indexOf(SplitChar);
         if(_loc3_ < 0)
         {
            return null;
         }
         _loc2_.simpleResType = parseInt(param1.substr(0,_loc3_));
         param1 = param1.substring(_loc3_ + 1);
         _loc3_ = param1.indexOf(SplitChar);
         if(_loc3_ < 0)
         {
            return null;
         }
         _loc2_.filterEffectRaceIds = JSON.parse(param1.substr(0,_loc3_)) as Array;
         param1 = param1.substring(_loc3_ + 1);
         _loc2_.oriBrData = JSON.parse(param1);
         return _loc2_;
      }
      
      public function toStr() : String
      {
         var _loc1_:String = "";
         _loc1_ += this.userName + SplitChar;
         _loc1_ += this.vipLv + SplitChar;
         _loc1_ += this.baiXingLv + SplitChar;
         _loc1_ += this.player0AvatarStr + SplitChar;
         _loc1_ += this.player1AvatarStr + SplitChar;
         _loc1_ += this.simpleResType.toString() + SplitChar;
         _loc1_ += JSON.stringify(this.filterEffectRaceIds) + SplitChar;
         return _loc1_ + JSON.stringify(this.oriBrData);
      }
   }
}

