package mmo.interfaces.battle.data
{
   import mmo.common.SplitUtil;
   
   public class DamageItemResult extends AbstractItemResult
   {
      
      protected var _arrDamages:Array;
      
      public function DamageItemResult()
      {
         super();
      }
      
      public static function parseServerResponce(param1:Object) : DamageItemResult
      {
         if(param1 == null)
         {
            return null;
         }
         var _loc2_:DamageItemResult = new DamageItemResult();
         _loc2_.setAbstractProperties(param1);
         _loc2_._arrDamages = SplitUtil.splitToInt(String(param1.ds),",");
         return _loc2_;
      }
      
      public function get damages() : Array
      {
         return this._arrDamages;
      }
   }
}

