package mmo.interfaces.battle.data
{
   public class ExtExpResult
   {
      
      private static const TYPE_VIP_EXT:int = 1;
      
      private static const TYPE_TIME_EXT:int = 2;
      
      private static const TYPE_ITEM_EXT:int = 3;
      
      private static const TYPE_ANTI_ADDICTION_EXT:int = 4;
      
      private static const TYPE_FAMILY_EXT:int = 5;
      
      private var _type2value:Array = [0,0,0,0,0,0];
      
      public function ExtExpResult()
      {
         super();
      }
      
      public static function paserServerResponce(param1:String) : ExtExpResult
      {
         var _loc3_:Array = null;
         var _loc4_:String = null;
         var _loc5_:Array = null;
         var _loc6_:int = 0;
         var _loc7_:int = 0;
         var _loc2_:ExtExpResult = new ExtExpResult();
         if(param1 != null)
         {
            _loc3_ = param1.split("#");
            for each(_loc4_ in _loc3_)
            {
               _loc5_ = _loc4_.split(":");
               _loc6_ = int(_loc5_[0]);
               _loc7_ = int(_loc5_[1]) - 100;
               _loc2_._type2value[_loc6_] = _loc7_;
            }
         }
         return _loc2_;
      }
      
      public function get vipExtraExp() : int
      {
         return this._type2value[TYPE_VIP_EXT];
      }
      
      public function get timeExtraExp() : int
      {
         return this._type2value[TYPE_TIME_EXT];
      }
      
      public function get itemExtraExp() : int
      {
         return this._type2value[TYPE_ITEM_EXT];
      }
      
      public function get antiAddictionExtraExp() : int
      {
         return this._type2value[TYPE_ANTI_ADDICTION_EXT];
      }
      
      public function get familyExtraExp() : int
      {
         return this._type2value[TYPE_FAMILY_EXT];
      }
   }
}

