package mmo.battleconfig.data
{
   import mmo.interfaces.battleconfig.define.ActionMovieDefine;
   
   public class ActionMovieConfigXML
   {
      
      private static var _instance:ActionMovieConfigXML;
      
      private var _xmlClass:Class = ActionMovieConfigXML__xmlClass;
      
      private var _id2define:Object;
      
      public function ActionMovieConfigXML()
      {
         super();
         this.parseConfig();
      }
      
      public static function get instance() : ActionMovieConfigXML
      {
         if(_instance == null)
         {
            _instance = new ActionMovieConfigXML();
         }
         return _instance;
      }
      
      public function parseConfig() : void
      {
         var _loc2_:XML = null;
         var _loc3_:ActionMovieDefine = null;
         this._id2define = {};
         var _loc1_:XML = XML(new this._xmlClass().toString());
         for each(_loc2_ in _loc1_.s)
         {
            _loc3_ = ActionMovieDefine.parseDefine(_loc2_);
            this._id2define[_loc3_.id] = _loc3_;
         }
      }
      
      public function getMovieDefineById(param1:int) : ActionMovieDefine
      {
         return this._id2define[param1];
      }
   }
}

