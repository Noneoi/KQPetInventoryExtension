package mmo.battleconfig.data
{
   import mmo.interfaces.battleconfig.define.AlmightySkillDefine;
   import mmo.loader.common.datastructures.HashMap;
   
   public class AlmightyConfigXML
   {
      
      private static var _instance:AlmightyConfigXML;
      
      private var _xmlClass:Class = AlmightyConfigXML__xmlClass;
      
      private var _id2Define:HashMap;
      
      public function AlmightyConfigXML()
      {
         super();
         this.parseConfig();
      }
      
      public static function get instance() : AlmightyConfigXML
      {
         if(_instance == null)
         {
            _instance = new AlmightyConfigXML();
         }
         return _instance;
      }
      
      public function parseConfig() : void
      {
         this._id2Define = new HashMap();
         this.parseXMLConfig(this._xmlClass);
      }
      
      private function parseXMLConfig(param1:Class) : void
      {
         var _loc3_:XML = null;
         var _loc4_:AlmightySkillDefine = null;
         var _loc2_:XML = XML(new param1().toString());
         for each(_loc3_ in _loc2_.pet.s)
         {
            _loc4_ = AlmightySkillDefine.parseDefine(_loc3_);
            if(!this._id2Define.containsKey(_loc4_.id))
            {
               this._id2Define.add(_loc4_.id,[_loc4_]);
            }
         }
      }
      
      public function getAlmightyDefine(param1:int) : Array
      {
         if(!this._id2Define.containsKey(param1))
         {
            return [];
         }
         return this._id2Define.getValue(param1).concat();
      }
   }
}

