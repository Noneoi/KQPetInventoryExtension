package mmo.battleconfig.data
{
   import mx.core.ByteArrayAsset;
   
   [Embed(source="/_assets/1_mmo.battleconfig.data.SummonConfigXML__xmlClass.bin", mimeType="application/octet-stream")]
   public class SummonConfigXML__xmlClass extends ByteArrayAsset
   {
      
      public function SummonConfigXML__xmlClass()
      {
         super();
      }
   }
}

