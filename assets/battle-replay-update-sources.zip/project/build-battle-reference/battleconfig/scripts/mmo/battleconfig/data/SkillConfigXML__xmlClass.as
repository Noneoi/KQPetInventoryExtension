package mmo.battleconfig.data
{
   import mx.core.ByteArrayAsset;
   
   [Embed(source="/_assets/17_mmo.battleconfig.data.SkillConfigXML__xmlClass.bin", mimeType="application/octet-stream")]
   public class SkillConfigXML__xmlClass extends ByteArrayAsset
   {
      
      public function SkillConfigXML__xmlClass()
      {
         super();
      }
   }
}

