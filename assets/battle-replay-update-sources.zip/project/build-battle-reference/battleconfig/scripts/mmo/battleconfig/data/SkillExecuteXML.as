package mmo.battleconfig.data
{
   import mmo.interfaces.battleconfig.define.SkillExecuteDefine;
   import mmo.loader.common.datastructures.HashMap;
   
   public class SkillExecuteXML
   {
      
      private static var _instance:SkillExecuteXML;
      
      private var _xmlClass:Class = SkillExecuteXML__xmlClass;
      
      private var _code2define:HashMap;
      
      public function SkillExecuteXML()
      {
         super();
         this.parseConfig();
      }
      
      public static function get instance() : SkillExecuteXML
      {
         if(_instance == null)
         {
            _instance = new SkillExecuteXML();
         }
         return _instance;
      }
      
      public function parseConfig() : void
      {
         var _loc2_:XML = null;
         var _loc3_:SkillExecuteDefine = null;
         this._code2define = new HashMap();
         var _loc1_:XML = XML(new this._xmlClass().toString());
         for each(_loc2_ in _loc1_.s)
         {
            _loc3_ = SkillExecuteDefine.parseDefine(_loc2_);
            this._code2define.add(_loc3_.code,_loc3_);
         }
      }
      
      public function getSkillExecutDefine(param1:int) : SkillExecuteDefine
      {
         return this._code2define.getValue(param1);
      }
   }
}

