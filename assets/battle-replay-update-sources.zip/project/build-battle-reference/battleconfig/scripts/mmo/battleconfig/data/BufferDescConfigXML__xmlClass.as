package mmo.battleconfig.data
{
   import mx.core.ByteArrayAsset;
   
   [Embed(source="/_assets/20_mmo.battleconfig.data.BufferDescConfigXML__xmlClass.bin", mimeType="application/octet-stream")]
   public class BufferDescConfigXML__xmlClass extends ByteArrayAsset
   {
      
      public function BufferDescConfigXML__xmlClass()
      {
         super();
      }
   }
}

