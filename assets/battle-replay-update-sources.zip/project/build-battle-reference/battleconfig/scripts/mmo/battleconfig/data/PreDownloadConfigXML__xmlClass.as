package mmo.battleconfig.data
{
   import mx.core.ByteArrayAsset;
   
   [Embed(source="/_assets/12_mmo.battleconfig.data.PreDownloadConfigXML__xmlClass.bin", mimeType="application/octet-stream")]
   public class PreDownloadConfigXML__xmlClass extends ByteArrayAsset
   {
      
      public function PreDownloadConfigXML__xmlClass()
      {
         super();
      }
   }
}

