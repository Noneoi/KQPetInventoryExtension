package mmo.battleconfig.data
{
   import mmo.interfaces.battleconfig.define.BattleAvatarDefine;
   import mmo.loader.common.datastructures.HashMap;
   
   public class BattleAvatarConfigXML
   {
      
      private static var _instance:BattleAvatarConfigXML;
      
      private var _xmlClass:Class = BattleAvatarConfigXML__xmlClass;
      
      private var _id2define:HashMap;
      
      public function BattleAvatarConfigXML()
      {
         super();
         this.parseConfig();
      }
      
      public static function get instance() : BattleAvatarConfigXML
      {
         if(_instance == null)
         {
            _instance = new BattleAvatarConfigXML();
         }
         return _instance;
      }
      
      public function parseConfig() : void
      {
         var _loc2_:XML = null;
         var _loc3_:BattleAvatarDefine = null;
         this._id2define = new HashMap();
         var _loc1_:XML = XML(new this._xmlClass().toString());
         for each(_loc2_ in _loc1_.s)
         {
            _loc3_ = BattleAvatarDefine.parseDefine(_loc2_);
            this._id2define.add(_loc3_.Id,_loc3_);
         }
      }
      
      public function getAvatorDefineById(param1:int) : BattleAvatarDefine
      {
         return this._id2define.getValue(param1);
      }
   }
}

