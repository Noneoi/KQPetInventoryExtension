package mmo.battleconfig.data
{
   public class BattleChangeAvatarConfigXML
   {
      
      private static var _instance:BattleChangeAvatarConfigXML;
      
      private var _ids:Array = [];
      
      private var _xmlClass:Class = BattleChangeAvatarConfigXML__xmlClass;
      
      public function BattleChangeAvatarConfigXML()
      {
         super();
         this.parseConfig();
      }
      
      public static function get instance() : BattleChangeAvatarConfigXML
      {
         if(_instance == null)
         {
            _instance = new BattleChangeAvatarConfigXML();
         }
         return _instance;
      }
      
      public function parseConfig() : void
      {
         var _loc2_:XML = null;
         var _loc1_:XML = XML(new this._xmlClass().toString());
         for each(_loc2_ in _loc1_.background.s)
         {
            this._ids.push(String(_loc2_.@id));
         }
      }
      
      public function get ids() : Array
      {
         return this._ids;
      }
   }
}

