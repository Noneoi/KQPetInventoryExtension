package mmo.battleconfig.data
{
   import mx.core.ByteArrayAsset;
   
   [Embed(source="/_assets/8_mmo.battleconfig.data.HuanConfigXML__xmlClass.bin", mimeType="application/octet-stream")]
   public class HuanConfigXML__xmlClass extends ByteArrayAsset
   {
      
      public function HuanConfigXML__xmlClass()
      {
         super();
      }
   }
}

