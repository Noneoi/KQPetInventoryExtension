package mmo.battleconfig.data
{
   import mmo.loader.common.datastructures.HashMap;
   
   public class ComboBuffsConfigXML
   {
      
      private static var _instance:ComboBuffsConfigXML;
      
      private var _xmlClass:Class = ComboBuffsConfigXML__xmlClass;
      
      private var _id2define:HashMap;
      
      public function ComboBuffsConfigXML()
      {
         super();
         this.parseConfig();
      }
      
      public static function get instance() : ComboBuffsConfigXML
      {
         if(_instance == null)
         {
            _instance = new ComboBuffsConfigXML();
         }
         return _instance;
      }
      
      public function getTargetSkillIds(param1:int, param2:Array) : int
      {
         var _loc3_:ComboBuffsDefine = this._id2define.getValue(param1) as ComboBuffsDefine;
         if(_loc3_ == null)
         {
            return -1;
         }
         var _loc4_:int = -1;
         var _loc5_:Array = _loc3_.buffs;
         var _loc6_:* = int(_loc5_.length - 1);
         while(_loc6_ >= 0)
         {
            if(param2.indexOf(int(_loc5_[_loc6_])) >= 0)
            {
               _loc4_ = int(_loc3_.targetSkillIds[_loc6_]);
               break;
            }
            _loc6_--;
         }
         return _loc4_;
      }
      
      public function parseConfig() : void
      {
         var _loc2_:XML = null;
         var _loc3_:ComboBuffsDefine = null;
         this._id2define = new HashMap();
         var _loc1_:XML = XML(new this._xmlClass().toString());
         for each(_loc2_ in _loc1_.combo.s)
         {
            _loc3_ = new ComboBuffsDefine(_loc2_.@skillId,_loc2_.@buffs,_loc2_.@targetSkillIds);
            this._id2define.add(_loc3_.skillId,_loc3_);
         }
      }
   }
}

class ComboBuffsDefine
{
   
   internal var skillId:int;
   
   internal var buffs:Array;
   
   internal var targetSkillIds:Array;
   
   public function ComboBuffsDefine(param1:int, param2:String, param3:String)
   {
      super();
      this.skillId = param1;
      this.buffs = param2.split(",");
      this.targetSkillIds = param3.split(",");
   }
}
