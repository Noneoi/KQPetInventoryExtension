package mmo.battleconfig.data
{
   import mmo.interfaces.battleconfig.define.HuanSkillDefine;
   import mmo.loader.common.datastructures.HashMap;
   
   public class HuanConfigXML
   {
      
      private static var _instance:HuanConfigXML;
      
      private var _xmlClass:Class = HuanConfigXML__xmlClass;
      
      private var _id2Define:HashMap;
      
      public function HuanConfigXML()
      {
         super();
         this.parseConfig();
      }
      
      public static function get instance() : HuanConfigXML
      {
         if(_instance == null)
         {
            _instance = new HuanConfigXML();
         }
         return _instance;
      }
      
      public function parseConfig() : void
      {
         this._id2Define = new HashMap();
         this.parseXMLConfig(this._xmlClass);
      }
      
      private function parseXMLConfig(param1:Class) : void
      {
         var _loc3_:XML = null;
         var _loc4_:HuanSkillDefine = null;
         var _loc5_:Array = null;
         var _loc6_:* = 0;
         var _loc2_:XML = XML(new param1().toString());
         for each(_loc3_ in _loc2_.pet.s)
         {
            _loc4_ = HuanSkillDefine.parseDefine(_loc3_);
            if(!this._id2Define.containsKey(_loc4_.id))
            {
               this._id2Define.add(_loc4_.id,[_loc4_]);
            }
            else
            {
               _loc5_ = this._id2Define.getValue(_loc4_.id);
               _loc6_ = int(_loc5_.length - 1);
               while(_loc6_ >= 0)
               {
                  if(_loc5_[_loc6_].valueToTakeEffect <= _loc4_.valueToTakeEffect)
                  {
                     break;
                  }
                  _loc5_[_loc6_ + 1] = _loc5_[_loc6_];
                  _loc6_--;
               }
               _loc5_[_loc6_ + 1] = _loc4_;
            }
         }
      }
      
      public function getHuanDefine(param1:int) : Array
      {
         if(!this._id2Define.containsKey(param1))
         {
            return [];
         }
         return this._id2Define.getValue(param1).concat();
      }
   }
}

