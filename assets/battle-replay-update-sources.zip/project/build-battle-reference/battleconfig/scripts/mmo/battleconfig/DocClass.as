package mmo.battleconfig
{
   import flash.display.Sprite;
   
   public class DocClass extends Sprite
   {
      
      public function DocClass()
      {
         super();
      }
      
      public function compileMe() : void
      {
         var _loc1_:BattleConfig = null;
         var _loc2_:BattleConfigLegacy = null;
      }
   }
}

