package mmo.battleconfig.data
{
   import mx.core.ByteArrayAsset;
   
   [Embed(source="/_assets/5_mmo.battleconfig.data.BattleChangeAvatarConfigXML__xmlClass.bin", mimeType="application/octet-stream")]
   public class BattleChangeAvatarConfigXML__xmlClass extends ByteArrayAsset
   {
      
      public function BattleChangeAvatarConfigXML__xmlClass()
      {
         super();
      }
   }
}

