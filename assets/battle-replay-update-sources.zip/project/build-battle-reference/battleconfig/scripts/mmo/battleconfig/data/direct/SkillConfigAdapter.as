package mmo.battleconfig.data.direct
{
   import mmo.config.ConfigReader;
   
   public class SkillConfigAdapter
   {
      
      public function SkillConfigAdapter()
      {
         super();
      }
      
      public static function getSkillConfigObj(param1:int) : Object
      {
         var _loc2_:String = param1.toString();
         if(SkillConfigSimpleAC.MAP.hasOwnProperty(_loc2_))
         {
            return SkillConfigSimpleAC.MAP[_loc2_];
         }
         var _loc3_:int = param1;
         if(_loc3_ > 100000000)
         {
            _loc3_ = Math.floor(_loc3_ / 1000);
         }
         else if(_loc3_ > 10000000)
         {
            _loc3_ = Math.floor(_loc3_ / 100);
         }
         else if(_loc3_ > 1000000)
         {
            _loc3_ = Math.floor(_loc3_ / 10);
         }
         _loc3_ %= 10000;
         if(_loc3_ <= 3000)
         {
            return SkillConfigSimple3000.MAP[_loc2_];
         }
         if(_loc3_ <= 6000)
         {
            return SkillConfigSimple6000.MAP[_loc2_];
         }
         if(_loc3_ <= 9999)
         {
            return SkillConfigSimple9999.MAP[_loc2_];
         }
         if(ConfigReader.instance.debug)
         {
            throw new Error("Out of range: " + param1 + ". (DEBUG)");
         }
         return null;
      }
   }
}

