package mmo.battleconfig.data
{
   import mmo.interfaces.battleconfig.define.RaceTypeDefine;
   import mmo.loader.common.datastructures.HashMap;
   
   public class RaceTypeConfigXML
   {
      
      private static var _instance:RaceTypeConfigXML;
      
      private var _xmlClass:Class = RaceTypeConfigXML__xmlClass;
      
      private var _id2define:HashMap;
      
      private var _weakEffCoeff:Number = 0.7;
      
      private var _strongEffCoeff:Number = 1.5;
      
      private var _map:Object = {};
      
      public function RaceTypeConfigXML()
      {
         super();
         this.parseConfig();
      }
      
      public static function get instance() : RaceTypeConfigXML
      {
         if(_instance == null)
         {
            _instance = new RaceTypeConfigXML();
         }
         return _instance;
      }
      
      public function parseConfig() : void
      {
         var _loc2_:XML = null;
         var _loc3_:XML = null;
         var _loc4_:XML = null;
         var _loc5_:RaceTypeDefine = null;
         this._id2define = new HashMap();
         var _loc1_:XML = XML(new this._xmlClass().toString());
         for each(_loc2_ in _loc1_.map.m)
         {
            this._map[_loc2_.@id] = _loc2_.@index;
         }
         for each(_loc3_ in _loc1_.race_type.s)
         {
            _loc5_ = RaceTypeDefine.parseDefine(_loc3_,this._map);
            this._id2define.add(_loc5_.id,_loc5_);
         }
         for each(_loc4_ in _loc1_.restraint_coefficient.r)
         {
            if(_loc4_.@nm == "强效")
            {
               this._strongEffCoeff = Number(_loc4_.@value);
            }
            else if(_loc4_.@nm == "弱效")
            {
               this._weakEffCoeff = Number(_loc4_.@value);
            }
         }
      }
      
      public function getRaceTypeDefineById(param1:int) : RaceTypeDefine
      {
         return this._id2define.getValue(param1);
      }
      
      public function get weakEffRestraintCoeff() : Number
      {
         return this._weakEffCoeff;
      }
      
      public function get strongEffRestraintCoeff() : Number
      {
         return this._strongEffCoeff;
      }
   }
}

