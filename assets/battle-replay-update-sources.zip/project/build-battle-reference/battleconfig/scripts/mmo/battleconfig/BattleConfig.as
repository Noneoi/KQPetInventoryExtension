package mmo.battleconfig
{
   import flash.events.EventDispatcher;
   import mmo.battleconfig.data.ActionMovieConfigXML;
   import mmo.battleconfig.data.AlmightyConfigXML;
   import mmo.battleconfig.data.BattleAvatarConfigXML;
   import mmo.battleconfig.data.BattleBgConfigXML;
   import mmo.battleconfig.data.BattleChangeAvatarConfigXML;
   import mmo.battleconfig.data.BufferConfigXML;
   import mmo.battleconfig.data.BufferExecuteXML;
   import mmo.battleconfig.data.CarryConfigXML;
   import mmo.battleconfig.data.ComboBuffsConfigXML;
   import mmo.battleconfig.data.EntryConfigXML;
   import mmo.battleconfig.data.HuanConfigXML;
   import mmo.battleconfig.data.JobTypeConfigXML;
   import mmo.battleconfig.data.PreDownloadConfigXML;
   import mmo.battleconfig.data.RaceTypeConfigXML;
   import mmo.battleconfig.data.SkillConfigXML;
   import mmo.battleconfig.data.SkillEmbedEffectXML;
   import mmo.battleconfig.data.SkillExecuteXML;
   import mmo.battleconfig.data.SummonConfigXML;
   import mmo.battleconfig.data.direct.SkillConfigAdapter;
   import mmo.interfaces.battleconfig.IBattleConfig;
   import mmo.interfaces.battleconfig.define.ActionMovieDefine;
   import mmo.interfaces.battleconfig.define.BattleAvatarDefine;
   import mmo.interfaces.battleconfig.define.BufferDefine;
   import mmo.interfaces.battleconfig.define.BufferExecuteDefine;
   import mmo.interfaces.battleconfig.define.CarryDefine;
   import mmo.interfaces.battleconfig.define.EmbedDialogDefine;
   import mmo.interfaces.battleconfig.define.EntryDefine;
   import mmo.interfaces.battleconfig.define.JobTypeDefine;
   import mmo.interfaces.battleconfig.define.RaceTypeDefine;
   import mmo.interfaces.battleconfig.define.SkillDefine;
   import mmo.interfaces.battleconfig.define.SkillExecuteDefine;
   import mmo.interfaces.battleconfig.define.SummonDefine;
   import mmo.interfaces.battleconfig.entry.IBattleEntry;
   import mmo.play.globalfunctions.optValue;
   
   public class BattleConfig extends EventDispatcher implements IBattleConfig
   {
      
      public function BattleConfig()
      {
         super();
      }
      
      public function getSkillDefineById(param1:int) : SkillDefine
      {
         return SkillConfigXML.instance.getSkillDefineById(param1);
      }
      
      public function getSkillName(param1:int) : String
      {
         return optValue(SkillConfigAdapter.getSkillConfigObj(param1),"name","");
      }
      
      public function getSkillDesc(param1:int) : String
      {
         return optValue(SkillConfigAdapter.getSkillConfigObj(param1),"desc","");
      }
      
      public function getLastSkillDefineById(param1:int) : SkillDefine
      {
         return SkillConfigXML.instance.getLastSkillDefineById(param1);
      }
      
      public function getEmbedEffectDefines(param1:int) : Array
      {
         return SkillEmbedEffectXML.instance.getEmbedEffectDefines(param1);
      }
      
      public function getEmbedDialogDefine(param1:int) : EmbedDialogDefine
      {
         return SkillEmbedEffectXML.instance.getEmbedDialogDefine(param1);
      }
      
      public function getSkillExecutDefine(param1:int) : SkillExecuteDefine
      {
         return SkillExecuteXML.instance.getSkillExecutDefine(param1);
      }
      
      public function getBufferDefineById(param1:int) : BufferDefine
      {
         return BufferConfigXML.instance.getBufferDefineById(param1);
      }
      
      public function getPowerFullBuffId(param1:int) : int
      {
         return BufferConfigXML.instance.getPowerFullBuffId(param1);
      }
      
      public function getDefaultPowerFullBuffId() : int
      {
         return BufferConfigXML.instance.getDefaultPowerFullBuffId();
      }
      
      public function getRaceTypeDefineById(param1:int) : RaceTypeDefine
      {
         return RaceTypeConfigXML.instance.getRaceTypeDefineById(param1);
      }
      
      public function getJobTypeDefineById(param1:int) : JobTypeDefine
      {
         return JobTypeConfigXML.instance.getJobTypeDefineById(param1);
      }
      
      public function get weakEffRestraintCoeff() : Number
      {
         return RaceTypeConfigXML.instance.weakEffRestraintCoeff;
      }
      
      public function get strongEffRestraintCoeff() : Number
      {
         return RaceTypeConfigXML.instance.strongEffRestraintCoeff;
      }
      
      public function get preDownloadFileList() : Array
      {
         return PreDownloadConfigXML.instance.preDownloadFileList;
      }
      
      public function get preDownloadFileListSeq() : Array
      {
         return PreDownloadConfigXML.instance.preDownloadFileListSeq;
      }
      
      public function getBattleAvatarDefineById(param1:int) : BattleAvatarDefine
      {
         return BattleAvatarConfigXML.instance.getAvatorDefineById(param1);
      }
      
      public function get backgroundScenes() : Array
      {
         return BattleBgConfigXML.instance.scenes;
      }
      
      public function get coolPetStoneBGInfo() : Object
      {
         return BattleBgConfigXML.instance.gainCoolPetStoneBgInfo;
      }
      
      public function get changeAvatarIds() : Array
      {
         return BattleChangeAvatarConfigXML.instance.ids;
      }
      
      public function getSummonDefine(param1:int, param2:int) : SummonDefine
      {
         return SummonConfigXML.instance.getSummonDefine(param1,param2);
      }
      
      public function getSummonedPetDefineArray(param1:int) : Array
      {
         return SummonConfigXML.instance.getSummonPet(param1);
      }
      
      public function getSummonerRaceIdArray() : Array
      {
         return SummonConfigXML.instance.getSummonerRaceIdArray();
      }
      
      public function getSummonerPetRaceIdArray() : Array
      {
         return SummonConfigXML.instance.getSummonerPetRaceIdArray();
      }
      
      public function isSummonEffect(param1:int, param2:int) : Boolean
      {
         return SummonConfigXML.instance.getSummonDefine(param1,param2) == null ? false : true;
      }
      
      public function getSummonerTeamRaceIdArray(param1:int) : Array
      {
         return SummonConfigXML.instance.getSummonerTeamRaceIdArray(param1);
      }
      
      public function getBufferExecutDefine(param1:int) : BufferExecuteDefine
      {
         return BufferExecuteXML.instance.getBufferExecutDefine(param1);
      }
      
      public function getComboTargetSkillIds(param1:int, param2:Array) : int
      {
         return ComboBuffsConfigXML.instance.getTargetSkillIds(param1,param2);
      }
      
      public function getCarryDefineArray(param1:int) : Array
      {
         return CarryConfigXML.instance.getCarryDefineArray(param1);
      }
      
      public function getCarryDefine(param1:int, param2:int) : CarryDefine
      {
         return CarryConfigXML.instance.getCarryDefine(param1,param2);
      }
      
      public function getActionMovieDefineById(param1:int) : ActionMovieDefine
      {
         return ActionMovieConfigXML.instance.getMovieDefineById(param1);
      }
      
      public function getHuanDefine(param1:int) : Array
      {
         return HuanConfigXML.instance.getHuanDefine(param1);
      }
      
      public function getAlmightyDefine(param1:int) : Array
      {
         return AlmightyConfigXML.instance.getAlmightyDefine(param1);
      }
      
      public function getEntryDefine(param1:String) : EntryDefine
      {
         return EntryConfigXML.instance.getEntryDefine(param1);
      }
      
      public function getEntry(param1:String) : IBattleEntry
      {
         return EntryConfigXML.instance.getEntry(param1);
      }
   }
}

