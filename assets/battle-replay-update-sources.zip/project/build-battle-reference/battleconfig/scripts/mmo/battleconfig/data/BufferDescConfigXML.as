package mmo.battleconfig.data
{
   import mmo.interfaces.battleconfig.define.BufferDescDefine;
   import mmo.loader.common.datastructures.HashMap;
   
   public class BufferDescConfigXML
   {
      
      private static var _instance:BufferDescConfigXML;
      
      private var _xmlClass:Class = BufferDescConfigXML__xmlClass;
      
      private var _id2define:HashMap;
      
      public function BufferDescConfigXML()
      {
         super();
         this.parseConfig();
      }
      
      public static function get instance() : BufferDescConfigXML
      {
         if(_instance == null)
         {
            _instance = new BufferDescConfigXML();
         }
         return _instance;
      }
      
      public function parseConfig() : void
      {
         var _loc2_:XML = null;
         var _loc3_:XML = null;
         var _loc4_:BufferDescDefine = null;
         this._id2define = new HashMap();
         var _loc1_:XML = XML(new this._xmlClass().toString());
         for each(_loc2_ in _loc1_.buff)
         {
            for each(_loc3_ in _loc2_.s)
            {
               _loc4_ = BufferDescDefine.parseDefine(_loc3_);
               this._id2define.add(_loc4_.id,_loc4_);
            }
         }
      }
      
      public function getBufferDescDefineById(param1:int) : BufferDescDefine
      {
         var _loc3_:XML = null;
         var _loc2_:BufferDescDefine = this._id2define.getValue(param1);
         if(_loc2_ == null)
         {
            _loc3_ = new XML(<s id="0" nm="" mess=""/>);
            _loc3_.@id = param1;
            _loc2_ = BufferDescDefine.parseDefine(_loc3_);
         }
         return _loc2_;
      }
   }
}

