package mmo.battleconfig.data
{
   import mx.core.ByteArrayAsset;
   
   [Embed(source="/_assets/4_mmo.battleconfig.data.BattleBgConfigXML__xmlClass.bin", mimeType="application/octet-stream")]
   public class BattleBgConfigXML__xmlClass extends ByteArrayAsset
   {
      
      public function BattleBgConfigXML__xmlClass()
      {
         super();
      }
   }
}

