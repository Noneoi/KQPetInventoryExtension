package mmo.battleconfig.data
{
   import mx.core.ByteArrayAsset;
   
   [Embed(source="/_assets/19_mmo.battleconfig.data.ActionMovieConfigXML__xmlClass.bin", mimeType="application/octet-stream")]
   public class ActionMovieConfigXML__xmlClass extends ByteArrayAsset
   {
      
      public function ActionMovieConfigXML__xmlClass()
      {
         super();
      }
   }
}

