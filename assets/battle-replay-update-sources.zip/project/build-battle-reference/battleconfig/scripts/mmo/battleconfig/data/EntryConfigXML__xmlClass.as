package mmo.battleconfig.data
{
   import mx.core.ByteArrayAsset;
   
   [Embed(source="/_assets/7_mmo.battleconfig.data.EntryConfigXML__xmlClass.bin", mimeType="application/octet-stream")]
   public class EntryConfigXML__xmlClass extends ByteArrayAsset
   {
      
      public function EntryConfigXML__xmlClass()
      {
         super();
      }
   }
}

