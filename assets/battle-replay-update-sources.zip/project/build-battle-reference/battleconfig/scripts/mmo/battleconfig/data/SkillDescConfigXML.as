package mmo.battleconfig.data
{
   import mmo.interfaces.battleconfig.define.SkillDescDefine;
   import mmo.loader.common.datastructures.HashMap;
   
   public class SkillDescConfigXML
   {
      
      private static var _instance:SkillDescConfigXML;
      
      private var _xmlClass:Class = SkillDescConfigXML__xmlClass;
      
      private var _id2define:HashMap;
      
      public function SkillDescConfigXML()
      {
         super();
         this.parseConfig();
      }
      
      public static function get instance() : SkillDescConfigXML
      {
         if(_instance == null)
         {
            _instance = new SkillDescConfigXML();
         }
         return _instance;
      }
      
      public function parseConfig() : void
      {
         var _loc2_:XML = null;
         var _loc3_:SkillDescDefine = null;
         this._id2define = new HashMap();
         var _loc1_:XMLList = XML(new this._xmlClass().toString()).pet.s;
         for each(_loc2_ in _loc1_)
         {
            _loc3_ = SkillDescDefine.parseDefine(_loc2_);
            this._id2define.add(_loc3_.id,_loc3_);
         }
      }
      
      public function getSkillDescDefineById(param1:int) : SkillDescDefine
      {
         var _loc3_:XML = null;
         var _loc2_:SkillDescDefine = this._id2define.getValue(param1);
         if(_loc2_ == null)
         {
            _loc3_ = new XML(<s id="1" nm="" desc=""/>);
            _loc3_.@id = param1;
            _loc2_ = SkillDescDefine.parseDefine(_loc3_);
         }
         return _loc2_;
      }
   }
}

