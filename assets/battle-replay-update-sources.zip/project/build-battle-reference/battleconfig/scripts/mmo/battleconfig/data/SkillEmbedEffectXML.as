package mmo.battleconfig.data
{
   import flash.utils.getDefinitionByName;
   import mmo.interfaces.battleconfig.define.EmbedDialogDefine;
   import mmo.interfaces.battleconfig.define.EmbedEffectDefine;
   import mmo.loader.common.datastructures.HashMap;
   
   public class SkillEmbedEffectXML
   {
      
      private static var _instance:SkillEmbedEffectXML;
      
      private var _xmlClass:Class = SkillEmbedEffectXML__xmlClass;
      
      private var _xml:XML;
      
      private var _nick2full:HashMap;
      
      private var _id2defineArr:HashMap;
      
      private var _id2npcDialog:HashMap;
      
      public function SkillEmbedEffectXML()
      {
         super();
         this.parseXML();
         this.parseCmdMap();
         this.parseConfig();
         this.parseNpcDialog();
      }
      
      public static function get instance() : SkillEmbedEffectXML
      {
         if(_instance == null)
         {
            _instance = new SkillEmbedEffectXML();
         }
         return _instance;
      }
      
      public function getEmbedEffectDefines(param1:int) : Array
      {
         return this._id2defineArr.getValue(param1);
      }
      
      public function getEmbedDialogDefine(param1:int) : EmbedDialogDefine
      {
         return this._id2npcDialog.getValue(param1);
      }
      
      private function parseXML() : void
      {
         this._xml = XML(new this._xmlClass().toString());
      }
      
      private function parseCmdMap() : *
      {
         var _loc1_:XML = null;
         var _loc2_:String = null;
         var _loc3_:String = null;
         this._nick2full = new HashMap();
         for each(_loc1_ in this._xml.cmdMap.m)
         {
            _loc2_ = String(_loc1_.@nickName);
            _loc3_ = String(_loc1_.@clsName);
            this._nick2full.add(_loc2_,_loc3_);
         }
      }
      
      private function parseConfig() : void
      {
         var _loc1_:XML = null;
         var _loc2_:EmbedEffectDefine = null;
         var _loc3_:Array = null;
         this._id2defineArr = new HashMap();
         for each(_loc1_ in this._xml.effect.e)
         {
            _loc2_ = EmbedEffectDefine.parseDefine(_loc1_,this.cmdMapFunction);
            _loc3_ = this._id2defineArr.getValue(_loc2_.raceId);
            if(_loc3_ == null)
            {
               _loc3_ = [];
               this._id2defineArr.add(_loc2_.raceId,_loc3_);
            }
            _loc3_.push(_loc2_);
         }
      }
      
      private function parseNpcDialog() : void
      {
         var _loc1_:XML = null;
         var _loc2_:EmbedDialogDefine = null;
         this._id2npcDialog = new HashMap();
         for each(_loc1_ in this._xml.npcDialog.d)
         {
            _loc2_ = EmbedDialogDefine.parseDefine(_loc1_);
            this._id2npcDialog.add(_loc2_.id,_loc2_);
         }
      }
      
      private function cmdMapFunction(param1:Array) : Array
      {
         var _loc4_:String = null;
         var _loc5_:String = null;
         var _loc6_:Class = null;
         var _loc2_:Array = [];
         var _loc3_:int = 0;
         while(_loc3_ < param1.length)
         {
            _loc4_ = param1[_loc3_];
            if(!this._nick2full.containsKey(_loc4_))
            {
               throw new Error("Can\'t find the full class name mapping of nickname【" + _loc4_ + "】, please check skill-embed-effect.xml");
            }
            _loc5_ = this._nick2full.getValue(_loc4_);
            _loc6_ = getDefinitionByName(_loc5_) as Class;
            _loc2_.push(_loc6_);
            _loc3_++;
         }
         return _loc2_;
      }
   }
}

