package mmo.battleconfig.data
{
   import mmo.interfaces.battleconfig.entry.IBattleEntry;
   
   public class EntryArgLike implements IBattleEntry
   {
      
      private static const SPLITTER:String = "·";
      
      private var _name:String;
      
      private var _desc:String;
      
      public function EntryArgLike(param1:String, param2:Array, param3:IBattleEntry)
      {
         var _loc5_:String = null;
         var _loc6_:String = null;
         super();
         this._name = param1;
         if(param2.length > 0)
         {
            this._name = this._name + EntryArgLike.SPLITTER + param2.join(EntryArgLike.SPLITTER);
         }
         this._desc = param3.desc;
         var _loc4_:* = int(param2.length - 1);
         while(_loc4_ >= 0)
         {
            _loc5_ = "ARG" + (_loc4_ + 1).toString();
            while(this.desc.indexOf(_loc5_) != -1)
            {
               this._desc = this.desc.replace(_loc5_,param2[_loc4_]);
            }
            _loc4_--;
         }
         if(param2.length > 0)
         {
            _loc6_ = "ARG";
            while(this.desc.indexOf(_loc6_) != -1)
            {
               this._desc = this.desc.replace(_loc6_,param2[0]);
            }
         }
         this._desc = this.desc.replace(/ARG\d*/g,"指定数值");
      }
      
      public function get name() : String
      {
         return this._name;
      }
      
      public function get desc() : String
      {
         return this._desc;
      }
   }
}

