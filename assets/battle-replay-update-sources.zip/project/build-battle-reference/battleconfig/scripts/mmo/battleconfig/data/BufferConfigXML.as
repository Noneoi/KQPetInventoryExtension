package mmo.battleconfig.data
{
   import mmo.interfaces.ServiceContainer;
   import mmo.interfaces.battleconfig.define.BufferDefine;
   import mmo.interfaces.pet.data.IPetDictionaryDataService;
   import mmo.interfaces.pet.data.PetDictionaryDataItem;
   import mmo.loader.common.datastructures.HashMap;
   
   public class BufferConfigXML
   {
      
      private static var _instance:BufferConfigXML;
      
      private var bufferDescConfigXML:BufferDescConfigXML = BufferDescConfigXML.instance;
      
      private var _xmlClass:Class = BufferConfigXML__xmlClass;
      
      private var _id2define:HashMap;
      
      private var _rid2bid:HashMap;
      
      private var _defaultPowerFullBuffId:int;
      
      public function BufferConfigXML()
      {
         super();
         this.parseConfig();
      }
      
      public static function get instance() : BufferConfigXML
      {
         if(_instance == null)
         {
            _instance = new BufferConfigXML();
         }
         return _instance;
      }
      
      public function parseConfig() : void
      {
         var _loc2_:XML = null;
         var _loc3_:XML = null;
         var _loc4_:BufferDefine = null;
         var _loc5_:int = 0;
         var _loc6_:int = 0;
         this._id2define = new HashMap();
         var _loc1_:XML = XML(new this._xmlClass().toString());
         for each(_loc2_ in _loc1_.buff.s)
         {
            _loc4_ = BufferDefine.parseDefine(_loc2_,this.bufferDescConfigXML.getBufferDescDefineById(int(_loc2_.@id)));
            this._id2define.add(_loc4_.id,_loc4_);
         }
         this._rid2bid = new HashMap();
         for each(_loc3_ in _loc1_.pfmap.m)
         {
            _loc5_ = int(_loc3_.@raceId);
            _loc6_ = int(_loc3_.@buffId);
            this._rid2bid.add(_loc5_,_loc6_);
         }
         this._defaultPowerFullBuffId = int(_loc1_.pfmap.def.@buffId);
      }
      
      public function getBufferDefineById(param1:int) : BufferDefine
      {
         return this._id2define.getValue(param1);
      }
      
      public function getPowerFullBuffId(param1:int) : int
      {
         var _loc4_:int = 0;
         if(this._rid2bid.containsKey(param1))
         {
            return this._rid2bid.getValue(param1);
         }
         var _loc2_:IPetDictionaryDataService = ServiceContainer.getService(IPetDictionaryDataService);
         var _loc3_:PetDictionaryDataItem = _loc2_.getDataItemByRaceId(param1);
         if(_loc3_ != null)
         {
            _loc4_ = int(_loc3_.fullPowerBuffId);
            if(_loc4_ != -1)
            {
               return _loc4_;
            }
         }
         return this._defaultPowerFullBuffId;
      }
      
      public function getDefaultPowerFullBuffId() : int
      {
         return this._defaultPowerFullBuffId;
      }
   }
}

