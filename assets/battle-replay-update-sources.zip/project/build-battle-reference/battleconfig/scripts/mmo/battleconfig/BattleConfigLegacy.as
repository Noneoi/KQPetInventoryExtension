package mmo.battleconfig
{
   import mmo.interfaces.battleconfig.IBattleConfigLegacy;
   
   public class BattleConfigLegacy extends BattleConfig implements IBattleConfigLegacy
   {
      
      public function BattleConfigLegacy()
      {
         super();
      }
   }
}

