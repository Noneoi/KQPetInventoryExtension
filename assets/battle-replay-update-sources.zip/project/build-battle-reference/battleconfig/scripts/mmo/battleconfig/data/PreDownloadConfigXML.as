package mmo.battleconfig.data
{
   public class PreDownloadConfigXML
   {
      
      private static var _instance:PreDownloadConfigXML;
      
      private var _xmlClass:Class = PreDownloadConfigXML__xmlClass;
      
      private var _fileList:Array;
      
      private var _fileListSeq:Array;
      
      public function PreDownloadConfigXML()
      {
         super();
         this.parseConfig();
      }
      
      public static function get instance() : PreDownloadConfigXML
      {
         if(_instance == null)
         {
            _instance = new PreDownloadConfigXML();
         }
         return _instance;
      }
      
      public function parseConfig() : void
      {
         var _loc2_:XML = null;
         var _loc3_:XML = null;
         var _loc4_:String = null;
         var _loc5_:String = null;
         var _loc1_:XML = XML(new this._xmlClass().toString());
         this._fileList = new Array();
         for each(_loc2_ in _loc1_.common.f)
         {
            _loc4_ = String(_loc2_.@file);
            this._fileList.push(_loc4_);
         }
         this._fileListSeq = new Array();
         for each(_loc3_ in _loc1_.seq.f)
         {
            _loc5_ = String(_loc3_.@file);
            this._fileListSeq.push(_loc5_);
         }
      }
      
      public function get preDownloadFileList() : Array
      {
         return this._fileList;
      }
      
      public function get preDownloadFileListSeq() : Array
      {
         return this._fileListSeq;
      }
   }
}

