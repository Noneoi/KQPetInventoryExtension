package mmo.battleconfig.data
{
   import mx.core.ByteArrayAsset;
   
   [Embed(source="/_assets/6_mmo.battleconfig.data.RaceTypeConfigXML__xmlClass.bin", mimeType="application/octet-stream")]
   public class RaceTypeConfigXML__xmlClass extends ByteArrayAsset
   {
      
      public function RaceTypeConfigXML__xmlClass()
      {
         super();
      }
   }
}

