package mmo.battleconfig.data
{
   import mx.core.ByteArrayAsset;
   
   [Embed(source="/_assets/18_mmo.battleconfig.data.ComboBuffsConfigXML__xmlClass.bin", mimeType="application/octet-stream")]
   public class ComboBuffsConfigXML__xmlClass extends ByteArrayAsset
   {
      
      public function ComboBuffsConfigXML__xmlClass()
      {
         super();
      }
   }
}

