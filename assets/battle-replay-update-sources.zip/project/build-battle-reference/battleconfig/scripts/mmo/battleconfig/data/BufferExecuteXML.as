package mmo.battleconfig.data
{
   import mmo.interfaces.battleconfig.define.BufferExecuteDefine;
   import mmo.loader.common.datastructures.HashMap;
   
   public class BufferExecuteXML
   {
      
      private static var _instance:BufferExecuteXML;
      
      private var _xmlClass:Class = BufferExecuteXML__xmlClass;
      
      private var _bufferId2define:HashMap;
      
      public function BufferExecuteXML()
      {
         super();
         this.parseConfig();
      }
      
      public static function get instance() : BufferExecuteXML
      {
         if(_instance == null)
         {
            _instance = new BufferExecuteXML();
         }
         return _instance;
      }
      
      public function parseConfig() : void
      {
         var _loc2_:XML = null;
         var _loc3_:BufferExecuteDefine = null;
         this._bufferId2define = new HashMap();
         var _loc1_:XML = XML(new this._xmlClass().toString());
         for each(_loc2_ in _loc1_.s)
         {
            _loc3_ = BufferExecuteDefine.parseDefine(_loc2_);
            this._bufferId2define.add(_loc3_.executeBufferId,_loc3_);
         }
      }
      
      public function getBufferExecutDefine(param1:int) : BufferExecuteDefine
      {
         return this._bufferId2define.getValue(param1);
      }
   }
}

