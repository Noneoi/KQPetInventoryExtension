package mmo.battleconfig.data
{
   public class BattleBgConfigXML
   {
      
      private static var _instance:BattleBgConfigXML;
      
      private var _gainCoolPetStoneBgInfo:Object = {};
      
      private var _scenes:Array = [];
      
      private var _xmlClass:Class = BattleBgConfigXML__xmlClass;
      
      public function BattleBgConfigXML()
      {
         super();
         this.parseConfig();
      }
      
      public static function get instance() : BattleBgConfigXML
      {
         if(_instance == null)
         {
            _instance = new BattleBgConfigXML();
         }
         return _instance;
      }
      
      public function parseConfig() : void
      {
         var _loc2_:XML = null;
         var _loc3_:XML = null;
         var _loc1_:XML = XML(new this._xmlClass().toString());
         for each(_loc2_ in _loc1_.background.s)
         {
            this._scenes.push(String(_loc2_.@scene));
         }
         for each(_loc3_ in _loc1_.gaincoolpetstone.s)
         {
            this._gainCoolPetStoneBgInfo[String(_loc3_.@itemid)] = String(_loc3_.@name);
         }
      }
      
      public function get scenes() : Array
      {
         return this._scenes;
      }
      
      public function get gainCoolPetStoneBgInfo() : *
      {
         return this._gainCoolPetStoneBgInfo;
      }
   }
}

