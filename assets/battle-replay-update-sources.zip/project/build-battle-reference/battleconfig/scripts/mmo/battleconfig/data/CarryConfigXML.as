package mmo.battleconfig.data
{
   import mmo.interfaces.battleconfig.define.CarryDefine;
   import mmo.loader.common.datastructures.HashMap;
   
   public class CarryConfigXML
   {
      
      private static var _instance:CarryConfigXML;
      
      private var _xmlClass:Class = CarryConfigXML__xmlClass;
      
      private var _raceId2Define:HashMap;
      
      public function CarryConfigXML()
      {
         super();
         this.parseConfig();
      }
      
      public static function get instance() : CarryConfigXML
      {
         if(_instance == null)
         {
            _instance = new CarryConfigXML();
         }
         return _instance;
      }
      
      public function parseConfig() : void
      {
         this._raceId2Define = new HashMap();
         this.parseXMLConfig(this._xmlClass);
      }
      
      private function parseXMLConfig(param1:Class) : void
      {
         var _loc3_:XML = null;
         var _loc4_:Array = null;
         var _loc5_:CarryDefine = null;
         var _loc2_:XML = XML(new param1().toString());
         for each(_loc3_ in _loc2_.pet.s)
         {
            _loc4_ = CarryDefine.parseDefines(_loc3_);
            for each(_loc5_ in _loc4_)
            {
               this._raceId2Define.add(_loc5_.carrierRaceId + "_" + _loc5_.carriedPetRaceId,_loc5_);
            }
         }
      }
      
      public function getCarryDefine(param1:int, param2:int) : CarryDefine
      {
         return this._raceId2Define.getValue(param1 + "_" + param2);
      }
      
      public function getCarryDefineArray(param1:int) : Array
      {
         var _loc3_:CarryDefine = null;
         var _loc2_:Array = [];
         for each(_loc3_ in this._raceId2Define.getValues())
         {
            if(_loc3_.carrierRaceId == param1)
            {
               _loc2_.push(_loc3_);
            }
         }
         _loc2_.sort(this.sortOnCarryDefine);
         return _loc2_;
      }
      
      private function sortOnCarryDefine(param1:CarryDefine, param2:CarryDefine) : Number
      {
         if(param1.carriedPetRaceId < param2.carriedPetRaceId)
         {
            return 1;
         }
         if(param1.carriedPetRaceId > param2.carriedPetRaceId)
         {
            return -1;
         }
         return 0;
      }
      
      public function getCarrierRaceIdArray() : Array
      {
         var _loc2_:CarryDefine = null;
         var _loc1_:Array = [];
         for each(_loc2_ in this._raceId2Define.getValues())
         {
            if(_loc1_.indexOf(_loc2_.carrierRaceId) == -1)
            {
               _loc1_.push(_loc2_.carrierRaceId);
            }
         }
         _loc1_.sort(Array.DESCENDING);
         return _loc1_;
      }
   }
}

