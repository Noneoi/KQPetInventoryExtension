package mmo.battleconfig.data
{
   import mx.core.ByteArrayAsset;
   
   [Embed(source="/_assets/15_mmo.battleconfig.data.SkillEmbedEffectXML__xmlClass.bin", mimeType="application/octet-stream")]
   public class SkillEmbedEffectXML__xmlClass extends ByteArrayAsset
   {
      
      public function SkillEmbedEffectXML__xmlClass()
      {
         super();
      }
   }
}

