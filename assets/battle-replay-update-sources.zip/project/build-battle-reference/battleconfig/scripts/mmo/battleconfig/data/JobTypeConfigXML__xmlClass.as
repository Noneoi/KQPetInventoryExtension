package mmo.battleconfig.data
{
   import mx.core.ByteArrayAsset;
   
   [Embed(source="/_assets/13_mmo.battleconfig.data.JobTypeConfigXML__xmlClass.bin", mimeType="application/octet-stream")]
   public class JobTypeConfigXML__xmlClass extends ByteArrayAsset
   {
      
      public function JobTypeConfigXML__xmlClass()
      {
         super();
      }
   }
}

