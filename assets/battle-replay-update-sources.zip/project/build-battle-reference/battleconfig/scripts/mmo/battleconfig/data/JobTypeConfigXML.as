package mmo.battleconfig.data
{
   import mmo.interfaces.battleconfig.define.JobTypeDefine;
   import mmo.loader.common.datastructures.HashMap;
   
   public class JobTypeConfigXML
   {
      
      private static var _instance:JobTypeConfigXML;
      
      private var _xmlClass:Class = JobTypeConfigXML__xmlClass;
      
      private var _id2define:HashMap;
      
      public function JobTypeConfigXML()
      {
         super();
         this.parseConfig();
      }
      
      public static function get instance() : JobTypeConfigXML
      {
         if(_instance == null)
         {
            _instance = new JobTypeConfigXML();
         }
         return _instance;
      }
      
      public function parseConfig() : void
      {
         var _loc3_:XML = null;
         var _loc4_:JobTypeDefine = null;
         this._id2define = new HashMap();
         var _loc1_:int = 0;
         var _loc2_:XML = XML(new this._xmlClass().toString());
         for each(_loc3_ in _loc2_.job_type.s)
         {
            _loc4_ = JobTypeDefine.parseDefine(_loc3_,_loc1_);
            _loc1_++;
            this._id2define.add(_loc4_.id,_loc4_);
         }
      }
      
      public function getJobTypeDefineById(param1:int) : JobTypeDefine
      {
         return this._id2define.getValue(param1);
      }
   }
}

