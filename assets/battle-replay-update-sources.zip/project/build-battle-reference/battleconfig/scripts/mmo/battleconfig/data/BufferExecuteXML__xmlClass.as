package mmo.battleconfig.data
{
   import mx.core.ByteArrayAsset;
   
   [Embed(source="/_assets/16_mmo.battleconfig.data.BufferExecuteXML__xmlClass.bin", mimeType="application/octet-stream")]
   public class BufferExecuteXML__xmlClass extends ByteArrayAsset
   {
      
      public function BufferExecuteXML__xmlClass()
      {
         super();
      }
   }
}

