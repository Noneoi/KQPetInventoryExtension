package mmo.battleconfig.data
{
   import flash.utils.getTimer;
   import flash.utils.setTimeout;
   import mmo.interfaces.battleconfig.define.SkillDefine;
   import mmo.interfaces.battleconfig.define.SkillDescDefine;
   import mmo.loader.common.datastructures.HashMap;
   import mmo.play.log.Log;
   
   public class SkillConfigXML
   {
      
      private static var _instance:SkillConfigXML;
      
      private var skillDescConfigXML:SkillDescConfigXML = SkillDescConfigXML.instance;
      
      private var _xmlClass:Class = SkillConfigXML__xmlClass;
      
      private var _id2define:HashMap;
      
      private var _lastId2Define:HashMap;
      
      public function SkillConfigXML()
      {
         super();
         this.parseConfig();
      }
      
      public static function get instance() : SkillConfigXML
      {
         if(_instance == null)
         {
            _instance = new SkillConfigXML();
         }
         return _instance;
      }
      
      public function parseConfig() : void
      {
         var t:*;
         var xml:XML;
         var define:SkillDefine = null;
         var errors:Array = null;
         var s:XML = null;
         var last:XML = null;
         this._id2define = new HashMap();
         this._lastId2Define = new HashMap();
         t = getTimer();
         xml = XML(new this._xmlClass().toString());
         errors = [];
         for each(s in xml.s)
         {
            try
            {
               define = SkillDefine.parseDefine(s,this.skillDescConfigXML.getSkillDescDefineById(int(s.@id)));
               this._id2define.add(define.id,define);
            }
            catch(e:*)
            {
               errors.push(e);
            }
         }
         for each(last in xml.last)
         {
            try
            {
               define = SkillDefine.parseDefine(last,this.skillDescConfigXML.getSkillDescDefineById(int(last.@id)));
               this._lastId2Define.add(define.id,define);
            }
            catch(e:*)
            {
               errors.push(e);
            }
         }
         Log.d("battleconfig",getTimer() - t);
         if(errors.length > 0)
         {
            setTimeout(function():*
            {
               throw errors[0];
            },100);
         }
      }
      
      public function getSkillDefineById(param1:int) : SkillDefine
      {
         var _loc3_:SkillDescDefine = null;
         var _loc4_:int = 0;
         var _loc5_:SkillDefine = null;
         var _loc2_:SkillDefine = this._id2define.getValue(param1);
         if(_loc2_ == null)
         {
            _loc3_ = this.skillDescConfigXML.getSkillDescDefineById(param1);
            if(_loc3_ != null)
            {
               _loc4_ = int(SkillDefine.getOrigSkillId(param1));
               _loc5_ = this._id2define.getValue(_loc4_);
               if(_loc5_ != null)
               {
                  _loc2_ = SkillDefine.copyDefine(param1,_loc5_,_loc3_);
                  this._lastId2Define.add(_loc2_.id,_loc2_);
               }
               if(_loc2_ == null)
               {
                  _loc2_ = SkillDefine.wrapDescOnly(_loc3_);
               }
            }
         }
         return _loc2_;
      }
      
      public function getLastSkillDefineById(param1:int) : SkillDefine
      {
         return this._lastId2Define.getValue(param1);
      }
   }
}

