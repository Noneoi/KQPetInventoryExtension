package mmo.battleconfig.data
{
   import mx.core.ByteArrayAsset;
   
   [Embed(source="/_assets/2_mmo.battleconfig.data.SummonConfigXML__hideConfigXmlClass.bin", mimeType="application/octet-stream")]
   public class SummonConfigXML__hideConfigXmlClass extends ByteArrayAsset
   {
      
      public function SummonConfigXML__hideConfigXmlClass()
      {
         super();
      }
   }
}

