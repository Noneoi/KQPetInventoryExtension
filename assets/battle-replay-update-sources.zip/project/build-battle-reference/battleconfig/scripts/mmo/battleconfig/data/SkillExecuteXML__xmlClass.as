package mmo.battleconfig.data
{
   import mx.core.ByteArrayAsset;
   
   [Embed(source="/_assets/10_mmo.battleconfig.data.SkillExecuteXML__xmlClass.bin", mimeType="application/octet-stream")]
   public class SkillExecuteXML__xmlClass extends ByteArrayAsset
   {
      
      public function SkillExecuteXML__xmlClass()
      {
         super();
      }
   }
}

