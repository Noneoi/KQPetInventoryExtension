package mmo.battleconfig.data
{
   import mmo.interfaces.battleconfig.define.EntryDefine;
   import mmo.interfaces.battleconfig.entry.IBattleEntry;
   import mmo.loader.common.datastructures.HashMap;
   
   public class EntryConfigXML
   {
      
      private static var _instance:EntryConfigXML;
      
      private var _xmlClass:Class = EntryConfigXML__xmlClass;
      
      private var _name2Define:HashMap;
      
      public function EntryConfigXML()
      {
         super();
         this.parseConfig();
      }
      
      public static function get instance() : EntryConfigXML
      {
         if(_instance == null)
         {
            _instance = new EntryConfigXML();
         }
         return _instance;
      }
      
      public function parseConfig() : void
      {
         this._name2Define = new HashMap();
         this.parseXMLConfig(this._xmlClass);
      }
      
      private function parseXMLConfig(param1:Class) : void
      {
         var _loc3_:XML = null;
         var _loc4_:EntryDefine = null;
         var _loc2_:XML = XML(new param1().toString());
         for each(_loc3_ in _loc2_.pet.s)
         {
            _loc4_ = EntryDefine.parseDefine(_loc3_);
            if(!this._name2Define.containsKey(_loc4_.name))
            {
               this._name2Define.add(_loc4_.name,_loc4_);
            }
         }
      }
      
      public function getEntryDefine(param1:String) : EntryDefine
      {
         if(!this._name2Define.containsKey(param1))
         {
            return null;
         }
         return this._name2Define.getValue(param1);
      }
      
      public function getEntry(param1:String) : IBattleEntry
      {
         var _loc3_:String = null;
         var _loc4_:IBattleEntry = null;
         var _loc2_:Array = param1.split("·");
         if(_loc2_.length > 1)
         {
            _loc3_ = _loc2_[0];
            _loc4_ = this.getEntryDefine(_loc3_);
            if(_loc4_)
            {
               return this.assemble(_loc3_,_loc2_.slice(1));
            }
         }
         return this.assemble(param1,[]);
      }
      
      private function assemble(param1:String, param2:Array) : IBattleEntry
      {
         var _loc3_:IBattleEntry = this.getEntryDefine(param1);
         if(_loc3_)
         {
            return new EntryArgLike(param1,param2,_loc3_);
         }
         return null;
      }
   }
}

