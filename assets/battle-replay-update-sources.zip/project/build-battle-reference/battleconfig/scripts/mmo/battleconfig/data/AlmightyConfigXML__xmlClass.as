package mmo.battleconfig.data
{
   import mx.core.ByteArrayAsset;
   
   [Embed(source="/_assets/3_mmo.battleconfig.data.AlmightyConfigXML__xmlClass.bin", mimeType="application/octet-stream")]
   public class AlmightyConfigXML__xmlClass extends ByteArrayAsset
   {
      
      public function AlmightyConfigXML__xmlClass()
      {
         super();
      }
   }
}

