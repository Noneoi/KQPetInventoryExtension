package mmo.battleconfig.data
{
   import mmo.interfaces.battleconfig.define.SummonDefine;
   import mmo.loader.common.datastructures.HashMap;
   
   public class SummonConfigXML
   {
      
      private static var _instance:SummonConfigXML;
      
      private var _xmlClass:Class = SummonConfigXML__xmlClass;
      
      private var _hideConfigXmlClass:Class = SummonConfigXML__hideConfigXmlClass;
      
      private var _raceId2Define:HashMap;
      
      private var _needHideIdArr:Array;
      
      public function SummonConfigXML()
      {
         super();
         this.parseConfig();
      }
      
      public static function get instance() : SummonConfigXML
      {
         if(_instance == null)
         {
            _instance = new SummonConfigXML();
         }
         return _instance;
      }
      
      public function parseConfig() : void
      {
         this._raceId2Define = new HashMap();
         this.parseXMLConfig(this._xmlClass);
         this.parseHideConfig();
      }
      
      private function parseHideConfig() : void
      {
         var _loc2_:XML = null;
         var _loc3_:Array = null;
         var _loc4_:SummonDefine = null;
         this.parseXMLConfig(this._hideConfigXmlClass);
         this._needHideIdArr = [];
         var _loc1_:XML = XML(new this._hideConfigXmlClass().toString());
         for each(_loc2_ in _loc1_.pet.s)
         {
            _loc3_ = SummonDefine.parseDefines(_loc2_);
            for each(_loc4_ in _loc3_)
            {
               this._needHideIdArr.push(_loc4_.summonerRaceId);
            }
         }
      }
      
      private function parseXMLConfig(param1:Class) : void
      {
         var _loc3_:XML = null;
         var _loc4_:Array = null;
         var _loc5_:SummonDefine = null;
         var _loc2_:XML = XML(new param1().toString());
         for each(_loc3_ in _loc2_.pet.s)
         {
            _loc4_ = SummonDefine.parseDefines(_loc3_);
            for each(_loc5_ in _loc4_)
            {
               this._raceId2Define.add(_loc5_.summonerRaceId + "_" + _loc5_.summonedPetRaceId,_loc5_);
            }
         }
      }
      
      public function getSummonDefine(param1:int, param2:int) : SummonDefine
      {
         return this._raceId2Define.getValue(param1 + "_" + param2);
      }
      
      public function getSummonPet(param1:int) : Array
      {
         var _loc3_:SummonDefine = null;
         var _loc2_:Array = [];
         for each(_loc3_ in this._raceId2Define.getValues())
         {
            if(_loc3_.summonerRaceId == param1)
            {
               _loc2_.push(_loc3_);
            }
         }
         _loc2_.sort(this.sortOnSummonDefine);
         return _loc2_;
      }
      
      private function sortOnSummonDefine(param1:SummonDefine, param2:SummonDefine) : Number
      {
         if(param1.summonedPetRaceId < param2.summonedPetRaceId)
         {
            return 1;
         }
         if(param1.summonedPetRaceId > param2.summonedPetRaceId)
         {
            return -1;
         }
         return 0;
      }
      
      public function getSummonerRaceIdArray() : Array
      {
         var _loc2_:SummonDefine = null;
         var _loc1_:Array = [];
         for each(_loc2_ in this._raceId2Define.getValues())
         {
            if(!this.checkIsHide(_loc2_.summonerRaceId))
            {
               if(_loc1_.indexOf(_loc2_.summonerRaceId) == -1)
               {
                  _loc1_.push(_loc2_.summonerRaceId);
               }
            }
         }
         _loc1_.sort(Array.DESCENDING);
         return _loc1_;
      }
      
      public function getSummonerPetRaceIdArray() : Array
      {
         var _loc2_:SummonDefine = null;
         var _loc1_:Array = [];
         for each(_loc2_ in this._raceId2Define.getValues())
         {
            if(_loc1_.indexOf(_loc2_.summonedPetRaceId) == -1)
            {
               _loc1_.push(_loc2_.summonedPetRaceId);
            }
         }
         _loc1_.sort(Array.DESCENDING);
         return _loc1_;
      }
      
      public function getSummonerTeamRaceIdArray(param1:int) : Array
      {
         var _loc3_:SummonDefine = null;
         var _loc2_:Array = [];
         for each(_loc3_ in this._raceId2Define.getValues())
         {
            if(_loc3_.summonerTeamId == param1)
            {
               if(!this.checkIsHide(_loc3_.summonerRaceId))
               {
                  if(_loc2_.indexOf(_loc3_.summonerRaceId) == -1)
                  {
                     _loc2_.push(_loc3_.summonerRaceId);
                  }
               }
            }
         }
         return _loc2_;
      }
      
      public function checkIsHide(param1:int) : Boolean
      {
         return this._needHideIdArr.indexOf(param1) != -1;
      }
   }
}

