package mmo.battleconfig.data
{
   import mx.core.ByteArrayAsset;
   
   [Embed(source="/_assets/21_mmo.battleconfig.data.SkillDescConfigXML__xmlClass.bin", mimeType="application/octet-stream")]
   public class SkillDescConfigXML__xmlClass extends ByteArrayAsset
   {
      
      public function SkillDescConfigXML__xmlClass()
      {
         super();
      }
   }
}

