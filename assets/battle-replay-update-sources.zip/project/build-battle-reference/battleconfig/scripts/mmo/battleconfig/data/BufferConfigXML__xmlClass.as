package mmo.battleconfig.data
{
   import mx.core.ByteArrayAsset;
   
   [Embed(source="/_assets/11_mmo.battleconfig.data.BufferConfigXML__xmlClass.bin", mimeType="application/octet-stream")]
   public class BufferConfigXML__xmlClass extends ByteArrayAsset
   {
      
      public function BufferConfigXML__xmlClass()
      {
         super();
      }
   }
}

