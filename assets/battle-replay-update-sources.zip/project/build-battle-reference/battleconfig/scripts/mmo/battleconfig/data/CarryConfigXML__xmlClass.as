package mmo.battleconfig.data
{
   import mx.core.ByteArrayAsset;
   
   [Embed(source="/_assets/9_mmo.battleconfig.data.CarryConfigXML__xmlClass.bin", mimeType="application/octet-stream")]
   public class CarryConfigXML__xmlClass extends ByteArrayAsset
   {
      
      public function CarryConfigXML__xmlClass()
      {
         super();
      }
   }
}

