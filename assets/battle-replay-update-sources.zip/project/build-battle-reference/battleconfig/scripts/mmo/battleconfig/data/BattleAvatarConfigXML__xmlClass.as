package mmo.battleconfig.data
{
   import mx.core.ByteArrayAsset;
   
   [Embed(source="/_assets/14_mmo.battleconfig.data.BattleAvatarConfigXML__xmlClass.bin", mimeType="application/octet-stream")]
   public class BattleAvatarConfigXML__xmlClass extends ByteArrayAsset
   {
      
      public function BattleAvatarConfigXML__xmlClass()
      {
         super();
      }
   }
}

