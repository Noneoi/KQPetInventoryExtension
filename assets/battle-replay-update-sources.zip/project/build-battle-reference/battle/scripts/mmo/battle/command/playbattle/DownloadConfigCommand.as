package mmo.battle.command.playbattle
{
   import mmo.battle.util.BattleContentUtil;
   import mmo.battle.util.BattleUtil;
   import mmo.interfaces.ServiceContainer;
   import mmo.interfaces.battle.data.BattleInfo;
   import mmo.interfaces.battleconfig.IBattleConfig;
   import mmo.util.command.ISceneCommand;
   import mmo.util.command.SceneSimpleCommand;
   
   public class DownloadConfigCommand extends SceneSimpleCommand implements ISceneCommand
   {
      
      private var _content:Object;
      
      public function DownloadConfigCommand()
      {
         super();
      }
      
      override public function execute(param1:Object) : void
      {
         this._content = param1;
         ServiceContainer.tryGetService(IBattleConfig,this.onGetBattleConfig,null,null,false);
      }
      
      private function onGetBattleConfig(param1:IBattleConfig, param2:Object) : void
      {
         BattleContentUtil.setContentProperty(this._content,BattleContentUtil.PN_BATTLE_CONFIG,param1);
         var _loc3_:Array = BattleContentUtil.getContentProperty(this._content,BattleContentUtil.PN_DROP_ITEM_DATA);
         BattleContentUtil.setContentProperty(this._content,BattleContentUtil.PN_GAIN_COOLPETSTONE_DATA,BattleUtil.getDropCoolPetStoneMCD(_loc3_,param1));
         var _loc4_:BattleInfo = BattleContentUtil.getContentProperty(this._content,BattleContentUtil.PN_BATTLE_INFO);
         var _loc5_:Boolean = false;
         if(_loc4_.getTeamInfoById(0).playerInfos.length > 1 || _loc4_.getTeamInfoById(1).playerInfos.length > 1)
         {
            _loc5_ = true;
         }
         BattleContentUtil.setContentProperty(this._content,BattleContentUtil.PN_IS_MULTIPLAYER,_loc5_);
         this.succeed(this._content);
         this._content = null;
      }
   }
}

