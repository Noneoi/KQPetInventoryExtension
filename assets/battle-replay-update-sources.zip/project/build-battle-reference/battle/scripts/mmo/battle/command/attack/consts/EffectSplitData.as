package mmo.battle.command.attack.consts
{
   import mmo.battle.util.BattleUtil;
   import mmo.interfaces.battle.data.SkillResult;
   
   public class EffectSplitData
   {
      
      private var _finalHpChange:Number = 0;
      
      private var _finalSpChange:Number = 0;
      
      private var _finalPowerChange:int = 0;
      
      private var _hpChangeArr:Array;
      
      private var _spChangeArr:Array;
      
      private var _powerChangeArr:Array;
      
      public function EffectSplitData()
      {
         super();
      }
      
      public static function valueFrom(param1:SkillResult, param2:int) : EffectSplitData
      {
         var _loc5_:Number = NaN;
         var _loc6_:Number = NaN;
         var _loc7_:int = 0;
         var _loc8_:int = 0;
         var _loc9_:int = 0;
         var _loc10_:Array = null;
         var _loc11_:int = 0;
         var _loc12_:Array = null;
         var _loc13_:int = 0;
         var _loc3_:EffectSplitData = new EffectSplitData();
         var _loc4_:Number = 0;
         for each(_loc5_ in param1.numResult.attackHps)
         {
            _loc4_ += _loc5_;
            _loc3_._finalHpChange += _loc5_;
         }
         for each(_loc6_ in param1.numResult.attackSps)
         {
            _loc3_._finalSpChange += _loc6_;
         }
         for each(_loc7_ in param1.numResult.attackPowers)
         {
            _loc3_._finalPowerChange += _loc7_;
         }
         _loc3_._hpChangeArr = BattleUtil.splitNumIntoNumArray(_loc3_._finalHpChange,param2,0.15);
         _loc3_._spChangeArr = BattleUtil.splitNumIntoNumArray(_loc3_._finalSpChange,param2,0.15);
         if(_loc3_._finalHpChange != 0 && _loc3_._finalSpChange != 0)
         {
            _loc3_._hpChangeArr = new Array(param2);
            _loc3_._spChangeArr = new Array(param2);
            _loc8_ = Math.floor(param2 / 2);
            _loc9_ = param2 > 1 ? int(_loc8_ + 1) : 1;
            _loc10_ = BattleUtil.splitNumIntoNumArray(_loc3_._finalSpChange,_loc9_,0.15);
            _loc11_ = param2 > 1 ? (param2 % 2 == 0 ? _loc8_ : int(_loc8_ + 1)) : 1;
            _loc12_ = BattleUtil.splitNumIntoNumArray(_loc3_._finalHpChange,_loc11_,0.15);
            _loc13_ = 0;
            while(_loc13_ < param2)
            {
               _loc3_._hpChangeArr[_loc13_] = _loc13_ >= _loc8_ ? _loc12_[_loc13_ - _loc8_] : 0;
               _loc3_._spChangeArr[_loc13_] = _loc13_ <= _loc8_ ? _loc10_[_loc13_] : 0;
               _loc13_++;
            }
         }
         _loc3_._powerChangeArr = BattleUtil.splitNumIntoNumArray(_loc3_._finalPowerChange,param2,0);
         return _loc3_;
      }
      
      public function get hpChangeArr() : Array
      {
         return this._hpChangeArr;
      }
      
      public function get spChangeArr() : Array
      {
         return this._spChangeArr;
      }
      
      public function get powerChangeArr() : Array
      {
         return this._powerChangeArr;
      }
   }
}

