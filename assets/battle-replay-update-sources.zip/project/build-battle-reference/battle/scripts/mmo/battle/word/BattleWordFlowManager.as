package mmo.battle.word
{
   import mmo.battle.entity.SyncInterrupt;
   import mmo.interfaces.IDispose;
   import mmo.interfaces.battle.data.BattleFlow;
   import mmo.interfaces.battle.data.BattleUnit;
   
   public class BattleWordFlowManager implements IDispose
   {
      
      private var _syncManager:BattleWordSyncManager;
      
      private var _battleFlow:BattleFlow;
      
      private var _disposed:Boolean;
      
      private var _battleWords:BattleWords;
      
      public function BattleWordFlowManager(param1:BattleFlow, param2:BattleWords)
      {
         super();
         this._battleFlow = param1;
         this._battleWords = param2;
         this._syncManager = new BattleWordSyncManager(param2);
      }
      
      public function startBattleFlow() : void
      {
         this._syncManager.addEventListener(SyncInterrupt.OVER_ROUND_LIMIT_WARNING,this.onOverRoundLimitWarning);
         this._syncManager.addEventListener(SyncInterrupt.ONE_BATTLELINE_END,this.onOneBattlelineEnd);
         this.onOneBattlelineEnd(null);
      }
      
      public function dispose() : void
      {
         if(this._disposed)
         {
            return;
         }
         this._disposed = true;
         this._syncManager.removeEventListener(SyncInterrupt.OVER_ROUND_LIMIT_WARNING,this.onOverRoundLimitWarning);
         this._syncManager.removeEventListener(SyncInterrupt.ONE_BATTLELINE_END,this.onOneBattlelineEnd);
         this._syncManager.dispose();
         this._syncManager = null;
      }
      
      private function onOverRoundLimitWarning(param1:SyncInterrupt) : void
      {
         BattleWordMessageUtil.showOverRoundMessage(this._battleWords);
      }
      
      private function onOneBattlelineEnd(param1:SyncInterrupt) : void
      {
         var _loc4_:BattleUnit = null;
         var _loc5_:Boolean = false;
         var _loc2_:Array = this._battleFlow.battleUnits;
         if(this._syncManager.getOnBattleLineNum() == 0 && _loc2_.length == 0)
         {
            return;
         }
         var _loc3_:Boolean = true;
         while(true)
         {
            _loc4_ = _loc2_.shift();
            if(_loc4_ == null)
            {
               break;
            }
            if(_loc4_.isReallyFight)
            {
               _loc3_ = false;
            }
            _loc5_ = this._syncManager.insertBattleUnit(_loc4_);
            if(!_loc5_)
            {
               _loc2_.unshift(_loc4_);
               break;
            }
         }
         if(_loc3_ && this._syncManager.getOnBattleLineNum() == 0 && _loc2_.length == 0)
         {
            return;
         }
         this._syncManager.run();
      }
   }
}

