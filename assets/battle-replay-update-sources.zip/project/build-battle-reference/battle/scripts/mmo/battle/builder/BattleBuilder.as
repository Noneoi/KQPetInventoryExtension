package mmo.battle.builder
{
   import mmo.battle.entity.BattleBase;
   import mmo.battle.entity.BattleBaseSequential;
   import mmo.battle.entity.BattleBaseTeam;
   import mmo.battle.word.BattleWords;
   import mmo.interfaces.battle.data.BattleResult;
   import mmo.interfaces.battle.entity.IBattle;
   import mmo.interfaces.battle.entity.IBattleSequential;
   import mmo.interfaces.battle.entity.IBattleTeam;
   import mmo.interfaces.battle.factory.IBattleFactory;
   import mmo.interfaces.battleconfig.IBattleConfig;
   
   public class BattleBuilder implements IBattleFactory
   {
      
      private static var _instance:BattleBuilder;
      
      public function BattleBuilder()
      {
         super();
      }
      
      public static function get instacne() : BattleBuilder
      {
         if(_instance == null)
         {
            _instance = new BattleBuilder();
         }
         return _instance;
      }
      
      public function buildBattle(param1:BattleResult) : IBattle
      {
         return new BattleBase(param1);
      }
      
      public function buildSequentialBattle(param1:Array, param2:Array) : IBattleSequential
      {
         return new BattleBaseSequential(param1,param2);
      }
      
      public function buildTeamBattle(param1:Array) : IBattleTeam
      {
         return new BattleBaseTeam(param1);
      }
      
      public function buildBattleWords(param1:BattleResult, param2:IBattleConfig) : BattleWords
      {
         return new BattleWords(param1,param2);
      }
   }
}

