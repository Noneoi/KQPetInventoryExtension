package mmo.battle.command.attack.disable
{
   import mmo.battle.command.BattleCommand;
   import mmo.battle.command.attack.common.AfterSequentialAttackCommand;
   import mmo.battle.command.attack.common.BeforeSequentialAttackCommand;
   import mmo.util.command.ISceneCommand;
   
   public class AttackDisalbeCommand extends BattleCommand implements ISceneCommand
   {
      
      public function AttackDisalbeCommand()
      {
         super();
      }
      
      override protected function initializeMacroCommand() : void
      {
         this.addSubCommand(BeforeSequentialAttackCommand);
         this.addSubCommand(AfterSequentialAttackCommand);
         super.initializeMacroCommand();
      }
   }
}

