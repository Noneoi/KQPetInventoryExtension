package mmo.battle.avatar
{
   import com.adobe.utils.StringUtil;
   import com.greensock.TweenLite;
   import com.greensock.easing.Cubic;
   import flash.display.DisplayObject;
   import flash.display.FrameLabel;
   import flash.display.MovieClip;
   import flash.display.Sprite;
   import flash.events.Event;
   import flash.events.IEventDispatcher;
   import flash.geom.Point;
   import flash.geom.Rectangle;
   import flash.system.ApplicationDomain;
   import flash.text.TextField;
   import mmo.battle.bitmap.RegularBitmapData;
   import mmo.battle.consts.BufferConsts;
   import mmo.battle.container.BattleContainer;
   import mmo.battle.entity.BattleBase;
   import mmo.battle.entity.BattleSimpleResManager;
   import mmo.battle.helper.BattleBufferHelper;
   import mmo.battle.tips.FighterTipsPanel;
   import mmo.battle.util.BattleContentUtil;
   import mmo.battle.util.BattleUtil;
   import mmo.common.DisplayUtil;
   import mmo.common.InstanceUtil;
   import mmo.common.NumberUtil;
   import mmo.common.utils.tips.TipsManager;
   import mmo.interfaces.ServiceContainer;
   import mmo.interfaces.battle.avatar.AvatarPosTypes;
   import mmo.interfaces.battle.avatar.IBattleAvatar;
   import mmo.interfaces.battle.consts.AvatarActionDefine;
   import mmo.interfaces.battle.consts.AvatarEffectIds;
   import mmo.interfaces.battle.consts.FormationConsts;
   import mmo.interfaces.battle.data.BattleInfo;
   import mmo.interfaces.battle.data.FighterInfo;
   import mmo.interfaces.battle.data.PlayerInfo;
   import mmo.interfaces.battle.fighter.IBattleFighter;
   import mmo.interfaces.battle.player.IBattlePlayer;
   import mmo.interfaces.battleconfig.IBattleConfig;
   import mmo.interfaces.battleconfig.consts.RaceTypePriority;
   import mmo.interfaces.battleconfig.consts.SkillTypes;
   import mmo.interfaces.battleconfig.define.BufferDefine;
   import mmo.interfaces.battleconfig.define.BufferExecuteDefine;
   import mmo.interfaces.battleconfig.define.RaceTypeDefine;
   import mmo.interfaces.battleconfig.define.SkillDefine;
   import mmo.interfaces.interacthelper.IInteractHelper;
   import mmo.interfaces.pet.data.IPetDictionaryDataService;
   import mmo.interfaces.pet.data.PetDictionaryDataItem;
   import mmo.loader.LoaderContainer;
   import mmo.loader.SpineLoader;
   import mmo.loader.common.datastructures.HashMap;
   import mmo.play.dialog.InteractUtil;
   import mmo.play.globalfunctions.forSvc;
   import spine.flash.SkeletonMovieClip;
   
   public class BattleAvatar extends Sprite implements IBattleAvatar
   {
      
      protected static const SPINE_ACTION_FILE:String = "battleaction/action%d";
      
      protected static const SPINE_FOREGROUND_FILE:String = "battleaction/fullscreen/foreground%d_%d";
      
      protected static const SPINE_BACKGROUND_FILE:String = "battleaction/fullscreen/background%d_%d";
      
      protected static const SPINE_EFFECT_FILE:String = "battleeffect/effect%d";
      
      protected static const SPINE_BUFFER_FILE:String = "battlebuffer/buffer%d";
      
      protected static const SPINE_SUMMON_FILE:String = "battlesummon/summon%d";
      
      protected static const ACTION_CLS_PREFIX:String = "mmo.battle.action.Action";
      
      protected static const TARGET_ACTION_CLS_BACKGROUND:String = "mmo.battle.action.Action_Target_Background";
      
      protected static const ACTION_CLS_FULLSCREEN_BACKGROUND:String = "mmo.battle.action.Action_FullScreen_Background";
      
      protected static const ACTION_CLS_FULLSCREEN_FOREGROUND:String = "mmo.battle.action.Action_FullScreen_Foreground";
      
      protected static const BLOOD_BAR_CLS:String = "mmo.battle.common.BloodBarRes";
      
      protected static const POWER_BAR_CLS:String = "mmo.battle.common.PowerBarRes";
      
      protected static const FADE_OUT_CLS:String = "mmo.battle.common.FadeOutRes";
      
      protected static const EFFECT_CLS_PREFIX:String = "mmo.battle.common.Effect";
      
      protected static const NUMBER_CLS_PREFIX:String = "mmo.battle.common.Number";
      
      protected static const NUMBER_BACKGROUND_CLS_PREFIX:String = "mmo.battle.common.NumberBackground";
      
      protected static const BUFF_FILE_PREFIX:String = "battlebuffer/buffer";
      
      protected static const BUFF_CLS_PREFIX:String = "mmo.battle.buffer.Buffer";
      
      protected static const STRONG_EFFECT_CLS:String = "mmo.battle.common.StrongEffect";
      
      protected static const WEAK_EFFECT_CLS:String = "mmo.battle.common.WeakEffect";
      
      protected static const DEATH_WING_CLS:String = "mmo.battle.common.DeathWing";
      
      protected static const SKILL_EFFECT_CLS_PREFIX:String = "mmo.effect.Effect";
      
      protected static const LAST_SKILL_EFFECT_CLS_PREFIX:String = "mmo.effect.LastEffect";
      
      protected static const SUMMON_EFFECT_CLS_PREFIX:String = "mmo.summon.Summon";
      
      protected static const SUMMON_EFFECT_MOV_CLS_DEFAULT:String = "mmo.summon.Summon_default";
      
      protected static const BUFF_HARM_SOURCE_CLS:String = "mmo.battle.common.BuffHarm";
      
      protected static const POWER_CHAR_CLS:String = "mmo.battle.common.PowerNum";
      
      protected static const BUFF_SPECIAL_CLS:String = "mmo.battle.common.SpecialBuff";
      
      protected static const BUFF_ATTR_CHANGE_CLS:String = "mmo.battle.common.BuffEffec";
      
      protected static const BUFF_PROFICIENT_CLS:String = "mmo.battle.common.ProBuff";
      
      protected static const PSY_PROGRESS_RES:String = "mmo.battle.common.PsyProgressRes";
      
      protected static const SLIDE_BACKWARD_DISTANCE:Number = 30;
      
      protected static const POWER_FULL_BUFF_ID2_PRIMARY_DATA:Array = [6182,19306];
      
      private static const STRONG_EFFECTS:Object = {
         "21":"Grass",
         "22":"Water",
         "23":"Fire",
         "24":"Dark",
         "25":"Light",
         "26":"Ling",
         "27":"Wuji",
         "28":"Fantasy",
         "10021":"Grass_T",
         "10022":"Water_T",
         "10023":"Fire_T",
         "10024":"Dark_T",
         "10025":"Light_T",
         "10026":"Ling_T",
         "10027":"Wuji_T",
         "10028":"Fantasy_T"
      };
      
      private static const SUPER_GOD_ATTR:Array = [27,28,29,30,31,32];
      
      protected var _info:FighterInfo;
      
      protected var _domain:ApplicationDomain;
      
      protected var _battleConfig:IBattleConfig;
      
      protected var _dispatcher:IEventDispatcher;
      
      protected var _winerTeamId:int;
      
      protected var _mcAction:MovieClip;
      
      protected var _bound:Rectangle;
      
      protected var _bloodBar:MovieClip;
      
      protected var _shieldBar:MovieClip;
      
      protected var _powerBar:Sprite;
      
      private var _txtPower:TextField;
      
      protected var _avatarLayer:Sprite;
      
      protected var _bloodLayer:Sprite;
      
      protected var _powerResLayer:Sprite;
      
      protected var _bufferLayer:Sprite;
      
      protected var _bufferLayer2:Sprite;
      
      protected var _effectLayer:Sprite;
      
      protected var _bubbleLayer:Sprite;
      
      protected var _skillLayer:Sprite;
      
      protected var _stateLayer:Sprite;
      
      protected var _tipsLayer:Sprite;
      
      protected var _movLayer:Sprite;
      
      protected var _powerLayer:Sprite;
      
      protected var _buffEffectLayer:Sprite;
      
      protected var _tips:FighterTipsPanel;
      
      protected var _deathWing:MovieClip;
      
      protected var _mapBuffId2Buff:HashMap = new HashMap();
      
      protected var _buffIdArray:Array = [];
      
      protected var _needFlip:Boolean;
      
      protected var _slideFlag:Boolean;
      
      protected var _orgXBeforeSlide:Number;
      
      protected var _isDead:Boolean;
      
      protected var _bloodBarRes:Sprite;
      
      private var content:Object;
      
      private var _redMC:MovieClip;
      
      private var actionBackGround:Sprite;
      
      private var _buffWaitCallback:Function;
      
      private var _battleBuffHelper:BattleBufferHelper;
      
      private var _isShowPowerBarRes:Boolean = true;
      
      private var _actionId:int;
      
      private var _artNumCacheMap:Object;
      
      private var _sourceFigherIsEnemy:Boolean = false;
      
      private var _regularBitmapData:RegularBitmapData;
      
      public function BattleAvatar(param1:FighterInfo, param2:Object, param3:Boolean = false)
      {
         super();
         this.content = param2;
         this._info = param1;
         this._domain = BattleContentUtil.getContentProperty(param2,BattleContentUtil.PN_DOMAIN);
         this._battleConfig = BattleContentUtil.getContentProperty(param2,BattleContentUtil.PN_BATTLE_CONFIG);
         this._dispatcher = BattleContentUtil.getContentProperty(param2,BattleContentUtil.PN_EVENT_DISPATCHER);
         this._winerTeamId = BattleContentUtil.getContentProperty(param2,BattleContentUtil.PN_WINNER_TEAM_ID);
         this._needFlip = param3;
         this._artNumCacheMap = BattleContentUtil.getContentProperty(param2,BattleContentUtil.PN_ART_NUM_CACHE_MAP);
         this._regularBitmapData = BattleContentUtil.getContentProperty(param2,BattleContentUtil.PN_REGULAR_BITMAP_DATA);
         this.init();
      }
      
      public function getAvatarLayer() : Sprite
      {
         return this._avatarLayer;
      }
      
      public function getBloodLayer() : Sprite
      {
         return this._bloodLayer;
      }
      
      public function getPowerResLayer() : Sprite
      {
         return this._powerResLayer;
      }
      
      public function getBufferLayer() : Sprite
      {
         return this._bufferLayer;
      }
      
      public function getBuffEffectLayer() : Sprite
      {
         return this._buffEffectLayer;
      }
      
      public function getBufferLayer2() : Sprite
      {
         return this._bufferLayer2;
      }
      
      public function getEffectLayer() : Sprite
      {
         return this._effectLayer;
      }
      
      public function getSkillLayer() : Sprite
      {
         return this._skillLayer;
      }
      
      public function getBubbleLayer() : Sprite
      {
         return this._bubbleLayer;
      }
      
      public function getStateLayer() : Sprite
      {
         return this._stateLayer;
      }
      
      public function getTipsLayer() : Sprite
      {
         return this._tipsLayer;
      }
      
      public function getMovLayer() : Sprite
      {
         return this._movLayer;
      }
      
      public function get mcAction() : MovieClip
      {
         return this._mcAction;
      }
      
      protected function init() : void
      {
         this.initLayers();
         this.initAvatar();
         if(this._needFlip)
         {
            this.flip();
         }
      }
      
      protected function initLayers() : void
      {
         this._avatarLayer = new Sprite();
         this._bloodLayer = new Sprite();
         this._powerResLayer = new Sprite();
         this._bufferLayer = new Sprite();
         this._bufferLayer2 = new Sprite();
         this._effectLayer = new Sprite();
         this._skillLayer = new Sprite();
         this._skillLayer.scaleX = -1;
         this._bubbleLayer = new Sprite();
         this._stateLayer = new Sprite();
         this._tipsLayer = new Sprite();
         this._movLayer = new Sprite();
         this._powerLayer = new Sprite();
         this._buffEffectLayer = new Sprite();
         this._avatarLayer.mouseEnabled = false;
         this._avatarLayer.mouseChildren = false;
         this._bloodLayer.mouseEnabled = false;
         this._bloodLayer.mouseChildren = false;
         this._powerResLayer.mouseEnabled = false;
         this._powerResLayer.mouseChildren = false;
         this._bufferLayer.mouseEnabled = false;
         this._bufferLayer.mouseChildren = false;
         this._bufferLayer2.mouseEnabled = false;
         this._bufferLayer2.mouseChildren = false;
         this._effectLayer.mouseEnabled = false;
         this._effectLayer.mouseChildren = false;
         this._skillLayer.mouseEnabled = false;
         this._skillLayer.mouseChildren = false;
         this._bubbleLayer.mouseEnabled = false;
         this._bubbleLayer.mouseChildren = false;
         this._stateLayer.mouseEnabled = false;
         this._stateLayer.mouseChildren = false;
         this._movLayer.mouseEnabled = false;
         this._movLayer.mouseChildren = false;
         this._powerLayer.mouseEnabled = false;
         this._powerLayer.mouseChildren = false;
         this._buffEffectLayer.mouseEnabled = false;
         this._buffEffectLayer.mouseChildren = false;
         this.addChild(this._bufferLayer2);
         this.addChild(this._avatarLayer);
         this.addChild(this._bloodLayer);
         this.addChild(this._powerResLayer);
         this.addChild(this._powerLayer);
         this.addChild(this._bufferLayer);
         this.addChild(this._effectLayer);
         this.addChild(this._skillLayer);
         this.addChild(this._bubbleLayer);
         this.addChild(this._stateLayer);
         this.addChild(this._tipsLayer);
         this.addChild(this._movLayer);
         this.addChild(this._powerLayer);
         this.addChild(this._buffEffectLayer);
      }
      
      public function summonDisappear() : void
      {
         this._bufferLayer2.visible = false;
         this._avatarLayer.visible = false;
         this._bloodLayer.visible = false;
         this._powerResLayer.visible = false;
         this._bufferLayer.visible = false;
         this._effectLayer.visible = false;
         this._skillLayer.visible = false;
         this._bubbleLayer.visible = false;
         this._stateLayer.visible = false;
         this._tipsLayer.visible = false;
         this._movLayer.visible = false;
         this._powerLayer.visible = false;
         this._buffEffectLayer.visible = false;
      }
      
      public function summonAppear() : void
      {
         this._bufferLayer2.visible = true;
         this._avatarLayer.visible = true;
         this._bloodLayer.visible = true;
         this._powerResLayer.visible = this._isShowPowerBarRes;
         this._bufferLayer.visible = true;
         this._effectLayer.visible = true;
         this._skillLayer.visible = true;
         this._bubbleLayer.visible = true;
         this._stateLayer.visible = true;
         this._tipsLayer.visible = true;
         this._movLayer.visible = true;
         this._powerLayer.visible = true;
         this._buffEffectLayer.visible = true;
      }
      
      protected function initAvatar() : void
      {
         this.setAvatarAction();
         this.initBloodBar();
         this.initPowerBar();
         this.checkDead();
         this._battleBuffHelper = new BattleBufferHelper();
      }
      
      private function checkDead() : void
      {
         if(this._info.curHp <= 0)
         {
            this.alpha = 0;
            this.mouseChildren = false;
            this.mouseEnabled = false;
         }
      }
      
      protected function newAvatarAction() : void
      {
         var _loc1_:String = null;
         var _loc2_:String = null;
         this._mcAction = SpineLoader.create(StringUtil.format(SPINE_ACTION_FILE,this._info.faceId));
         if(!this._mcAction)
         {
            _loc1_ = ACTION_CLS_PREFIX + this._info.faceId;
            _loc2_ = ACTION_CLS_PREFIX + "Default";
            this._mcAction = this.getMovieClipByClsName(_loc1_,_loc2_);
         }
      }
      
      private function setAvatarAction() : void
      {
         var _loc2_:int = 0;
         var _loc3_:MovieClip = null;
         this.newAvatarAction();
         this._avatarLayer.addChild(this._mcAction);
         var _loc1_:Sprite = "bound" in this._mcAction ? this._mcAction["bound"] : this._mcAction;
         this._bound = _loc1_.getBounds(this._avatarLayer);
         if(!(this._mcAction is SkeletonMovieClip))
         {
            _loc2_ = 1;
            while(_loc2_ <= this._mcAction.totalFrames)
            {
               this._mcAction.gotoAndStop(_loc2_);
               _loc3_ = this.curActionTimeline;
               if(_loc3_ == null)
               {
                  throw new Error("mc of action file is null, the race id is " + this._info.raceId + ", Action frameId is " + _loc2_);
               }
               _loc3_.gotoAndStop(1);
               _loc2_++;
            }
         }
         this._tipsLayer.graphics.beginFill(16777215,0);
         this._tipsLayer.graphics.drawRect(this._bound.x,this._bound.y,this._bound.width,this._bound.height);
         this._tipsLayer.graphics.endFill();
         this.doAction(AvatarActionDefine.STAND);
      }
      
      public function resetMapBuffId2Buff() : void
      {
         this._mapBuffId2Buff = new HashMap();
         this._buffIdArray = [];
      }
      
      protected function isUseSimpleResBySkillId(param1:int) : Boolean
      {
         var _loc2_:BattleSimpleResManager = BattleContentUtil.getContentProperty(this.content,BattleContentUtil.SIMPLE_RES_DATA);
         var _loc3_:int = int(SkillDefine.getRaceIdBySkillId(param1));
         return _loc2_.isSimpleRes || _loc2_.checkShouldBeSimpleResByRaceId(_loc3_) || _loc2_.isOnlyEnemySimpleRes && this._sourceFigherIsEnemy;
      }
      
      protected function get isUseSimpleRes() : Boolean
      {
         var _loc1_:BattleSimpleResManager = BattleContentUtil.getContentProperty(this.content,BattleContentUtil.SIMPLE_RES_DATA);
         var _loc2_:BattleInfo = BattleContentUtil.getContentProperty(this.content,BattleContentUtil.PN_BATTLE_INFO);
         var _loc3_:int = int(this._info.belong2PlayerIndex);
         var _loc4_:PlayerInfo = _loc2_.teamInfos[this._needFlip ? 1 : 0].playerInfos[_loc3_];
         return _loc1_.isSimpleRes || _loc1_.checkShouldBeSimpleResByRaceId(this._info.getShowRaceIdWithOrigin()) || _loc1_.isOnlyEnemySimpleRes && !BattleSimpleResManager.isMyFormationByUsername(_loc4_.playerName);
      }
      
      private function isSkipBuffEffect(param1:BufferDefine) : Boolean
      {
         if(this.isUseSimpleRes && Boolean(param1.isSkipWhenSimpleBattleRes))
         {
            return true;
         }
         if(BattleContentUtil.checkIsBuffSkip(param1.buffEffect))
         {
            return true;
         }
         return false;
      }
      
      private function showAttrBuffEffect(param1:MovieClip, param2:Point) : void
      {
         var endY:Number = NaN;
         var effect:Sprite = null;
         var buffMovie:MovieClip = param1;
         var pos:Point = param2;
         while(this._buffEffectLayer.numChildren > 0)
         {
            effect = this._buffEffectLayer.getChildAt(0) as Sprite;
            if(this._buffEffectLayer.numChildren == 1)
            {
               effect.alpha = 1;
               endY = effect["dir"] ? this.avatarBound.top : this.avatarBound.bottom;
               TweenLite.to(effect,30,{
                  "useFrames":true,
                  "y":endY,
                  "alpha":0.5,
                  "onComplete":function():void
                  {
                     DisplayUtil.stopAndRemove(effect);
                  }
               });
               break;
            }
            TweenLite.killTweensOf(effect);
            DisplayUtil.stopAndRemove(effect);
         }
         this._buffEffectLayer.addChild(buffMovie);
         buffMovie.x = pos.x;
         buffMovie.y = pos.y;
         buffMovie.alpha = 0.2;
         this.setBloodAndPowerLayerVisible(false);
         TweenLite.to(buffMovie,3,{
            "alpha":1,
            "useFrames":true,
            "onComplete":function():void
            {
               endY = buffMovie["dir"] ? buffMovie.y - 30 : buffMovie.y + 30;
               TweenLite.to(buffMovie,25,{
                  "useFrames":true,
                  "y":endY,
                  "onComplete":function():void
                  {
                     TweenLite.to(buffMovie,10,{
                        "alpha":0,
                        "useFrames":true,
                        "onComplete":function():void
                        {
                           DisplayUtil.stopAndRemove(buffMovie);
                           setBloodAndPowerLayerVisible(true);
                        }
                     });
                  }
               });
            }
         });
      }
      
      private function setBloodAndPowerLayerVisible(param1:Boolean) : void
      {
         this.setBloodLayerVisible(param1);
         this.setPowerResLayerVisible(this._isShowPowerBarRes && param1);
      }
      
      private function showSpecialBuffEffect(param1:MovieClip, param2:Point) : void
      {
         var bubble:Sprite = null;
         var buffMovie:MovieClip = param1;
         var pos:Point = param2;
         var i:int = 0;
         while(i < this._bubbleLayer.numChildren)
         {
            bubble = this._bubbleLayer.getChildAt(i) as Sprite;
            TweenLite.killTweensOf(bubble);
            TweenLite.to(bubble,14,{
               "useFrames":true,
               "y":bubble.y - 70,
               "alpha":0
            });
            i++;
         }
         buffMovie.x = pos.x;
         buffMovie.y = pos.y;
         this._bubbleLayer.addChild(buffMovie);
         buffMovie.scaleX = buffMovie.scaleY = 0.5;
         this.setBloodAndPowerLayerVisible(false);
         TweenLite.to(buffMovie,1,{
            "scaleX":0.9,
            "scaleY":0.9,
            "y":buffMovie.y - 3,
            "useFrames":true,
            "onComplete":function():void
            {
               TweenLite.to(buffMovie,14,{
                  "scaleX":1,
                  "scaleY":1,
                  "useFrames":true,
                  "onComplete":function():void
                  {
                     TweenLite.to(buffMovie,15,{
                        "scaleX":0.71,
                        "scaleY":0.71,
                        "alpha":0,
                        "useFrames":true,
                        "onComplete":function():void
                        {
                           DisplayUtil.stopAndRemove(buffMovie);
                           setBloodAndPowerLayerVisible(true);
                        }
                     });
                  }
               });
            }
         });
      }
      
      private function playBuffEffect(param1:BufferDefine) : void
      {
         var buffArr:Array;
         var i:int;
         var index:int = 0;
         var pos:Point = null;
         var buffMovie:MovieClip = null;
         var clsName:String = null;
         var cls:Class = null;
         var proCls:String = null;
         var proBuffMovie:MovieClip = null;
         var define:BufferDefine = param1;
         if(StringUtil.isNullOrEmpty(define.buffEffect))
         {
            return;
         }
         index = BufferConsts.SPECIAL_BUFF.indexOf(define.buffEffect);
         if(index != -1)
         {
            clsName = BUFF_SPECIAL_CLS + index;
            cls = this._domain.getDefinition(clsName) as Class;
            buffMovie = new cls() as MovieClip;
            pos = this.getAvatarPos(AvatarPosTypes.TOP);
            buffMovie["dir"] = true;
            this.showAttrBuffEffect(buffMovie,pos);
            return;
         }
         buffArr = define.buffEffect.split("，");
         i = 0;
         while(i < buffArr.length)
         {
            index = BufferConsts.PRO_BUFF.indexOf(buffArr[i]);
            if(index != -1)
            {
               proCls = BUFF_PROFICIENT_CLS + index;
               proBuffMovie = InstanceUtil.getInstance(proCls,this._domain) as MovieClip;
               pos = this.getAvatarPos(AvatarPosTypes.BUTTOM);
               proBuffMovie.x = pos.x;
               proBuffMovie.y = pos.y - 30;
               this._effectLayer.addChild(proBuffMovie);
               proBuffMovie.addFrameScript(proBuffMovie.totalFrames - 1,function():*
               {
                  DisplayUtil.stopAndRemove(proBuffMovie);
               });
               proBuffMovie.gotoAndPlay(1);
               break;
            }
            i++;
         }
         buffMovie = this.getBufferEffect(define.buffEffect);
         if(buffMovie != null)
         {
            pos = this.getAvatarPos(AvatarPosTypes.CENTER);
            this.showAttrBuffEffect(buffMovie,pos);
         }
      }
      
      private function getBufferEffect(param1:String) : MovieClip
      {
         var _loc6_:String = null;
         var _loc7_:int = 0;
         var _loc8_:Array = null;
         var _loc9_:String = null;
         var _loc10_:int = 0;
         var _loc11_:MovieClip = null;
         var _loc12_:Rectangle = null;
         var _loc13_:MovieClip = null;
         var _loc14_:Rectangle = null;
         var _loc2_:Boolean = false;
         var _loc3_:Boolean = false;
         var _loc4_:Array = param1.split("，");
         var _loc5_:MovieClip = new MovieClip();
         for each(_loc6_ in _loc4_)
         {
            _loc10_ = 0;
            if(_loc6_.indexOf("↓") != -1)
            {
               _loc10_ = 3;
               _loc9_ = "↓";
               _loc2_ = false;
            }
            else
            {
               if(_loc6_.indexOf("↑") == -1)
               {
                  continue;
               }
               _loc10_ = 0;
               _loc9_ = "↑";
               _loc2_ = true;
            }
            _loc8_ = _loc6_.split(_loc9_);
            if(_loc8_.length > 0 && !StringUtil.isNullOrEmpty(_loc8_[0]))
            {
               _loc7_ = BufferConsts.BUFF_ATTR_CHANGE.indexOf(_loc8_[0]);
               if(_loc7_ != -1)
               {
                  _loc11_ = this.getEffectMovie(_loc7_,_loc10_ + _loc8_.length - 1);
                  _loc12_ = _loc5_.getRect(null);
                  _loc11_.x = _loc12_.right + _loc11_.width / 2;
                  if(_loc3_)
                  {
                     _loc11_.x += 2;
                  }
                  _loc5_.addChild(_loc11_);
                  _loc3_ = true;
               }
            }
         }
         if(_loc3_)
         {
            _loc13_ = new MovieClip();
            _loc14_ = _loc5_.getRect(null);
            _loc5_.x = -_loc5_.width / 2 - _loc14_.left;
            _loc13_.addChild(_loc5_);
            _loc13_["dir"] = _loc2_;
            return _loc13_;
         }
         return null;
      }
      
      private function getEffectMovie(param1:int, param2:int) : MovieClip
      {
         var _loc3_:String = BUFF_ATTR_CHANGE_CLS + param1;
         var _loc4_:Class = this._domain.getDefinition(_loc3_) as Class;
         var _loc5_:MovieClip = new _loc4_() as MovieClip;
         _loc5_.gotoAndStop(param2);
         return _loc5_.getChildAt(0) as MovieClip;
      }
      
      public function addBuff(param1:int, param2:Function = null) : void
      {
         var _loc4_:MovieClip = null;
         var _loc6_:Sprite = null;
         var _loc7_:Class = null;
         if(POWER_FULL_BUFF_ID2_PRIMARY_DATA.indexOf(param1) >= 0)
         {
            if(this._mapBuffId2Buff.containsKey(param1))
            {
               return;
            }
            _loc6_ = this.getBufferByIdP(param1);
            this._bufferLayer2.addChild(_loc6_);
            this._mapBuffId2Buff.add(param1,_loc6_);
            this._buffIdArray.push(param1);
            return;
         }
         this._buffIdArray.push(param1);
         var _loc3_:BufferDefine = this._battleConfig.getBufferDefineById(param1);
         if(Boolean(this._mapBuffId2Buff.containsKey(param1)) && _loc3_.buffWaitType <= 0)
         {
            return;
         }
         this.playBuffEffect(_loc3_);
         if(_loc3_.hidden)
         {
            return;
         }
         if(this.isSkipBuffEffect(_loc3_))
         {
            InteractUtil.applyCallback(param2);
            return;
         }
         var _loc5_:BufferExecuteDefine = this._battleConfig.getBufferExecutDefine(param1);
         if(_loc5_ != null && _loc5_.maxValue > 0)
         {
            _loc7_ = this._domain.getDefinition(PSY_PROGRESS_RES) as Class;
            _loc4_ = new _loc7_() as MovieClip;
         }
         else
         {
            _loc4_ = this.getBufferById(_loc3_.displayId);
         }
         if(Boolean(_loc3_.displayOnce) && _loc4_.totalFrames > 1)
         {
            if(_loc3_.buffWaitEndFrame <= 0)
            {
               _loc4_.addFrameScript(_loc4_.totalFrames - 1,this.onBuffMcEnd(param1,_loc4_,param2));
            }
            else
            {
               _loc4_.addFrameScript(Math.min(_loc4_.totalFrames - 1,_loc3_.buffWaitEndFrame - 1),this.onBuffMcEnd(param1,_loc4_,param2));
            }
         }
         this.listenBuffFrameEvent(_loc4_);
         this.hadleBuffByBufferHelper(_loc4_,_loc3_);
         this.addBuff2avatarPos(_loc4_,_loc3_);
         this._mapBuffId2Buff.add(param1,_loc4_);
      }
      
      private function listenBuffFrameEvent(param1:MovieClip) : void
      {
         var _loc4_:FrameLabel = null;
         var _loc2_:Array = param1.currentLabels;
         var _loc3_:int = 0;
         while(_loc3_ < _loc2_.length)
         {
            _loc4_ = _loc2_[_loc3_];
            if(_loc4_.frame != param1.totalFrames)
            {
               if(_loc4_.name.indexOf("@evt_") == 0)
               {
                  param1.addFrameScript(_loc4_.frame - 1,this.onEvtFrame(_loc4_.name));
               }
            }
            _loc3_++;
         }
      }
      
      private function hadleBuffByBufferHelper(param1:MovieClip, param2:BufferDefine) : void
      {
         var _loc3_:BattleBase = null;
         var _loc4_:BattleInfo = null;
         var _loc5_:int = 0;
         var _loc6_:PlayerInfo = null;
         var _loc7_:IBattlePlayer = null;
         var _loc8_:IBattleFighter = null;
         if(param2.buffWaitType > 0)
         {
            _loc3_ = BattleContentUtil.getContentProperty(this.content,BattleContentUtil.PN_BATTLE);
            _loc4_ = BattleContentUtil.getContentProperty(this.content,BattleContentUtil.PN_BATTLE_INFO);
            _loc5_ = int(this._info.belong2PlayerIndex);
            _loc6_ = _loc4_.teamInfos[this._needFlip ? 1 : 0].playerInfos[_loc5_];
            _loc7_ = _loc3_.getPlayerByName(_loc6_.playerName);
            _loc8_ = _loc7_.getFighterById(this._info.id);
            this._battleBuffHelper.handleFrameLabel(param1,this.content,_loc7_,_loc8_);
         }
      }
      
      private function addBuff2avatarPos(param1:MovieClip, param2:BufferDefine) : void
      {
         var _loc3_:Point = this.getAvatarPos(param2.posId);
         param1.x = _loc3_.x;
         param1.y = _loc3_.y;
         param1.name = "buff_" + param2.id + "_" + this._needFlip;
         if(this._needFlip)
         {
            this.handleBuffFile(param1,param2);
         }
         var _loc4_:BattleContainer = BattleContentUtil.getContentProperty(this.content,BattleContentUtil.PN_CONTAINER);
         if(param2.posId == AvatarPosTypes.FLOOR_REGISTER_POINT)
         {
            this.add2containerWithoutReplace(_loc4_.floor,param1,param2.id);
         }
         else if(param2.posId == AvatarPosTypes.FULL_SCREEN_BACK || param2.posId == AvatarPosTypes.FULL_SCREEN_FRONT || param2.posId == AvatarPosTypes.RESPONSE2MOUSE_FULL_SCREEN_FRONT)
         {
            if(param2.need2HidePlayerUi)
            {
               this.add2containerWithOnlyOne(_loc4_.uniqueSkillHideOtherLayer,param1);
            }
            else if(param2.posId == AvatarPosTypes.FULL_SCREEN_BACK)
            {
               this.add2containerWithOnlyOne(_loc4_.fullScreenBuffLayerBelow,param1);
            }
            else if(param2.posId == AvatarPosTypes.RESPONSE2MOUSE_FULL_SCREEN_FRONT)
            {
               this.add2containerWithOnlyOne(_loc4_.response2mouseFullScreenFrontLayer,param1);
            }
            else
            {
               this.add2containerWithOnlyOne(_loc4_.fullScreenBuffLayerAbove,param1);
            }
         }
         else if(param2.posId >= 0)
         {
            this._bufferLayer.addChild(param1);
         }
         else
         {
            this._bufferLayer2.addChild(param1);
         }
      }
      
      private function add2containerWithOnlyOne(param1:Sprite, param2:MovieClip) : void
      {
         var _loc5_:MovieClip = null;
         var _loc3_:int = -1;
         var _loc4_:int = 0;
         while(_loc4_ < param1.numChildren)
         {
            _loc5_ = param1.getChildAt(_loc4_) as MovieClip;
            if(_loc5_.name == param2.name)
            {
               _loc3_ = _loc4_;
               break;
            }
            _loc4_++;
         }
         if(_loc3_ != -1)
         {
            param1.removeChildAt(_loc3_);
         }
         param1.addChildAt(param2,param1.numChildren);
      }
      
      private function add2containerWithoutReplace(param1:Sprite, param2:MovieClip, param3:int) : void
      {
         var _loc6_:MovieClip = null;
         var _loc4_:int = -1;
         var _loc5_:int = 0;
         while(_loc5_ < param1.numChildren)
         {
            _loc6_ = param1.getChildAt(_loc5_) as MovieClip;
            if(this.getBuffMcByBuffId(param3) == _loc6_ && _loc6_.name == param2.name)
            {
               _loc4_ = _loc5_;
               break;
            }
            _loc5_++;
         }
         if(_loc4_ != -1)
         {
            param1.removeChildAt(_loc4_);
         }
         param1.addChildAt(param2,param1.numChildren);
      }
      
      private function handleBuffFile(param1:MovieClip, param2:BufferDefine) : void
      {
         if(param2.posId == AvatarPosTypes.FULL_SCREEN_BACK || param2.posId == AvatarPosTypes.FULL_SCREEN_FRONT || param2.posId == AvatarPosTypes.RESPONSE2MOUSE_FULL_SCREEN_FRONT)
         {
            if(!param2.disableFlip)
            {
               param1.scaleX = -1;
               param1.x = LoaderContainer.stageWidth;
               this.handleBuffMcScale(param1);
            }
            return;
         }
         if(param2.posId == AvatarPosTypes.FLOOR_REGISTER_POINT)
         {
            if(!param2.disableFlip)
            {
               param1.scaleX *= -1;
               this.handleBuffMcScale(param1);
            }
            return;
         }
         if(param2.posId != AvatarPosTypes.FIRST_COLUMN_FONT && param2.posId != AvatarPosTypes.COLUMN_FONT)
         {
            param1.x = -param1.x;
         }
         if(param2.disableFlip)
         {
            param1.scaleX *= -1;
         }
         else
         {
            this.handleBuffMcScale_NoFlip(param1);
         }
      }
      
      private function handleBuffMcScale(param1:MovieClip) : void
      {
         if(param1["scale"] != null)
         {
            MovieClip(param1["scale"]).scaleX = -1;
         }
      }
      
      private function handleBuffMcScale_NoFlip(param1:MovieClip) : void
      {
         var mcScale:MovieClip = null;
         var arr:Array = null;
         var frameLabel:FrameLabel = null;
         var buffMc:MovieClip = param1;
         mcScale = buffMc["scale"];
         if(mcScale != null)
         {
            arr = mcScale.currentLabels;
            if(arr.length == 0)
            {
               return;
            }
            for each(frameLabel in arr)
            {
               if(frameLabel.name.indexOf("startset") != -1)
               {
                  mcScale.addFrameScript(frameLabel.frame - 1,function():void
                  {
                     mcScale.addFrameScript(frameLabel.frame - 1,null);
                     var _loc1_:MovieClip = mcScale.getChildByName("noscale") as MovieClip;
                     if(_loc1_ != null)
                     {
                        _loc1_.scaleX = -1;
                     }
                  });
               }
            }
         }
      }
      
      private function onSetNoScale(param1:MovieClip, param2:int) : void
      {
         param1.addFrameScript(param2,null);
         var _loc3_:MovieClip = param1.getChildByName("noscale") as MovieClip;
         if(_loc3_ != null)
         {
            _loc3_.scaleX = -1;
         }
      }
      
      private function onEvtFrame(param1:String) : Function
      {
         var frameName:String = param1;
         var fun:Function = function():void
         {
            var _loc1_:String = frameName.replace("@evt_","");
            _dispatcher.dispatchEvent(new Event(_loc1_));
         };
         return fun;
      }
      
      public function removeBuff(param1:int) : void
      {
         var _loc4_:MovieClip = null;
         var _loc2_:int = this._buffIdArray.indexOf(param1);
         var _loc3_:BufferDefine = this._battleConfig.getBufferDefineById(param1);
         if(_loc2_ != -1)
         {
            this._buffIdArray.splice(_loc2_,1);
            if(this._buffIdArray.indexOf(param1) == -1)
            {
               _loc4_ = this._mapBuffId2Buff.remove(param1);
               if(_loc4_ != null)
               {
                  if(_loc3_.buffWaitType > 0)
                  {
                     if(_loc4_.currentFrame >= _loc4_.totalFrames)
                     {
                        this.removeBuffSp(_loc4_);
                     }
                  }
                  else
                  {
                     this.removeBuffSp(_loc4_);
                  }
               }
            }
         }
      }
      
      private function removeBuffSp(param1:MovieClip) : void
      {
         var buffSp:MovieClip = param1;
         TweenLite.to(buffSp,0.3,{
            "alpha":0,
            "onComplete":function():void
            {
               DisplayUtil.stopAndRemove(buffSp);
            }
         });
      }
      
      public function showSkillEffect(param1:int, param2:Boolean, param3:Function, param4:Boolean) : MovieClip
      {
         var pos:Point;
         var skillDefine:SkillDefine;
         var container:BattleContainer;
         var effectMC:MovieClip = null;
         var skillId:int = param1;
         var isLastEffect:Boolean = param2;
         var callback:Function = param3;
         var useSimpleRes:Boolean = param4;
         this._sourceFigherIsEnemy = useSimpleRes;
         effectMC = this.getSkillEffectMC(skillId,isLastEffect);
         pos = this.getSkillEffectPos(skillId);
         effectMC.x = pos.x;
         effectMC.y = pos.y;
         skillDefine = this._battleConfig.getSkillDefineById(skillId);
         container = BattleContentUtil.getContentProperty(this.content,BattleContentUtil.PN_CONTAINER);
         if(this.isUseSimpleResBySkillId(skillId))
         {
            this._skillLayer.addChild(effectMC);
         }
         else if(skillDefine.isFullSceneEffect)
         {
            this.add2containerWithOnlyOne(container.response2mouseFullScreenFrontLayer,effectMC);
            if(effectMC is SkeletonMovieClip)
            {
               this.handleFullScreenSpine(effectMC as SkeletonMovieClip);
            }
            else if(!this._needFlip && effectMC["scale"] != null)
            {
               effectMC["scale"].scaleX = -effectMC["scale"].scaleX;
            }
         }
         else
         {
            this._skillLayer.addChild(effectMC);
         }
         effectMC.addFrameScript(effectMC.totalFrames - 1,function():void
         {
            DisplayUtil.stopAndRemove(effectMC);
            if(callback != null)
            {
               callback.apply();
            }
         });
         return effectMC;
      }
      
      public function showSummonEffect(param1:int, param2:Function) : MovieClip
      {
         var pos:Point;
         var container:BattleContainer;
         var effectMC:MovieClip = null;
         var effectId:int = param1;
         var callback:Function = param2;
         effectMC = this.getSummonEffectMC(effectId);
         this._bufferLayer.addChild(effectMC);
         pos = this.getAvatarPos(AvatarPosTypes.REGISTER_POINT);
         effectMC.x = pos.x;
         effectMC.y = pos.y;
         container = BattleContentUtil.getContentProperty(this.content,BattleContentUtil.PN_CONTAINER);
         effectMC.addFrameScript(effectMC.totalFrames - 1,function():void
         {
            DisplayUtil.stopAndRemove(effectMC);
            if(callback != null)
            {
               callback.apply();
            }
         });
         return effectMC;
      }
      
      public function showEffect(param1:int, param2:Function, param3:Boolean = false) : void
      {
         var _loc4_:MovieClip = this.getEffectMCById(param1);
         var _loc5_:int = int(AvatarEffectIds.effectIdToAvatarPos.getValue(param1));
         this.showEffectMovie(_loc4_,_loc5_,param2,param3);
      }
      
      public function showEffectMovie(param1:MovieClip, param2:int, param3:Function, param4:Boolean = false) : void
      {
         var pos:Point;
         var effectMC:MovieClip = param1;
         var posType:int = param2;
         var callback:Function = param3;
         var isFlip:Boolean = param4;
         this._effectLayer.addChild(effectMC);
         if(isFlip && this._needFlip)
         {
            effectMC.scaleX = -1;
            if(effectMC["scale"] != null)
            {
               MovieClip(effectMC["scale"]).scaleX = -1;
            }
         }
         pos = this.getAvatarPos(posType);
         effectMC.x = pos.x;
         effectMC.y = pos.y;
         effectMC.alpha = 0.1;
         this.setBloodAndPowerLayerVisible(false);
         if(this._info.curHp <= 0 || this.alpha == 0)
         {
            effectMC.alpha = 1;
            TweenLite.to(effectMC,24,{
               "useFrames":true,
               "alpha":0,
               "onComplete":function():void
               {
                  DisplayUtil.stopAndRemove(effectMC);
               }
            });
            if(callback != null)
            {
               callback.apply();
            }
         }
         else
         {
            TweenLite.to(effectMC,3,{
               "alpha":1,
               "useFrames":true,
               "onComplete":function():void
               {
                  TweenLite.to(effectMC,16,{
                     "useFrames":true,
                     "onComplete":function():void
                     {
                        TweenLite.to(effectMC,10,{
                           "alpha":0,
                           "useFrames":true,
                           "onComplete":function():void
                           {
                              DisplayUtil.stopAndRemove(effectMC);
                              setBloodAndPowerLayerVisible(true);
                              if(callback != null)
                              {
                                 callback.apply();
                              }
                           }
                        });
                     }
                  });
               }
            });
         }
      }
      
      public function showMovie(param1:MovieClip, param2:Function) : void
      {
         var movie:MovieClip = param1;
         var callback:Function = param2;
         this._skillLayer.addChild(movie);
         movie.addFrameScript(movie.totalFrames - 1,function():void
         {
            DisplayUtil.stopAndRemove(movie);
            if(callback != null)
            {
               callback.apply();
            }
         });
         movie.gotoAndPlay(1);
      }
      
      public function showBubble(param1:FighterInfo, param2:Number, param3:Number, param4:Function, param5:int = 0) : void
      {
         var i:int;
         var pos:Point;
         var bufferDefine:BufferDefine = null;
         var bubbleSp:Sprite = null;
         var bubble:Sprite = null;
         var sourceFighterInfo:FighterInfo = param1;
         var bubbleNum:Number = param2;
         var restraintCoeff:Number = param3;
         var callback:Function = param4;
         var buffId:int = param5;
         if(buffId != 0 && buffId != BufferConsts.ShieldBuffId)
         {
            bufferDefine = this._battleConfig.getBufferDefineById(buffId);
            if(bufferDefine != null && bufferDefine.buffEffect.indexOf(BufferConsts.NO_BUFF_BLOOD) != -1)
            {
               return;
            }
         }
         i = 0;
         while(i < this._bubbleLayer.numChildren)
         {
            bubble = this._bubbleLayer.getChildAt(i) as Sprite;
            TweenLite.killTweensOf(bubble);
            TweenLite.to(bubble,14,{
               "useFrames":true,
               "y":bubble.y - 70,
               "alpha":0
            });
            i++;
         }
         if(buffId == BufferConsts.ShieldBuffId)
         {
            bubbleSp = this.getArtNumBase(NUMBER_CLS_PREFIX + "Shield",bubbleNum,-2);
         }
         else
         {
            bubbleSp = this.getBubbleSpByNum(sourceFighterInfo,bubbleNum,restraintCoeff,bufferDefine);
         }
         this._bubbleLayer.addChild(bubbleSp);
         pos = this.getBubblePos();
         bubbleSp.x = pos.x;
         bubbleSp.y = pos.y;
         bubbleSp.scaleX = bubbleSp.scaleY = 0.5;
         this.setBloodAndPowerLayerVisible(false);
         TweenLite.to(bubbleSp,1,{
            "scaleX":0.9,
            "scaleY":0.9,
            "y":bubbleSp.y - 3,
            "useFrames":true,
            "onComplete":function():void
            {
               TweenLite.to(bubbleSp,14,{
                  "scaleX":1,
                  "scaleY":1,
                  "useFrames":true,
                  "onComplete":function():void
                  {
                     TweenLite.to(bubbleSp,15,{
                        "scaleX":0.71,
                        "scaleY":0.71,
                        "alpha":0,
                        "useFrames":true,
                        "onComplete":function():void
                        {
                           DisplayUtil.stopAndRemove(bubbleSp);
                           setBloodAndPowerLayerVisible(true);
                           if(callback != null)
                           {
                              callback.apply();
                           }
                        }
                     });
                  }
               });
            }
         });
      }
      
      public function showPowerBubble(param1:FighterInfo, param2:Number, param3:Number, param4:Function, param5:int = 0) : void
      {
         var i:int;
         var artNum:Sprite;
         var spPower:Sprite;
         var pos:Point;
         var bubbleSp:Sprite = null;
         var bufferDefine:BufferDefine = null;
         var bubble:Sprite = null;
         var sourceFighterInfo:FighterInfo = param1;
         var bubbleNum:Number = param2;
         var restraintCoeff:Number = param3;
         var callback:Function = param4;
         var buffId:int = param5;
         if(buffId > 0)
         {
            bufferDefine = this._battleConfig.getBufferDefineById(buffId);
            if(bufferDefine.buffEffect.indexOf(BufferConsts.NO_BUFF_POWER) != -1)
            {
               return;
            }
         }
         i = 0;
         while(i < this._powerLayer.numChildren)
         {
            bubble = this._powerLayer.getChildAt(i) as Sprite;
            TweenLite.killTweensOf(bubble);
            TweenLite.to(bubble,14,{
               "useFrames":true,
               "y":bubble.y - 90,
               "alpha":0
            });
            i++;
         }
         artNum = this.getArtNumBase(NUMBER_CLS_PREFIX + "Yellow",bubbleNum,1);
         spPower = this._regularBitmapData.getSprite(POWER_CHAR_CLS);
         bubbleSp = this.getSpriteGroup(artNum,spPower);
         this._powerLayer.addChild(bubbleSp);
         pos = this.getBubblePos();
         bubbleSp.x = pos.x;
         bubbleSp.y = pos.y + 30;
         bubbleSp.scaleX = bubbleSp.scaleY = 0.5;
         this.setBloodAndPowerLayerVisible(false);
         TweenLite.to(bubbleSp,1,{
            "scaleX":0.9,
            "scaleY":0.9,
            "y":bubbleSp.y - 3,
            "useFrames":true,
            "onComplete":function():void
            {
               TweenLite.to(bubbleSp,14,{
                  "scaleX":1,
                  "scaleY":1,
                  "useFrames":true,
                  "onComplete":function():void
                  {
                     TweenLite.to(bubbleSp,15,{
                        "scaleX":0.71,
                        "scaleY":0.71,
                        "alpha":0,
                        "useFrames":true,
                        "onComplete":function():void
                        {
                           DisplayUtil.stopAndRemove(bubbleSp);
                           setBloodAndPowerLayerVisible(true);
                           if(callback != null)
                           {
                              callback.apply();
                           }
                        }
                     });
                  }
               });
            }
         });
      }
      
      public function showTips(param1:Sprite, param2:FighterInfo, param3:IBattleConfig) : void
      {
         if(this._tips != null)
         {
            DisplayUtil.stopAndRemove(this._tips.getResSprite());
         }
         this._tips = this.getFighterTips(param1,param2,param3);
         TipsManager.getInstance().removeTips(this._tipsLayer);
         TipsManager.getInstance().addCustomTips(this._tipsLayer,this._tips.getResSprite());
      }
      
      public function updateTips() : void
      {
         if(this._tips != null)
         {
            this._tips.refreash();
         }
      }
      
      public function set scale(param1:Number) : void
      {
         this.scaleX = this.scaleY = Math.abs(param1);
      }
      
      public function jumpTo(param1:Number, param2:Number, param3:Function) : void
      {
         var thisObj:DisplayObject = null;
         var duration:Number = NaN;
         var tarX:Number = param1;
         var tarY:Number = param2;
         var callback:Function = param3;
         var midX:Number = (this.x + tarX) / 2;
         var midY:Number = (this.y + tarY) / 2;
         thisObj = this;
         duration = this.isUseSimpleRes ? 0.05 * 2 : 0.05;
         TweenLite.to(thisObj,duration,{
            "x":midX,
            "y":midY,
            "alpha":0,
            "onComplete":function():void
            {
               TweenLite.to(thisObj,duration,{
                  "x":tarX,
                  "y":tarY,
                  "alpha":1,
                  "onComplete":callback
               });
            }
         });
      }
      
      public function slideBackward(param1:Function) : void
      {
         var backX:Number;
         var thisObj:DisplayObject = null;
         var callback:Function = param1;
         thisObj = this._mcAction;
         if(this._slideFlag)
         {
            TweenLite.killTweensOf(thisObj);
            thisObj.x = this._orgXBeforeSlide;
         }
         this._slideFlag = true;
         this._orgXBeforeSlide = thisObj.x;
         backX = this._orgXBeforeSlide - SLIDE_BACKWARD_DISTANCE;
         TweenLite.to(thisObj,0.6,{
            "x":backX,
            "ease":Cubic.easeOut,
            "onComplete":function():void
            {
               thisObj.x = _orgXBeforeSlide;
               _slideFlag = false;
               if(callback != null)
               {
                  callback.apply();
               }
            }
         });
      }
      
      public function doAction(param1:int) : MovieClip
      {
         var _loc3_:Sprite = null;
         this._actionId = param1;
         var _loc2_:MovieClip = this.curActionTimeline;
         if(_loc2_ is SkeletonMovieClip)
         {
            SkeletonMovieClip(_loc2_).setAnimation(param1 + "");
         }
         else
         {
            _loc2_.gotoAndStop(1);
            this._mcAction.gotoAndStop(param1);
            _loc2_ = this.curActionTimeline;
            _loc2_.gotoAndPlay(1);
            _loc3_ = _loc2_.getChildByName("scale") as Sprite;
            if(_loc3_ != null && this._needFlip)
            {
               _loc3_.scaleX = -1;
            }
         }
         return _loc2_;
      }
      
      public function get curActionTimeline() : MovieClip
      {
         if(this._mcAction is SkeletonMovieClip)
         {
            return this._mcAction;
         }
         var _loc1_:MovieClip = this._mcAction.getChildByName("mc") as MovieClip;
         if(_loc1_ == null && this._mcAction.numChildren > 0)
         {
            _loc1_ = this._mcAction.getChildAt(0) as MovieClip;
         }
         return _loc1_;
      }
      
      public function get curActionId() : int
      {
         return this._actionId;
      }
      
      public function flip() : void
      {
         this._avatarLayer.scaleX = -Math.abs(this._avatarLayer.scaleX);
         this._bufferLayer.scaleX = -Math.abs(this._bufferLayer.scaleX);
         this._bufferLayer2.scaleX = -Math.abs(this._bufferLayer2.scaleX);
         this._skillLayer.scaleX = Math.abs(this._skillLayer.scaleX);
      }
      
      public function getAvatarPos(param1:int) : Point
      {
         var _loc4_:MovieClip = null;
         var _loc2_:Point = new Point();
         var _loc3_:Number = (this.avatarBound.left + this.avatarBound.right) / 2;
         switch(Math.abs(param1))
         {
            case AvatarPosTypes.REGISTER_POINT:
               _loc2_.x = 0;
               _loc2_.y = 0;
               break;
            case AvatarPosTypes.TOP_FRONT:
               _loc2_.x = this._avatarLayer.scaleX > 0 ? this.avatarBound.right : this.avatarBound.left;
               _loc2_.y = this.avatarBound.top;
               break;
            case AvatarPosTypes.TOP:
               _loc2_.x = this._avatarLayer.scaleX > 0 ? _loc3_ : -_loc3_;
               _loc2_.y = this.avatarBound.top;
               break;
            case AvatarPosTypes.TOP_BACK:
               _loc2_.x = this._avatarLayer.scaleX > 0 ? this.avatarBound.left : this.avatarBound.right;
               _loc2_.y = this.avatarBound.top;
               break;
            case AvatarPosTypes.FRONT:
               _loc2_.x = this._avatarLayer.scaleX > 0 ? this.avatarBound.right : this.avatarBound.left;
               _loc2_.y = (this.avatarBound.top + this.avatarBound.bottom) / 2;
               break;
            case AvatarPosTypes.CENTER:
               _loc2_.x = this._avatarLayer.scaleX > 0 ? _loc3_ : -_loc3_;
               _loc2_.y = (this.avatarBound.top + this.avatarBound.bottom) / 2;
               break;
            case AvatarPosTypes.BACK:
               _loc2_.x = this._avatarLayer.scaleX > 0 ? this.avatarBound.left : this.avatarBound.right;
               _loc2_.y = (this.avatarBound.top + this.avatarBound.bottom) / 2;
               break;
            case AvatarPosTypes.BUTTOM_FRONT:
               _loc2_.x = this._avatarLayer.scaleX > 0 ? this.avatarBound.right : this.avatarBound.left;
               _loc2_.y = this.avatarBound.bottom;
               break;
            case AvatarPosTypes.BUTTOM:
               _loc2_.x = this._avatarLayer.scaleX > 0 ? _loc3_ : -_loc3_;
               _loc2_.y = this.avatarBound.bottom;
               break;
            case AvatarPosTypes.BUTTOM_BACK:
               _loc2_.x = this._avatarLayer.scaleX > 0 ? this.avatarBound.left : this.avatarBound.right;
               _loc2_.y = this.avatarBound.bottom;
               break;
            case AvatarPosTypes.FULL_SCREEN_BACK:
               _loc2_.x = 0;
               _loc2_.y = 0;
               break;
            case AvatarPosTypes.FULL_SCREEN_FRONT:
            case AvatarPosTypes.RESPONSE2MOUSE_FULL_SCREEN_FRONT:
               _loc2_.x = 0;
               _loc2_.y = 0;
               break;
            case AvatarPosTypes.COLUMN_FONT:
               _loc2_ = this.getBottomFightLocatorPointByPosY(this._info.initPosY);
               break;
            case AvatarPosTypes.FIRST_COLUMN_FONT:
               _loc2_ = this.getBottomFightLocatorPointByPosY(0);
               break;
            case AvatarPosTypes.FLOOR_REGISTER_POINT:
               _loc2_ = this.localToGlobal(new Point());
               break;
            case AvatarPosTypes.ATTR_ICON:
               if(this._bloodBarRes == null)
               {
                  _loc2_.x = 1000;
                  _loc2_.y = -100;
               }
               else
               {
                  _loc4_ = this._bloodBarRes.getChildByName("mcAttr") as MovieClip;
                  _loc2_ = this._bloodBarRes.localToGlobal(new Point(_loc4_.x,_loc4_.y));
                  _loc2_ = this.globalToLocal(_loc2_);
               }
         }
         return _loc2_;
      }
      
      private function getBottomFightLocatorPointByPosY(param1:int) : Point
      {
         var _loc2_:Sprite = BattleContentUtil.getContentProperty(this.content,BattleContentUtil.PN_LOCATOR);
         var _loc3_:int = this._needFlip ? 1 : 0;
         var _loc4_:Sprite = _loc2_.getChildByName("t" + _loc3_) as Sprite;
         var _loc5_:int = int(this._info.belong2PlayerIndex);
         var _loc6_:Sprite = _loc4_.getChildByName("p" + _loc5_) as Sprite;
         var _loc7_:int = 2 + param1 * FormationConsts.MAX_ROW_COUNT;
         var _loc8_:Sprite = _loc6_.getChildByName("f" + _loc7_) as Sprite;
         var _loc9_:Point = _loc6_.localToGlobal(new Point(_loc8_.x,_loc8_.y));
         return this._avatarLayer.globalToLocal(new Point(_loc9_.x,_loc9_.y));
      }
      
      public function get avatarBound() : Rectangle
      {
         return this._bound;
      }
      
      public function set hpPersentage(param1:Number) : void
      {
         this._bloodBar.gotoAndStop(Math.max(1,Math.floor(this._bloodBar.totalFrames * param1)));
      }
      
      public function set spPersentage(param1:Number) : void
      {
         this._shieldBar.gotoAndStop(Math.max(1,Math.floor(this._shieldBar.totalFrames * param1)));
      }
      
      public function set powerPersentage(param1:Number) : void
      {
         if(param1 > 1)
         {
            param1 = 1;
         }
         this._powerBar.scaleX = param1;
         this._txtPower.visible = false;
      }
      
      public function set isDead(param1:Boolean) : void
      {
         if(this._isDead == param1)
         {
            return;
         }
         this._isDead = param1;
         if(param1)
         {
            this.fadeOut(null);
            this.setupDeathWing();
            this.setBloodAndPowerLayerVisible(false);
         }
         else
         {
            this.showUp();
            this.removeDeathWing();
            this.setBloodAndPowerLayerVisible(true);
         }
      }
      
      public function fadeOut(param1:Function) : void
      {
         var callback:Function = param1;
         TweenLite.killTweensOf(this);
         TweenLite.to(this,0.8,{
            "alpha":0,
            "onComplete":function():void
            {
               if(callback != null)
               {
                  callback.apply();
               }
            }
         });
         this.mouseEnabled = false;
         this.mouseChildren = false;
      }
      
      public function showUp() : void
      {
         TweenLite.killTweensOf(this);
         this.alpha = 1;
         this.mouseEnabled = true;
         this.mouseChildren = true;
         this.doAction(AvatarActionDefine.STAND);
      }
      
      public function dispose() : void
      {
         DisplayUtil.stopAndRemove(this);
      }
      
      protected function getBubblePos() : Point
      {
         return this.getAvatarPos(AvatarPosTypes.TOP);
      }
      
      protected function getSkillEffectPos(param1:int) : Point
      {
         var _loc2_:SkillDefine = this._battleConfig.getSkillDefineById(param1);
         if(this.isUseSimpleResBySkillId(param1))
         {
            if(param1.toString().charAt(0) == "1")
            {
               return this.getAvatarPos(AvatarPosTypes.CENTER);
            }
            return this.getAvatarPos(AvatarPosTypes.REGISTER_POINT);
         }
         return this.getAvatarPos(_loc2_.pos);
      }
      
      protected function getBubbleSpByNum(param1:FighterInfo, param2:int, param3:Number, param4:BufferDefine = null) : Sprite
      {
         var _loc5_:String = null;
         var _loc8_:RaceTypeDefine = null;
         var _loc9_:int = 0;
         var _loc6_:Boolean = false;
         if(param2 > 0)
         {
            _loc5_ = "Green";
         }
         else if(param3 <= this._battleConfig.weakEffRestraintCoeff)
         {
            _loc5_ = "Gray";
         }
         else if(param3 >= this._battleConfig.strongEffRestraintCoeff)
         {
            _loc5_ = "Red";
            if(param1 != null)
            {
               _loc8_ = this._battleConfig.getRaceTypeDefineById(BattleUtil.getOneRaceTypeByPriority(param1.raceTypeIds,this._battleConfig));
               if(STRONG_EFFECTS.hasOwnProperty(_loc8_.id.toString()))
               {
                  _loc5_ = STRONG_EFFECTS[_loc8_.id];
                  _loc6_ = true;
               }
            }
         }
         else
         {
            _loc5_ = "Yellow";
         }
         var _loc7_:Sprite = this.getArtNumBase(NUMBER_CLS_PREFIX + _loc5_,param2,-2);
         if(param4 != null && !StringUtil.isNullOrEmpty(param4.buffHarmSource))
         {
            _loc9_ = BufferConsts.BUFF_HARM_SOURCE.indexOf(param4.buffHarmSource);
            if(_loc9_ != -1)
            {
               _loc7_ = this.addHarmSource(_loc7_,_loc9_);
            }
         }
         return this.addArtNumBackground(_loc7_,_loc6_,_loc5_);
      }
      
      private function getArtNumBase(param1:String, param2:Number, param3:Number) : Sprite
      {
         if(this._artNumCacheMap.hasOwnProperty(param1))
         {
            return NumberUtil.instance.getArtNumByCacheData(this._artNumCacheMap[param1],param2,param3,false);
         }
         var _loc4_:Class = this._domain.getDefinition(param1) as Class;
         var _loc5_:Sprite = new _loc4_() as Sprite;
         return NumberUtil.instance.getArtNum(_loc5_,param2,param3,false,this._artNumCacheMap);
      }
      
      private function addHarmSource(param1:Sprite, param2:int) : Sprite
      {
         var _loc3_:String = BUFF_HARM_SOURCE_CLS + param2;
         var _loc4_:Class = this._domain.getDefinition(_loc3_) as Class;
         var _loc5_:Sprite = new _loc4_() as Sprite;
         return this.getSpriteGroup(param1,_loc5_);
      }
      
      private function getSpriteGroup(param1:Sprite, param2:Sprite) : Sprite
      {
         var _loc3_:Sprite = new Sprite();
         _loc3_.addChild(param2);
         var _loc4_:Rectangle = _loc3_.getRect(null);
         param1.x = _loc4_.right + param1.width / 2 + 2;
         param1.y = _loc3_.y;
         _loc3_.addChild(param1);
         _loc3_.x = -_loc3_.width / 2 - _loc4_.left;
         var _loc5_:Sprite = new Sprite();
         _loc5_.addChild(_loc3_);
         return _loc5_;
      }
      
      private function addArtNumBackground(param1:Sprite, param2:Boolean, param3:String) : Sprite
      {
         if(!param2)
         {
            return param1;
         }
         var _loc4_:String = NUMBER_BACKGROUND_CLS_PREFIX + param3;
         var _loc5_:Class = this._domain.getDefinition(_loc4_) as Class;
         var _loc6_:Sprite = new _loc5_() as Sprite;
         _loc6_.width = param1.width;
         _loc6_.y = 0;
         _loc6_.x = 40;
         var _loc7_:Sprite = new Sprite();
         _loc7_.addChild(_loc6_);
         _loc7_.addChild(param1);
         return _loc7_;
      }
      
      protected function initBloodBar() : void
      {
         var _loc1_:Class = this._domain.getDefinition(BLOOD_BAR_CLS) as Class;
         this._bloodBarRes = new _loc1_() as Sprite;
         this._bloodBar = this._bloodBarRes.getChildByName("blood") as MovieClip;
         this._bloodBar.gotoAndStop(1);
         this._shieldBar = this._bloodBarRes.getChildByName("shield") as MovieClip;
         this._shieldBar.gotoAndStop(1);
         var _loc2_:Point = this.getBloodBarPos();
         this._bloodBarRes.x = _loc2_.x;
         this._bloodBarRes.y = _loc2_.y;
         var _loc3_:MovieClip = this._bloodBarRes.getChildByName("jobmc") as MovieClip;
         var _loc4_:IPetDictionaryDataService = ServiceContainer.getService(IPetDictionaryDataService) as IPetDictionaryDataService;
         var _loc5_:PetDictionaryDataItem = _loc4_.getDataItemByRaceId(this._info.raceId);
         if(_loc5_ == null)
         {
            throw new Error("Cant find pet config where raceId = " + this._info.raceId);
         }
         if(_loc3_)
         {
            _loc3_.gotoAndStop(1);
            _loc3_.visible = false;
         }
         this._bloodLayer.addChild(this._bloodBarRes);
         this.updateAttr();
      }
      
      public function updateAttr() : void
      {
         var _loc1_:MovieClip = this._bloodBarRes.getChildByName("mcAttr") as MovieClip;
         var _loc2_:IInteractHelper = ServiceContainer.getService(IInteractHelper);
         _loc2_.addAttribute(_loc1_,BattleUtil.getOneRaceTypeByPriority(this._info.raceTypeIds,this._battleConfig));
      }
      
      protected function initPowerBar() : void
      {
         var _loc1_:Class = this._domain.getDefinition(POWER_BAR_CLS) as Class;
         var _loc2_:Sprite = new _loc1_() as Sprite;
         this._powerBar = _loc2_.getChildByName("power") as Sprite;
         this._txtPower = _loc2_.getChildByName("txtPower") as TextField;
         var _loc3_:Point = this.getPowerBarPos();
         _loc2_.x = _loc3_.x;
         _loc2_.y = _loc3_.y;
         this._powerResLayer.addChild(_loc2_);
         this._powerResLayer.visible = this._isShowPowerBarRes;
      }
      
      protected function getBloodBarPos() : Point
      {
         return new Point(0,this._bound.top);
      }
      
      protected function getPowerBarPos() : Point
      {
         return new Point(0,this._bound.top + 10);
      }
      
      protected function setupDeathWing() : void
      {
         if(this._deathWing != null && this._deathWing.stage != null)
         {
            return;
         }
         var _loc1_:Class = this._domain.getDefinition(DEATH_WING_CLS) as Class;
         var _loc2_:Point = this.getAvatarPos(AvatarPosTypes.TOP);
         this._deathWing = new _loc1_() as MovieClip;
         this._deathWing.x = _loc2_.x;
         this._deathWing.y = _loc2_.y;
         this._stateLayer.addChild(this._deathWing);
      }
      
      protected function removeDeathWing() : void
      {
         DisplayUtil.stopAndRemove(this._deathWing);
         this._deathWing = null;
      }
      
      protected function getBufferById(param1:int) : MovieClip
      {
         return this.getBufferByIdP(param1);
      }
      
      private function getBufferByIdP(param1:int) : MovieClip
      {
         var _loc2_:String = BUFF_CLS_PREFIX + param1;
         var _loc3_:Class = this._domain.getDefinition(_loc2_) as Class;
         return new _loc3_() as MovieClip;
      }
      
      protected function getEffectMCById(param1:int) : MovieClip
      {
         var _loc2_:String = EFFECT_CLS_PREFIX + param1;
         var _loc3_:Class = this._domain.getDefinition(_loc2_) as Class;
         return new _loc3_() as MovieClip;
      }
      
      protected function getSkillEffectMC(param1:int, param2:Boolean) : MovieClip
      {
         var _loc3_:String = null;
         var _loc5_:String = null;
         var _loc6_:String = null;
         var _loc7_:SkeletonMovieClip = null;
         if(param2)
         {
            _loc3_ = LAST_SKILL_EFFECT_CLS_PREFIX + param1;
         }
         else
         {
            _loc3_ = SKILL_EFFECT_CLS_PREFIX + param1;
         }
         var _loc4_:String = SKILL_EFFECT_CLS_PREFIX + "Default";
         if(this.isUseSimpleResBySkillId(param1))
         {
            _loc6_ = _loc5_ = this.getSimpleEffectClsName(param1,_loc4_);
            if(_loc5_.indexOf("r") != -1)
            {
               _loc6_ = _loc5_.replace("r","c");
            }
            else if(_loc5_.indexOf("c") != -1)
            {
               _loc6_ = _loc5_.replace("c","r");
            }
            return this.getMovieClipByClsName(_loc5_,_loc6_);
         }
         _loc7_ = SpineLoader.create(StringUtil.format(SPINE_EFFECT_FILE,param1));
         if(_loc7_)
         {
            return _loc7_;
         }
         return this.getMovieClipByClsName(_loc3_,_loc4_);
      }
      
      private function getSimpleEffectClsName(param1:int, param2:String) : String
      {
         var _loc6_:String = null;
         var _loc10_:int = 0;
         var _loc11_:RaceTypeDefine = null;
         var _loc3_:int = int(SkillDefine.getRaceIdBySkillId(param1));
         var _loc4_:IPetDictionaryDataService = forSvc(IPetDictionaryDataService);
         var _loc5_:PetDictionaryDataItem = _loc4_.getDataItemByRaceId(_loc3_);
         if(_loc5_ == null)
         {
            _loc6_ = "00";
         }
         else
         {
            _loc10_ = int(PetDictionaryDataItem.getMainAttribute([_loc5_.attribute1,_loc5_.attribute2]));
            _loc11_ = this._battleConfig.getRaceTypeDefineById(_loc10_);
            _loc6_ = (_loc11_.id % 100).toString();
            if(_loc11_.priority == RaceTypePriority.NORMAL || _loc6_.length < 2)
            {
               _loc6_ = "00";
            }
         }
         var _loc7_:SkillDefine = this._battleConfig.getSkillDefineById(param1);
         var _loc8_:String = _loc7_.type == SkillTypes.CLOSE ? "c" : "r";
         var _loc9_:Boolean = _loc7_.functionalType == "治疗";
         if((_loc9_) || _loc6_ == "00")
         {
            return SKILL_EFFECT_CLS_PREFIX + SkillDefine.getOrigSkillId(param1);
         }
         if(param1.toString().charAt(0) == "1")
         {
            return "mmo.effect.Effect100000" + _loc8_ + _loc6_;
         }
         if(param1.toString().charAt(0) == "2")
         {
            return "mmo.effect.Effect200000" + _loc8_ + _loc6_;
         }
         return param2;
      }
      
      private function getMovieClipByClsName(param1:String, param2:String) : MovieClip
      {
         var effectCls:Class = null;
         var effectMC:MovieClip = null;
         var defaultCls:Class = null;
         var defaultMC:MovieClip = null;
         var clsName:String = param1;
         var defaultClsName:String = param2;
         if(this._domain.hasDefinition(clsName))
         {
            effectCls = this._domain.getDefinition(clsName) as Class;
            effectMC = new effectCls() as MovieClip;
            return effectMC;
         }
         try
         {
            defaultCls = this._domain.getDefinition(defaultClsName) as Class;
            defaultMC = new defaultCls() as MovieClip;
            return defaultMC;
         }
         catch(e:Error)
         {
            throw new Error("Can not find " + clsName + " and " + defaultClsName + ", combo effects are in the same file.");
         }
      }
      
      protected function getSummonEffectMC(param1:int) : MovieClip
      {
         var _loc3_:Class = null;
         var _loc2_:String = SUMMON_EFFECT_CLS_PREFIX + param1;
         if(this._domain.hasDefinition(_loc2_))
         {
            _loc3_ = this._domain.getDefinition(_loc2_) as Class;
         }
         else
         {
            _loc3_ = this._domain.getDefinition(SUMMON_EFFECT_MOV_CLS_DEFAULT) as Class;
         }
         return new _loc3_() as MovieClip;
      }
      
      protected function setBloodLayerVisible(param1:Boolean) : void
      {
         this._bloodLayer.visible = param1;
      }
      
      protected function setPowerResLayerVisible(param1:Boolean) : void
      {
         this._powerResLayer.visible = param1;
      }
      
      protected function getFighterTips(param1:Sprite, param2:FighterInfo, param3:IBattleConfig) : FighterTipsPanel
      {
         return new FighterTipsPanel(param1,param2,param3);
      }
      
      public function hideBufferLayer() : void
      {
         this._bufferLayer.visible = false;
         this._bufferLayer2.visible = false;
      }
      
      public function showBufferLayer() : void
      {
         this._bufferLayer.visible = true;
         this._bufferLayer2.visible = true;
      }
      
      public function hideEffectLayer() : void
      {
         this._effectLayer.visible = false;
      }
      
      public function showEffectLayer() : void
      {
         this._effectLayer.visible = true;
      }
      
      public function getTargetAction_BackGround(param1:int) : MovieClip
      {
         var _loc2_:MovieClip = this.getMovieByActionId(TARGET_ACTION_CLS_BACKGROUND,param1);
         if(_loc2_ != null && this._needFlip)
         {
            this.handleMcNeedFlip(_loc2_);
         }
         return _loc2_;
      }
      
      public function getAction_FullScreen_BackGround(param1:int) : MovieClip
      {
         var _loc2_:MovieClip = SpineLoader.create(StringUtil.format(SPINE_BACKGROUND_FILE,this._info.faceId,param1));
         if(_loc2_)
         {
            this.handleFullScreenSpine(_loc2_ as SkeletonMovieClip);
         }
         else
         {
            _loc2_ = this.getMovieByActionId(ACTION_CLS_FULLSCREEN_BACKGROUND,param1);
            if(_loc2_ != null && this._needFlip)
            {
               this.handleMcNeedFlip(_loc2_);
            }
         }
         return _loc2_;
      }
      
      public function getAction_FullScreen_ForeGround(param1:int) : MovieClip
      {
         var _loc2_:MovieClip = SpineLoader.create(StringUtil.format(SPINE_FOREGROUND_FILE,this._info.faceId,param1));
         if(_loc2_)
         {
            this.handleFullScreenSpine(_loc2_ as SkeletonMovieClip);
         }
         else
         {
            _loc2_ = this.getMovieByActionId(ACTION_CLS_FULLSCREEN_FOREGROUND,param1);
            if(_loc2_ != null && this._needFlip)
            {
               this.handleMcNeedFlip(_loc2_);
            }
         }
         return _loc2_;
      }
      
      private function handleMcNeedFlip(param1:MovieClip) : void
      {
         var _loc4_:* = undefined;
         var _loc5_:DisplayObject = null;
         var _loc2_:Sprite = param1.getChildByName("scale") as Sprite;
         if(_loc2_ != null)
         {
            _loc2_.scaleX = -1;
            _loc2_.x = LoaderContainer.stageWidth - _loc2_.x;
            _loc4_ = 0;
            while(_loc4_ < _loc2_.numChildren)
            {
               _loc5_ = _loc2_.getChildAt(_loc4_);
               if(_loc5_.name == "noscale")
               {
                  _loc5_.scaleX = -1;
               }
               _loc4_++;
            }
         }
         var _loc3_:Sprite = param1.getChildByName("middle") as Sprite;
         if(_loc3_ != null)
         {
            _loc3_.x = LoaderContainer.stageWidth - _loc3_.x;
         }
      }
      
      private function handleFullScreenSpine(param1:SkeletonMovieClip) : void
      {
         if(this._needFlip && SkeletonMovieClip(param1).animationNum > 1)
         {
            param1.setAnimation("2");
         }
         var _loc2_:Number = LoaderContainer.stageHeight / LoaderContainer.designHeight;
         param1.scaleX = param1.scaleY = _loc2_;
         param1.x = (LoaderContainer.stageWidth - LoaderContainer.designWidth * _loc2_) / 2;
      }
      
      private function onBuffMcEnd(param1:int, param2:MovieClip, param3:Function = null) : Function
      {
         var bufferDefine:BufferDefine = null;
         var buffId:int = param1;
         var buffMC:MovieClip = param2;
         var buffWaitCallback:Function = param3;
         bufferDefine = this._battleConfig.getBufferDefineById(buffId);
         return function():void
         {
            var stopAndRemoveBuff:* = function():void
            {
               removeBuffSp(buffMC);
               buffMC.stop();
               removeBuff(buffId);
            };
            var applyBuffWaitCallback:* = function():void
            {
               if(bufferDefine.buffWaitType > 0)
               {
                  InteractUtil.applyCallback(buffWaitCallback);
               }
            };
            if(bufferDefine.buffWaitEndFrame <= 0)
            {
               stopAndRemoveBuff.apply();
               applyBuffWaitCallback.apply();
            }
            else if(buffMC.currentFrame == buffMC.totalFrames)
            {
               stopAndRemoveBuff.apply();
               applyBuffWaitCallback.apply();
            }
            else
            {
               buffMC.addFrameScript(bufferDefine.buffWaitEndFrame - 1,null);
               buffMC.addFrameScript(buffMC.totalFrames - 1,stopAndRemoveBuff);
               applyBuffWaitCallback.apply();
            }
         };
      }
      
      private function getMovieByActionId(param1:String, param2:int) : MovieClip
      {
         var _loc4_:Class = null;
         var _loc3_:String = param1 + this._info.faceId + "_" + param2;
         if(this._domain.hasDefinition(_loc3_))
         {
            _loc4_ = this._domain.getDefinition(_loc3_) as Class;
            return new _loc4_();
         }
         return null;
      }
      
      public function getBuffMcByBuffId(param1:int) : MovieClip
      {
         return this._mapBuffId2Buff.getValue(param1);
      }
   }
}

