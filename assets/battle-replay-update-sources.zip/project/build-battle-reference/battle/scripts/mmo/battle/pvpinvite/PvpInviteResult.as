package mmo.battle.pvpinvite
{
   import mmo.common.dialog.NewDialog;
   import mmo.loader.common.datastructures.HashMap;
   
   public class PvpInviteResult
   {
      
      public static const SUCCESS:int = 0;
      
      private static const USER_NAME_EVIL:int = -1;
      
      private static const CAN_NOT_PK_SELF:int = -2;
      
      private static const TARGET_IS_NOT_ONLINE:int = -3;
      
      private static const REQUEST_PK_ING:int = -4;
      
      private static const PK_BATTLE_ING:int = -5;
      
      private static const PK_CANCEL:int = -6;
      
      private static const REQUESTOR_NOT_EXIST:int = -7;
      
      private static const BATTLE_FAIL:int = -8;
      
      private static const REQUESTOR_IS_NOT_ONLINE:int = -9;
      
      private static const PK_STATE_NULL:int = 0;
      
      private static const PK_STATE_REQUEST:int = 1;
      
      private static const PK_STATE_BATTLE:int = 2;
      
      private static var CODE_2_MESSAGE:HashMap = new HashMap();
      
      CODE_2_MESSAGE.add(USER_NAME_EVIL,"你邀请的小奥奇不存在喔！");
      CODE_2_MESSAGE.add(CAN_NOT_PK_SELF,"不能邀请自己喔！");
      CODE_2_MESSAGE.add(TARGET_IS_NOT_ONLINE,"你邀请的小奥奇不在线喔！");
      CODE_2_MESSAGE.add(REQUEST_PK_ING,"你已经邀请过了喔！");
      CODE_2_MESSAGE.add(PK_BATTLE_ING,"你邀请的小奥奇正在战斗中，稍后再试试吧。");
      CODE_2_MESSAGE.add(PK_CANCEL,"对方放弃了向你挑战。");
      CODE_2_MESSAGE.add(REQUESTOR_NOT_EXIST,"你暂时还不适合战斗喔！");
      CODE_2_MESSAGE.add(REQUESTOR_IS_NOT_ONLINE,"你还没有登陆喔！");
      
      public function PvpInviteResult()
      {
         super();
      }
      
      public static function handleReturnCode(param1:int) : void
      {
         var _loc2_:String = CODE_2_MESSAGE.getValue(param1);
         if(_loc2_ != null)
         {
            NewDialog.showFailMessage(_loc2_);
         }
      }
   }
}

