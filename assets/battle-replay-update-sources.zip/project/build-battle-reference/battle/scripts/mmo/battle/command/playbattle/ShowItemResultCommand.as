package mmo.battle.command.playbattle
{
   import com.greensock.TweenLite;
   import flash.display.MovieClip;
   import flash.display.Sprite;
   import flash.geom.Point;
   import flash.system.ApplicationDomain;
   import mmo.battle.entity.BattleBase;
   import mmo.battle.util.BattleContentUtil;
   import mmo.common.DisplayUtil;
   import mmo.interfaces.battle.avatar.IBattleAvatar;
   import mmo.interfaces.battle.data.BufferItemResult;
   import mmo.interfaces.battle.data.BufferItemTargetResult;
   import mmo.interfaces.battle.data.CatchItemResult;
   import mmo.interfaces.battle.data.UseItemResult;
   import mmo.interfaces.battle.fighter.IBattleFighter;
   import mmo.interfaces.battle.player.IBattlePlayer;
   import mmo.interfaces.battleconfig.IBattleConfig;
   import mmo.interfaces.battleconfig.define.BufferDefine;
   import mmo.loader.LoaderContainer;
   import mmo.util.command.ISceneCommand;
   import mmo.util.command.SceneSimpleCommand;
   
   public class ShowItemResultCommand extends SceneSimpleCommand implements ISceneCommand
   {
      
      private static const CATCH_SUCC_TIPS_CLS:String = "mmo.battle.common.CatchSuccTips";
      
      private static const CATCH_FAIL_TIPS_CLS:String = "mmo.battle.common.CatchFailTips";
      
      private static const ITEM_CLS_PREFIX:String = "mmo.battle.Item";
      
      private static const CATCH_ITEM_DEFAULT_ID:int = 6000002;
      
      private static const CATCH_SUCC_POSTFIX:String = "_succ";
      
      private static const CATCH_FAIL_POSTFIX:String = "_fail";
      
      private static const ABSORB_MOVIE_FRAME:int = 28;
      
      private var _content:Object;
      
      private var _itemResult:UseItemResult;
      
      private var _battle:BattleBase;
      
      private var _domain:ApplicationDomain;
      
      private var _callbackSemphore:int = 0;
      
      private var _bufferSemphore:int = 0;
      
      private var _catchSuccFlag:Boolean = false;
      
      public function ShowItemResultCommand()
      {
         super();
      }
      
      override public function execute(param1:Object) : void
      {
         this._content = param1;
         this._itemResult = BattleContentUtil.getContentProperty(param1,BattleContentUtil.PN_ITEM_RESULT);
         this._battle = BattleContentUtil.getContentProperty(param1,BattleContentUtil.PN_BATTLE);
         this._domain = BattleContentUtil.getContentProperty(param1,BattleContentUtil.PN_DOMAIN);
         if(this._itemResult == null)
         {
            this.finish();
            return;
         }
         var _loc2_:Boolean = false;
         if(this._itemResult.bufferResults != null)
         {
            this.handleBufferResults();
            _loc2_ = true;
         }
         if(this._itemResult.damageResults != null)
         {
            this.handleDamageResults();
            _loc2_ = true;
         }
         if(this._itemResult.catchResults != null)
         {
            this.handleCatchResults();
            _loc2_ = true;
         }
         if(!_loc2_)
         {
            this.finish();
         }
      }
      
      private function handleBufferResults() : void
      {
         var _loc1_:BufferItemResult = null;
         var _loc2_:BufferItemTargetResult = null;
         var _loc3_:IBattlePlayer = null;
         var _loc4_:String = null;
         var _loc5_:Class = null;
         var _loc6_:MovieClip = null;
         var _loc7_:IBattleFighter = null;
         var _loc8_:IBattleAvatar = null;
         var _loc9_:int = 0;
         var _loc10_:IBattleConfig = null;
         var _loc11_:BufferDefine = null;
         var _loc12_:Point = null;
         for each(_loc1_ in this._itemResult.bufferResults)
         {
            for each(_loc2_ in _loc1_.itemTargetResults)
            {
               if(_loc2_.hit)
               {
                  _loc3_ = this._battle.getPlayerByName(_loc2_.playerName);
                  _loc4_ = ITEM_CLS_PREFIX + _loc1_.itemId;
                  _loc5_ = this._domain.getDefinition(_loc4_) as Class;
                  _loc6_ = new _loc5_() as MovieClip;
                  _loc7_ = _loc3_.getFighterById(_loc2_.characterId);
                  _loc8_ = _loc7_.avatar;
                  _loc9_ = int(_loc2_.buffIds[0]);
                  _loc7_.addBuff(_loc9_);
                  _loc7_.maxHp = _loc2_.maxHp;
                  _loc7_.curHp = _loc2_.curHp;
                  if(_loc7_.info.curHp <= 0)
                  {
                     _loc7_.fadeOut(null);
                  }
                  _loc8_.hideBufferLayer();
                  _loc10_ = BattleContentUtil.getContentProperty(this._content,BattleContentUtil.PN_BATTLE_CONFIG);
                  _loc11_ = _loc10_.getBufferDefineById(_loc9_);
                  _loc12_ = _loc8_.getAvatarPos(_loc11_.posId);
                  _loc6_.x = _loc12_.x;
                  _loc6_.y = _loc12_.y;
                  ++this._bufferSemphore;
                  _loc7_.showMovie(_loc6_,this.getMovieEndFunction(_loc8_));
               }
            }
            if(this._bufferSemphore == 0)
            {
               this.finish();
            }
         }
      }
      
      private function getMovieEndFunction(param1:IBattleAvatar) : Function
      {
         var battleAvatar:IBattleAvatar = param1;
         var fun:Function = function():void
         {
            battleAvatar.showBufferLayer();
            onBufferMovieEnd();
         };
         return fun;
      }
      
      private function onBufferMovieEnd() : void
      {
         --this._bufferSemphore;
         if(this._bufferSemphore == 0)
         {
            this.finish();
         }
      }
      
      private function handleDamageResults() : void
      {
      }
      
      private function handleCatchResults() : void
      {
         var _loc1_:CatchItemResult = null;
         var _loc2_:IBattlePlayer = null;
         var _loc3_:int = 0;
         var _loc4_:String = null;
         var _loc5_:Boolean = false;
         var _loc6_:Class = null;
         var _loc7_:MovieClip = null;
         var _loc8_:IBattleFighter = null;
         for each(_loc1_ in this._itemResult.catchResults)
         {
            _loc2_ = this._battle.getPlayerByName(_loc1_.targetPlayerName);
            for each(_loc3_ in _loc1_.targetFighters)
            {
               _loc4_ = ITEM_CLS_PREFIX + CATCH_ITEM_DEFAULT_ID;
               _loc5_ = false;
               if(_loc1_.hitFitghters.indexOf(_loc3_) != -1)
               {
                  this._catchSuccFlag = true;
                  _loc5_ = true;
                  _loc4_ += CATCH_SUCC_POSTFIX;
               }
               else
               {
                  _loc4_ += CATCH_FAIL_POSTFIX;
               }
               _loc6_ = this._domain.getDefinition(_loc4_) as Class;
               _loc7_ = new _loc6_() as MovieClip;
               _loc8_ = _loc2_.getFighterById(_loc3_);
               if(_loc5_)
               {
                  this.showCatchEffect(_loc7_,_loc2_,_loc8_);
               }
               ++this._callbackSemphore;
               _loc8_.showMovie(_loc7_,this.onMovieEnd);
            }
         }
      }
      
      private function showCatchEffect(param1:MovieClip, param2:IBattlePlayer, param3:IBattleFighter) : void
      {
         var movie:MovieClip = param1;
         var player:IBattlePlayer = param2;
         var fighter:IBattleFighter = param3;
         movie.addFrameScript(ABSORB_MOVIE_FRAME,function():void
         {
            fighter.avatar.fadeOut(function():*
            {
               player.removeFighter(fighter);
            });
         });
      }
      
      private function onMovieEnd() : void
      {
         --this._callbackSemphore;
         if(this._callbackSemphore == 0)
         {
            this.showCatchTips();
         }
      }
      
      private function showCatchTips() : void
      {
         var tipsCls:Class;
         var container:Sprite;
         var tips:Sprite = null;
         var tipsClsName:String = CATCH_FAIL_TIPS_CLS;
         if(this._catchSuccFlag)
         {
            tipsClsName = CATCH_SUCC_TIPS_CLS;
         }
         tipsCls = this._domain.getDefinition(tipsClsName) as Class;
         tips = new tipsCls() as Sprite;
         DisplayUtil.middleDisplay(tips,LoaderContainer.stageWidth,LoaderContainer.stageHeight);
         container = BattleContentUtil.getContentProperty(this._content,BattleContentUtil.PN_CONTAINER);
         container.addChild(tips);
         tips.alpha = 0.1;
         TweenLite.to(tips,3,{
            "alpha":1,
            "useFrames":true,
            "onComplete":function():void
            {
               TweenLite.to(tips,16,{
                  "useFrames":true,
                  "onComplete":function():void
                  {
                     TweenLite.to(tips,10,{
                        "alpha":0,
                        "useFrames":true,
                        "onComplete":function():void
                        {
                           DisplayUtil.stopAndRemove(tips);
                           finish();
                        }
                     });
                  }
               });
            }
         });
      }
      
      private function finish() : void
      {
         this.succeed(this._content);
         this._itemResult = null;
         this._content = null;
      }
   }
}

