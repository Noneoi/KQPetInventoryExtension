package mmo.battle.command
{
   import mmo.battle.command.attack.common.AfterSequentialAttackCommand;
   import mmo.battle.command.attack.common.BeforeSequentialAttackCommand;
   import mmo.battle.command.attack.common.ClearUniqueSkillEffectCommand;
   import mmo.battle.command.attack.common.PlayEffectCommand;
   import mmo.battle.command.attack.common.ShowSkillNameCommand;
   import mmo.battle.command.attack.common.UniqueSkillEffectCommand;
   import mmo.battle.command.attack.remote.PlayRemoteActionCommandSimpleRes;
   import mmo.battle.command.attack.remote.RecoverActionCommand;
   import mmo.interfaces.battle.command.IBattleCommand;
   
   public class RemoteAttackCommandSimpleRes extends BattleCommand implements IBattleCommand
   {
      
      public function RemoteAttackCommandSimpleRes()
      {
         super();
      }
      
      override protected function initializeMacroCommand() : void
      {
         addSubCommand(BeforeSequentialAttackCommand);
         addSubCommand(UniqueSkillEffectCommand);
         addSubCommand(ShowSkillNameCommand);
         addParallelSubCommand([PlayRemoteActionCommandSimpleRes,PlayEffectCommand]);
         addSubCommand(RecoverActionCommand);
         addSubCommand(ClearUniqueSkillEffectCommand);
         addSubCommand(AfterSequentialAttackCommand);
         super.initializeMacroCommand();
      }
   }
}

