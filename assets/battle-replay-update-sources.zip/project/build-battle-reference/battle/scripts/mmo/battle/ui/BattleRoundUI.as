package mmo.battle.ui
{
   import flash.display.Sprite;
   import mmo.battle.util.BattleContentUtil;
   import mmo.common.NumberUtil;
   import mmo.interfaces.battle.consts.UserBattleConfig;
   import mmo.interfaces.battle.data.RoundResult;
   
   public class BattleRoundUI
   {
      
      private var _resSprite:Sprite;
      
      private var _spQueues:Array;
      
      private var _mapsId2Race:Array;
      
      private var _numRound:int;
      
      private var _arrPlayerRounds:Array;
      
      private var _content:Object;
      
      public function BattleRoundUI(param1:Sprite, param2:Array, param3:Object)
      {
         super();
         this._resSprite = param1;
         this._mapsId2Race = param2;
         this._content = param3;
         this.init();
      }
      
      private function init() : void
      {
         this._numRound = 0;
         this._arrPlayerRounds = [0,0];
         this._artRound();
         this._artPlayerRound(0);
         this._artPlayerRound(1);
         this._spQueues = [];
         this._spQueues.push(new BattleTeamRoundQueue(this._resSprite["queue0"],this._mapsId2Race[0],this._content));
         this._spQueues.push(new BattleTeamRoundQueue(this._resSprite["queue1"],this._mapsId2Race[1],this._content));
      }
      
      public function show(param1:Sprite) : void
      {
         param1.addChild(this._resSprite);
      }
      
      public function get resSprite() : Sprite
      {
         return this._resSprite;
      }
      
      public function setVisible(param1:Boolean) : BattleRoundUI
      {
         this._resSprite.visible = param1;
         return this;
      }
      
      public function setXY(param1:Number, param2:Number) : BattleRoundUI
      {
         this._resSprite.x = param1;
         this._resSprite.y = param2;
         return this;
      }
      
      public function setByRoundResult(param1:RoundResult, param2:Boolean) : void
      {
         var _loc3_:int = 0;
         var _loc4_:Boolean = false;
         this.updateRound(param1.roundNum);
         if(param2)
         {
            _loc3_ = int(param1.sourceTeamId);
            _loc4_ = this.updatePlayerRound(_loc3_,param1.playerRoundNum);
            if(BattleContentUtil.getBuffShowValueByKey(UserBattleConfig.SHOW_ACTION_SEQUENCE))
            {
               this.updateQueue(param1,_loc4_);
            }
         }
      }
      
      private function updateRound(param1:int) : void
      {
         if(param1 == this._numRound)
         {
            return;
         }
         this._numRound = param1;
         this._artRound(true);
      }
      
      private function updatePlayerRound(param1:int, param2:int) : Boolean
      {
         if(param2 <= 0 || this._arrPlayerRounds[param1] == param2)
         {
            return false;
         }
         this._arrPlayerRounds[param1] = param2;
         this._artPlayerRound(param1,true);
         return true;
      }
      
      private function updateQueue(param1:RoundResult, param2:Boolean) : void
      {
         var _loc3_:int = int(param1.sourceTeamId);
         var _loc4_:int = 1 - _loc3_;
         this.getQueue(_loc3_).setByQueue(param1.queue.getArr(_loc3_),param1.roundNum,param2,param1.sourceCharacterId,param1.isFromNormalQueue);
         this.getQueue(_loc4_).setByQueue(param1.queue.getArr(_loc4_),param1.roundNum,param2,-1);
      }
      
      private function _artRound(param1:Boolean = false) : void
      {
         NumberUtil.instance.setArtNum(this._resSprite["spRoundNum"],this._numRound,true,true);
      }
      
      private function _artPlayerRound(param1:int, param2:Boolean = false) : void
      {
         NumberUtil.instance.setArtNum(this._resSprite["spPlayerRoundNum" + param1],this._arrPlayerRounds[param1],true,true);
      }
      
      private function getQueue(param1:int) : BattleTeamRoundQueue
      {
         return this._spQueues[param1];
      }
   }
}

