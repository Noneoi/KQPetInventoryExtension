package mmo.battle.pvpinvite
{
   import flash.display.InteractiveObject;
   import flash.display.MovieClip;
   import flash.system.ApplicationDomain;
   import flash.utils.getDefinitionByName;
   import mmo.common.ModalDialog;
   import mmo.common.ModalDialogEvent;
   import mmo.common.ProgressFullSprite;
   import mmo.common.dialog.NewDialog;
   import mmo.interfaces.ServiceContainer;
   import mmo.interfaces.ServiceNames;
   import mmo.interfaces.battle.service.IBattleService;
   import mmo.interfaces.icon.IIconService;
   import mmo.interfaces.interacthelper.IInteractHelper;
   import mmo.loader.scheduler.ResScheduler;
   
   public class PvpInviteIcon
   {
      
      private static const ICON_SERVICE_KEY:String = "PvpInviteIcon";
      
      private static const ICON_SERVICE_PRIORITY:int = 300;
      
      private static const RES_FILE:String = "battle/invite_res";
      
      private static const RES_CLS:String = "mmo.battle.common.PvpInviteIconRes";
      
      private var _battleService:IBattleService;
      
      private var _iconService:IIconService;
      
      private var _senderDid:String;
      
      private var _senderNickname:String;
      
      private var _didQuene:Array = [];
      
      private var _nicknameQuene:Array = [];
      
      private var _res:MovieClip;
      
      public function PvpInviteIcon()
      {
         super();
         this.initService();
      }
      
      public function pushData(param1:String, param2:String) : *
      {
         this._didQuene.push(param1);
         this._nicknameQuene.push(param2);
      }
      
      public function show() : void
      {
         if(this._didQuene.length == 0)
         {
            return;
         }
         var _loc1_:InteractiveObject = this._iconService.getIconByKey(ICON_SERVICE_KEY);
         if(_loc1_ == null)
         {
            this.tryDownloadResource();
         }
      }
      
      private function initService() : void
      {
         this._battleService = ServiceContainer.getService(IBattleService) as IBattleService;
         this._iconService = ServiceContainer.getService(ServiceNames.ICONSERVICE_RIGHTTOP) as IIconService;
      }
      
      private function tryDownloadResource() : void
      {
         var _loc1_:Class = null;
         var _loc2_:MovieClip = null;
         if(ApplicationDomain.currentDomain.hasDefinition(RES_CLS))
         {
            _loc1_ = getDefinitionByName(RES_CLS) as Class;
            _loc2_ = new _loc1_() as MovieClip;
            this.initComponent(_loc2_);
            this.initListener();
            this.addToStage();
         }
         else
         {
            ProgressFullSprite.show();
            ResScheduler.getResource(RES_FILE,this.onGetResource,RES_CLS);
         }
      }
      
      private function onGetResource(param1:MovieClip) : void
      {
         ProgressFullSprite.close();
         this.initComponent(param1);
         this.initListener();
         this.addToStage();
      }
      
      private function initComponent(param1:MovieClip) : void
      {
         this._res = param1;
         this._res.buttonMode = true;
      }
      
      private function initListener() : void
      {
      }
      
      private function addToStage() : void
      {
         var _loc1_:IInteractHelper = ServiceContainer.getService(IInteractHelper) as IInteractHelper;
         _loc1_.addHUDIcon(ServiceNames.ICONSERVICE_RIGHTTOP,ICON_SERVICE_KEY,this._res,ICON_SERVICE_PRIORITY,"战斗邀请",6,this.onIconClick);
      }
      
      private function onIconClick() : void
      {
         this._senderDid = this._didQuene.shift();
         this._senderNickname = this._nicknameQuene.shift();
         this.showConfirmPanel();
         if(this._didQuene.length == 0)
         {
            this._iconService.remove(ICON_SERVICE_KEY);
         }
      }
      
      private function showConfirmPanel() : void
      {
         var message:String = this._senderNickname + "向你发出了挑战，你要接受吗？";
         NewDialog.getCofirmDialog(message,function(param1:ModalDialog):void
         {
            param1.addEventListener(ModalDialogEvent.OK,onConfirm);
            param1.addEventListener(ModalDialogEvent.CANCEL,onRefuse);
            param1.addEventListener(ModalDialogEvent.CLOSE,onRefuse);
            param1.show();
         });
      }
      
      private function onConfirm(param1:ModalDialogEvent) : void
      {
         var _loc2_:ModalDialog = param1.currentTarget as ModalDialog;
         _loc2_.removeEventListener(ModalDialogEvent.OK,this.onConfirm);
         _loc2_.removeEventListener(ModalDialogEvent.CANCEL,this.onRefuse);
         _loc2_.removeEventListener(ModalDialogEvent.CLOSE,this.onRefuse);
         this._battleService.acceptPvpInvite(this._senderDid);
      }
      
      private function onRefuse(param1:ModalDialogEvent) : void
      {
         var _loc2_:ModalDialog = param1.currentTarget as ModalDialog;
         _loc2_.removeEventListener(ModalDialogEvent.OK,this.onConfirm);
         _loc2_.removeEventListener(ModalDialogEvent.CANCEL,this.onRefuse);
         _loc2_.removeEventListener(ModalDialogEvent.CLOSE,this.onRefuse);
         this._battleService.refusePvpInvite(this._senderDid);
      }
   }
}

