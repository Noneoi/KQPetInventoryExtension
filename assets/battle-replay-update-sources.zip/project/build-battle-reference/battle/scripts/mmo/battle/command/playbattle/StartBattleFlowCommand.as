package mmo.battle.command.playbattle
{
   import flash.display.Sprite;
   import flash.events.EventDispatcher;
   import flash.events.TimerEvent;
   import flash.system.ApplicationDomain;
   import flash.utils.Timer;
   import mmo.battle.entity.BattleBase;
   import mmo.battle.entity.BattleFlowManager;
   import mmo.battle.util.BattleContentUtil;
   import mmo.common.DateUtil;
   import mmo.common.DisplayUtil;
   import mmo.common.event.EnterFrameManager;
   import mmo.common.user.UserInfo;
   import mmo.config.ConfigReader;
   import mmo.interfaces.ServiceContainer;
   import mmo.interfaces.avatar.IAvatarService;
   import mmo.interfaces.battle.data.BarrageResult;
   import mmo.interfaces.battle.data.BattleFlow;
   import mmo.interfaces.battle.data.PlayerInfo;
   import mmo.interfaces.battle.data.UseItemResult;
   import mmo.interfaces.battle.events.BattleEvent;
   import mmo.interfaces.material.battlebarrage.BattleBarrage;
   import mmo.interfaces.material.battlebarrage.BattleBarrageIconType;
   import mmo.interfaces.material.battlebarrage.IBattleBarrageService;
   import mmo.interfaces.vip.IVipService;
   import mmo.loader.LoaderContainer;
   import mmo.play.log.Log;
   import mmo.util.command.ISceneCommand;
   import mmo.util.command.SceneSimpleCommand;
   
   public class StartBattleFlowCommand extends SceneSimpleCommand implements ISceneCommand
   {
      
      private static const DELAY_TIME_AFTER_FLOW:int = 1000;
      
      private static const BARRAGE_SPEED:Number = 8;
      
      private static const BARRAGE_STOP_FRAME:int = 25 * 3;
      
      private static const BARRAGE_Y:Number = 50;
      
      private static const LEFT_BARRAGE_START_X:Number = -370;
      
      private static const RIGHT_BARRAGE_START_X:Number = 960;
      
      private static const LEFT_BARRAGE_END_X:Number = 55;
      
      private static const RIGHT_BARRAGE_END_X:Number = 530;
      
      private var _content:Object;
      
      private var _flowManager:BattleFlowManager;
      
      private var _ed:EventDispatcher;
      
      private var _orgFrameRate:int;
      
      private var _battle:BattleBase;
      
      private var _barrageContainer:Sprite;
      
      private var _barrageSvc:IBattleBarrageService = ServiceContainer.getService(IBattleBarrageService);
      
      private var _avatarService:IAvatarService = ServiceContainer.getService(IAvatarService);
      
      private var _domain:ApplicationDomain;
      
      private var _leftBarrage:Sprite;
      
      private var _rightBarrage:Sprite;
      
      private var _hadStartFlow:Boolean;
      
      private var _barrageStopFrameCnt:int;
      
      private var _isBarrageStop:Boolean;
      
      private var _frameCounterEnabled:Boolean = false;
      
      private var _frameCounter:uint = 0;
      
      private var _frameCounterBeganTimestamp:Number;
      
      public function StartBattleFlowCommand()
      {
         super();
      }
      
      override public function execute(param1:Object) : void
      {
         this._content = param1;
         this._hadStartFlow = false;
         var _loc2_:BattleFlow = BattleContentUtil.getContentProperty(this._content,BattleContentUtil.PN_BATTLE_FLOW);
         this._flowManager = new BattleFlowManager(_loc2_,this._content,this.onBattleFlowEnd);
         this._battle = BattleContentUtil.getContentProperty(this._content,BattleContentUtil.PN_BATTLE);
         this._ed = BattleContentUtil.getContentProperty(param1,BattleContentUtil.PN_EVENT_DISPATCHER);
         this._ed.addEventListener(BattleEvent.SKIP_BATTLE_FLOW,this.onSkipBattleFlow);
         this._orgFrameRate = LoaderContainer.instance.stage.frameRate;
         if(BattleContentUtil.getIsInVipBattleFrame())
         {
            LoaderContainer.instance.stage.frameRate = ConfigReader.instance.vipBattleFrameRate;
         }
         else
         {
            LoaderContainer.instance.stage.frameRate = ConfigReader.instance.battleFrameRate;
         }
         if(this._frameCounterEnabled)
         {
            this._frameCounterBeganTimestamp = DateUtil.getServerTimeInMS();
            Log.d("battle","FPS mark beginning.");
            EnterFrameManager.instance.registerFun(this.enterFrameHandlerDebug,null,1);
         }
         this.playBarrage();
      }
      
      private function startFlow() : void
      {
         this._hadStartFlow = true;
         if(this._ed.hasEventListener(BattleEvent.ON_BATTLE_PLAY))
         {
            this._ed.dispatchEvent(new BattleEvent(BattleEvent.ON_BATTLE_PLAY,{}));
         }
         this._flowManager.startBattleFlow();
      }
      
      private function get isVip() : Boolean
      {
         var _loc1_:IVipService = ServiceContainer.getService(IVipService);
         return _loc1_.isVip();
      }
      
      private function onBattleFlowEnd(param1:int) : void
      {
         if(this._frameCounterEnabled)
         {
            Log.d("battle","FPS: " + this._frameCounter / ((DateUtil.getServerTimeInMS() - this._frameCounterBeganTimestamp) / 1000));
            EnterFrameManager.instance.removeFun(this.enterFrameHandlerDebug);
         }
         this.stopBarrage();
         if(param1 == BattleFlowManager.REACH_THE_END)
         {
            this.delaySomeTime();
         }
         else if(param1 == BattleFlowManager.SKIP_TO_THE_END)
         {
            this.preFinish();
         }
         else
         {
            BattleContentUtil.setContentProperty(this._content,BattleContentUtil.PN_ERROR_MSG,"战斗流程执行错误，请重试。");
            this.fail(this._content);
            this._content = null;
            this._flowManager.dispose();
            this._flowManager = null;
         }
      }
      
      private function delaySomeTime() : void
      {
         var _loc1_:Timer = new Timer(DELAY_TIME_AFTER_FLOW,1);
         _loc1_.addEventListener(TimerEvent.TIMER_COMPLETE,this.onTimer);
         _loc1_.start();
      }
      
      private function onTimer(param1:TimerEvent) : void
      {
         var _loc2_:Timer = param1.currentTarget as Timer;
         _loc2_.removeEventListener(TimerEvent.TIMER_COMPLETE,this.onTimer);
         this.preFinish();
      }
      
      private function onSkipBattleFlow(param1:BattleEvent) : void
      {
         this.onBattleFlowEnd(BattleFlowManager.SKIP_TO_THE_END);
      }
      
      private function preFinish() : void
      {
         if(this._ed.hasEventListener(BattleEvent.ON_BATTLE_END))
         {
            this._ed.dispatchEvent(new BattleEvent(BattleEvent.ON_BATTLE_END,{"callback":this.finish}));
         }
         else
         {
            this.finish();
         }
      }
      
      private function finish() : void
      {
         this._ed.removeEventListener(BattleEvent.SKIP_BATTLE_FLOW,this.onSkipBattleFlow);
         this._flowManager.dispose();
         LoaderContainer.instance.stage.frameRate = this._orgFrameRate;
         this.succeed(this._content);
         this._content = null;
      }
      
      private function playBarrage() : void
      {
         var _loc3_:Array = null;
         var _loc4_:BattleBarrage = null;
         var _loc5_:int = 0;
         var _loc6_:BattleBarrage = null;
         var _loc7_:BarrageResult = null;
         var _loc8_:PlayerInfo = null;
         var _loc9_:Boolean = false;
         var _loc10_:Array = null;
         var _loc11_:Sprite = null;
         var _loc12_:Sprite = null;
         var _loc13_:Sprite = null;
         var _loc1_:Boolean = false;
         this._barrageContainer = new Sprite();
         this._domain = BattleContentUtil.getContentProperty(this._content,BattleContentUtil.PN_DOMAIN);
         var _loc2_:UseItemResult = BattleContentUtil.getContentProperty(this._content,BattleContentUtil.PN_ITEM_RESULT);
         if(_loc2_ != null)
         {
            _loc3_ = _loc2_.barrageResults;
            _loc5_ = -1;
            _loc6_ = null;
            for each(_loc7_ in _loc3_)
            {
               _loc8_ = this._battle.battleResult.battleInfo.getTeamInfoById(_loc7_.teamId).playerInfos[0];
               if(_loc8_.playerType == PlayerInfo.PLAYER_TYPE_USER)
               {
                  if(!(_loc8_.playerName == UserInfo.nickName && !this._barrageSvc.isWatchMe))
                  {
                     _loc9_ = _loc7_.teamId == 0;
                     _loc10_ = this._barrageSvc.transformToClientId(_loc7_.serverId);
                     _loc11_ = this._barrageSvc.getBarrageRes(BattleBarrageIconType.BATTLE,_loc10_[0],_loc10_[1],0,0,this._domain,_loc9_);
                     _loc12_ = this.setBarrage(_loc11_,_loc8_,_loc9_);
                     this._barrageContainer.addChild(_loc12_);
                     if(_loc9_)
                     {
                        _loc12_.x = LEFT_BARRAGE_START_X;
                        this._leftBarrage = _loc12_;
                     }
                     else
                     {
                        _loc12_.x = RIGHT_BARRAGE_START_X;
                        this._rightBarrage = _loc12_;
                     }
                     _loc12_.y = BARRAGE_Y;
                     _loc1_ = true;
                     _loc4_ = this._barrageSvc.getBarrage(_loc10_[0]);
                     if(Boolean(_loc4_.hasCV) && Boolean(this._barrageSvc.isOpenCV))
                     {
                        if(_loc6_ == null || _loc8_.playerName == UserInfo.nickName)
                        {
                           _loc6_ = _loc4_;
                           _loc5_ = int(_loc10_[1]);
                        }
                     }
                  }
               }
            }
            if(_loc6_ != null)
            {
               this._barrageSvc.playCV(_loc6_,_loc5_,this._domain);
            }
         }
         if(_loc1_)
         {
            this._barrageStopFrameCnt = 0;
            this._isBarrageStop = false;
            _loc13_ = BattleContentUtil.getContentProperty(this._content,BattleContentUtil.PN_CONTAINER);
            _loc13_.addChild(this._barrageContainer);
            EnterFrameManager.instance.registerFun(this.enterFramehandler,null,1);
         }
         this.startFlow();
      }
      
      private function enterFramehandler() : void
      {
         var _loc3_:Number = NaN;
         var _loc1_:Boolean = false;
         var _loc2_:Boolean = false;
         if(!this._isBarrageStop)
         {
            _loc3_ = this._barrageSvc.playSpeed * BARRAGE_SPEED;
            if(this._leftBarrage != null)
            {
               this._leftBarrage.x += _loc3_;
               if(this._leftBarrage.x >= LEFT_BARRAGE_END_X)
               {
                  this._leftBarrage.x = LEFT_BARRAGE_END_X;
                  _loc1_ = true;
                  _loc2_ = true;
               }
            }
            if(this._rightBarrage != null)
            {
               this._rightBarrage.x -= _loc3_;
               if(this._rightBarrage.x <= RIGHT_BARRAGE_END_X)
               {
                  this._rightBarrage.x = RIGHT_BARRAGE_END_X;
                  _loc1_ = true;
               }
               else
               {
                  _loc2_ = false;
               }
            }
         }
         if(_loc2_ && !this._isBarrageStop)
         {
            this._isBarrageStop = true;
         }
         if(_loc1_ && !this._hadStartFlow)
         {
         }
         if(this._isBarrageStop)
         {
            ++this._barrageStopFrameCnt;
         }
         if(this._barrageStopFrameCnt >= BARRAGE_STOP_FRAME)
         {
            this.stopBarrage();
         }
      }
      
      private function enterFrameHandlerDebug() : void
      {
         ++this._frameCounter;
      }
      
      private function stopBarrage() : void
      {
         EnterFrameManager.instance.removeFun(this.enterFramehandler);
         DisplayUtil.stopAndRemove(this._barrageContainer);
      }
      
      private function setBarrage(param1:Sprite, param2:PlayerInfo, param3:Boolean) : Sprite
      {
         var _loc4_:Sprite = new Sprite();
         _loc4_.addChild(param1);
         param1.x = 0;
         param1.y = 0;
         var _loc5_:Sprite = param1.getChildByName("view") as Sprite;
         var _loc6_:Sprite = _loc5_.getChildByName("spHeadIcon") as Sprite;
         var _loc7_:Sprite = this._avatarService.getHeadIcon(null,param2.playerName,50,true,!param3,true,true);
         _loc6_.addChild(_loc7_);
         return _loc4_;
      }
   }
}

