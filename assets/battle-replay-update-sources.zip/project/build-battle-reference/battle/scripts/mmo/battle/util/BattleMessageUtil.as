package mmo.battle.util
{
   import mmo.battle.ui.BattleUI;
   import mmo.interfaces.battle.data.SkillResult;
   import mmo.interfaces.battleconfig.consts.SkillTypes;
   import mmo.interfaces.battleconfig.define.BufferDefine;
   import mmo.interfaces.battleconfig.define.SkillDefine;
   
   public class BattleMessageUtil
   {
      
      public function BattleMessageUtil()
      {
         super();
      }
      
      public static function shwoPowerFullMessage(param1:BattleUI, param2:Boolean, param3:String) : void
      {
         if(param1 == null || param1.messageUI == null)
         {
            return;
         }
         param1.messageUI.println(getNameMessgae(param2,param3) + getColorMessage("气势满了","#FFCC00"));
      }
      
      public static function showBuffMessage(param1:BufferDefine, param2:BattleUI, param3:Boolean, param4:String) : void
      {
         if(Boolean(param1.hidden) || param2 == null || param2.messageUI == null)
         {
            return;
         }
         var _loc5_:String = param1.uiMessage;
         if(_loc5_ == null || _loc5_.length <= 0)
         {
            return;
         }
         while(_loc5_.indexOf("#pet#") != -1)
         {
            _loc5_ = _loc5_.replace("#pet#",getNameMessgae(param3,param4));
         }
         param2.messageUI.println(_loc5_);
      }
      
      public static function showAttackMessage(param1:SkillDefine, param2:BattleUI, param3:Boolean, param4:String) : void
      {
         if(param2 == null || param2.messageUI == null)
         {
            return;
         }
         var _loc5_:String = SkillTypes.ID2CN[param1.type2];
         param2.messageUI.println(getNameMessgae(param3,param4) + getColorMessage("使用了" + _loc5_,"#FFFFFF") + getColorMessage(param1.name,"#FF6600"));
      }
      
      public static function showSkillMissCriticalBlogMessage(param1:String, param2:SkillResult, param3:BattleUI) : void
      {
         var _loc5_:String = null;
         if(param3 == null || param3.messageUI == null)
         {
            return;
         }
         var _loc4_:String = getColorMessage("[" + param1 + "]",param2.targetTeamId == 1 ? "#CC0000" : "#0098FF");
         if(param2.miss)
         {
            _loc5_ = getColorMessage("闪避","#99CC00");
         }
         else if(param2.block)
         {
            _loc5_ = getColorMessage("格挡","#00FFFF");
         }
         if(_loc5_ != null)
         {
            param3.messageUI.println(_loc4_ + _loc5_);
         }
         if(param2.critical)
         {
            _loc5_ = getColorMessage("被暴击","#FF3300");
            param3.messageUI.println(_loc4_ + _loc5_);
         }
      }
      
      private static function getNameMessgae(param1:Boolean, param2:String) : String
      {
         var _loc3_:String = param1 ? "#CC0000" : "#0098FF";
         return getColorMessage("[" + param2 + "]",_loc3_);
      }
      
      private static function getColorMessage(param1:String, param2:String) : String
      {
         return "<font color=\'" + param2 + "\'>" + param1 + "</font>";
      }
   }
}

