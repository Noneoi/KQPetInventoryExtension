package mmo.battle.command.attack.common
{
   import mmo.battle.entity.BattleBase;
   import mmo.battle.util.BattleContentUtil;
   import mmo.battle.util.BattleNumUnitUtil;
   import mmo.interfaces.battle.data.RepresentRoundResult;
   import mmo.interfaces.battle.data.RoundResult;
   import mmo.interfaces.battle.data.SkillNumUnit;
   import mmo.interfaces.battle.data.SkillResult;
   import mmo.interfaces.battle.fighter.IBattleFighter;
   import mmo.interfaces.battle.player.IBattlePlayer;
   import mmo.util.command.ISceneCommand;
   import mmo.util.command.SceneSimpleCommand;
   
   public class BeforeAttackResultObjectCommand extends SceneSimpleCommand implements ISceneCommand
   {
      
      private var _content:Object;
      
      private var _result:RoundResult;
      
      private var _battle:BattleBase;
      
      private var _numUnitUtil:BattleNumUnitUtil;
      
      public function BeforeAttackResultObjectCommand()
      {
         super();
      }
      
      override public function execute(param1:Object) : void
      {
         this._content = param1;
         this._battle = BattleContentUtil.getContentProperty(param1,BattleContentUtil.PN_BATTLE);
         this._result = BattleContentUtil.getContentProperty(this._content,BattleContentUtil.PN_ROUND_RESULT);
         this.handleSkillNumUnit();
      }
      
      private function handleSkillNumUnit() : void
      {
         var _loc1_:SkillNumUnit = null;
         var _loc2_:SkillResult = null;
         var _loc3_:SkillResult = null;
         var _loc4_:IBattlePlayer = null;
         var _loc5_:IBattleFighter = null;
         this._numUnitUtil = new BattleNumUnitUtil(this._content);
         for each(_loc1_ in this._result.sourceSkillNumResult.beforeNumUnit)
         {
            _loc4_ = this._battle.getPlayerByName(this._result.sourcePlayerName);
            _loc5_ = _loc4_.getFighterById(this._result.sourceCharacterId);
            this._numUnitUtil.addFighterUnitPair(_loc4_,_loc5_,_loc1_);
         }
         for each(_loc2_ in this._result.targetSkillResults)
         {
            for each(_loc1_ in _loc2_.numResult.beforeNumUnit)
            {
               _loc4_ = this._battle.getPlayerByName(_loc2_.targetPlayerName);
               _loc5_ = _loc4_.getFighterById(_loc2_.targetCharacterId);
               this._numUnitUtil.addFighterUnitPair(_loc4_,_loc5_,_loc1_);
            }
         }
         for each(_loc3_ in this._result.targetRepresenterResults)
         {
            for each(_loc1_ in _loc3_.numResult.beforeNumUnit)
            {
               _loc4_ = this._battle.getPlayerByName(_loc3_.targetPlayerName);
               _loc5_ = _loc4_.getFighterById(RepresentRoundResult.REPRESENTER_SOURCE_CHARACTER_ID);
               this._numUnitUtil.addFighterUnitPair(_loc4_,_loc5_,_loc1_);
            }
         }
         this._numUnitUtil.handleNumUnitList(this.onFinish);
      }
      
      private function onFinish() : void
      {
         this.succeed(this._content);
         this._content = null;
      }
   }
}

