package mmo.battle.ui
{
   import com.greensock.TweenLite;
   import flash.display.MovieClip;
   import flash.display.Sprite;
   import mmo.loader.common.datastructures.HashMap;
   
   public class BattleTeamRoundQueue
   {
      
      private static const MAX_GAP:Number = 25;
      
      private static const SPOT_SIZE:Number = 0.8;
      
      private static const STAND_SIZE:Number = 0.6;
      
      private static const SHOWING_OFFSET:Number = 10;
      
      private static const SHOWING_T:Number = 1;
      
      private static const SIDE_DOWN:int = 0;
      
      private static const SIDE_UP:int = 1;
      
      private static const SIDE_OUT:int = 2;
      
      private static const SIDE_IN:int = 3;
      
      private var _res:Sprite;
      
      private var _iconContainerDown:Sprite;
      
      private var _iconContainerUp:Sprite;
      
      private var _mapId2Race:HashMap;
      
      private var _mcHead:MovieClip;
      
      private var _mcTail:MovieClip;
      
      private var _mcCurrent:MovieClip;
      
      private var _nRound:int;
      
      private var _arrQueue:Array;
      
      private var _unitsStand:Array;
      
      private var _unitsSpot:Array;
      
      private var _pool:UnitResPool;
      
      private var _content:Object;
      
      public function BattleTeamRoundQueue(param1:Sprite, param2:HashMap, param3:Object)
      {
         super();
         this._res = param1;
         this._mapId2Race = param2;
         this._content = param3;
         this.init();
      }
      
      private function init() : void
      {
         this._iconContainerDown = this._res["containerDown"];
         this._iconContainerUp = this._res["containerUp"];
         this._mcHead = this._res["posHead"];
         this._mcHead.visible = false;
         this._mcTail = this._res["posTail"];
         this._mcTail.visible = false;
         this._mcCurrent = this._res["posCurrent"];
         this._mcCurrent.visible = false;
         this._pool = new UnitResPool(this._mcCurrent.constructor,this._content);
         this._nRound = 0;
         this._arrQueue = [];
         this._unitsStand = [];
         this._unitsSpot = [];
      }
      
      public function setByQueue(param1:Array, param2:int, param3:Boolean, param4:int, param5:Boolean = true) : void
      {
         var qLength:int;
         var newShowing:Array;
         var i:int = 0;
         var lastCopy:Array = null;
         var spotPicked:Boolean = false;
         var nextDifferent:int = 0;
         var hasMatched:Boolean = false;
         var petId:int = 0;
         var j:int = 0;
         var uBefore:UnitInQueue = null;
         var uNew:UnitInQueue = null;
         var queue:Array = param1;
         var round:int = param2;
         var playerRoundAdded:Boolean = param3;
         var current:int = param4;
         var fromNormalQueue:Boolean = param5;
         var roundChanged:Boolean = round != this._nRound;
         this._nRound = round;
         if(this.identical(queue,this._arrQueue))
         {
            this.setSpotting(playerRoundAdded,current,false);
            return;
         }
         qLength = int(queue.length);
         this._qPrepare();
         newShowing = [];
         lastCopy = this._arrQueue.concat();
         this._unitsStand.forEach(function(param1:UnitInQueue, param2:int, ... rest):void
         {
            var _loc4_:int = 0;
            if(param1.settled)
            {
               return;
            }
            if(dismissCount(param1.id,lastCopy,queue,current) > 0)
            {
               _loc4_ = lastCopy.indexOf(param1.id);
               if(_loc4_ != -1)
               {
                  lastCopy.splice(_loc4_,1);
                  param1.updatePlace(-1);
                  _uFadeOutAndRemove(param1,SIDE_UP);
               }
            }
         });
         spotPicked = false;
         nextDifferent = 0;
         i = 0;
         while(i < queue.length)
         {
            if(queue[i] != current)
            {
               nextDifferent = i;
            }
            i++;
         }
         this._unitsStand.forEach(function(param1:UnitInQueue, param2:int, param3:Array):void
         {
            var _loc4_:Boolean = false;
            var _loc5_:int = 0;
            var _loc6_:int = 0;
            var _loc7_:UnitInQueue = null;
            if(param1.settled || spotPicked)
            {
               return;
            }
            if(param1.id == current)
            {
               if(nextDifferent > 0)
               {
                  _loc4_ = true;
                  _loc5_ = param2 + 1;
                  _loc6_ = param2 + 1 + nextDifferent;
                  if(_loc6_ < param3.length)
                  {
                     i = _loc5_;
                     while(i <= _loc6_)
                     {
                        _loc7_ = param3[i];
                        _loc4_ &&= _loc7_.id == param1.id;
                        ++i;
                     }
                     if(_loc4_)
                     {
                        return;
                     }
                  }
               }
               spotPicked = true;
               param1.updatePlace(-1);
               _uFadeOutAndRemove(param1,SIDE_DOWN);
            }
         });
         i = 0;
         while(i < queue.length)
         {
            hasMatched = false;
            petId = int(queue[i]);
            j = 0;
            while(j < this._unitsStand.length)
            {
               uBefore = this._unitsStand[j];
               if(!uBefore.settled && uBefore.id == petId)
               {
                  uBefore.updatePlace(i);
                  newShowing.push(uBefore);
                  hasMatched = true;
                  this._tweenPos(uBefore.res,this.standX(i,qLength),this.standY(i,qLength));
                  break;
               }
               j++;
            }
            if(!hasMatched)
            {
               uNew = this.newUnit(queue[i],i);
               this.addUnit(this._iconContainerDown,uNew,this.standX(i,queue.length),this.standY(i,queue.length),STAND_SIZE,SIDE_UP);
               newShowing.push(uNew);
            }
            i++;
         }
         this._unitsStand.forEach(function(param1:UnitInQueue, ... rest):void
         {
            if(!param1.settled)
            {
               _uFadeOutAndRemove(param1,SIDE_UP);
            }
         });
         this.setSpotting(playerRoundAdded,current,fromNormalQueue);
         this._unitsStand = newShowing;
         this._qReLayer();
         this._arrQueue = queue.concat();
      }
      
      private function qCountX(param1:Array, param2:int) : int
      {
         var queue:Array = param1;
         var petId:int = param2;
         var x:int = 0;
         queue.forEach(function(param1:int, ... rest):void
         {
            if(petId == param1)
            {
               ++x;
            }
         });
         return x;
      }
      
      private function dismissCount(param1:int, param2:Array, param3:Array, param4:int) : int
      {
         return this.qCountX(param2,param1) - this.qCountX(param3,param1) - (param1 == param4 ? 1 : 0);
      }
      
      private function setSpotting(param1:Boolean, param2:int, param3:Boolean) : void
      {
         var unit:UnitInQueue = null;
         var currentSpot:int = 0;
         var latestPet:int = 0;
         var sideWise:int = 0;
         var preId:int = 0;
         var playerRoundAdded:Boolean = param1;
         var current:int = param2;
         var sourceNormal:Boolean = param3;
         if(current < 0 || playerRoundAdded)
         {
            this._unitsSpot.forEach(function(param1:UnitInQueue, ... rest):void
            {
               _uFadeOutAndRemove(param1,SIDE_OUT);
            });
            this._unitsSpot = [];
         }
         if(current > 0)
         {
            unit = this.newUnit(current,this._unitsSpot.length);
            currentSpot = int(this._unitsSpot.length);
            latestPet = -1;
            sideWise = SIDE_IN;
            if(currentSpot == 0)
            {
               unit.setRoundExtra(!sourceNormal);
               unit.setTail();
               sideWise = unit.isExtra() ? SIDE_DOWN : SIDE_UP;
            }
            else
            {
               latestPet = int(this._unitsSpot[currentSpot - 1].id);
            }
            this.addUnit(this._iconContainerUp,unit,this.spotX(currentSpot,currentSpot + 1),this.spotY(currentSpot,currentSpot + 1,false),SPOT_SIZE,sideWise);
            preId = -1;
            this._unitsSpot.forEach(function(param1:UnitInQueue, param2:int, param3:Array):void
            {
               var _loc4_:Boolean = param1.id == preId;
               _tweenPos(param1.res,spotX(param2,currentSpot + 1,_loc4_),spotY(param2,currentSpot + 1,false));
               preId = param1.id;
            });
            this._unitsSpot.push(unit);
         }
      }
      
      private function gapStandX(param1:int) : Number
      {
         var _loc2_:Number = this._mcHead.x - this._mcTail.x;
         var _loc3_:Number = MAX_GAP;
         if(param1 >= 2)
         {
            _loc3_ = Math.min(_loc2_ / (param1 - 1),_loc3_);
         }
         return _loc3_;
      }
      
      private function gapSpotX(param1:int) : Number
      {
         var _loc2_:Number = this._mcCurrent.x - this._mcTail.x;
         var _loc3_:Number = MAX_GAP;
         if(param1 >= 2)
         {
            _loc3_ = Math.min(_loc2_ / (param1 - 1),_loc3_);
         }
         return _loc3_;
      }
      
      private function standX(param1:int, param2:int) : Number
      {
         var _loc3_:Number = this.gapStandX(param2);
         return this._mcHead.x - _loc3_ * param1;
      }
      
      private function standY(param1:int, param2:int) : Number
      {
         return this._mcHead.y;
      }
      
      private function spotX(param1:int, param2:int, param3:Boolean = false) : Number
      {
         var _loc4_:Number = this.gapSpotX(param2);
         return this._mcCurrent.x - _loc4_ * param1;
      }
      
      private function spotY(param1:int, param2:int, param3:Boolean = false) : Number
      {
         return this._mcCurrent.y + (param3 ? this._mcCurrent.height * (SPOT_SIZE - STAND_SIZE) / 2 : 0);
      }
      
      private function identical(param1:Array, param2:Array) : Boolean
      {
         var arr1:Array = param1;
         var arr2:Array = param2;
         return arr1.length == arr2.length && arr1.every(function(param1:*, param2:int, ... rest):Boolean
         {
            return param1 == arr2[param2];
         });
      }
      
      private function newUnit(param1:int, param2:int) : UnitInQueue
      {
         var _loc3_:int = this._mapId2Race.containsKey(param1) ? int(this._mapId2Race.getValue(param1)) : 0;
         return new UnitInQueue(param1,_loc3_,this._pool.getMc(_loc3_),param2);
      }
      
      private function _recycleUnit(param1:UnitInQueue) : void
      {
         if(param1.res.parent)
         {
            param1.res.parent.removeChild(param1.res);
         }
         this._pool.recycle(param1.res,param1.raceId);
      }
      
      private function addUnit(param1:Sprite, param2:UnitInQueue, param3:Number, param4:Number, param5:Number, param6:int) : void
      {
         param2.res.x = param3;
         param2.res.y = param4;
         param2.res.scaleX = param2.res.scaleY = param5;
         param1.addChild(param2.res);
         this._uShow(param2,param6);
      }
      
      private function _qPrepare() : void
      {
         var _loc2_:UnitInQueue = null;
         var _loc1_:int = 0;
         while(_loc1_ < this._unitsStand.length)
         {
            _loc2_ = this._unitsStand[_loc1_];
            _loc2_.settled = false;
            _loc1_++;
         }
      }
      
      private function _qReLayer() : void
      {
         this._unitsStand.forEach(function(param1:UnitInQueue, param2:int, ... rest):void
         {
            _iconContainerDown.setChildIndex(param1.res,0);
         });
      }
      
      private function _uFadeOutAndRemove(param1:UnitInQueue, param2:int) : void
      {
         var x:Number;
         var y:Number;
         var icon:MovieClip = null;
         var tl:TweenLite = null;
         var unit:UnitInQueue = param1;
         var sideWise:int = param2;
         icon = unit.res;
         icon.visible = true;
         x = icon.x;
         y = icon.y;
         icon.alpha = 1;
         tl = TweenLite.to(icon,SHOWING_T / 2,{
            "alpha":0,
            "x":x + (sideWise == SIDE_IN ? SHOWING_OFFSET : 0) + (sideWise == SIDE_OUT ? -SHOWING_OFFSET : 0),
            "y":y + (sideWise == SIDE_UP ? -SHOWING_OFFSET : 0) + (sideWise == SIDE_DOWN ? SHOWING_OFFSET : 0),
            "onComplete":function():void
            {
               tl.kill();
               icon.alpha = 1;
               _recycleUnit(unit);
            }
         });
      }
      
      private function _uShow(param1:UnitInQueue, param2:int) : void
      {
         var tl:TweenLite = null;
         var unit:UnitInQueue = param1;
         var sideWise:int = param2;
         var icon:MovieClip = unit.res;
         var x:Number = icon.x;
         var y:Number = icon.y;
         tl = TweenLite.from(icon,SHOWING_T,{
            "alpha":0,
            "x":x + (sideWise == SIDE_IN ? -SHOWING_OFFSET : 0) + (sideWise == SIDE_OUT ? SHOWING_OFFSET : 0),
            "y":y + (sideWise == SIDE_UP ? -SHOWING_OFFSET : 0) + (sideWise == SIDE_DOWN ? SHOWING_OFFSET : 0),
            "onComplete":function():void
            {
               tl.kill();
            }
         });
      }
      
      private function _tweenPos(param1:MovieClip, param2:Number, param3:Number) : void
      {
         TweenLite.killTweensOf(param1);
         TweenLite.to(param1,SHOWING_T,{
            "x":param2,
            "y":param3
         });
      }
   }
}

import flash.display.Bitmap;
import flash.display.BitmapData;
import flash.display.MovieClip;
import flash.display.Sprite;
import mmo.battle.util.BattleContentUtil;

class UnitInQueue
{
   
   private var _id:int;
   
   private var _raceId:int;
   
   private var _res:MovieClip;
   
   private var _place:int;
   
   private var _isExtra:Boolean;
   
   public var settled:Boolean = false;
   
   public var remove:Boolean = false;
   
   public function UnitInQueue(param1:int, param2:int, param3:MovieClip, param4:int)
   {
      super();
      this._id = param1;
      this._raceId = param2;
      this._res = param3;
      this._place = param4;
      this._res.visible = true;
      this._isExtra = false;
      this.setResBg();
      this._res["bg"]["tail"].visible = false;
   }
   
   public function get id() : int
   {
      return this._id;
   }
   
   public function get raceId() : int
   {
      return this._raceId;
   }
   
   public function get res() : MovieClip
   {
      return this._res;
   }
   
   public function get place() : int
   {
      return this._place;
   }
   
   public function isExtra() : Boolean
   {
      return this._isExtra;
   }
   
   public function setRoundExtra(param1:Boolean) : void
   {
      this._isExtra = param1;
      this.setResBg();
   }
   
   private function setResBg() : void
   {
      this._res["bg"].gotoAndStop(this._isExtra ? 2 : 1);
   }
   
   public function setTail() : void
   {
      this._res["bg"]["tail"].visible = true;
   }
   
   public function asSameAs(param1:UnitInQueue) : Boolean
   {
      return this._id == param1._id;
   }
   
   public function updatePlace(param1:int) : void
   {
      this._place = param1;
      this.settled = true;
   }
   
   public function updateRemove() : void
   {
      this.settled = true;
      this.remove = true;
   }
   
   public function dispose() : void
   {
      this._res = null;
   }
}

class UnitResPool
{
   
   private var _class:Class;
   
   private var _source:Array;
   
   private var _raceIds:Array;
   
   private var _content:Object;
   
   public function UnitResPool(param1:Class, param2:Object)
   {
      super();
      this._class = param1;
      this._source = [];
      this._raceIds = [];
      this._content = param2;
   }
   
   public function getMc(param1:int) : MovieClip
   {
      var _loc3_:MovieClip = null;
      var _loc2_:int = int(this._raceIds.indexOf(param1));
      if(_loc2_ >= 0)
      {
         _loc3_ = this._source[_loc2_];
         this._source.splice(_loc2_,1);
         this._raceIds.splice(_loc2_,1);
         return _loc3_;
      }
      return this._newMc(param1);
   }
   
   public function recycle(param1:MovieClip, param2:int) : void
   {
      this._source.push(param1);
      this._raceIds.push(param2);
   }
   
   private function _newMc(param1:int) : MovieClip
   {
      var _loc2_:MovieClip = new this._class();
      var _loc3_:Sprite = _loc2_["c"];
      var _loc4_:Object = BattleContentUtil.getContentProperty(this._content,BattleContentUtil.PN_RACE_ID_2_BITMAP_DATA_MAP);
      var _loc5_:BitmapData = _loc4_[param1.toString()];
      var _loc6_:Bitmap = new Bitmap(_loc5_,"auto",true);
      _loc6_.x = -24;
      _loc6_.y = -24;
      _loc3_.addChild(_loc6_);
      return _loc2_;
   }
}
