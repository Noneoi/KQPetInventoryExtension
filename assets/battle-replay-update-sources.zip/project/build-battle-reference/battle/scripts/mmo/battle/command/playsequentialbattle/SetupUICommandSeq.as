package mmo.battle.command.playsequentialbattle
{
   import flash.display.Sprite;
   import flash.events.IEventDispatcher;
   import flash.system.ApplicationDomain;
   import mmo.battle.container.BattleContainer;
   import mmo.battle.entity.BattleBase;
   import mmo.battle.ui.BattleUISeq;
   import mmo.battle.util.BattleContentUtil;
   import mmo.interfaces.battle.data.BattleInfo;
   import mmo.interfaces.battle.data.NpcBlessResult;
   import mmo.interfaces.battle.entity.IBattle;
   import mmo.util.command.ISceneCommand;
   import mmo.util.command.SceneSimpleCommand;
   
   public class SetupUICommandSeq extends SceneSimpleCommand implements ISceneCommand
   {
      
      private static const UI_RES_CLS:String = "mmo.battle.common.BattleUIRes";
      
      private var _content:Object;
      
      private var _battle:IBattle;
      
      private var _battleInfo:BattleInfo;
      
      private var _npcBlessResult:NpcBlessResult;
      
      private var _domain:ApplicationDomain;
      
      private var _dispatcher:IEventDispatcher;
      
      private var _nodePetRaceIds:Array;
      
      public function SetupUICommandSeq()
      {
         super();
      }
      
      override public function execute(param1:Object) : void
      {
         this._content = param1;
         var _loc2_:Array = BattleContentUtil.getContentProperty(param1,BattleContentUtil.PN_BATTLES);
         this._battleInfo = (_loc2_[0] as IBattle).battleResult.battleInfo;
         this._battle = BattleContentUtil.getContentProperty(param1,BattleContentUtil.PN_BATTLE_SEQ);
         this._npcBlessResult = BattleContentUtil.getContentProperty(param1,BattleContentUtil.PN_NPC_BLESS_RESULT);
         this._domain = BattleContentUtil.getContentProperty(param1,BattleContentUtil.PN_DOMAIN);
         this._dispatcher = BattleContentUtil.getContentProperty(param1,BattleContentUtil.PN_EVENT_DISPATCHER);
         this._nodePetRaceIds = BattleContentUtil.getContentProperty(param1,BattleContentUtil.PN_NODE_RACE_ID);
         this.setupUI();
      }
      
      private function setupUI() : void
      {
         var _loc1_:Class = this._domain.getDefinition(UI_RES_CLS) as Class;
         var _loc2_:Sprite = new _loc1_() as Sprite;
         var _loc3_:BattleUISeq = new BattleUISeq(_loc2_,this._domain,this._dispatcher,this._nodePetRaceIds);
         _loc3_.setInfo(this._battleInfo,this._npcBlessResult,BattleBase(this._battle));
         var _loc4_:BattleContainer = BattleContentUtil.getContentProperty(this._content,BattleContentUtil.PN_CONTAINER);
         _loc3_.show(_loc4_.uiLayer);
         BattleContentUtil.setContentProperty(this._content,BattleContentUtil.PN_UI,_loc3_);
         this.succeed(this._content);
         this._content = null;
      }
   }
}

