package mmo.battle.resultpanel
{
   import flash.display.FrameLabel;
   import flash.display.MovieClip;
   import flash.display.SimpleButton;
   import flash.display.Sprite;
   import flash.events.MouseEvent;
   import flash.system.ApplicationDomain;
   import flash.text.TextField;
   import mmo.common.DisplayUtil;
   import mmo.common.utils.panel.modaldialog.ModalDialogManager;
   import mmo.interfaces.ServiceContainer;
   import mmo.interfaces.battle.data.GainExpInfo;
   import mmo.interfaces.pet.data.IPetDataService;
   import mmo.interfaces.pet.data.PetBriefInfo;
   import mmo.interfaces.pet.peticon.IPetIcon;
   import mmo.interfaces.pet.peticon.PetIconContainer;
   import mmo.interfaces.pet.peticon.PetIconEvent;
   import mmo.interfaces.pet.peticon.PetIconType;
   
   public class EvolutionPanel
   {
      
      private static const EVOLUTION_PANEL_CLS:String = "mmo.battle.common.EvolutionPanelRes";
      
      private var _content:Object;
      
      private var _callback:Function;
      
      private var _evolutionInfos:Array;
      
      private var _res:Sprite;
      
      private var _dataService:IPetDataService;
      
      private var _iconService:IPetIcon;
      
      private var _expInfo:GainExpInfo;
      
      private var _petInfo:PetBriefInfo;
      
      private var _orgIcon:PetIconContainer;
      
      private var _newIcon:PetIconContainer;
      
      private var _txtName:TextField;
      
      private var _txtLevel:TextField;
      
      private var _mcSpinBoard:MovieClip;
      
      private var _spIconContainer:Sprite;
      
      private var _txtPhyAtt0:TextField;
      
      private var _txtPhyDef0:TextField;
      
      private var _txtMagAtt0:TextField;
      
      private var _txtMagDef0:TextField;
      
      private var _txtUtlAtt0:TextField;
      
      private var _txtUtlDef0:TextField;
      
      private var _txtHp0:TextField;
      
      private var _txtSpeed0:TextField;
      
      private var _txtPhyAtt1:TextField;
      
      private var _txtPhyDef1:TextField;
      
      private var _txtMagAtt1:TextField;
      
      private var _txtMagDef1:TextField;
      
      private var _txtUtlAtt1:TextField;
      
      private var _txtUtlDef1:TextField;
      
      private var _txtHp1:TextField;
      
      private var _txtSpeed1:TextField;
      
      private var _btnOk:SimpleButton;
      
      public function EvolutionPanel(param1:Object, param2:Function, param3:Array)
      {
         super();
         this._content = param1;
         this._callback = param2;
         this._evolutionInfos = param3;
         this.initComponent();
         this.initListener();
         this.initService();
      }
      
      public function show() : void
      {
         ModalDialogManager.getInstance().addModalDialog(this._res);
      }
      
      public function close() : void
      {
         ModalDialogManager.getInstance().removeModalDialog(this._res);
         this.removeListener();
         this._callback.apply();
      }
      
      private function initComponent() : void
      {
         var domain:ApplicationDomain = this._content["Domain"];
         var cls:Class = domain.getDefinition(EVOLUTION_PANEL_CLS) as Class;
         this._res = new cls() as Sprite;
         this._txtName = this._res.getChildByName("petname") as TextField;
         this._txtLevel = this._res.getChildByName("lv") as TextField;
         this._mcSpinBoard = this._res.getChildByName("movie") as MovieClip;
         this._mcSpinBoard.gotoAndStop(1);
         this._mcSpinBoard.addFrameScript(this._mcSpinBoard.totalFrames - 1,function():void
         {
            _mcSpinBoard.stop();
            setButtonEnable(true);
         });
         this._spIconContainer = this._res.getChildByName("ic") as Sprite;
         this._txtPhyAtt0 = this._res.getChildByName("patt0") as TextField;
         this._txtPhyDef0 = this._res.getChildByName("pdef0") as TextField;
         this._txtMagAtt0 = this._res.getChildByName("matt0") as TextField;
         this._txtMagDef0 = this._res.getChildByName("mdef0") as TextField;
         this._txtUtlAtt0 = this._res.getChildByName("uatt0") as TextField;
         this._txtUtlDef0 = this._res.getChildByName("udef0") as TextField;
         this._txtHp0 = this._res.getChildByName("hp0") as TextField;
         this._txtSpeed0 = this._res.getChildByName("speed0") as TextField;
         this._txtPhyAtt1 = this._res.getChildByName("patt1") as TextField;
         this._txtPhyDef1 = this._res.getChildByName("pdef1") as TextField;
         this._txtMagAtt1 = this._res.getChildByName("matt1") as TextField;
         this._txtMagDef1 = this._res.getChildByName("mdef1") as TextField;
         this._txtUtlAtt1 = this._res.getChildByName("uatt1") as TextField;
         this._txtUtlDef1 = this._res.getChildByName("udef1") as TextField;
         this._txtHp1 = this._res.getChildByName("hp1") as TextField;
         this._txtSpeed1 = this._res.getChildByName("speed1") as TextField;
         this._btnOk = this._res.getChildByName("ok") as SimpleButton;
         this.setButtonEnable(false);
      }
      
      private function setButtonEnable(param1:Boolean) : void
      {
         this._btnOk.mouseEnabled = param1;
         if(param1)
         {
            DisplayUtil.clearFilters(this._btnOk);
         }
         else
         {
            DisplayUtil.applyGray(this._btnOk);
         }
      }
      
      private function initListener() : void
      {
         this._btnOk.addEventListener(MouseEvent.CLICK,this.onCloseClick);
      }
      
      private function initService() : void
      {
         this._dataService = ServiceContainer.getService(IPetDataService) as IPetDataService;
         ServiceContainer.tryGetService(IPetIcon,this.onGetPetIconService);
      }
      
      private function removeListener() : void
      {
         this._btnOk.removeEventListener(MouseEvent.CLICK,this.onCloseClick);
      }
      
      private function onCloseClick(param1:MouseEvent) : void
      {
         this.handleNextInfo();
      }
      
      private function onGetPetIconService(param1:IPetIcon, param2:Object) : void
      {
         this._iconService = param1;
         this.handleNextInfo();
      }
      
      private function handleNextInfo() : void
      {
         if(this._evolutionInfos.length == 0)
         {
            this.close();
            return;
         }
         var _loc1_:GainExpInfo = this._evolutionInfos.shift();
         this.setInfo(_loc1_);
      }
      
      private function setInfo(param1:GainExpInfo) : void
      {
         this._expInfo = param1;
         this._petInfo = this._dataService.getPetByPetId(param1.id);
         this.setButtonEnable(false);
         this._mcSpinBoard.visible = false;
         this._txtName.text = this._petInfo.name;
         this._txtLevel.text = "lv." + this._petInfo.level;
         while(this._spIconContainer.numChildren > 0)
         {
            this._spIconContainer.removeChildAt(0);
         }
         this._orgIcon = this._iconService.getPetIcon(this._expInfo.orgFaceId,PetIconType.LARGE,130,120,false);
         this._orgIcon.addEventListener(PetIconEvent.ON_ICON_LOADED,this.onOrgIconLoaded);
         this._orgIcon.startLoad();
      }
      
      private function onOrgIconLoaded(param1:PetIconEvent) : void
      {
         this._orgIcon.removeEventListener(PetIconEvent.ON_ICON_LOADED,this.onOrgIconLoaded);
         this._spIconContainer.addChild(this._orgIcon);
         this._txtPhyAtt0.text = this._expInfo.orgPetInfo.physicalAttack.toString();
         this._txtPhyDef0.text = this._expInfo.orgPetInfo.physicalDefence.toString();
         this._txtMagAtt0.text = this._expInfo.orgPetInfo.magicAttack.toString();
         this._txtMagDef0.text = this._expInfo.orgPetInfo.magicDefence.toString();
         this._txtUtlAtt0.text = this._expInfo.orgPetInfo.ultimateAttack.toString();
         this._txtUtlDef0.text = this._expInfo.orgPetInfo.ultimateDefence.toString();
         this._txtHp0.text = this._expInfo.orgPetInfo.maxHp.toString();
         this._txtSpeed0.text = this._expInfo.orgPetInfo.speed.toString();
         this._newIcon = this._iconService.getPetIcon(this._petInfo.faceId,PetIconType.LARGE,130,120,false);
         this._newIcon.addEventListener(PetIconEvent.ON_ICON_LOADED,this.onNewIconLoaded);
         this._newIcon.startLoad();
      }
      
      private function onNewIconLoaded(param1:PetIconEvent) : void
      {
         var evt:PetIconEvent = param1;
         this._newIcon.removeEventListener(PetIconEvent.ON_ICON_LOADED,this.onNewIconLoaded);
         this._mcSpinBoard.addFrameScript(this.showNewIconFrameIndex,function():void
         {
            _spIconContainer.removeChild(_orgIcon);
            _spIconContainer.addChild(_newIcon);
            _txtPhyAtt1.text = _expInfo.newPetInfo.physicalAttack.toString();
            _txtPhyDef1.text = _expInfo.newPetInfo.physicalDefence.toString();
            _txtMagAtt1.text = _expInfo.newPetInfo.magicAttack.toString();
            _txtMagDef1.text = _expInfo.newPetInfo.magicDefence.toString();
            _txtUtlAtt1.text = _expInfo.newPetInfo.ultimateAttack.toString();
            _txtUtlDef1.text = _expInfo.newPetInfo.ultimateDefence.toString();
            _txtHp1.text = _expInfo.newPetInfo.maxHp.toString();
            _txtSpeed1.text = _expInfo.newPetInfo.speed.toString();
         });
         this._mcSpinBoard.visible = true;
         this._mcSpinBoard.gotoAndPlay(1);
      }
      
      private function get showNewIconFrameIndex() : int
      {
         var _loc1_:FrameLabel = this._mcSpinBoard.currentLabels[0];
         return _loc1_.frame;
      }
   }
}

