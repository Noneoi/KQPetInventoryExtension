package mmo.battle.command
{
   import mmo.battle.command.attack.close.ApproachCommand;
   import mmo.battle.command.attack.close.CounterCommand;
   import mmo.battle.command.attack.close.PlayCloseActionCommandSimpleRes;
   import mmo.battle.command.attack.close.ReturnCommand;
   import mmo.battle.command.attack.close.WarmUpCommandSimpleRes;
   import mmo.battle.command.attack.common.AfterSequentialAttackCommand;
   import mmo.battle.command.attack.common.BeforeSequentialAttackCommand;
   import mmo.battle.command.attack.common.PlayEffectCommand;
   import mmo.interfaces.battle.command.IBattleCommand;
   
   public class CloseCounterCommandSimpleRes extends BattleCommand implements IBattleCommand
   {
      
      public function CloseCounterCommandSimpleRes()
      {
         super();
      }
      
      override protected function initializeMacroCommand() : void
      {
         addSubCommand(BeforeSequentialAttackCommand);
         addSubCommand(WarmUpCommandSimpleRes);
         addSubCommand(ApproachCommand);
         addParallelSubCommand([PlayCloseActionCommandSimpleRes,PlayEffectCommand]);
         addSubCommand(ReturnCommand);
         addSubCommand(CounterCommand);
         addSubCommand(AfterSequentialAttackCommand);
         super.initializeMacroCommand();
      }
   }
}

