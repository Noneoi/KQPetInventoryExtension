package mmo.battle.command.playteambattle
{
   import mmo.battle.command.playbattle.NotifyResultCommand;
   import mmo.battle.resultpanel.GainExpTeamPanel;
   import mmo.battle.util.BattleContentUtil;
   import mmo.battle.util.BattleUtil;
   import mmo.interfaces.ServiceContainer;
   import mmo.interfaces.battle.data.BattleInfo;
   import mmo.interfaces.battle.entity.IBattle;
   import mmo.interfaces.user.IUserNameManager;
   
   public class NotifyTeamResultCommand extends NotifyResultCommand
   {
      
      private var _battle:IBattle;
      
      private var userNameManager:IUserNameManager = ServiceContainer.getService(IUserNameManager) as IUserNameManager;
      
      public function NotifyTeamResultCommand()
      {
         super();
      }
      
      override protected function handleWinBattle(param1:String) : void
      {
         var _loc2_:GainExpTeamPanel = new GainExpTeamPanel(this._content,this.onResultNotifyCallback,param1);
         _loc2_.show();
      }
      
      override protected function isCurUserWiner() : Boolean
      {
         var _loc1_:BattleInfo = BattleContentUtil.getContentProperty(this._content,BattleContentUtil.PN_BATTLE_INFO);
         this._battle = BattleContentUtil.getContentProperty(this._content,BattleContentUtil.PN_BATTLE);
         var _loc2_:String = this.userNameManager.getNickName(this._battle.battleResult.teamLeaderName);
         return BattleUtil.isCurUserInTeam(_loc1_,this._winerTeamId,_loc2_);
      }
      
      override protected function isCurUserLoser() : Boolean
      {
         var _loc1_:BattleInfo = BattleContentUtil.getContentProperty(this._content,BattleContentUtil.PN_BATTLE_INFO);
         var _loc2_:int = 1 - this._winerTeamId;
         var _loc3_:String = this.userNameManager.getNickName(this._battle.battleResult.teamLeaderName);
         return BattleUtil.isCurUserInTeam(_loc1_,_loc2_,_loc3_);
      }
   }
}

