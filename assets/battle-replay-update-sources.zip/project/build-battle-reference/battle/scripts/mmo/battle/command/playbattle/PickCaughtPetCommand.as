package mmo.battle.command.playbattle
{
   import flash.events.EventDispatcher;
   import mmo.battle.catchpanel.CatchPanel;
   import mmo.battle.client.BattleClient;
   import mmo.battle.util.BattleContentUtil;
   import mmo.common.dialog.NewDialog;
   import mmo.framework.comm.SocketClient;
   import mmo.framework.comm.SocketClientEvent;
   import mmo.interfaces.battle.data.CatchPetResult;
   import mmo.interfaces.battle.events.BattleEvent;
   import mmo.util.command.ISceneCommand;
   import mmo.util.command.SceneSimpleCommand;
   
   public class PickCaughtPetCommand extends SceneSimpleCommand implements ISceneCommand
   {
      
      private var _content:Object;
      
      private var _characterIds:Array;
      
      private var _raceIds:Array;
      
      public function PickCaughtPetCommand()
      {
         super();
      }
      
      override public function execute(param1:Object) : void
      {
         var _loc3_:CatchPanel = null;
         this._content = param1;
         var _loc2_:CatchPetResult = BattleContentUtil.getContentProperty(param1,BattleContentUtil.PN_CATCH_RESULT);
         if(_loc2_ == null || _loc2_.catchPetInfos == null || _loc2_.catchPetInfos.length == 0)
         {
            this.succeed(this._content);
            this._content = null;
         }
         else
         {
            _loc3_ = new CatchPanel(this._content,this.onCatchPanelClose);
            _loc3_.show();
         }
      }
      
      private function onCatchPanelClose(param1:Number, param2:Array, param3:Array) : void
      {
         this._characterIds = param2;
         this._raceIds = param3;
         SocketClient.instance.addEventListener(BattleClient.CMD_PICK_NOTIFICATION,this.onPickResponce);
         BattleClient.instance.notifyCatchRusult(param1,param2);
      }
      
      private function onPickResponce(param1:SocketClientEvent) : void
      {
         SocketClient.instance.removeEventListener(BattleClient.CMD_PICK_NOTIFICATION,this.onPickResponce);
         var _loc2_:int = int(param1.params.r);
         if(_loc2_ != 1)
         {
            NewDialog.showFailMessage("捕捉异常...");
         }
         var _loc3_:EventDispatcher = BattleContentUtil.getContentProperty(this._content,BattleContentUtil.PN_EVENT_DISPATCHER);
         if(_loc3_.hasEventListener(BattleEvent.PICK_CAULT_PET))
         {
            param1.params["cids"] = this._characterIds;
            param1.params["rids"] = this._raceIds;
            _loc3_.dispatchEvent(new BattleEvent(BattleEvent.PICK_CAULT_PET,param1.params));
         }
         this.succeed(this._content);
         this._content = null;
      }
   }
}

