package mmo.battle.word
{
   import flash.events.EventDispatcher;
   import mmo.battle.entity.SyncInterrupt;
   import mmo.interfaces.IDispose;
   import mmo.interfaces.battle.consts.FormationConsts;
   import mmo.interfaces.battle.data.BattleUnit;
   import mmo.interfaces.battle.data.DeleteAction;
   import mmo.interfaces.battle.data.RoundResult;
   import mmo.interfaces.battle.data.ShiftAction;
   
   public class BattleWordSyncManager extends EventDispatcher implements IDispose
   {
      
      private var _battleWords:BattleWords;
      
      private var _arrBattleLines:Array;
      
      private var _roundSemaphore:int;
      
      private var _lineState:int;
      
      private var _shiftSemaphore:int = 0;
      
      public function BattleWordSyncManager(param1:BattleWords)
      {
         super();
         this._battleWords = param1;
         this._arrBattleLines = [];
      }
      
      public function getOnBattleLineNum() : int
      {
         var _loc3_:BattleUnit = null;
         var _loc1_:int = 0;
         var _loc2_:int = 0;
         while(_loc2_ < FormationConsts.MAX_ROW_COUNT)
         {
            _loc3_ = this._arrBattleLines[_loc2_];
            if(_loc3_ != null && _loc3_.roundResults.length > 0)
            {
               _loc1_++;
            }
            _loc2_++;
         }
         return _loc1_;
      }
      
      public function insertBattleUnit(param1:BattleUnit) : Boolean
      {
         var _loc4_:Boolean = false;
         var _loc2_:int = int(param1.battleLineIndex);
         var _loc3_:BattleUnit = this._arrBattleLines[_loc2_];
         if(_loc3_ == null || _loc3_.roundResults.length == 0)
         {
            _loc4_ = this.handleDeleteAction(param1.shiftResult.deleteActions);
            if(!_loc4_)
            {
               return false;
            }
            this.handleShiftActions(param1.shiftResult.shiftActions);
            if(param1.isReallyFight)
            {
               this._lineState |= 1 << _loc2_;
            }
            this._arrBattleLines[_loc2_] = param1;
            return true;
         }
         return false;
      }
      
      public function run() : void
      {
         var _loc2_:BattleUnit = null;
         var _loc3_:RoundResult = null;
         if(this._shiftSemaphore > 0)
         {
            return;
         }
         var _loc1_:int = 0;
         while(_loc1_ < FormationConsts.MAX_ROW_COUNT)
         {
            _loc2_ = this._arrBattleLines[_loc1_];
            if(_loc2_ != null && _loc2_.roundResults.length > 0)
            {
               _loc3_ = _loc2_.roundResults.shift();
               this.handleRoundResult(_loc3_);
            }
            _loc1_++;
         }
      }
      
      private function handleRoundResult(param1:RoundResult) : void
      {
         if(param1.isOverRoundLimit)
         {
            this.dispatchEvent(new SyncInterrupt(SyncInterrupt.OVER_ROUND_LIMIT_WARNING,null));
         }
         ++this._roundSemaphore;
         var _loc2_:BattleWordPlayer = this._battleWords.getPlayerByName(param1.sourcePlayerName);
         var _loc3_:BattleWordFighter = _loc2_.getFighterById(param1.sourceCharacterId);
         _loc3_.attack(param1,this.onOneAttackEnd);
      }
      
      private function onOneAttackEnd() : void
      {
         --this._roundSemaphore;
         if(this._roundSemaphore == 0)
         {
            if(this.hasNewBattleLineEnd())
            {
               this.dispatchEvent(new SyncInterrupt(SyncInterrupt.ONE_BATTLELINE_END,null));
            }
            else
            {
               this.run();
            }
         }
      }
      
      private function handleDeleteAction(param1:Array) : Boolean
      {
         var _loc2_:DeleteAction = null;
         var _loc3_:String = null;
         var _loc4_:BattleWordPlayer = null;
         for each(_loc2_ in param1)
         {
            _loc3_ = _loc2_.playerName;
            if(this.isPlayerInBattle(_loc3_))
            {
               return false;
            }
            _loc4_ = this._battleWords.getPlayerByName(_loc3_);
            this._battleWords.removePlayer(_loc4_);
         }
         return true;
      }
      
      private function handleShiftActions(param1:Array) : void
      {
         var _loc2_:ShiftAction = null;
         var _loc3_:String = null;
         var _loc4_:BattleWordPlayer = null;
         this._shiftSemaphore = param1.length;
         for each(_loc2_ in param1)
         {
            _loc3_ = _loc2_.playerName;
            _loc4_ = this._battleWords.getPlayerByName(_loc3_);
         }
      }
      
      private function onPlayerShiftComplete() : void
      {
         --this._shiftSemaphore;
         if(this._shiftSemaphore == 0)
         {
            this.run();
         }
      }
      
      private function hasNewBattleLineEnd() : Boolean
      {
         var _loc4_:BattleUnit = null;
         var _loc1_:int = 0;
         var _loc2_:int = 0;
         while(_loc2_ < FormationConsts.MAX_ROW_COUNT)
         {
            _loc4_ = this._arrBattleLines[_loc2_];
            if(_loc4_ != null && _loc4_.roundResults.length > 0)
            {
               _loc1_ |= 1 << _loc2_;
            }
            _loc2_++;
         }
         var _loc3_:Boolean = this._lineState != _loc1_;
         this._lineState = _loc1_;
         return _loc3_;
      }
      
      private function isPlayerInBattle(param1:String) : Boolean
      {
         var _loc3_:BattleUnit = null;
         var _loc2_:int = 0;
         while(_loc2_ < FormationConsts.MAX_ROW_COUNT)
         {
            _loc3_ = this._arrBattleLines[_loc2_];
            if(_loc3_ != null)
            {
               if(!(_loc3_.aPlayerName != param1 && _loc3_.bPlayerName != param1))
               {
                  if(_loc3_.roundResults.length == 0)
                  {
                     return false;
                  }
                  return true;
               }
            }
            _loc2_++;
         }
         return false;
      }
      
      public function dispose() : void
      {
      }
   }
}

