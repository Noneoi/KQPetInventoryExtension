package mmo.battle.command.playbattle
{
   import mmo.battle.util.BattleContentUtil;
   import mmo.common.helper.ActUtil;
   import mmo.common.loader.LoadResUtil;
   import mmo.framework.comm.SocketClient;
   import mmo.interfaces.ServiceContainer;
   import mmo.interfaces.battle.data.BattleFlashToH5Info;
   import mmo.interfaces.battle.data.BattleInfo;
   import mmo.interfaces.battle.data.PlayerInfo;
   import mmo.interfaces.battle.data.TeamInfo;
   import mmo.interfaces.material.clothes.AvatarInfo;
   import mmo.interfaces.material.clothes.IClothesService;
   import mmo.interfaces.pet.data.IPetDataService;
   import mmo.interfaces.user.IUserNameManager;
   import mmo.loader.FlashJSConnector;
   import mmo.loader.LoadingSpriteType;
   import mmo.util.command.ISceneCommand;
   import mmo.util.command.SceneSimpleCommand;
   
   public class JumpH5BattleCommand extends SceneSimpleCommand implements ISceneCommand
   {
      
      private var _content:Object;
      
      private var _flashToH5Info:BattleFlashToH5Info;
      
      private const ArrayResList:Array = ["battle/gaincoolpetstone_res","battle/catch_res"];
      
      public function JumpH5BattleCommand()
      {
         super();
      }
      
      override public function execute(param1:Object) : void
      {
         this._content = param1;
         this._flashToH5Info = BattleContentUtil.getContentProperty(this._content,BattleContentUtil.FlashToH5_DATA);
         this._flashToH5Info.filterEffectRaceIds = (ServiceContainer.getService(IPetDataService) as IPetDataService).getClosedEffectRaceIds();
         this._flashToH5Info.simpleResType = BattleContentUtil.getIsSimpleBattleResType();
         if(this._flashToH5Info == null)
         {
            this.finishPlayH5Battle();
            return;
         }
         if(this.ArrayResList.length <= 0)
         {
            this.finishLoadRes();
            return;
         }
         var _loc2_:* = BattleContentUtil.getContentProperty(param1,BattleContentUtil.PN_DOMAIN);
         LoadResUtil.loadListRes(this.ArrayResList,LoadingSpriteType.NONE,this.finishLoadRes,null,_loc2_);
      }
      
      private function finishLoadRes() : void
      {
         var _loc6_:BattleInfo = null;
         var _loc7_:TeamInfo = null;
         var _loc8_:TeamInfo = null;
         var _loc1_:IUserNameManager = ServiceContainer.getService(IUserNameManager) as IUserNameManager;
         var _loc2_:String = _loc1_.getNickName(SocketClient.instance.myUserName);
         this._flashToH5Info.userName = _loc2_;
         var _loc3_:int = int(ActUtil.vipService.myVipLevel);
         var _loc4_:int = Math.max(ActUtil.vipService.curBaixingTitleIdx,ActUtil.vipService.curExperienceBaixingLv);
         this._flashToH5Info.vipLv = _loc3_;
         this._flashToH5Info.baiXingLv = _loc4_;
         var _loc5_:* = BattleContentUtil.getContentProperty(this._content,BattleContentUtil.PN_IS_MULTIPLAYER);
         if(!_loc5_)
         {
            _loc6_ = BattleContentUtil.getContentProperty(this._content,BattleContentUtil.PN_BATTLE_INFO);
            _loc7_ = _loc6_.teamInfos[0] as TeamInfo;
            _loc8_ = _loc6_.teamInfos[1] as TeamInfo;
            this.setupAvatar(_loc7_.playerInfos[0],_loc8_.playerInfos[0],true);
         }
         else
         {
            this.startShowH5();
         }
      }
      
      private function setupAvatar(param1:PlayerInfo, param2:PlayerInfo, param3:Boolean) : void
      {
         var clothesService:IClothesService;
         var playerInfo:PlayerInfo = param1;
         var playerInfoExt:PlayerInfo = param2;
         var isFirst:Boolean = param3;
         if(playerInfo.playerType == PlayerInfo.PLAYER_TYPE_AI)
         {
            if(isFirst)
            {
               this.setupAvatar(playerInfoExt,null,false);
            }
            else
            {
               this.startShowH5();
            }
            return;
         }
         clothesService = ServiceContainer.getService(IClothesService);
         clothesService.getOthersAvatarInfo("",function(param1:AvatarInfo):void
         {
            if(isFirst)
            {
               _flashToH5Info.player0AvatarStr = param1.toString();
               setupAvatar(playerInfoExt,null,false);
            }
            else
            {
               _flashToH5Info.player1AvatarStr = param1.toString();
               startShowH5();
            }
         },playerInfo.playerName);
      }
      
      private function startShowH5() : void
      {
         var _loc1_:String = this._flashToH5Info.toStr();
         var _loc2_:String = "";
         if(ActUtil.isDebug())
         {
            _loc2_ = "http://www.pjx.com/h5/batindex.html?testBT=true";
         }
         else
         {
            _loc2_ = "https://aoqi.100bt.com/h5/batindex.html?testBT=true";
         }
         FlashJSConnector.registerFunction("afterPlayH5Battle",this.finishPlayH5Battle);
         FlashJSConnector.showBattleByInnerHtml(_loc2_,_loc1_,true);
      }
      
      private function finishPlayH5Battle() : void
      {
         succeed(this._content);
      }
   }
}

