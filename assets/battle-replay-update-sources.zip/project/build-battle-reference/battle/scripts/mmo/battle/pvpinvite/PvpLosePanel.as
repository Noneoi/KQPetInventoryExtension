package mmo.battle.pvpinvite
{
   import flash.display.SimpleButton;
   import flash.display.Sprite;
   import flash.events.MouseEvent;
   import flash.utils.getDefinitionByName;
   import mmo.common.utils.panel.modaldialog.ModalDialogManager;
   
   public class PvpLosePanel
   {
      
      private static const RES_CLS:String = "mmo.battle.common.PvpLosePanelRes";
      
      private var _res:Sprite;
      
      private var _btnClose:SimpleButton;
      
      private var _btnOk:SimpleButton;
      
      private var _callback:Function;
      
      public function PvpLosePanel(param1:Function)
      {
         super();
         this._callback = param1;
      }
      
      public function show() : void
      {
         this.initComponent();
         this.initListener();
         this.addToStage();
      }
      
      private function initComponent() : void
      {
         var _loc1_:Class = getDefinitionByName(RES_CLS) as Class;
         this._res = new _loc1_() as Sprite;
         this._btnClose = this._res.getChildByName("close") as SimpleButton;
         this._btnOk = this._res.getChildByName("ok") as SimpleButton;
      }
      
      private function initListener() : void
      {
         this._btnClose.addEventListener(MouseEvent.CLICK,this.onCloseClick);
         this._btnOk.addEventListener(MouseEvent.CLICK,this.onCloseClick);
      }
      
      private function onCloseClick(param1:MouseEvent) : void
      {
         this._btnClose.removeEventListener(MouseEvent.CLICK,this.onCloseClick);
         this._btnOk.removeEventListener(MouseEvent.CLICK,this.onCloseClick);
         this._callback.apply();
      }
      
      private function addToStage() : void
      {
         ModalDialogManager.getInstance().addModalDialog(this._res);
      }
   }
}

