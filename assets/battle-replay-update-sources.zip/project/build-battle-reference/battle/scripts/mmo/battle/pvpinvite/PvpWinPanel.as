package mmo.battle.pvpinvite
{
   import flash.display.SimpleButton;
   import flash.display.Sprite;
   import flash.events.Event;
   import flash.events.MouseEvent;
   import flash.net.FileReference;
   import flash.utils.getDefinitionByName;
   import mmo.battle.ui.BattleMessageUI;
   import mmo.common.dialog.NewDialog;
   import mmo.common.utils.panel.modaldialog.ModalDialogManager;
   import mmo.config.ConfigReader;
   
   public class PvpWinPanel
   {
      
      private static const RES_CLS:String = "mmo.battle.common.PvpWinPanelRes";
      
      private var _res:Sprite;
      
      private var _btnClose:SimpleButton;
      
      private var _btnOk:SimpleButton;
      
      private var _btnSave:SimpleButton;
      
      private var _callback:Function;
      
      public function PvpWinPanel(param1:Function)
      {
         super();
         this._callback = param1;
      }
      
      public function show() : void
      {
         this.initComponent();
         this.initListener();
         this.addToStage();
      }
      
      private function initComponent() : void
      {
         var _loc1_:Class = getDefinitionByName(RES_CLS) as Class;
         this._res = new _loc1_() as Sprite;
         this._btnClose = this._res.getChildByName("close") as SimpleButton;
         this._btnOk = this._res.getChildByName("ok") as SimpleButton;
         this._btnSave = this._res.getChildByName("btnSave") as SimpleButton;
         if(!ConfigReader.instance.debug)
         {
            this._btnSave.visible = false;
         }
      }
      
      private function initListener() : void
      {
         this._btnClose.addEventListener(MouseEvent.CLICK,this.onCloseClick);
         this._btnOk.addEventListener(MouseEvent.CLICK,this.onCloseClick);
         this._btnSave.addEventListener(MouseEvent.CLICK,this.onSave);
      }
      
      private function onSave(param1:MouseEvent) : void
      {
         var _loc2_:FileReference = new FileReference();
         _loc2_.addEventListener(Event.COMPLETE,this.completeHandler);
         _loc2_.save(BattleMessageUI.battleInfoStr,"对战信息.txt");
      }
      
      private function completeHandler(param1:Event) : void
      {
         NewDialog.showSucceedMessage("保存战斗信息成功！");
      }
      
      private function onCloseClick(param1:MouseEvent) : void
      {
         this._btnClose.removeEventListener(MouseEvent.CLICK,this.onCloseClick);
         this._btnOk.removeEventListener(MouseEvent.CLICK,this.onCloseClick);
         this._callback.apply();
      }
      
      private function addToStage() : void
      {
         ModalDialogManager.getInstance().addModalDialog(this._res);
      }
   }
}

