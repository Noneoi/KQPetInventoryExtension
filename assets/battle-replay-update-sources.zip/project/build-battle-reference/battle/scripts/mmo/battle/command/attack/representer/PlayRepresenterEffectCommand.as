package mmo.battle.command.attack.representer
{
   import flash.display.FrameLabel;
   import flash.display.MovieClip;
   import flash.geom.Point;
   import flash.system.ApplicationDomain;
   import mmo.battle.avatar.BattleAvatar;
   import mmo.battle.command.attack.consts.EffectFrameLabels;
   import mmo.battle.command.attack.consts.EffectSplitData;
   import mmo.battle.consts.BubbleConsts;
   import mmo.battle.consts.BufferConsts;
   import mmo.battle.container.BattleContainer;
   import mmo.battle.entity.BattleBase;
   import mmo.battle.entity.BattleSimpleResManager;
   import mmo.battle.helper.BattleEffectHelper;
   import mmo.battle.ui.BattleMultiHitEffectUI;
   import mmo.battle.util.BattleContentUtil;
   import mmo.battle.util.BattleUtil;
   import mmo.common.DisplayUtil;
   import mmo.interfaces.battle.avatar.AvatarPosTypes;
   import mmo.interfaces.battle.consts.AvatarActionDefine;
   import mmo.interfaces.battle.consts.AvatarEffectIds;
   import mmo.interfaces.battle.data.BattleInfo;
   import mmo.interfaces.battle.data.PlayerInfo;
   import mmo.interfaces.battle.data.RoundResult;
   import mmo.interfaces.battle.data.SkillNumResult;
   import mmo.interfaces.battle.data.SkillResult;
   import mmo.interfaces.battle.fighter.IBattleFighter;
   import mmo.interfaces.battle.player.IBattlePlayer;
   import mmo.interfaces.battleconfig.IBattleConfig;
   import mmo.interfaces.battleconfig.consts.RaceTypePriority;
   import mmo.interfaces.battleconfig.define.RaceTypeDefine;
   import mmo.interfaces.battleconfig.define.SkillDefine;
   import mmo.loader.layer.LayerManager;
   import mmo.play.camera.CameraController;
   import mmo.util.command.ISceneCommand;
   import mmo.util.command.SceneSimpleCommand;
   
   public class PlayRepresenterEffectCommand extends SceneSimpleCommand implements ISceneCommand
   {
      
      private static const RED_SCREEN_CLS:String = "mmo.battle.common.RedScreenRes";
      
      private var _content:Object;
      
      private var _domain:ApplicationDomain;
      
      private var _result:RoundResult;
      
      private var _timeline:MovieClip;
      
      private var _battle:BattleBase;
      
      private var _battleConfig:IBattleConfig;
      
      private var _sourcePlayer:IBattlePlayer;
      
      private var _sourceFighter:IBattleFighter;
      
      private var _container:BattleContainer;
      
      private var _effectSemaphore:int = 0;
      
      private var _isSourceNumResultPlayed:Boolean = false;
      
      private var _redMC:MovieClip;
      
      private var _effectSkillResultNum:int = 0;
      
      public function PlayRepresenterEffectCommand()
      {
         super();
      }
      
      override public function execute(param1:Object) : void
      {
         var _loc3_:String = null;
         this._content = param1;
         this._timeline = BattleContentUtil.getContentProperty(param1,BattleContentUtil.PN_TIME_LINE);
         this._domain = BattleContentUtil.getContentProperty(param1,BattleContentUtil.PN_DOMAIN);
         this._result = BattleContentUtil.getContentProperty(param1,BattleContentUtil.PN_ROUND_RESULT);
         this._container = BattleContentUtil.getContentProperty(param1,BattleContentUtil.PN_CONTAINER);
         if(BattleUtil.getEffectSkillResultNum(this._result.targetSkillResults) == 0)
         {
            this.succeed(this._content);
            this._content = null;
            return;
         }
         this._battle = BattleContentUtil.getContentProperty(param1,BattleContentUtil.PN_BATTLE);
         this._battleConfig = BattleContentUtil.getContentProperty(param1,BattleContentUtil.PN_BATTLE_CONFIG);
         this._sourcePlayer = BattleContentUtil.getContentProperty(param1,BattleContentUtil.PN_SOURCE_PLAYER);
         this._sourceFighter = BattleContentUtil.getContentProperty(param1,BattleContentUtil.PN_SOURCE_FIGHTER);
         var _loc2_:int = BattleContentUtil.getContentProperty(param1,BattleContentUtil.PN_EFFECT_FRAME);
         if(_loc2_ == 0)
         {
            _loc3_ = "Missing frame label \"eff\" in effect fla";
            BattleContentUtil.setContentProperty(param1,BattleContentUtil.PN_ERROR_MSG,_loc3_);
            this.fail(this._content);
            this._content = null;
            return;
         }
         this._timeline.addFrameScript(_loc2_ - 1,this.onEffectFrame);
      }
      
      private function onEffectFrame() : void
      {
         var _loc7_:SkillResult = null;
         var _loc8_:String = null;
         var _loc9_:int = 0;
         var _loc10_:IBattlePlayer = null;
         var _loc11_:IBattleFighter = null;
         var _loc12_:Boolean = false;
         var _loc13_:Number = NaN;
         var _loc14_:int = 0;
         var _loc15_:MovieClip = null;
         var _loc16_:BattleEffectHelper = null;
         var _loc17_:Object = null;
         var _loc18_:Array = null;
         var _loc19_:EffectSplitData = null;
         var _loc20_:BattleMultiHitEffectUI = null;
         var _loc21_:int = 0;
         var _loc22_:FrameLabel = null;
         var _loc23_:Array = null;
         var _loc1_:BattleSimpleResManager = BattleContentUtil.getContentProperty(this._content,BattleContentUtil.SIMPLE_RES_DATA);
         var _loc2_:SkillDefine = BattleContentUtil.getContentProperty(this._content,BattleContentUtil.PN_SKILLDEFINE);
         var _loc3_:Boolean = true;
         var _loc4_:BattleInfo = BattleContentUtil.getContentProperty(this._content,BattleContentUtil.PN_BATTLE_INFO);
         var _loc5_:int = int(this._sourceFighter.info.belong2PlayerIndex);
         var _loc6_:PlayerInfo = _loc4_.teamInfos[this._sourceFighter.needFlip ? 1 : 0].playerInfos[_loc5_];
         for each(_loc7_ in this._result.targetSkillResults)
         {
            if(_loc7_.effect)
            {
               _loc3_ = false;
               ++this._effectSkillResultNum;
               _loc8_ = _loc7_.targetPlayerName;
               _loc9_ = int(_loc7_.targetCharacterId);
               _loc10_ = this._battle.getPlayerByName(_loc8_);
               _loc11_ = _loc10_.getFighterById(_loc9_);
               _loc12_ = false;
               if(Boolean(this._result.isLastRound) && Boolean(_loc2_.hasLastEffect))
               {
                  _loc12_ = true;
               }
               _loc13_ = Number(_loc7_.numResult.finalHp);
               _loc14_ = int(_loc7_.numResult.finalPower);
               if(BattleAvatar(_loc11_.avatar).alpha == 0 && _loc13_ > 0)
               {
                  this.finalHpAndPowerHelper(_loc10_,_loc11_,_loc13_,_loc14_);
               }
               _loc15_ = _loc11_.showSkillEffect(this._result.skillId,_loc12_,this.onEffectEnd,!BattleSimpleResManager.isMyFormationByUsername(_loc6_.playerName));
               _loc16_ = new BattleEffectHelper();
               _loc17_ = _loc16_.buildContent(_loc7_.targetTeamId);
               _loc16_.handleElementsName(_loc15_,_loc17_);
               _loc18_ = _loc15_.currentLabels;
               if(_loc18_ == null || _loc18_.length == 0)
               {
                  throw new Error("Unexpected bubble label in battleeffect" + this._result.skillId);
               }
               _loc19_ = EffectSplitData.valueFrom(_loc7_,_loc18_.length);
               _loc20_ = new BattleMultiHitEffectUI(this._domain,_loc18_.length);
               _loc21_ = 0;
               while(_loc21_ < _loc18_.length)
               {
                  _loc22_ = _loc18_[_loc21_];
                  if(_loc22_.name.indexOf(EffectFrameLabels.BUBBLE) == -1)
                  {
                     --_loc20_.totalHitNum;
                  }
                  else
                  {
                     _loc23_ = new Array();
                     _loc15_.addFrameScript(_loc22_.frame - 1,this.onBubbleFrame(_loc10_,_loc11_,_loc7_,_loc19_.hpChangeArr[_loc21_],_loc19_.powerChangeArr[_loc21_],_loc20_,_loc22_.frame - 1,_loc23_,_loc19_.spChangeArr[_loc21_]));
                  }
                  _loc21_++;
               }
            }
         }
         if(_loc3_)
         {
            this.succeed(this._content);
            this._content = null;
         }
      }
      
      private function finalHpAndPowerHelper(param1:IBattlePlayer, param2:IBattleFighter, param3:Number, param4:int) : void
      {
         param2.curHp = param3;
         param2.curPower = param4;
         if(param2.curHp > 0)
         {
            param2.showUp();
         }
      }
      
      private function onEffectEnd(param1:IBattleFighter) : void
      {
         var targetFighter:IBattleFighter = param1;
         ++this._effectSemaphore;
         if(targetFighter.info.curHp <= 0)
         {
            targetFighter.fadeOut(function():*
            {
               if(targetFighter.curHp > 0)
               {
                  targetFighter.showUp();
               }
            });
         }
         if(this._sourceFighter.info.curHp <= 0)
         {
            this._sourceFighter.fadeOut(function():*
            {
               if(_sourceFighter.curHp > 0)
               {
                  _sourceFighter.showUp();
               }
            });
         }
         if(this._effectSemaphore == this._effectSkillResultNum)
         {
            BattleContentUtil.setContentProperty(this._content,BattleContentUtil.PN_TIME_LINE,this._sourceFighter.curActionTimeline);
            this.succeed(this._content);
            this._content = null;
         }
      }
      
      private function onBubbleFrame(param1:IBattlePlayer, param2:IBattleFighter, param3:SkillResult, param4:Number, param5:int, param6:BattleMultiHitEffectUI, param7:int, param8:Array, param9:Number) : Function
      {
         var targetPlayer:IBattlePlayer = param1;
         var targetFighter:IBattleFighter = param2;
         var skillResult:SkillResult = param3;
         var hpChange:Number = param4;
         var powerChange:int = param5;
         var multiHitEffectUI:BattleMultiHitEffectUI = param6;
         var frameIndex:int = param7;
         var frameRecordArr:Array = param8;
         var spChange:Number = param9;
         var fun:Function = function():void
         {
            var skillDefine:SkillDefine;
            var angle:int = 0;
            var beHitMC:MovieClip = null;
            var playerDeltaPos:Point = null;
            var tarUIPos:Point = null;
            if(frameRecordArr.indexOf(frameIndex) != -1)
            {
               return;
            }
            frameRecordArr.push(frameIndex);
            skillDefine = BattleContentUtil.getContentProperty(_content,BattleContentUtil.PN_SKILLDEFINE);
            handleHpAndPowerChanges(skillResult,targetPlayer,targetFighter,hpChange,powerChange,spChange);
            if(skillResult.miss)
            {
               targetFighter.showEffect(AvatarEffectIds.MISS,null);
               targetFighter.slideBackward(null);
            }
            else if(skillResult.immunity)
            {
               targetFighter.showEffect(AvatarEffectIds.IMMUNITY,null);
               targetFighter.slideBackward(null);
            }
            else
            {
               if(skillResult.block)
               {
                  targetFighter.showEffect(AvatarEffectIds.BLOCK_EFFECT,null);
                  targetFighter.showEffect(AvatarEffectIds.BLOCK,null);
               }
               if(skillResult.critical)
               {
                  targetFighter.showEffect(AvatarEffectIds.CRITICAL,null);
                  angle = (Math.random() - 0.5) * 180;
                  CameraController.instance.shockScreen(15,angle);
                  setRedScreen();
               }
               if(hpChange < 0)
               {
                  beHitMC = targetFighter.doAction(AvatarActionDefine.BE_HIT);
                  BattleContentUtil.setContentProperty(_content,BattleContentUtil.PN_TIME_LINE,beHitMC);
                  beHitMC.addFrameScript(beHitMC.totalFrames - 1,function():void
                  {
                     if(targetFighter.curActionId != AvatarActionDefine.BE_HIT)
                     {
                        return;
                     }
                     var _loc1_:MovieClip = targetFighter.doAction(AvatarActionDefine.STAND);
                     if(_content != null)
                     {
                        BattleContentUtil.setContentProperty(_content,BattleContentUtil.PN_TIME_LINE,_loc1_);
                     }
                  });
                  playerDeltaPos = targetFighter.avatar.getAvatarPos(AvatarPosTypes.TOP);
                  tarUIPos = new Point(targetFighter.x + playerDeltaPos.x,targetFighter.y + playerDeltaPos.y);
                  multiHitEffectUI.showOneHit(hpChange,spChange,_container,tarUIPos.x,tarUIPos.y,frameIndex);
               }
               if(skillDefine.shockScreen)
               {
                  CameraController.instance.shockScreen(15,angle);
               }
            }
         };
         return fun;
      }
      
      private function setRedScreen() : void
      {
         var resCls:Class = null;
         if(this._redMC == null)
         {
            resCls = this._domain.getDefinition(RED_SCREEN_CLS) as Class;
            this._redMC = new resCls() as MovieClip;
            this._redMC.addFrameScript(this._redMC.totalFrames - 1,function():void
            {
               DisplayUtil.stopAndRemove(_redMC);
            });
         }
         LayerManager.getFightingTop().addChild(this._redMC);
         this._redMC.gotoAndPlay(1);
      }
      
      private function handleHpAndPowerChanges(param1:SkillResult, param2:IBattlePlayer, param3:IBattleFighter, param4:Number, param5:int, param6:Number) : void
      {
         var _loc9_:Number = NaN;
         var _loc10_:Boolean = false;
         var _loc11_:int = 0;
         var _loc12_:int = 0;
         var _loc13_:RaceTypeDefine = null;
         this.playSourceSkillNumResult();
         if(param1.numResult == null)
         {
            return;
         }
         var _loc7_:Boolean = this.isIgnoreAttRestraint(param1);
         if(!_loc7_)
         {
            _loc9_ = BattleUtil.getRestraintCoefficient(this._sourceFighter,param3,this._battleConfig);
            if(_loc9_ <= this._battleConfig.weakEffRestraintCoeff)
            {
               param3.showEffect(AvatarEffectIds.WEAK_EFFECT,null);
            }
            else if(_loc9_ >= this._battleConfig.strongEffRestraintCoeff)
            {
               _loc10_ = false;
               _loc11_ = 0;
               while(_loc11_ < this._sourceFighter.info.raceTypeIds.length)
               {
                  _loc12_ = int(this._sourceFighter.info.raceTypeIds[_loc11_]);
                  _loc13_ = this._battleConfig.getRaceTypeDefineById(_loc12_);
                  if(_loc13_.priority == RaceTypePriority.GOD)
                  {
                     _loc10_ = true;
                     param3.showEffect(AvatarEffectIds.STRONG_EFFECT + _loc12_,null);
                  }
                  _loc11_++;
               }
               if(!_loc10_)
               {
                  param3.showEffect(AvatarEffectIds.STRONG_EFFECT,null);
               }
            }
         }
         if(param1.numResult.attackHps.length > 0)
         {
            if(_loc7_)
            {
               param3.showBubble(this._sourceFighter.info,param4,_loc9_ + 0.1,null);
            }
            else
            {
               param3.showBubble(this._sourceFighter.info,param4,_loc9_,null);
            }
         }
         var _loc8_:Number = Number(param3.curHp);
         param3.curHp += param4;
         param3.curSp += param6;
         param3.curPower += param5;
      }
      
      private function isIgnoreAttRestraint(param1:SkillResult) : Boolean
      {
         var _loc4_:String = null;
         var _loc5_:Array = null;
         var _loc6_:int = 0;
         var _loc2_:Array = param1.numResult.getAllChangeSetIdArrValueByProName(SkillNumResult.beforeDisplayBuff_Key);
         var _loc3_:Boolean = false;
         for each(_loc4_ in _loc2_)
         {
            _loc5_ = _loc4_.split("_");
            _loc6_ = int(_loc5_[1]);
            if(BufferConsts.Ignore_Att_Restraint_BuffIds.indexOf(_loc6_) != -1)
            {
               _loc3_ = true;
               break;
            }
         }
         return _loc3_;
      }
      
      private function playSourceSkillNumResult() : void
      {
         var _loc5_:Number = NaN;
         var _loc6_:int = 0;
         if(this._isSourceNumResultPlayed || this._result.sourceSkillNumResult == null)
         {
            return;
         }
         this._isSourceNumResultPlayed = true;
         var _loc1_:Array = this._result.sourceSkillNumResult.attackHps;
         var _loc2_:Number = Number(this._sourceFighter.curHp);
         var _loc3_:int = 0;
         while(_loc3_ < _loc1_.length)
         {
            _loc5_ = Number(_loc1_[_loc3_]);
            this._sourceFighter.showBubble(null,_loc5_,1,null,BubbleConsts.BUBBLE_INTERVAL * _loc3_);
            this._sourceFighter.curHp += _loc5_;
            _loc2_ = Number(this._sourceFighter.curHp);
            _loc3_++;
         }
         var _loc4_:Array = this._result.sourceSkillNumResult.attackPowers;
         _loc3_ = 0;
         while(_loc3_ < _loc4_.length)
         {
            _loc6_ = int(_loc4_[_loc3_]);
            this._sourceFighter.curPower += _loc6_;
            _loc3_++;
         }
      }
   }
}

