package mmo.battle.ui
{
   import flash.display.MovieClip;
   import flash.display.Sprite;
   import mmo.common.DisplayUtil;
   import mmo.interfaces.ServiceContainer;
   import mmo.interfaces.battle.data.FightPetDragonInfo;
   import mmo.interfaces.petdragon.IPetDragonService;
   import mmo.interfaces.petdragon.PetDragonIconType;
   import mmo.interfaces.petdragon.PetDragonInfo;
   
   public class PetDragonSeqIcon
   {
      
      public static const STATE_READY:int = 1;
      
      public static const STATE_FIGHTING:int = 2;
      
      public static const STATE_FINISHED:int = 3;
      
      public static const STATE_EMPTYE_PETDRAGON:int = 4;
      
      private static const ICON_WIDTH:int = 60;
      
      private var _res:Sprite;
      
      private var _index:int;
      
      private var _spIconContainer:Sprite;
      
      private var _glitteryContainer:Sprite;
      
      private var _levelContainer:Sprite;
      
      private var _mcState:MovieClip;
      
      private var _fightInfo:FightPetDragonInfo;
      
      public function PetDragonSeqIcon(param1:Sprite, param2:int)
      {
         super();
         this._res = param1;
         this._index = param2;
         this.initComponent();
      }
      
      public function setInfo(param1:FightPetDragonInfo, param2:Boolean = false) : void
      {
         var fightInfo:FightPetDragonInfo = param1;
         var needFlip:Boolean = param2;
         this._fightInfo = fightInfo;
         ServiceContainer.tryGetService(IPetDragonService,function(param1:IPetDragonService, param2:Object):void
         {
            var _loc3_:PetDragonInfo = null;
            if(_fightInfo != null && _fightInfo.getDefineId() > 0)
            {
               _loc3_ = _fightInfo.covert2PetDragonInfo();
            }
            param1.loadPetDragonIconByInfo(_loc3_,PetDragonIconType.CIRCLE,_spIconContainer,_glitteryContainer,_levelContainer);
         });
         this._glitteryContainer.scaleX = this._glitteryContainer.scaleY = 0.6;
         this._levelContainer.scaleX = this._levelContainer.scaleY = 0.6;
         if(needFlip)
         {
            this._spIconContainer.scaleX = -1;
         }
      }
      
      public function setState(param1:int) : void
      {
         this._mcState.gotoAndStop(param1);
         if(param1 == STATE_FINISHED)
         {
            DisplayUtil.applyGray(this._spIconContainer);
         }
         else
         {
            DisplayUtil.clearFilters(this._spIconContainer);
         }
      }
      
      private function initComponent() : void
      {
         this._spIconContainer = this._res.getChildByName("ic") as Sprite;
         this._mcState = this._res.getChildByName("state") as MovieClip;
         this._glitteryContainer = this._res["gc"];
         this._levelContainer = this._res["lc"];
         this._mcState.gotoAndStop(STATE_READY);
      }
   }
}

