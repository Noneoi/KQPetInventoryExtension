package mmo.battle.catchpanel
{
   import flash.display.MovieClip;
   import flash.display.SimpleButton;
   import flash.display.Sprite;
   import flash.events.EventDispatcher;
   import flash.events.MouseEvent;
   import flash.system.ApplicationDomain;
   import mmo.common.utils.panel.modaldialog.ModalDialogManager;
   import mmo.interfaces.ServiceContainer;
   import mmo.interfaces.battle.data.CatchPetInfo;
   import mmo.interfaces.battle.data.CatchPetResult;
   import mmo.interfaces.battle.entity.IBattle;
   import mmo.interfaces.pet.data.IPetDictionaryDataService;
   
   public class CatchPanel extends EventDispatcher
   {
      
      private static const CATCH_PANEL_CLS:String = "mmo.battle.common.CatchPanelRes";
      
      private static const CATCH_CARD_COUNT:int = 5;
      
      private var _res:Sprite;
      
      private var _btnClose:SimpleButton;
      
      private var _btnPickAll:SimpleButton;
      
      private var _btnShowHelp:SimpleButton;
      
      private var _arrCatchCard:Array;
      
      private var _dictionary:IPetDictionaryDataService;
      
      private var _content:Object;
      
      private var _battleId:Number;
      
      private var _closeCallback:Function;
      
      public function CatchPanel(param1:Object, param2:Function)
      {
         super();
         this._content = param1;
         this._closeCallback = param2;
         this.initService();
         this.initComponent();
         this.initData();
         this.initListener();
      }
      
      public function show() : void
      {
         ModalDialogManager.getInstance().addModalDialog(this._res);
      }
      
      public function close() : void
      {
         var _loc4_:CatchCard = null;
         ModalDialogManager.getInstance().removeModalDialog(this._res);
         var _loc1_:Array = [];
         var _loc2_:Array = [];
         var _loc3_:int = 0;
         while(_loc3_ < this._arrCatchCard.length)
         {
            _loc4_ = this._arrCatchCard[_loc3_];
            if(_loc4_.isCardClicked)
            {
               _loc1_.push(_loc4_.petInfo.id);
               _loc2_.push(_loc4_.petInfo.raceId);
            }
            _loc3_++;
         }
         if(this._closeCallback != null)
         {
            this._closeCallback.apply(null,[this._battleId,_loc1_,_loc2_]);
         }
      }
      
      private function initService() : void
      {
         this._dictionary = ServiceContainer.getService(IPetDictionaryDataService) as IPetDictionaryDataService;
      }
      
      private function initComponent() : void
      {
         var _loc4_:MovieClip = null;
         var _loc5_:CatchCard = null;
         var _loc1_:ApplicationDomain = this._content["Domain"];
         var _loc2_:Class = _loc1_.getDefinition(CATCH_PANEL_CLS) as Class;
         this._res = new _loc2_() as Sprite;
         this._btnClose = this._res.getChildByName("close") as SimpleButton;
         this._btnPickAll = this._res.getChildByName("pickall") as SimpleButton;
         this._btnShowHelp = this._res.getChildByName("help") as SimpleButton;
         this._arrCatchCard = new Array();
         var _loc3_:int = 0;
         while(_loc3_ < CATCH_CARD_COUNT)
         {
            _loc4_ = this._res.getChildByName("card" + _loc3_) as MovieClip;
            _loc5_ = new CatchCard(_loc4_,this.onCatchCardClick);
            _loc5_.setPetInfo(null);
            this._arrCatchCard.push(_loc5_);
            _loc3_++;
         }
      }
      
      private function initData() : void
      {
         var _loc5_:CatchCard = null;
         var _loc6_:CatchPetInfo = null;
         var _loc1_:CatchPetResult = this._content["CatchResult"];
         var _loc2_:IBattle = this._content["Battle"];
         var _loc3_:ApplicationDomain = this._content["Domain"];
         if(_loc1_.catchPetInfos == null)
         {
            return;
         }
         this._battleId = _loc1_.battleId;
         var _loc4_:int = 0;
         while(_loc4_ < _loc1_.catchPetInfos.length)
         {
            _loc5_ = this._arrCatchCard[_loc4_];
            _loc6_ = _loc1_.catchPetInfos[_loc4_];
            _loc5_.setPetInfo(_loc6_);
            _loc4_++;
         }
      }
      
      private function onCatchCardClick() : void
      {
         var _loc1_:CatchCard = null;
         for each(_loc1_ in this._arrCatchCard)
         {
            if(_loc1_.petInfo != null && !_loc1_.isCardClicked)
            {
               return;
            }
         }
         this.close();
      }
      
      private function initListener() : void
      {
         this._btnClose.addEventListener(MouseEvent.CLICK,this.onCloseClick);
         this._btnPickAll.addEventListener(MouseEvent.CLICK,this.onPickAllClick);
         this._btnShowHelp.addEventListener(MouseEvent.CLICK,this.onShowHelpClick);
      }
      
      private function onCloseClick(param1:MouseEvent) : void
      {
         this.close();
      }
      
      private function onPickAllClick(param1:MouseEvent) : void
      {
         var _loc2_:CatchCard = null;
         for each(_loc2_ in this._arrCatchCard)
         {
            if(_loc2_.petInfo != null)
            {
               _loc2_.isCardClicked = true;
            }
         }
         this.close();
      }
      
      private function onShowHelpClick(param1:MouseEvent) : void
      {
         var _loc2_:CatchHelpPanel = new CatchHelpPanel(this._content);
         _loc2_.show();
      }
   }
}

