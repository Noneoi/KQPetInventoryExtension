package mmo.battle.command
{
   import mmo.battle.command.playbattle.DelayCommand;
   import mmo.battle.command.playbattle.DisposeBattlefieldCommand;
   import mmo.interfaces.battle.command.IBattleCommand;
   
   public class SkipBattleCommand extends BattleCommand implements IBattleCommand
   {
      
      public function SkipBattleCommand()
      {
         super();
      }
      
      override protected function initializeMacroCommand() : void
      {
         addSubCommand(DelayCommand);
         addSubCommand(DisposeBattlefieldCommand);
         super.initializeMacroCommand();
      }
   }
}

