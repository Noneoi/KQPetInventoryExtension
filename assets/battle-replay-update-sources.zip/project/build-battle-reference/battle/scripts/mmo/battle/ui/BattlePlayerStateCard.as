package mmo.battle.ui
{
   import flash.display.MovieClip;
   import flash.display.Sprite;
   import flash.events.Event;
   import mmo.common.DisplayUtil;
   import mmo.common.utils.tips.TipsManager;
   import mmo.interfaces.IDispose;
   import mmo.interfaces.ServiceContainer;
   import mmo.interfaces.avatar.IAvatarService;
   import mmo.interfaces.battle.data.PlayerInfo;
   
   public class BattlePlayerStateCard implements IDispose
   {
      
      private static const HEAD_ICON_WIDTH:int = 55;
      
      public static const STATE_READY:int = 1;
      
      public static const STATE_FIGHTING:int = 2;
      
      public static const STATE_DEAD:int = 3;
      
      private var _cardRes:MovieClip;
      
      private var _spHeadIconContainer:MovieClip;
      
      private var _mcState:MovieClip;
      
      private var _spTipsBoard:Sprite;
      
      private var _cardIndex:int;
      
      private var _info:PlayerInfo;
      
      private var _avatarService:IAvatarService;
      
      public function BattlePlayerStateCard(param1:int, param2:MovieClip)
      {
         super();
         this._cardIndex = param1;
         this._cardRes = param2;
         this._spHeadIconContainer = this._cardRes.getChildByName("ic") as MovieClip;
         this._mcState = this._cardRes.getChildByName("s") as MovieClip;
         this._mcState.gotoAndStop(1);
         this._spTipsBoard = this._cardRes.getChildByName("tb") as Sprite;
         this._spTipsBoard.alpha = 0;
         this._avatarService = ServiceContainer.getService(IAvatarService) as IAvatarService;
      }
      
      public function setInfo(param1:PlayerInfo) : void
      {
         var headIcon:Sprite = null;
         var playerInfo:PlayerInfo = param1;
         this._info = playerInfo;
         TipsManager.getInstance().removeTips(this._spTipsBoard);
         while(this._spHeadIconContainer.numChildren > 0)
         {
            this._spHeadIconContainer.removeChildAt(0);
         }
         if(this._info == null)
         {
            this._cardRes.visible = false;
         }
         else
         {
            this._cardRes.visible = true;
            if(this._info.playerId < 0)
            {
               this._spHeadIconContainer.gotoAndStop(1 - this._info.playerId);
            }
            else
            {
               headIcon = this._avatarService.getHeadIcon(null,this._info.playerName,HEAD_ICON_WIDTH);
               this._spHeadIconContainer.addChild(headIcon);
            }
            if(this._spTipsBoard.stage == null)
            {
               this._spTipsBoard.addEventListener(Event.ADDED_TO_STAGE,function fun(param1:Event):void
               {
                  _spTipsBoard.removeEventListener(Event.ADDED_TO_STAGE,fun);
                  TipsManager.getInstance().addComplexTips(_spTipsBoard,_info.playerName,"全员战斗力：" + _info.battlePower);
               });
            }
            else
            {
               TipsManager.getInstance().addComplexTips(this._spTipsBoard,this._info.playerName,"全员战斗力：" + this._info.battlePower);
            }
         }
      }
      
      public function setState(param1:int) : void
      {
         this._mcState.gotoAndStop(param1);
         if(param1 == STATE_DEAD)
         {
            DisplayUtil.applyGray(this._spHeadIconContainer);
         }
         else
         {
            DisplayUtil.clearFilters(this._spHeadIconContainer);
         }
      }
      
      public function get info() : PlayerInfo
      {
         return this._info;
      }
      
      public function dispose() : void
      {
      }
   }
}

