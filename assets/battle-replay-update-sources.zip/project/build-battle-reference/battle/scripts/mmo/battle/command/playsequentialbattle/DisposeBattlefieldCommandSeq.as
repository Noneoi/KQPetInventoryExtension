package mmo.battle.command.playsequentialbattle
{
   import flash.events.EventDispatcher;
   import mmo.battle.entity.BattleBase;
   import mmo.battle.ui.BattleUI;
   import mmo.battle.util.BattleContentUtil;
   import mmo.common.sound.SoundManager;
   import mmo.interfaces.battle.events.BattleEvent;
   import mmo.util.command.ISceneCommand;
   import mmo.util.command.SceneSimpleCommand;
   
   public class DisposeBattlefieldCommandSeq extends SceneSimpleCommand implements ISceneCommand
   {
      
      public function DisposeBattlefieldCommandSeq()
      {
         super();
      }
      
      override public function execute(param1:Object) : void
      {
         var _loc2_:BattleBase = BattleContentUtil.getContentProperty(param1,BattleContentUtil.PN_BATTLE);
         _loc2_.autoDispose();
         var _loc3_:BattleUI = BattleContentUtil.getContentProperty(param1,BattleContentUtil.PN_UI);
         if(_loc3_ != null)
         {
            _loc3_.dispose();
         }
         var _loc4_:String = BattleContentUtil.getContentProperty(param1,BattleContentUtil.PN_ORG_MUSIC);
         SoundManager.instance.playBackgroundMusic(_loc4_);
         this.succeed(param1);
         var _loc5_:EventDispatcher = BattleContentUtil.getContentProperty(param1,BattleContentUtil.PN_EVENT_DISPATCHER);
         var _loc6_:Boolean = BattleContentUtil.getContentProperty(param1,BattleContentUtil.PN_IS_CUR_USER_WINNER);
         _loc5_.dispatchEvent(new BattleEvent(BattleEvent.ON_BATTLE_DISPOSE,{
            "isCurUserWiner":_loc6_,
            "isChangeScene":param1["isChangeScene"]
         }));
      }
   }
}

