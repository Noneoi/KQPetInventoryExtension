package mmo.battle.player
{
   import flash.display.Sprite;
   import flash.events.EventDispatcher;
   import flash.geom.Point;
   import flash.text.TextField;
   import mmo.battle.fighter.BattleFighter;
   import mmo.common.DisplayUtil;
   import mmo.interfaces.battle.consts.FormationConsts;
   import mmo.interfaces.battle.data.PlayerInfo;
   import mmo.interfaces.battle.fighter.IBattleFighter;
   import mmo.interfaces.battle.player.IBattlePlayer;
   import mmo.loader.common.datastructures.HashMap;
   
   public class BattlePlayer extends EventDispatcher implements IBattlePlayer
   {
      
      private var _content:Object;
      
      private var _info:PlayerInfo;
      
      private var _mapId2Fighter:HashMap;
      
      private var _teamLoactor:Sprite;
      
      private var _playerNameRes:Sprite;
      
      private var _txtPlayerName:TextField;
      
      private var _playerScale:Number;
      
      private var _shiftSemaphore:int;
      
      private var _shiftCallback:Function;
      
      public function BattlePlayer(param1:PlayerInfo, param2:Object, param3:Sprite)
      {
         super();
         this._info = param1;
         this._content = param2;
         this._mapId2Fighter = new HashMap();
         this._teamLoactor = param3;
      }
      
      public function get playerInfo() : PlayerInfo
      {
         return this._info;
      }
      
      public function get fighterList() : Array
      {
         return this._mapId2Fighter.getValues();
      }
      
      public function registerFighter(param1:IBattleFighter) : void
      {
         this._mapId2Fighter.add(param1.info.id,param1);
      }
      
      public function removeFighter(param1:IBattleFighter) : void
      {
         this._mapId2Fighter.remove(param1.info.id);
      }
      
      public function getFighterById(param1:int) : IBattleFighter
      {
         return this._mapId2Fighter.getValue(param1);
      }
      
      public function fadeOut() : void
      {
         var _loc1_:BattleFighter = null;
         this._info.setIsDead(true);
         for each(_loc1_ in this._mapId2Fighter.getValues())
         {
            _loc1_.avatar.fadeOut(null);
         }
         if(this._playerNameRes != null)
         {
            DisplayUtil.stopAndRemove(this._playerNameRes);
         }
      }
      
      public function shiftTo(param1:int, param2:int, param3:Function) : void
      {
         var _loc6_:IBattleFighter = null;
         var _loc7_:int = 0;
         var _loc8_:int = 0;
         var _loc9_:int = 0;
         var _loc10_:Sprite = null;
         var _loc11_:Point = null;
         var _loc12_:Point = null;
         if(this._shiftSemaphore > 0)
         {
            throw new Error("Unexpected parallel call of shiftTo()");
         }
         this._info.setCurX(param1);
         this._info.setCurY(param2);
         var _loc4_:int = param1 + param2 * FormationConsts.MAX_ROW_COUNT;
         var _loc5_:Sprite = this._teamLoactor.getChildByName("p" + _loc4_) as Sprite;
         this._shiftSemaphore = this._mapId2Fighter.length;
         this._shiftCallback = param3;
         for each(_loc6_ in this._mapId2Fighter.getValues())
         {
            _loc7_ = int(_loc6_.info.initPosX);
            _loc8_ = int(_loc6_.info.initPosY);
            _loc9_ = _loc7_ + _loc8_ * FormationConsts.MAX_ROW_COUNT;
            _loc10_ = _loc5_.getChildByName("f" + _loc9_) as Sprite;
            _loc11_ = _loc5_.localToGlobal(new Point(_loc10_.x,_loc10_.y));
            _loc6_.jumpTo(_loc11_.x,_loc11_.y,this.onFighterShiftComplete);
         }
         if(this._playerNameRes != null)
         {
            _loc12_ = _loc5_.localToGlobal(new Point(_loc5_.x + _loc5_.width / 2,_loc5_.height));
            this._playerNameRes.x = _loc12_.x;
            this._playerNameRes.y = _loc12_.y;
         }
      }
      
      private function onFighterShiftComplete() : void
      {
         --this._shiftSemaphore;
         if(this._shiftSemaphore == 0 && this._shiftCallback != null)
         {
            this._shiftCallback.apply();
            this._shiftCallback = null;
         }
      }
      
      public function set scale(param1:Number) : void
      {
         var _loc2_:IBattleFighter = null;
         this._playerScale = param1;
         for each(_loc2_ in this._mapId2Fighter.getValues())
         {
            _loc2_.scale = param1;
         }
      }
      
      public function showPlayerName(param1:Sprite, param2:Sprite) : void
      {
         this._playerNameRes = param2;
         this._txtPlayerName = this._playerNameRes.getChildByName("txt") as TextField;
         this._txtPlayerName.text = this._info.playerName;
         var _loc3_:int = this._info.initPosX + this._info.initPosY * FormationConsts.MAX_ROW_COUNT;
         var _loc4_:Sprite = this._teamLoactor.getChildByName("p" + _loc3_) as Sprite;
         var _loc5_:Sprite = _loc4_.getChildByName("f2") as Sprite;
         var _loc6_:Sprite = _loc4_.getChildByName("f8") as Sprite;
         var _loc7_:Point = _loc4_.localToGlobal(new Point((_loc5_.x + _loc6_.x) / 2,_loc5_.y));
         this._playerNameRes.x = _loc7_.x;
         this._playerNameRes.y = _loc7_.y;
         this._playerNameRes.scaleX = this._playerNameRes.scaleY = this._playerScale;
         param1.addChild(this._playerNameRes);
      }
   }
}

