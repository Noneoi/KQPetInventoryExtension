package mmo.battle.command.embed.sub
{
   import mmo.interfaces.ServiceContainer;
   import mmo.interfaces.battleconfig.define.EmbedDialogDefine;
   import mmo.interfaces.battleconfig.define.EmbedEffectDefine;
   import mmo.interfaces.npc.INpcService;
   import mmo.interfaces.npc.NpcServiceEvent;
   
   public class EmbedCommandNpcDialog extends EmbedCommandBase
   {
      
      private var _npcService:INpcService;
      
      public function EmbedCommandNpcDialog(param1:EmbedEffectDefine)
      {
         super(param1);
      }
      
      override protected function applyEmbedEffect() : void
      {
         var _loc1_:int = int(this._embedEffectDefine.params);
         var _loc2_:EmbedDialogDefine = this._config.getEmbedDialogDefine(_loc1_);
         this._npcService = ServiceContainer.getService(INpcService) as INpcService;
         this._npcService.addEventListener(NpcServiceEvent.ON_END_NPC_TALK,this.onEndNpcTalk);
         this._npcService.showNpcPanelFreelyByXml(_loc2_.context,_loc2_.npcId,_loc2_.iconId,_loc2_.showBtnOk);
      }
      
      private function onEndNpcTalk(param1:NpcServiceEvent) : void
      {
         this._npcService.removeEventListener(NpcServiceEvent.ON_END_NPC_TALK,this.onEndNpcTalk);
         --this._repeatCount;
         --playNpcCount;
         this.succeed(this._content);
      }
   }
}

