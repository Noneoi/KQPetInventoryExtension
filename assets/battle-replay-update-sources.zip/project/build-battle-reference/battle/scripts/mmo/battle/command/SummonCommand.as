package mmo.battle.command
{
   import mmo.battle.command.attack.common.AfterSequentialAttackCommand;
   import mmo.battle.command.attack.common.BeforeSequentialAttackCommand;
   import mmo.battle.command.attack.common.ShowSkillNameCommand;
   import mmo.battle.command.attack.remote.PlayRemoteActionCommand;
   import mmo.battle.command.attack.remote.RecoverActionCommand;
   import mmo.battle.command.attack.summon.PlaySummonEffectCommand;
   import mmo.interfaces.battle.command.IBattleCommand;
   
   public class SummonCommand extends BattleCommand implements IBattleCommand
   {
      
      public function SummonCommand()
      {
         super();
      }
      
      override protected function initializeMacroCommand() : void
      {
         addSubCommand(BeforeSequentialAttackCommand);
         addSubCommand(ShowSkillNameCommand);
         addParallelSubCommand([PlayRemoteActionCommand,PlaySummonEffectCommand]);
         addSubCommand(RecoverActionCommand);
         addSubCommand(AfterSequentialAttackCommand);
         super.initializeMacroCommand();
      }
   }
}

