package mmo.battle.ui
{
   import flash.display.MovieClip;
   import flash.display.Sprite;
   import mmo.util.component.artnumber.ArtNumberManager;
   
   public class BattleNumUI
   {
      
      private var _resSprite:Sprite;
      
      private var _numArray:Array;
      
      private var _num:int;
      
      public function BattleNumUI(param1:Sprite)
      {
         var _loc3_:MovieClip = null;
         this._numArray = [];
         super();
         this._resSprite = param1;
         var _loc2_:int = 0;
         while(_loc2_ < 3)
         {
            _loc3_ = this._resSprite.getChildByName("num" + _loc2_) as MovieClip;
            if(_loc3_ != null)
            {
               this._numArray.push(_loc3_);
            }
            _loc2_++;
         }
      }
      
      public function show(param1:Sprite) : void
      {
         param1.addChild(this._resSprite);
      }
      
      public function setNum(param1:int) : void
      {
         this._num = param1;
         ArtNumberManager.setNumber(this._numArray,this._num);
      }
      
      public function increase() : void
      {
         ++this._num;
         ArtNumberManager.setNumber(this._numArray,this._num);
      }
      
      public function get resSprite() : Sprite
      {
         return this._resSprite;
      }
      
      public function setVisible(param1:Boolean) : BattleNumUI
      {
         this._resSprite.visible = param1;
         return this;
      }
      
      public function setXY(param1:Number, param2:Number) : BattleNumUI
      {
         this._resSprite.x = param1;
         this._resSprite.y = param2;
         return this;
      }
   }
}

