package mmo.battle.ui
{
   import flash.display.Sprite;
   import flash.system.ApplicationDomain;
   import mmo.common.NumberUtil;
   
   public class BattleMultiHitEffectDamageUI
   {
      
      private var _domain:ApplicationDomain;
      
      private var _unitCls:String;
      
      private var _numCls:String;
      
      private var _resSprite:Sprite;
      
      public function BattleMultiHitEffectDamageUI(param1:ApplicationDomain, param2:String, param3:String)
      {
         super();
         this._domain = param1;
         this._unitCls = param2;
         this._numCls = param3;
         this.init();
      }
      
      public function show(param1:Sprite) : void
      {
         if(this._resSprite)
         {
            param1.addChild(this._resSprite);
         }
      }
      
      private function init() : void
      {
         var _loc1_:Class = this._domain.getDefinition(this._unitCls) as Class;
         this._resSprite = new _loc1_() as Sprite;
      }
      
      public function setDamage(param1:Number) : void
      {
         var _loc2_:Class = this._domain.getDefinition(this._numCls) as Class;
         var _loc3_:Sprite = new _loc2_() as Sprite;
         var _loc4_:Sprite = NumberUtil.instance.getArtNum2(_loc3_,param1,5,true,this._domain);
         _loc4_.x = -_loc4_.width / 2;
         this._resSprite.addChild(_loc4_);
      }
   }
}

