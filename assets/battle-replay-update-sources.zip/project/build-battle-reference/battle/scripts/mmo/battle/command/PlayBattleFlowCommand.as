package mmo.battle.command
{
   import mmo.battle.command.playbattle.ClearSceneCommand;
   import mmo.battle.command.playbattle.CloseLoaderCommand;
   import mmo.battle.command.playbattle.DisposeBattlefieldCommand;
   import mmo.battle.command.playbattle.DownloadBackgroundCommand;
   import mmo.battle.command.playbattle.DownloadCardFaceCommand;
   import mmo.battle.command.playbattle.DownloadCommonResCommand;
   import mmo.battle.command.playbattle.DownloadConfigCommand;
   import mmo.battle.command.playbattle.DownloadFighterCommand;
   import mmo.battle.command.playbattle.DownloadItemCommand;
   import mmo.battle.command.playbattle.DownloadLoadingStyleCommand;
   import mmo.battle.command.playbattle.NotifyGainCoolPetStoneCommand;
   import mmo.battle.command.playbattle.NotifyRidingHungryCommand;
   import mmo.battle.command.playbattle.RealDownloadCommand;
   import mmo.battle.command.playbattle.SetupBattleMusicCommand;
   import mmo.battle.command.playbattle.SetupBattlefieldCommand;
   import mmo.battle.command.playbattle.SetupFighterCommand;
   import mmo.battle.command.playbattle.SetupNumCommand;
   import mmo.battle.command.playbattle.SetupUICommand;
   import mmo.battle.command.playbattle.ShowItemResultCommand;
   import mmo.battle.command.playbattle.StartBattleFlowCommand;
   import mmo.interfaces.battle.command.IBattleCommand;
   
   public class PlayBattleFlowCommand extends BattleCommand implements IBattleCommand
   {
      
      public function PlayBattleFlowCommand()
      {
         super();
      }
      
      override protected function initializeMacroCommand() : void
      {
         addSubCommand(ClearSceneCommand);
         addSubCommand(DownloadConfigCommand);
         addSubCommand(DownloadCommonResCommand);
         addSubCommand(DownloadBackgroundCommand);
         addSubCommand(DownloadFighterCommand);
         addSubCommand(DownloadItemCommand);
         addSubCommand(DownloadLoadingStyleCommand);
         addSubCommand(DownloadCardFaceCommand);
         addSubCommand(RealDownloadCommand);
         addSubCommand(SetupBattleMusicCommand);
         addSubCommand(SetupBattlefieldCommand);
         addSubCommand(SetupNumCommand);
         addSubCommand(SetupUICommand);
         addSubCommand(SetupFighterCommand);
         addSubCommand(ShowItemResultCommand);
         addSubCommand(CloseLoaderCommand);
         addSubCommand(StartBattleFlowCommand);
         addSubCommand(NotifyRidingHungryCommand);
         addSubCommand(NotifyGainCoolPetStoneCommand);
         addSubCommand(DisposeBattlefieldCommand);
         super.initializeMacroCommand();
      }
   }
}

