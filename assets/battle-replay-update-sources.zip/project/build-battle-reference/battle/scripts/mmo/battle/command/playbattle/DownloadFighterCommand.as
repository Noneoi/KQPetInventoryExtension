package mmo.battle.command.playbattle
{
   import com.adobe.utils.StringUtil;
   import mmo.battle.entity.BattleBase;
   import mmo.battle.entity.BattleSimpleResManager;
   import mmo.battle.util.BattleContentUtil;
   import mmo.battle.util.BattleUtil;
   import mmo.common.dialog.NewDialog;
   import mmo.interfaces.ServiceContainer;
   import mmo.interfaces.battle.data.BattleFlow;
   import mmo.interfaces.battle.data.BattleInfo;
   import mmo.interfaces.battle.data.BattleUnit;
   import mmo.interfaces.battle.data.BufferData;
   import mmo.interfaces.battle.data.FightPetDragonInfo;
   import mmo.interfaces.battle.data.FighterInfo;
   import mmo.interfaces.battle.data.PlayerInfo;
   import mmo.interfaces.battle.data.RoundResult;
   import mmo.interfaces.battle.data.SkillNumResult;
   import mmo.interfaces.battle.data.SkillNumUnit;
   import mmo.interfaces.battle.data.SkillNumUnitTransform;
   import mmo.interfaces.battle.data.SkillResult;
   import mmo.interfaces.battle.data.TeamInfo;
   import mmo.interfaces.battleconfig.IBattleConfig;
   import mmo.interfaces.battleconfig.consts.RaceTypePriority;
   import mmo.interfaces.battleconfig.consts.SkillTypes;
   import mmo.interfaces.battleconfig.define.ActionMovieDefine;
   import mmo.interfaces.battleconfig.define.BufferDefine;
   import mmo.interfaces.battleconfig.define.BufferExecuteDefine;
   import mmo.interfaces.battleconfig.define.RaceTypeDefine;
   import mmo.interfaces.battleconfig.define.SkillDefine;
   import mmo.interfaces.battleconfig.define.SummonDefine;
   import mmo.interfaces.pet.data.IPetDictionaryDataService;
   import mmo.interfaces.pet.data.PetDictionaryDataItem;
   import mmo.loader.FileType;
   import mmo.loader.error.InspectorErrorLog;
   import mmo.loader.error.InspectorErrorWatch;
   import mmo.play.globalfunctions.forSvc;
   import mmo.util.command.ISceneCommand;
   import mmo.util.command.SceneSimpleCommand;
   
   public class DownloadFighterCommand extends SceneSimpleCommand implements ISceneCommand
   {
      
      private static const PETTITLE_FILE_PREFIX:String = "pettitle/movie/pettitlemovie";
      
      private static const SIMPLE_EFFECT_FILE_PREFIX:String = "battle/simpleeffect/";
      
      private const ACTION_FILE_PREFIX:String = "battleaction/action";
      
      private const EFFECT_FILE_PREFIX:String = "battleeffect/effect";
      
      private const BUFFER_FILE_PREFIX:String = "battlebuffer/buffer";
      
      private const SUMMON_FILE_PREFIX:String = "battlesummon/summon";
      
      private const CHANGEAVATAR_FILE_PREFIX:String = "battlechangeavatar/battlechangeavatar";
      
      private const BUFFERSTATE_FILE_PREFIX:String = "bufferstate/bufferstatemovie";
      
      private const SPINE_ACTION_FILE:String = "battleaction/action%d.aqz";
      
      private const SPINE_FOREGROUND_FILE:String = "battleaction/fullscreen/foreground%d_%d.aqz";
      
      private const SPINE_BACKGROUND_FILE:String = "battleaction/fullscreen/background%d_%d.aqz";
      
      private const SPINE_EFFECT_FILE:String = "battleeffect/effect%d.aqz";
      
      private const SPINE_BUFFER_FILE:String = "battlebuffer/buffer%d.aqz";
      
      private const SPINE_SUMMON_FILE:String = "battlesummon/summon%d.aqz";
      
      private var _content:Object;
      
      private var _config:IBattleConfig;
      
      private var _zipUrls:Array;
      
      public function DownloadFighterCommand()
      {
         super();
      }
      
      override public function execute(param1:Object) : void
      {
         var content:Object = param1;
         this._content = content;
         this._config = BattleContentUtil.getContentProperty(content,BattleContentUtil.PN_BATTLE_CONFIG);
         this._zipUrls = [];
         BattleContentUtil.addToPreDownloadList(content,this.getDownloadFileList().concat(this._zipUrls.map(function(param1:String, param2:int, param3:Array):Object
         {
            return {
               "url":param1,
               "type":FileType.AQZ
            };
         })));
         this.succeed(content);
      }
      
      private function getDownloadFileList() : Array
      {
         var _loc17_:int = 0;
         var _loc18_:Array = null;
         var _loc19_:Array = null;
         var _loc20_:Array = null;
         var _loc21_:Array = null;
         var _loc22_:Array = null;
         var _loc23_:FightPetDragonInfo = null;
         var _loc24_:Array = null;
         var _loc25_:BufferData = null;
         var _loc26_:BufferData = null;
         var _loc27_:BufferDefine = null;
         var _loc28_:BufferDefine = null;
         var _loc29_:BufferExecuteDefine = null;
         var _loc30_:int = 0;
         var _loc31_:BufferExecuteDefine = null;
         var _loc1_:BattleInfo = BattleContentUtil.getContentProperty(this._content,BattleContentUtil.PN_BATTLE_INFO);
         var _loc2_:Object = this.getFileList(_loc1_.getTeamInfoById(0));
         var _loc3_:Array = _loc2_["action"];
         var _loc4_:Array = _loc2_["effect"];
         var _loc5_:Array = _loc2_["pfbuff"];
         var _loc6_:Array = _loc2_["other"];
         var _loc7_:Object = this.getFileList(_loc1_.getTeamInfoById(1));
         var _loc8_:Array = _loc7_["action"];
         var _loc9_:Array = _loc7_["effect"];
         var _loc10_:Array = _loc7_["pfbuff"];
         var _loc11_:Array = _loc7_["other"];
         var _loc12_:Array = BattleUtil.mergeArray(_loc3_,_loc8_);
         var _loc13_:Array = BattleUtil.mergeArray(_loc4_,_loc9_);
         var _loc14_:Array = BattleUtil.mergeArray(_loc6_,_loc11_);
         var _loc15_:Array = BattleUtil.mergeArray(_loc5_,_loc10_);
         var _loc16_:Array = BattleContentUtil.getContentProperty(this._content,BattleContentUtil.PN_BUFFER_NEEDED);
         for each(_loc17_ in _loc16_)
         {
            _loc28_ = this._config.getBufferDefineById(int(_loc17_));
            _loc29_ = this._config.getBufferExecutDefine(_loc17_);
            if(_loc28_ == null)
            {
               if(_loc29_ == null)
               {
                  if(_loc17_ >= 200001)
                  {
                     throw new Error("Missing 【bufferId = " + _loc17_ + "】 in player-buffer-execute.xml");
                  }
                  throw new Error("Missing buffer config【bufferId = " + _loc17_ + "】");
               }
               throw new Error("Missing buffer config【bufferId = " + _loc17_ + "】");
            }
            if(!_loc28_.hidden && !this.isSkipBuffEffect(_loc28_))
            {
               if(_loc28_.isSpine)
               {
                  this.addToArrayHelper(this._zipUrls,StringUtil.format(this.SPINE_BUFFER_FILE,_loc28_.displayId));
               }
               else
               {
                  this.addToArrayHelper(_loc15_,this.BUFFER_FILE_PREFIX + _loc28_.displayId);
               }
            }
         }
         _loc18_ = [];
         _loc19_ = [];
         _loc20_ = _loc1_.teamInfos[0].playerInfos[0].fightPetDragonInfos;
         _loc21_ = _loc1_.teamInfos[1].playerInfos[0].fightPetDragonInfos;
         _loc22_ = _loc20_.concat(_loc21_.concat());
         for each(_loc23_ in _loc22_)
         {
            if(_loc23_ != null && _loc23_.getDragonId() > 0)
            {
               _loc30_ = int(_loc23_.getExecuteBufferId());
               _loc31_ = this._config.getBufferExecutDefine(_loc30_);
               if(_loc23_.isGlittery())
               {
                  _loc19_.push(this.EFFECT_FILE_PREFIX + _loc31_.lightedSkillId);
               }
               else
               {
                  _loc19_.push(this.EFFECT_FILE_PREFIX + _loc31_.skillId);
               }
               _loc18_.push(this.ACTION_FILE_PREFIX + _loc31_.actionResId);
            }
         }
         _loc12_ = BattleUtil.mergeArray(_loc12_,_loc18_);
         _loc13_ = BattleUtil.mergeArray(_loc13_,_loc19_);
         _loc15_.push(this.BUFFER_FILE_PREFIX + this._config.getDefaultPowerFullBuffId());
         _loc24_ = [];
         _loc25_ = _loc1_.teamInfos[0].playerInfos[0].psychicsBuffData;
         _loc26_ = _loc1_.teamInfos[1].playerInfos[0].psychicsBuffData;
         if(_loc25_)
         {
            _loc27_ = this._config.getBufferDefineById(_loc25_.bufferId);
            _loc24_.push(this.BUFFERSTATE_FILE_PREFIX + _loc27_.displayId);
         }
         if(_loc26_)
         {
            _loc27_ = this._config.getBufferDefineById(_loc26_.bufferId);
            _loc24_.push(this.BUFFERSTATE_FILE_PREFIX + _loc27_.displayId);
         }
         return _loc12_.concat(_loc13_).concat(_loc15_).concat(_loc6_).concat(_loc24_);
      }
      
      private function isSkipBuffEffect(param1:BufferDefine) : Boolean
      {
         var _loc2_:IBattleConfig = BattleContentUtil.getContentProperty(this._content,BattleContentUtil.PN_BATTLE_CONFIG);
         var _loc3_:BufferExecuteDefine = _loc2_.getBufferExecutDefine(param1.id);
         if(_loc3_ != null && _loc3_.maxValue > 0)
         {
            return true;
         }
         var _loc4_:BattleSimpleResManager = BattleContentUtil.getContentProperty(this._content,BattleContentUtil.SIMPLE_RES_DATA);
         if(_loc4_.isSimpleRes && Boolean(param1.isSkipWhenSimpleBattleRes))
         {
            return true;
         }
         if(BattleContentUtil.checkIsBuffSkip(param1.buffEffect))
         {
            return true;
         }
         return false;
      }
      
      private function getSimpleEffectFileName(param1:int) : String
      {
         var _loc5_:String = null;
         var _loc10_:int = 0;
         var _loc11_:RaceTypeDefine = null;
         var _loc2_:int = int(SkillDefine.getRaceIdBySkillId(param1));
         var _loc3_:IPetDictionaryDataService = forSvc(IPetDictionaryDataService);
         var _loc4_:PetDictionaryDataItem = _loc3_.getDataItemByRaceId(_loc2_);
         if(_loc4_ == null)
         {
            _loc5_ = "00";
         }
         else
         {
            _loc10_ = int(PetDictionaryDataItem.getMainAttribute([_loc4_.attribute1,_loc4_.attribute2]));
            _loc11_ = this._config.getRaceTypeDefineById(_loc10_);
            _loc5_ = (_loc11_.id % 100).toString();
            if(_loc11_.priority == RaceTypePriority.NORMAL || _loc5_.length < 2)
            {
               _loc5_ = "00";
            }
         }
         var _loc6_:SkillDefine = this._config.getSkillDefineById(param1);
         var _loc7_:String = _loc6_.type == SkillTypes.CLOSE ? "close" : "remote";
         var _loc8_:String = _loc6_.type == SkillTypes.CLOSE ? "c" : "r";
         var _loc9_:Boolean = _loc6_.functionalType == "治疗";
         if((_loc9_) || _loc5_ == "00")
         {
            if(_loc6_.isSpine)
            {
               return StringUtil.format(this.SPINE_EFFECT_FILE,SkillDefine.getOrigSkillId(param1));
            }
            return this.EFFECT_FILE_PREFIX + SkillDefine.getOrigSkillId(param1);
         }
         if(param1.toString().charAt(0) == "1")
         {
            return SIMPLE_EFFECT_FILE_PREFIX + _loc7_ + "/effect100000" + _loc8_ + _loc5_;
         }
         if(param1.toString().charAt(0) == "2")
         {
            return SIMPLE_EFFECT_FILE_PREFIX + _loc7_ + "/effect200000" + _loc8_ + _loc5_;
         }
         return "";
      }
      
      private function checkShouldDownloadSimpleResBySkillId(param1:int) : Boolean
      {
         var _loc2_:BattleSimpleResManager = BattleContentUtil.getContentProperty(this._content,BattleContentUtil.SIMPLE_RES_DATA);
         if(_loc2_.isSimpleRes)
         {
            return true;
         }
         var _loc3_:int = int(SkillDefine.getRaceIdBySkillId(param1));
         return _loc2_.checkShouldBeSimpleResByRaceId(_loc3_);
      }
      
      private function checkShouldDownloadSimpleResByPlayerName(param1:String) : Boolean
      {
         var _loc2_:BattleSimpleResManager = BattleContentUtil.getContentProperty(this._content,BattleContentUtil.SIMPLE_RES_DATA);
         if(_loc2_.isOnlyEnemySimpleRes && !BattleSimpleResManager.isMyFormationByUsername(param1))
         {
            return true;
         }
         return false;
      }
      
      private function getFileList(param1:TeamInfo) : Object
      {
         var otherList:Array = null;
         var playerInfo:PlayerInfo = null;
         var battleFlow:BattleFlow = null;
         var battleBase:BattleBase = null;
         var battleUnit:BattleUnit = null;
         var fighterInfo:FighterInfo = null;
         var pwBuffId:int = 0;
         var pwBufferDefine:BufferDefine = null;
         var pfBuffURL:String = null;
         var titleIds:Array = null;
         var roundResult:RoundResult = null;
         var numUnitList:Array = null;
         var srcNumResult:SkillNumResult = null;
         var skillId:int = 0;
         var downloadSimpleFlag:Boolean = false;
         var skillUrl:String = null;
         var skillDefine:SkillDefine = null;
         var isSummon:Boolean = false;
         var skillResult:SkillResult = null;
         var petDictDataSvc:IPetDictionaryDataService = null;
         var numUnit:SkillNumUnit = null;
         var simpleEffectFile:String = null;
         var problemFighter:FighterInfo = null;
         var counterSkillResult:SkillResult = null;
         var fighter:FighterInfo = null;
         var counterSkillId:int = 0;
         var simpleCounterSkillEffectFile:String = null;
         var counterSkillDefine:SkillDefine = null;
         var summonFighter:FighterInfo = null;
         var sourceFighter:FighterInfo = null;
         var sourceRaceId:int = 0;
         var summonedPetRaceId:int = 0;
         var summonDefine:SummonDefine = null;
         var transform:SkillNumUnitTransform = null;
         var simpleTransformEffectFile:String = null;
         var transformSkillDefine:SkillDefine = null;
         var teamInfo:TeamInfo = param1;
         var actionFileList:Array = [];
         var effectFileList:Array = [];
         var powerFullList:Array = [];
         otherList = [];
         for each(playerInfo in teamInfo.playerInfos)
         {
            for each(fighterInfo in playerInfo.fighterInfos)
            {
               this.addActionFile(fighterInfo.faceId,actionFileList);
               pwBuffId = int(this._config.getPowerFullBuffId(fighterInfo.faceId));
               pwBufferDefine = this._config.getBufferDefineById(pwBuffId);
               pfBuffURL = this.BUFFER_FILE_PREFIX + pwBufferDefine.displayId;
               this.addToArrayHelper(powerFullList,pfBuffURL);
               if(fighterInfo.petTitleData)
               {
                  titleIds = fighterInfo.petTitleData.getTitleIds();
                  titleIds.forEach(function(param1:int, ... rest):*
                  {
                     var _loc3_:String = PETTITLE_FILE_PREFIX + param1;
                     addToArrayHelper(otherList,_loc3_);
                  });
               }
            }
         }
         battleFlow = BattleContentUtil.getContentProperty(this._content,BattleContentUtil.PN_BATTLE_FLOW);
         battleBase = BattleContentUtil.getContentProperty(this._content,BattleContentUtil.PN_BATTLE);
         for each(battleUnit in battleFlow.battleUnits)
         {
            for each(roundResult in battleUnit.roundResults)
            {
               numUnitList = [];
               srcNumResult = roundResult.sourceSkillNumResult;
               numUnitList = numUnitList.concat(srcNumResult.allBeforeNumUnit);
               numUnitList = numUnitList.concat(srcNumResult.allAfterNumUnit);
               skillId = int(roundResult.skillId);
               downloadSimpleFlag = false;
               if(this.checkShouldDownloadSimpleResBySkillId(skillId) || this.checkShouldDownloadSimpleResByPlayerName(roundResult.sourcePlayerName))
               {
                  simpleEffectFile = this.getSimpleEffectFileName(skillId);
                  if(simpleEffectFile)
                  {
                     if(this.isZip(simpleEffectFile))
                     {
                        this.addToArrayHelper(this._zipUrls,simpleEffectFile);
                     }
                     else
                     {
                        this.addToArrayHelper(effectFileList,simpleEffectFile);
                     }
                     downloadSimpleFlag = true;
                  }
               }
               skillDefine = this._config.getSkillDefineById(skillId);
               if(skillDefine.isSpine)
               {
                  skillUrl = StringUtil.format(this.SPINE_EFFECT_FILE,skillId);
               }
               else
               {
                  skillUrl = this.EFFECT_FILE_PREFIX + skillId;
               }
               if(this._config.getSkillDefineById(skillId) == null)
               {
                  isSummon = false;
               }
               else
               {
                  isSummon = this._config.getSkillDefineById(skillId).type2 == SkillTypes.SUMMON ? true : false;
               }
               if(skillId == 0)
               {
                  problemFighter = battleBase.battleResult.battleInfo.getTeamInfoById(roundResult.sourceTeamId).getPlayerInfoByName(roundResult.sourcePlayerName).getFighterInfoById(roundResult.sourceCharacterId);
                  this.recordErrorMsg("DownloadFighterCommand 技能ID==0的种族id" + problemFighter.raceId);
               }
               if(roundResult.skillExecuteCode > 0 && !isSummon)
               {
                  if(!downloadSimpleFlag)
                  {
                     if(this.isZip(skillUrl))
                     {
                        this.addToArrayHelper(this._zipUrls,skillUrl);
                     }
                     else
                     {
                        this.addToArrayHelper(effectFileList,skillUrl);
                     }
                  }
               }
               for each(skillResult in roundResult.targetSkillResults)
               {
                  if(skillResult.counter)
                  {
                     counterSkillResult = SkillResult.genCounterResult(skillResult.targetTeamId,skillResult.targetPlayerName,skillResult.targetCharacterId,skillResult.numResult);
                     fighter = battleBase.battleResult.battleInfo.getTeamInfoById(counterSkillResult.targetTeamId).getPlayerInfoByName(counterSkillResult.targetPlayerName).getFighterInfoById(counterSkillResult.targetCharacterId);
                     counterSkillId = int(fighter.normalSkill);
                     if(this.checkShouldDownloadSimpleResBySkillId(counterSkillId) || this.checkShouldDownloadSimpleResByPlayerName(roundResult.sourcePlayerName))
                     {
                        simpleCounterSkillEffectFile = this.getSimpleEffectFileName(counterSkillId);
                        if(simpleCounterSkillEffectFile)
                        {
                           this.addToArrayHelper(effectFileList,simpleCounterSkillEffectFile);
                        }
                     }
                     else
                     {
                        if(counterSkillId == 0)
                        {
                           this.recordErrorMsg("DownloadFighterCommand 技能ID==0的种族id[counter]" + fighter.raceId);
                        }
                        counterSkillDefine = this._config.getSkillDefineById(counterSkillId);
                        if(counterSkillDefine.isSpine)
                        {
                           this.addToArrayHelper(this._zipUrls,StringUtil.format(this.SPINE_EFFECT_FILE,counterSkillId));
                        }
                        else
                        {
                           this.addToArrayHelper(effectFileList,this.EFFECT_FILE_PREFIX + counterSkillId);
                        }
                     }
                  }
                  if(isSummon && Boolean(skillResult.effect))
                  {
                     summonFighter = battleBase.battleResult.battleInfo.getTeamInfoById(skillResult.targetTeamId).getPlayerInfoByName(skillResult.targetPlayerName).getFighterInfoById(skillResult.targetCharacterId);
                     sourceFighter = battleBase.battleResult.battleInfo.getTeamInfoById(roundResult.sourceTeamId).getPlayerInfoByName(roundResult.sourcePlayerName).getFighterInfoById(roundResult.sourceCharacterId);
                     sourceRaceId = int(sourceFighter.originalRaceId);
                     summonedPetRaceId = int(summonFighter.originalRaceId);
                     summonDefine = this._config.getSummonDefine(sourceRaceId,summonedPetRaceId);
                     if(summonDefine == null)
                     {
                        NewDialog.showMessage("召唤技能定义为空！sourceFighter.raceId:" + sourceRaceId + ", summonFighter.raceId:" + summonedPetRaceId);
                     }
                     if(skillDefine.isSpine)
                     {
                        this.addToArrayHelper(this._zipUrls,StringUtil.format(this.SPINE_SUMMON_FILE,summonDefine.effect));
                     }
                     else
                     {
                        this.addToArrayHelper(effectFileList,this.SUMMON_FILE_PREFIX + summonDefine.effect);
                     }
                  }
                  numUnitList = numUnitList.concat(skillResult.numResult.allBeforeNumUnit);
                  numUnitList = numUnitList.concat(skillResult.numResult.allAfterNumUnit);
               }
               petDictDataSvc = ServiceContainer.getService(IPetDictionaryDataService);
               for each(numUnit in numUnitList)
               {
                  transform = numUnit as SkillNumUnitTransform;
                  if(transform != null)
                  {
                     if(petDictDataSvc.getDataItemByRaceId(transform.curRaceId).desc != "内测")
                     {
                        this.addActionFile(transform.curFaceId,actionFileList);
                        if(this.checkShouldDownloadSimpleResBySkillId(transform.normalSkillId) || this.checkShouldDownloadSimpleResByPlayerName(roundResult.sourcePlayerName))
                        {
                           simpleTransformEffectFile = this.getSimpleEffectFileName(transform.normalSkillId);
                           if(simpleTransformEffectFile)
                           {
                              if(this.isZip(simpleTransformEffectFile))
                              {
                                 this.addToArrayHelper(this._zipUrls,simpleTransformEffectFile);
                              }
                              else
                              {
                                 this.addToArrayHelper(effectFileList,simpleTransformEffectFile);
                              }
                           }
                        }
                        else
                        {
                           transformSkillDefine = this._config.getSkillDefineById(transform.normalSkillId);
                           if(transformSkillDefine.isSpine)
                           {
                              this.addToArrayHelper(this._zipUrls,StringUtil.format(this.SPINE_EFFECT_FILE,transform.normalSkillId));
                           }
                           else
                           {
                              this.addToArrayHelper(effectFileList,this.EFFECT_FILE_PREFIX + transform.normalSkillId);
                           }
                        }
                        pwBuffId = int(this._config.getPowerFullBuffId(transform.curFaceId));
                        pwBufferDefine = this._config.getBufferDefineById(pwBuffId);
                        this.addToArrayHelper(powerFullList,this.BUFFER_FILE_PREFIX + pwBufferDefine.displayId);
                        if(this._config.changeAvatarIds.indexOf(transform.curFaceId) != -1)
                        {
                           this.addToArrayHelper(otherList,this.CHANGEAVATAR_FILE_PREFIX + transform.curFaceId);
                        }
                        else
                        {
                           this.addToArrayHelper(otherList,this.CHANGEAVATAR_FILE_PREFIX + "_default");
                        }
                     }
                  }
               }
            }
         }
         return {
            "action":actionFileList,
            "effect":effectFileList,
            "pfbuff":powerFullList,
            "other":otherList
         };
      }
      
      private function recordErrorMsg(param1:String) : void
      {
         var _loc2_:InspectorErrorLog = new InspectorErrorLog(new Error(param1));
         InspectorErrorWatch.instance.addErrorLog(_loc2_);
      }
      
      private function addToArrayHelper(param1:Array, param2:String) : void
      {
         if(param1.indexOf(param2) == -1)
         {
            param1.push(param2);
         }
      }
      
      private function addActionFile(param1:int, param2:Array) : void
      {
         var _loc5_:Array = null;
         var _loc6_:int = 0;
         var _loc7_:Boolean = false;
         var _loc3_:Boolean = false;
         var _loc4_:ActionMovieDefine = this._config.getActionMovieDefineById(param1);
         if(_loc4_)
         {
            if(_loc4_.isSpine)
            {
               this.addToArrayHelper(this._zipUrls,StringUtil.format(this.SPINE_ACTION_FILE,param1));
            }
            else
            {
               _loc3_ = true;
            }
            for each(_loc5_ in _loc4_.foreground)
            {
               _loc6_ = int(_loc5_[0]);
               _loc7_ = _loc5_[1] == 1;
               if(_loc7_)
               {
                  this.addToArrayHelper(this._zipUrls,StringUtil.format(this.SPINE_FOREGROUND_FILE,param1,_loc6_));
               }
               else
               {
                  _loc3_ = true;
               }
            }
            for each(_loc5_ in _loc4_.background)
            {
               _loc6_ = int(_loc5_[0]);
               _loc7_ = _loc5_[1] == 1;
               if(_loc7_)
               {
                  this.addToArrayHelper(this._zipUrls,StringUtil.format(this.SPINE_BACKGROUND_FILE,param1,_loc6_));
               }
               else
               {
                  _loc3_ = true;
               }
            }
         }
         else
         {
            _loc3_ = true;
         }
         if(_loc3_)
         {
            this.addToArrayHelper(param2,this.ACTION_FILE_PREFIX + param1);
         }
      }
      
      private function isZip(param1:String) : Boolean
      {
         return param1.indexOf(".aqz") != -1;
      }
   }
}

