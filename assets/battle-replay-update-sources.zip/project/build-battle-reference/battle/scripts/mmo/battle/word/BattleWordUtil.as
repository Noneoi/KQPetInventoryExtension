package mmo.battle.word
{
   import mmo.battle.consts.BufferConsts;
   import mmo.interfaces.battle.data.BufferNumResult;
   
   public class BattleWordUtil
   {
      
      public function BattleWordUtil()
      {
         super();
      }
      
      public static function handleHpChangesSingle(param1:Array, param2:BattleWordFighter) : void
      {
         var _loc4_:BufferNumResult = null;
         var _loc5_:Number = NaN;
         var _loc3_:int = 0;
         while(_loc3_ < param1.length)
         {
            _loc4_ = param1[_loc3_];
            _loc5_ = Number(_loc4_.effect);
            param2.curHp += _loc5_;
            _loc3_++;
         }
      }
      
      public static function handleSpChangesSingle(param1:Array, param2:BattleWordFighter) : void
      {
         var _loc4_:BufferNumResult = null;
         var _loc5_:Number = NaN;
         var _loc3_:int = 0;
         while(_loc3_ < param1.length)
         {
            _loc4_ = param1[_loc3_];
            _loc5_ = Number(_loc4_.effect);
            param2.curSp += _loc5_;
            _loc3_++;
         }
      }
      
      public static function handlePowerChangesSingle(param1:Array, param2:BattleWordFighter) : void
      {
         var _loc4_:BufferNumResult = null;
         var _loc5_:int = 0;
         var _loc3_:int = 0;
         while(_loc3_ < param1.length)
         {
            _loc4_ = param1[_loc3_];
            _loc5_ = int(_loc4_.effect);
            param2.curPower += _loc5_;
            _loc3_++;
         }
      }
      
      public static function handleBuffChangesSingle(param1:Array, param2:Array, param3:BattleWordFighter) : void
      {
         var _loc4_:int = 0;
         for each(_loc4_ in param1)
         {
            param3.addBuff(_loc4_);
         }
      }
      
      public static function handleDisplayBuffChangesSingle(param1:Array, param2:BattleWordFighter) : void
      {
         var _loc3_:String = null;
         var _loc4_:Array = null;
         var _loc5_:int = 0;
         var _loc6_:int = 0;
         for each(_loc3_ in param1)
         {
            _loc4_ = _loc3_.split("_");
            _loc5_ = int(_loc4_[0]);
            _loc6_ = int(_loc4_[1]);
            if(_loc5_ != BufferConsts.BuffDisplayType_CLEAR)
            {
               if(_loc5_ == BufferConsts.BuffDisplayType_APPEAR)
               {
                  param2.addBuff(_loc6_);
               }
            }
         }
      }
   }
}

