package mmo.battle.fighter
{
   import flash.display.MovieClip;
   import flash.display.Sprite;
   import flash.events.Event;
   import flash.events.IEventDispatcher;
   import mmo.battle.avatar.BattleAvatar;
   import mmo.battle.avatar.BattleRepresenterAvatar;
   import mmo.battle.command.attack.representer.RepresenterRemoteAttackCommand;
   import mmo.battle.command.attack.representer.RepresenterSimpleAttackCommand;
   import mmo.battle.consts.BufferConsts;
   import mmo.battle.container.BattleContainer;
   import mmo.battle.helper.BattleBufferHelper;
   import mmo.battle.util.BattleContentUtil;
   import mmo.interfaces.battle.data.BattleInfo;
   import mmo.interfaces.battle.data.BufferData;
   import mmo.interfaces.battle.data.FightPetDragonInfo;
   import mmo.interfaces.battle.data.FighterInfo;
   import mmo.interfaces.battle.data.RoundResult;
   import mmo.interfaces.battle.events.BattlePetDragonEvent;
   import mmo.interfaces.battle.fighter.IBattleFighter;
   import mmo.interfaces.battleconfig.define.BufferExecuteDefine;
   import mmo.interfaces.battleconfig.define.SkillDefine;
   import mmo.loader.common.datastructures.HashMap;
   
   public class BattleRepresenter extends BattleFighter implements IBattleFighter
   {
      
      private var _executeBufferId:int;
      
      private var _dispatcher:IEventDispatcher;
      
      private var _bufferId2States:HashMap = new HashMap(true);
      
      private var _noNeed2InitStateBuffIds:Array = [];
      
      public function BattleRepresenter(param1:FighterInfo, param2:Object, param3:Boolean = false)
      {
         super(param1,param2,param3);
         this._dispatcher = BattleContentUtil.getContentProperty(param2,BattleContentUtil.PN_EVENT_DISPATCHER);
      }
      
      override public function attack(param1:RoundResult, param2:Function) : void
      {
         var attackCallback:Function;
         var skillId:int;
         var timeline:MovieClip;
         var skillDefine:SkillDefine;
         var enableEmbedCommand:Boolean;
         var attackCmdContent:Object;
         var cmdClsRef:Class = null;
         var roundResult:RoundResult = param1;
         var callback:Function = param2;
         var bufferExecuteDefine:BufferExecuteDefine = this._battleConfig.getBufferExecutDefine(roundResult.executeBufferId);
         var playerBuffType:int = this.getPlayerBuffType(bufferExecuteDefine);
         if(playerBuffType == BufferConsts.PLAYER_BUFF_EXECUTE)
         {
            this.changeBattleRepresenterInfo(roundResult,bufferExecuteDefine);
            cmdClsRef = RepresenterRemoteAttackCommand;
         }
         else
         {
            cmdClsRef = RepresenterSimpleAttackCommand;
         }
         attackCallback = function():*
         {
            setupNumUI(roundResult);
            if(roundResult.executePetDragonIds.length > 0)
            {
               _dispatcher.dispatchEvent(new BattlePetDragonEvent(BattlePetDragonEvent.PET_DRAGON_ATTACK_FINISHED,{
                  "executeBufferId":roundResult.executeBufferId,
                  "executePetDragonIds":roundResult.executePetDragonIds,
                  "roundNum":roundResult.roundNum,
                  "teamId":roundResult.sourceTeamId
               }));
            }
            callback.apply();
         };
         skillId = int(_info.uniqueSkill);
         timeline = this._avatar.curActionTimeline;
         skillDefine = this._battleConfig.getSkillDefineById(skillId);
         enableEmbedCommand = true;
         attackCmdContent = this.getCloneContent(this._content);
         setupOtherParam(attackCmdContent,skillDefine,timeline,roundResult);
         executeCommand(cmdClsRef,attackCmdContent,attackCallback,enableEmbedCommand);
         setBattleRoundUI(roundResult);
      }
      
      private function changeBattleRepresenterInfo(param1:RoundResult, param2:BufferExecuteDefine) : void
      {
         var _loc3_:int = this.getChangedSkillId(param1,param2);
         _info.faceId = param2.actionResId;
         _info.uniqueSkill = _loc3_;
         param1.skillId = _loc3_;
         this.resetRepresenterAvatar(param1.executeBufferId);
         this._executeBufferId = param1.executeBufferId;
      }
      
      private function resetRepresenterAvatar(param1:int) : void
      {
         var _loc2_:BattleAvatar = this._avatar;
         var _loc3_:Sprite = _loc2_.parent as Sprite;
         if(this._executeBufferId != param1)
         {
            this.resetAvatar(null);
         }
         if(_needFlip)
         {
            addToStage(_loc3_,960,0);
         }
         else
         {
            addToStage(_loc3_,0,0);
         }
      }
      
      private function getPlayerBuffType(param1:BufferExecuteDefine) : int
      {
         if(param1 != null && param1.actionResId > 0)
         {
            return BufferConsts.PLAYER_BUFF_EXECUTE;
         }
         if(param1 != null && param1.maxValue > 0)
         {
            return BufferConsts.PLAYER_BUFF_WITH_STATE;
         }
         return BufferConsts.PLAYER_BUFF_NORMAL;
      }
      
      private function getChangedSkillId(param1:RoundResult, param2:BufferExecuteDefine) : int
      {
         var _loc3_:int = 0;
         var _loc4_:BattleInfo = null;
         var _loc5_:int = 0;
         var _loc6_:Array = null;
         var _loc7_:FightPetDragonInfo = null;
         if(param1.executePetDragonIds.length > 0)
         {
            _loc4_ = BattleContentUtil.getContentProperty(_content,BattleContentUtil.PN_BATTLE_INFO);
            _loc5_ = int(_info.belong2PlayerIndex);
            _loc6_ = _loc4_.teamInfos[_needFlip ? 1 : 0].playerInfos[_loc5_].fightPetDragonInfos;
            _loc7_ = this.getFightPetDragonInfoById(int(param1.executePetDragonIds[0]),_loc6_);
            if(_loc7_.isGlittery())
            {
               _loc3_ = int(param2.lightedSkillId);
            }
            else
            {
               _loc3_ = int(param2.skillId);
            }
            this._dispatcher.dispatchEvent(new BattlePetDragonEvent(BattlePetDragonEvent.PET_DRAGON_ATTACK_START,{
               "executeBufferId":param1.executeBufferId,
               "executePetDragonIds":param1.executePetDragonIds,
               "roundNum":param1.roundNum,
               "teamId":param1.sourceTeamId
            }));
         }
         else
         {
            _loc3_ = int(param2.skillId);
         }
         return _loc3_;
      }
      
      private function getFightPetDragonInfoById(param1:int, param2:Array) : FightPetDragonInfo
      {
         var _loc4_:FightPetDragonInfo = null;
         var _loc3_:int = 0;
         while(_loc3_ < param2.length)
         {
            _loc4_ = param2[_loc3_];
            if(_loc4_ != null)
            {
               if(_loc4_.getDragonId() == param1)
               {
                  return _loc4_;
               }
            }
            _loc3_++;
         }
         return null;
      }
      
      override public function resetAvatar(param1:Function) : void
      {
         var _loc2_:BattleAvatar = this._avatar;
         var _loc3_:Sprite = _loc2_.parent as Sprite;
         var _loc4_:BattleContainer = BattleContentUtil.getContentProperty(_content,BattleContentUtil.PN_CONTAINER);
         if(this._avatar != null)
         {
            this._avatar.dispose();
            this._avatar = null;
         }
         this.setupAvatar();
         this.recoverBuffers();
         if(param1 != null)
         {
            param1.apply();
         }
      }
      
      override protected function recoverBuffers() : void
      {
         super.recoverBuffers();
      }
      
      override protected function setupAvatar() : void
      {
         var _loc1_:int = 0;
         this._avatar = new BattleRepresenterAvatar(this._info,this._content,this._needFlip);
         this._avatar.scale = _scale;
         this.curHp = this._info.curHp;
         this.curSp = this._info.curSp;
         this.curPower = this._info.curPower;
         this._avatar.resetMapBuffId2Buff();
         if(this._info.curPower >= this._info.maxPower)
         {
            _loc1_ = int(this._battleConfig.getPowerFullBuffId(this._info.faceId));
            this._avatar.addBuff(_loc1_);
         }
         if(Boolean(this._info.isSummoned) && !this._info.isSummonedCallOut)
         {
            this._avatar.summonDisappear();
         }
      }
      
      override public function addBuff(param1:int, param2:Boolean = true, param3:Function = null) : void
      {
         super.addBuff(param1,param2,param3);
         this.initBuffWithState(param1);
      }
      
      private function initBuffWithState(param1:int) : void
      {
         var _loc4_:MovieClip = null;
         var _loc5_:BattleInfo = null;
         var _loc6_:int = 0;
         var _loc7_:BufferData = null;
         var _loc8_:SkillDefine = null;
         var _loc9_:int = 0;
         var _loc2_:BufferExecuteDefine = this._battleConfig.getBufferExecutDefine(param1);
         var _loc3_:int = this.getPlayerBuffType(_loc2_);
         if(_loc3_ == BufferConsts.PLAYER_BUFF_WITH_STATE)
         {
            _loc4_ = this._avatar.getBuffMcByBuffId(param1);
            _loc5_ = BattleContentUtil.getContentProperty(_content,BattleContentUtil.PN_BATTLE_INFO);
            _loc6_ = int(_info.belong2PlayerIndex);
            _loc7_ = _loc5_.teamInfos[_needFlip ? 1 : 0].playerInfos[_loc6_].psychicsBuffData;
            if(_loc7_ != null && param1 == _loc7_.bufferId)
            {
               _loc8_ = _battleConfig.getSkillDefineById(_loc2_.skillId);
               _loc9_ = this._bufferId2States.getValue(param1) == null ? int(_loc7_.initValue) : int(this._bufferId2States.getValue(param1));
               BattleBufferHelper.setBuffProgress(_loc4_,_loc9_,_loc7_.maxValue,_loc8_);
               _loc4_.addEventListener(Event.REMOVED_FROM_STAGE,this.onRemoveFromStage);
            }
         }
      }
      
      private function onRemoveFromStage(param1:Event) : void
      {
         var _loc2_:int = int(_info.belong2PlayerIndex);
         var _loc3_:MovieClip = MovieClip(param1.currentTarget);
         _loc3_.removeEventListener(Event.REMOVED_FROM_STAGE,this.onRemoveFromStage);
         var _loc4_:int = int(_loc3_.name.split("_")[1]);
         var _loc5_:BattleInfo = BattleContentUtil.getContentProperty(_content,BattleContentUtil.PN_BATTLE_INFO);
         var _loc6_:BufferData = _loc5_.teamInfos[_needFlip ? 1 : 0].playerInfos[_loc2_].psychicsBuffData;
         var _loc7_:MovieClip = _loc3_["mcProgress"];
         var _loc8_:MovieClip = _loc7_["mcAttributes"];
         var _loc9_:int = _loc8_.width / (_loc7_.width / _loc7_.scaleX) * _loc6_.maxValue;
         this._bufferId2States.add(_loc4_,_loc9_);
      }
      
      override public function removeBuff(param1:int) : void
      {
         super.removeBuff(param1);
      }
   }
}

