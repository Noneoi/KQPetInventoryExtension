package mmo.battle.command.playbattle
{
   import mmo.battle.util.BattleContentUtil;
   import mmo.common.user.UserInfo;
   import mmo.interfaces.ServiceContainer;
   import mmo.interfaces.battle.data.BackgroundResult;
   import mmo.interfaces.battle.data.BattleInfo;
   import mmo.interfaces.battle.data.PlayerInfo;
   import mmo.interfaces.battle.data.UseItemResult;
   import mmo.interfaces.battleconfig.IBattleConfig;
   import mmo.interfaces.material.MaterialCommonData;
   import mmo.interfaces.material.battlebackground.IBattleBackgroundService;
   import mmo.util.command.ISceneCommand;
   import mmo.util.command.SceneSimpleCommand;
   
   public class DownloadBackgroundCommand extends SceneSimpleCommand implements ISceneCommand
   {
      
      public static const BACKGROUND_FILE_PREFIX:String = "battlebg/";
      
      public static const DEFAULT_BACKGROUND_POSTFIX:String = "default";
      
      public static const DEFAULT_BACKGROUND_FILE:String = BACKGROUND_FILE_PREFIX + DEFAULT_BACKGROUND_POSTFIX;
      
      public static const NEW_BACKGROUND_FILE_PREFIX:String = "battlebackground/bg";
      
      public static const NEW_DEFAULT_ID:String = "1";
      
      private var _backgroundSvc:IBattleBackgroundService = ServiceContainer.getService(IBattleBackgroundService);
      
      private var _content:Object;
      
      public function DownloadBackgroundCommand()
      {
         super();
      }
      
      override public function execute(param1:Object) : void
      {
         this._content = param1;
         var _loc2_:IBattleConfig = BattleContentUtil.getContentProperty(param1,BattleContentUtil.PN_BATTLE_CONFIG);
         var _loc3_:Array = BattleContentUtil.getPreDownloadList(param1);
         this.loadBackground();
         var _loc4_:MaterialCommonData = BattleContentUtil.getContentProperty(param1,BattleContentUtil.PN_GAIN_COOLPETSTONE_DATA);
         if(_loc4_ != null)
         {
            _loc3_.push(BACKGROUND_FILE_PREFIX + _loc2_.coolPetStoneBGInfo[_loc4_.id]);
         }
         this.succeed(param1);
      }
      
      private function loadBackground() : void
      {
         var _loc7_:* = undefined;
         var _loc8_:* = undefined;
         var _loc9_:BackgroundResult = null;
         var _loc10_:PlayerInfo = null;
         var _loc11_:Boolean = false;
         var _loc1_:IBattleConfig = BattleContentUtil.getContentProperty(this._content,BattleContentUtil.PN_BATTLE_CONFIG);
         var _loc2_:Array = BattleContentUtil.getPreDownloadList(this._content);
         var _loc3_:BattleInfo = BattleContentUtil.getContentProperty(this._content,BattleContentUtil.PN_BATTLE_INFO);
         var _loc4_:String = _loc3_.sceneName;
         var _loc5_:* = NEW_DEFAULT_ID;
         var _loc6_:UseItemResult = BattleContentUtil.getContentProperty(this._content,BattleContentUtil.PN_ITEM_RESULT);
         if(_loc6_ != null)
         {
            _loc7_ = _loc6_.backgroundResults;
            _loc8_ = 0;
            while(_loc8_ < _loc7_.length)
            {
               _loc9_ = _loc7_[_loc8_];
               _loc10_ = _loc3_.teamInfos[_loc9_.teamId].playerInfos[0];
               _loc11_ = _loc10_.playerId == UserInfo.userId && this._backgroundSvc.getDisplayPreference() == 0 || _loc10_.playerId != UserInfo.userId && this._backgroundSvc.getDisplayPreference() == 1;
               if(_loc11_)
               {
                  _loc5_ = _loc9_.serverId;
                  break;
               }
               _loc8_++;
            }
         }
         if(Boolean(this._backgroundSvc.hasBackgroundData(_loc5_)) && _loc5_ != NEW_DEFAULT_ID)
         {
            _loc2_.push(NEW_BACKGROUND_FILE_PREFIX + "_" + _loc5_);
            BattleContentUtil.setContentProperty(this._content,BattleContentUtil.BACKGROUND,_loc5_);
         }
         if(_loc1_.backgroundScenes.indexOf(_loc4_) != -1)
         {
            _loc2_.push(BACKGROUND_FILE_PREFIX + _loc4_);
         }
         else
         {
            _loc2_.push(DEFAULT_BACKGROUND_FILE);
         }
      }
      
      private function loadBg(param1:Array) : void
      {
      }
   }
}

