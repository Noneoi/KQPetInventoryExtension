package mmo.battle.command.playsequentialbattle
{
   import flash.display.Sprite;
   import flash.geom.Point;
   import flash.system.ApplicationDomain;
   import mmo.battle.command.playbattle.DownloadBackgroundCommand;
   import mmo.battle.container.BattleContainer;
   import mmo.battle.util.BattleContentUtil;
   import mmo.interfaces.ServiceContainer;
   import mmo.interfaces.battle.consts.FormationConsts;
   import mmo.interfaces.battle.data.BattleInfo;
   import mmo.interfaces.battle.data.PlayerInfo;
   import mmo.interfaces.battle.data.TeamInfo;
   import mmo.interfaces.battle.entity.IBattle;
   import mmo.interfaces.formation.FormationDefine;
   import mmo.interfaces.formation.IFormationService;
   import mmo.loader.layer.LayerManager;
   import mmo.util.command.ISceneCommand;
   import mmo.util.command.SceneSimpleCommand;
   
   public class SetupBattlefieldCommandSeq extends SceneSimpleCommand implements ISceneCommand
   {
      
      private static const DEFAULT_DIAMOND_CLS_PREFIX:String = "mmo.battle.Diamond_";
      
      private static const BACKGROUND_CLS_PREFIX:String = "mmo.battle.Background_";
      
      private static const SINGAL_LOCATOR_CLS_PREFIX:String = "mmo.battle.SingalLocator_";
      
      private static const MUTIPAL_LOCATOR_CLS_PREFIX:String = "mmo.battle.MutiLocator_";
      
      private var _content:Object;
      
      private var _battles:Array;
      
      private var _battleInfo:BattleInfo;
      
      private var _domain:ApplicationDomain;
      
      private var _container:BattleContainer;
      
      private var _locator:Sprite;
      
      private var _isMulti:Boolean;
      
      public function SetupBattlefieldCommandSeq()
      {
         super();
      }
      
      override public function execute(param1:Object) : void
      {
         this._content = param1;
         this._battles = BattleContentUtil.getContentProperty(param1,BattleContentUtil.PN_BATTLES);
         this._battleInfo = (this._battles[0] as IBattle).battleResult.battleInfo;
         this._domain = BattleContentUtil.getContentProperty(param1,BattleContentUtil.PN_DOMAIN);
         this._container = BattleContentUtil.getContentProperty(param1,BattleContentUtil.PN_CONTAINER);
         this._isMulti = BattleContentUtil.getContentProperty(param1,BattleContentUtil.PN_IS_MULTIPLAYER);
         this.switchLayer();
         this.setupBackground();
         this.setupLoactor();
         this.succeed(this._content);
         this._content = null;
      }
      
      private function switchLayer() : void
      {
         LayerManager.switchLayer(LayerManager.FIGHTING_LAYER);
         LayerManager.getFightingScene().addChild(this._container);
      }
      
      private function setupBackground() : void
      {
         var _loc1_:String = BACKGROUND_CLS_PREFIX + this._battleInfo.sceneName;
         if(!this._domain.hasDefinition(_loc1_))
         {
            _loc1_ = BACKGROUND_CLS_PREFIX + DownloadBackgroundCommand.DEFAULT_BACKGROUND_POSTFIX;
         }
         var _loc2_:Class = this._domain.getDefinition(_loc1_) as Class;
         var _loc3_:Sprite = new _loc2_() as Sprite;
         this._container.backgroundLayer.addChild(_loc3_);
      }
      
      private function setupLoactor() : void
      {
         var _loc1_:String = SINGAL_LOCATOR_CLS_PREFIX;
         if(this._isMulti)
         {
            _loc1_ = MUTIPAL_LOCATOR_CLS_PREFIX;
         }
         var _loc2_:String = _loc1_ + this._battleInfo.sceneName;
         if(!this._domain.hasDefinition(_loc2_))
         {
            _loc2_ = _loc1_ + DownloadBackgroundCommand.DEFAULT_BACKGROUND_POSTFIX;
         }
         var _loc3_:Class = this._domain.getDefinition(_loc2_) as Class;
         this._locator = new _loc3_() as Sprite;
         BattleContentUtil.setContentProperty(this._content,BattleContentUtil.PN_LOCATOR,this._locator);
      }
      
      private function setupDiamond() : void
      {
         var _loc1_:TeamInfo = null;
         var _loc2_:PlayerInfo = null;
         for each(_loc1_ in this._battleInfo.teamInfos)
         {
            for each(_loc2_ in _loc1_.playerInfos)
            {
               this.setupPlayerDiamond(_loc1_.teamId,_loc2_);
            }
         }
      }
      
      private function setupPlayerDiamond(param1:int, param2:PlayerInfo) : void
      {
         var _loc8_:int = 0;
         var _loc9_:Sprite = null;
         var _loc10_:Point = null;
         var _loc11_:Class = null;
         var _loc12_:Sprite = null;
         var _loc3_:IFormationService = ServiceContainer.getService(IFormationService) as IFormationService;
         var _loc4_:FormationDefine = _loc3_.getFormationDefine(param2.formationId,param2.formationLevel);
         var _loc5_:Sprite = this._locator.getChildByName("t" + param1) as Sprite;
         var _loc6_:int = param2.initPosX + param2.initPosY * FormationConsts.MAX_ROW_COUNT;
         var _loc7_:Sprite = _loc5_.getChildByName("p" + _loc6_) as Sprite;
         for each(_loc8_ in _loc4_.data)
         {
            _loc9_ = _loc7_.getChildByName("f" + _loc8_) as Sprite;
            _loc10_ = _loc7_.localToGlobal(new Point(_loc9_.x,_loc9_.y));
            _loc11_ = this._domain.getDefinition(DEFAULT_DIAMOND_CLS_PREFIX + param1 + _loc8_) as Class;
            _loc12_ = new _loc11_() as Sprite;
            this._container.addChildAt(_loc12_,1);
            _loc12_.x = _loc10_.x;
            _loc12_.y = _loc10_.y;
         }
      }
   }
}

