package mmo.battle.command.attack.common
{
   import mmo.battle.entity.BattleBase;
   import mmo.battle.util.BattleContentUtil;
   import mmo.battle.util.BattleUtil;
   import mmo.config.ConfigReader;
   import mmo.interfaces.battle.consts.AvatarActionDefine;
   import mmo.interfaces.battle.data.RoundResult;
   import mmo.interfaces.battle.data.SkillNumResult;
   import mmo.interfaces.battle.data.SkillResult;
   import mmo.interfaces.battle.fighter.IBattleFighter;
   import mmo.interfaces.battle.player.IBattlePlayer;
   import mmo.util.command.ISceneCommand;
   import mmo.util.command.SceneSimpleCommand;
   
   public class AfterAttackCommand extends SceneSimpleCommand implements ISceneCommand
   {
      
      private var _content:Object;
      
      private var _battle:BattleBase;
      
      private var _result:RoundResult;
      
      private var _sourcePlayer:IBattlePlayer;
      
      private var _sourceFighter:IBattleFighter;
      
      private var _curHitActionSemaphore:int;
      
      private var _curWaitBuffSemaphore:int;
      
      private var _allSkillResultNumSemaphore:int;
      
      private var _hadExcuted:Boolean;
      
      private var _semaphoreDenied:Boolean = false;
      
      public function AfterAttackCommand()
      {
         super();
      }
      
      override public function execute(param1:Object) : void
      {
         this._content = param1;
         this._battle = BattleContentUtil.getContentProperty(param1,BattleContentUtil.PN_BATTLE);
         this._result = BattleContentUtil.getContentProperty(param1,BattleContentUtil.PN_ROUND_RESULT);
         this._sourcePlayer = BattleContentUtil.getContentProperty(param1,BattleContentUtil.PN_SOURCE_PLAYER);
         this._sourceFighter = BattleContentUtil.getContentProperty(param1,BattleContentUtil.PN_SOURCE_FIGHTER);
         this.onSourceSkillBeHitActionEnd();
      }
      
      private function handleMyHpChanges() : void
      {
         if(this._result.sourceSkillNumResult != null)
         {
            BattleUtil.handleHpChangesSingle(this._result.sourceSkillNumResult.afterHps,this._result.sourceSkillNumResult.afterSps,this._sourceFighter,AvatarActionDefine.STAND,this.onSourceSkillBeHitActionEnd);
         }
         else
         {
            this.onSourceSkillBeHitActionEnd();
         }
      }
      
      private function onSourceSkillBeHitActionEnd() : void
      {
         var _loc1_:Boolean = BattleUtil.checkHasWaitTypeBuff(this._result.sourceSkillNumResult.afterDisplayBuff);
         var _loc2_:Boolean = this.checkHasWaitTypeBuffInTargetSkillResults(this._result.targetSkillResults) || this.checkHasWaitTypeBuffInTargetSkillResults(this._result.targetRepresenterResults) || _loc1_;
         this._allSkillResultNumSemaphore = this.calculateAllSkillResultNum(this._result.targetSkillResults,_loc2_) + this.calculateAllSkillResultNum(this._result.targetRepresenterResults,_loc2_);
         if(this._result.sourceSkillNumResult != null)
         {
            ++this._allSkillResultNumSemaphore;
         }
         if(_loc2_)
         {
            BattleUtil.handleDisplayBuffChangesSingle(this._result.sourceSkillNumResult.afterDisplayBuff,this._sourceFighter,this.onWaitBuffEnd);
            this.handleBuffChanges(this._result.targetSkillResults,this.onWaitBuffEnd);
            this.handleBuffChanges(this._result.targetRepresenterResults,this.onWaitBuffEnd);
         }
         else
         {
            BattleUtil.handleHpChangesSingle(this._result.sourceSkillNumResult.afterHps,this._result.sourceSkillNumResult.afterSps,this._sourceFighter,AvatarActionDefine.STAND,this.onBeHitActionEnd);
            this.handleSkillTargetHpChanges(this._result.targetSkillResults,this.onBeHitActionEnd);
            this.handleSkillTargetHpChanges(this._result.targetRepresenterResults,this.onBeHitActionEnd);
         }
      }
      
      private function checkHasWaitTypeBuffInTargetSkillResults(param1:Array) : Boolean
      {
         var _loc2_:SkillResult = null;
         for each(_loc2_ in param1)
         {
            if(_loc2_.numResult != null)
            {
               if(BattleUtil.checkHasWaitTypeBuff(_loc2_.numResult.afterDisplayBuff))
               {
                  return true;
               }
            }
         }
         return false;
      }
      
      private function calculateAllSkillResultNum(param1:Array, param2:Boolean) : int
      {
         var _loc4_:SkillResult = null;
         var _loc5_:IBattlePlayer = null;
         var _loc6_:IBattleFighter = null;
         var _loc3_:int = 0;
         for each(_loc4_ in param1)
         {
            if(_loc4_.numResult != null)
            {
               _loc5_ = this._battle.getPlayerByName(_loc4_.targetPlayerName);
               _loc6_ = _loc5_.getFighterById(_loc4_.targetCharacterId);
               if(!param2 || Boolean(_loc6_))
               {
                  _loc3_++;
               }
            }
         }
         if(param1.length == 0)
         {
            _loc3_++;
         }
         return _loc3_;
      }
      
      private function handleSourceFighterChanges() : void
      {
         var _loc1_:Array = this._result.sourceSkillNumResult.afterPowers;
         BattleUtil.handlePowerChangesSingle(_loc1_,this._sourceFighter);
         BattleUtil.handleDisplayBuffChangesSingle(this._result.sourceSkillNumResult.afterDisplayBuff,this._sourceFighter);
      }
      
      private function handleSkillTargetHpChanges(param1:Array, param2:Function) : void
      {
         var _loc3_:SkillResult = null;
         var _loc4_:Array = null;
         var _loc5_:IBattlePlayer = null;
         var _loc6_:IBattleFighter = null;
         var _loc7_:Boolean = false;
         var _loc8_:Boolean = false;
         for each(_loc3_ in param1)
         {
            if(_loc3_.numResult != null)
            {
               _loc4_ = _loc3_.numResult.afterHps;
               _loc5_ = this._battle.getPlayerByName(_loc3_.targetPlayerName);
               _loc6_ = _loc5_.getFighterById(_loc3_.targetCharacterId);
               if((Boolean(_loc6_)) && _loc6_ != this._sourceFighter)
               {
                  BattleUtil.handleHpChangesSingle(_loc3_.numResult.afterHps,_loc3_.numResult.afterSps,_loc6_,AvatarActionDefine.STAND,param2);
               }
               else
               {
                  _loc7_ = BattleUtil.checkHasWaitTypeBuff(this._result.sourceSkillNumResult.afterDisplayBuff);
                  _loc8_ = this.checkHasWaitTypeBuffInTargetSkillResults(this._result.targetSkillResults) || this.checkHasWaitTypeBuffInTargetSkillResults(this._result.targetRepresenterResults) || _loc7_;
                  if(!(_loc6_ == null && _loc8_))
                  {
                     param2.apply();
                  }
               }
            }
         }
         if(param1.length == 0)
         {
            param2.apply();
         }
      }
      
      private function onWaitBuffEnd() : void
      {
         ++this._curWaitBuffSemaphore;
         this.checkTargetBuffSemaphore();
      }
      
      private function onBeHitActionEnd() : void
      {
         ++this._curHitActionSemaphore;
         this.checkTargetHpSemaphore();
      }
      
      private function checkTargetHpSemaphore() : void
      {
         var _loc1_:Array = null;
         if(this._curHitActionSemaphore >= this._allSkillResultNumSemaphore)
         {
            if(this._semaphoreDenied)
            {
               if(ConfigReader.instance.debug)
               {
                  throw new Error("Repeated call checkTargetHpSemaphore().");
               }
               return;
            }
            this._semaphoreDenied = true;
            _loc1_ = this._result.sourceSkillNumResult.afterPowers;
            BattleUtil.handlePowerChangesSingle(_loc1_,this._sourceFighter);
            BattleUtil.handleDisplayBuffChangesSingle(this._result.sourceSkillNumResult.afterDisplayBuff,this._sourceFighter);
            this.handlePowerChanges(this._result.targetSkillResults);
            this.handleBuffChanges(this._result.targetSkillResults);
            this.handlePowerChanges(this._result.targetRepresenterResults);
            this.handleBuffChanges(this._result.targetRepresenterResults);
            this.onAfterAttackEnd();
         }
      }
      
      private function checkTargetBuffSemaphore() : void
      {
         if(this._curWaitBuffSemaphore >= this._allSkillResultNumSemaphore)
         {
            BattleUtil.handleHpChangesSingle(this._result.sourceSkillNumResult.afterHps,this._result.sourceSkillNumResult.afterSps,this._sourceFighter,AvatarActionDefine.STAND,this.onAfterBuffAndHpActionEnd);
            this.handleSkillTargetHpChanges(this._result.targetSkillResults,this.onAfterBuffAndHpActionEnd);
            this.handleSkillTargetHpChanges(this._result.targetRepresenterResults,this.onAfterBuffAndHpActionEnd);
         }
      }
      
      private function onAfterBuffAndHpActionEnd() : void
      {
         ++this._curHitActionSemaphore;
         this.checkAfterBuffAndHpSemaphore();
      }
      
      private function checkAfterBuffAndHpSemaphore() : void
      {
         var _loc1_:Array = null;
         if(this._curHitActionSemaphore >= this._allSkillResultNumSemaphore)
         {
            _loc1_ = this._result.sourceSkillNumResult.afterPowers;
            BattleUtil.handlePowerChangesSingle(_loc1_,this._sourceFighter);
            this.handlePowerChanges(this._result.targetSkillResults);
            this.handlePowerChanges(this._result.targetRepresenterResults);
            this.onAfterAttackEnd();
         }
      }
      
      private function handlePowerChanges(param1:Array) : void
      {
         var _loc3_:SkillResult = null;
         var _loc4_:IBattlePlayer = null;
         var _loc5_:IBattleFighter = null;
         var _loc2_:Array = [];
         for each(_loc3_ in param1)
         {
            if(_loc3_.numResult != null)
            {
               _loc2_ = _loc3_.numResult.afterPowers;
               _loc4_ = this._battle.getPlayerByName(_loc3_.targetPlayerName);
               _loc5_ = _loc4_.getFighterById(_loc3_.targetCharacterId);
               BattleUtil.handlePowerChangesSingle(_loc2_,_loc5_);
            }
         }
      }
      
      private function handleBuffChanges(param1:Array, param2:Function = null) : void
      {
         var _loc3_:SkillResult = null;
         var _loc4_:SkillNumResult = null;
         var _loc5_:IBattlePlayer = null;
         var _loc6_:IBattleFighter = null;
         for each(_loc3_ in param1)
         {
            if(_loc3_.numResult != null)
            {
               _loc4_ = _loc3_.numResult;
               _loc5_ = this._battle.getPlayerByName(_loc3_.targetPlayerName);
               _loc6_ = _loc5_.getFighterById(_loc3_.targetCharacterId);
               (_loc6_) && BattleUtil.handleDisplayBuffChangesSingle(_loc4_.afterDisplayBuff,_loc6_,param2);
            }
         }
         if(param1.length == 0)
         {
            if(param2 != null)
            {
               param2.apply();
            }
         }
      }
      
      private function onAfterAttackEnd() : void
      {
         var _loc1_:Number = NaN;
         var _loc2_:int = 0;
         var _loc3_:SkillResult = null;
         var _loc4_:IBattlePlayer = null;
         var _loc5_:IBattleFighter = null;
         if(this._hadExcuted)
         {
            return;
         }
         this._hadExcuted = true;
         for each(_loc3_ in this._result.targetSkillResults)
         {
            if(_loc3_.numResult != null)
            {
               if(this.checkReachFinalChangeSetIdx(_loc3_.numResult))
               {
                  _loc1_ = Number(_loc3_.numResult.finalHp);
                  _loc2_ = int(_loc3_.numResult.finalPower);
                  _loc4_ = this._battle.getPlayerByName(_loc3_.targetPlayerName);
                  _loc5_ = _loc4_.getFighterById(_loc3_.targetCharacterId);
                  (_loc5_) && this.finalHpAndPowerHelper(_loc4_,_loc5_,_loc1_,_loc2_);
               }
            }
         }
         if(this.checkReachFinalChangeSetIdx(this._result.sourceSkillNumResult))
         {
            _loc1_ = Number(this._result.sourceSkillNumResult.finalHp);
            _loc2_ = int(this._result.sourceSkillNumResult.finalPower);
            this.finalHpAndPowerHelper(this._sourcePlayer,this._sourceFighter,_loc1_,_loc2_);
         }
         BattleContentUtil.setContentProperty(this._content,BattleContentUtil.PN_TIME_LINE,this._sourceFighter.curActionTimeline);
         this.succeed(this._content);
         this._content = null;
      }
      
      private function checkReachFinalChangeSetIdx(param1:SkillNumResult) : Boolean
      {
         if(param1.curChangeSetIdx >= param1.changeSetId2AfterDataMap.getKeys().length - 1)
         {
            return true;
         }
         return false;
      }
      
      private function finalHpAndPowerHelper(param1:IBattlePlayer, param2:IBattleFighter, param3:Number, param4:int) : void
      {
         var player:IBattlePlayer = param1;
         var fighter:IBattleFighter = param2;
         var finalHp:Number = param3;
         var finalPower:int = param4;
         fighter.curHp = finalHp;
         fighter.curPower = finalPower;
         if(fighter.info.curHp <= 0)
         {
            fighter.fadeOut(function():*
            {
               if(fighter.curHp > 0)
               {
                  fighter.showUp();
               }
            });
         }
      }
   }
}

