package mmo.battle.command.playbattle
{
   import flash.display.Sprite;
   import flash.system.ApplicationDomain;
   import mmo.battle.util.BattleContentUtil;
   import mmo.common.DisplayUtil;
   import mmo.common.dialog.NewDialogWithCallback;
   import mmo.interfaces.ServiceContainer;
   import mmo.interfaces.material.IMaterialFactory;
   import mmo.interfaces.material.IMaterialService;
   import mmo.interfaces.material.MaterialCommonData;
   import mmo.interfaces.material.UserMaterial;
   import mmo.util.command.ISceneCommand;
   import mmo.util.command.SceneSimpleCommand;
   
   public class NotifyGainCoolPetStoneCommand extends SceneSimpleCommand implements ISceneCommand
   {
      
      private const PanelCls:String = "mmo.battle.common.GainCoolPetStoneRes";
      
      protected var _content:Object;
      
      private var _gainCoolPetStoneMCD:MaterialCommonData;
      
      public function NotifyGainCoolPetStoneCommand()
      {
         super();
      }
      
      override public function execute(param1:Object) : void
      {
         var domain:ApplicationDomain;
         var cls:Class;
         var panel:Sprite;
         var mf:IMaterialFactory;
         var mSvc:IMaterialService;
         var userM:UserMaterial;
         var content:Object = param1;
         this._content = content;
         this._gainCoolPetStoneMCD = BattleContentUtil.getContentProperty(this._content,BattleContentUtil.PN_GAIN_COOLPETSTONE_DATA);
         if(this._gainCoolPetStoneMCD == null)
         {
            succeed(this._content);
            return;
         }
         domain = this._content["Domain"];
         cls = domain.getDefinition(this.PanelCls) as Class;
         panel = new cls() as Sprite;
         mf = ServiceContainer.getService(IMaterialFactory);
         mSvc = mf.getService(this._gainCoolPetStoneMCD.type);
         userM = mSvc.getMyMaterialById(this._gainCoolPetStoneMCD.id);
         panel["txtNum"].text = this._gainCoolPetStoneMCD.num;
         panel["txtName"].text = mSvc.getMaterialById(this._gainCoolPetStoneMCD.id).name;
         DisplayUtil.clearContainer(panel["mcIcon"]);
         panel["mcIcon"].addChild(mSvc.getView(this._gainCoolPetStoneMCD.id));
         NewDialogWithCallback.showCustomDialog(panel,function():*
         {
            succeed(_content);
         });
      }
   }
}

