package mmo.battle.ui
{
   import flash.display.Sprite;
   import flash.events.Event;
   import mmo.interfaces.ServiceContainer;
   import mmo.interfaces.battle.events.BattleSeqEvent;
   import mmo.interfaces.battle.service.IBattleService;
   
   public class BattleSeqUI
   {
      
      private static const MAX_NODE_NUM:int = 5;
      
      private var _resSprite:Sprite;
      
      private var _nodePetRaceIds:Array;
      
      private var _nodeIcons:Array;
      
      private var _battleService:IBattleService;
      
      public function BattleSeqUI(param1:Sprite)
      {
         super();
         this._resSprite = param1;
         this.initService();
         this.initComponent();
         this.initListener();
      }
      
      public function setInfo(param1:Array) : void
      {
         var _loc3_:BattleSeqIcon = null;
         this._nodePetRaceIds = param1;
         var _loc2_:int = 0;
         while(_loc2_ < MAX_NODE_NUM)
         {
            _loc3_ = this._nodeIcons[_loc2_];
            _loc3_.setInfo(this._nodePetRaceIds[_loc2_]);
            _loc2_++;
         }
      }
      
      public function get resSprite() : Sprite
      {
         return this._resSprite;
      }
      
      private function initComponent() : void
      {
         var _loc2_:Sprite = null;
         var _loc3_:BattleSeqIcon = null;
         this._nodeIcons = new Array();
         var _loc1_:int = 0;
         while(_loc1_ < MAX_NODE_NUM)
         {
            _loc2_ = this._resSprite.getChildByName("n" + _loc1_) as Sprite;
            _loc3_ = new BattleSeqIcon(_loc2_,_loc1_);
            this._nodeIcons.push(_loc3_);
            _loc1_++;
         }
      }
      
      private function initService() : void
      {
         this._battleService = ServiceContainer.getService(IBattleService) as IBattleService;
      }
      
      private function initListener() : void
      {
         this._resSprite.addEventListener(Event.REMOVED_FROM_STAGE,this.onRemoved);
         this._battleService.addEventListener(BattleSeqEvent.ON_BATTLE_NODE_START,this.onBattleNodeStart);
         this._battleService.addEventListener(BattleSeqEvent.ON_BATTLE_NODE_END,this.onBattleNodeEnd);
      }
      
      private function removeListener() : void
      {
         this._resSprite.removeEventListener(Event.REMOVED_FROM_STAGE,this.onRemoved);
         this._battleService.removeEventListener(BattleSeqEvent.ON_BATTLE_NODE_START,this.onBattleNodeStart);
         this._battleService.removeEventListener(BattleSeqEvent.ON_BATTLE_NODE_END,this.onBattleNodeEnd);
      }
      
      private function onRemoved(param1:Event) : void
      {
         this.removeListener();
      }
      
      private function onBattleNodeStart(param1:BattleSeqEvent) : void
      {
         var _loc2_:int = int(param1.params.nodePass);
         var _loc3_:BattleSeqIcon = this._nodeIcons[_loc2_];
         _loc3_.setState(BattleSeqIcon.STATE_FIGHTING);
      }
      
      private function onBattleNodeEnd(param1:BattleSeqEvent) : void
      {
         var _loc5_:BattleSeqIcon = null;
         var _loc2_:int = int(param1.params.nodePass);
         var _loc3_:int = int(param1.params.nodeLeft);
         var _loc4_:int = int(param1.params.winnerTeamId);
         if(_loc2_ > 0)
         {
            _loc5_ = this._nodeIcons[_loc2_ - 1];
            if(_loc4_ == 0)
            {
               _loc5_.setState(BattleSeqIcon.STATE_KO);
            }
            else
            {
               _loc5_.setState(BattleSeqIcon.STATE_LOSE);
            }
         }
      }
   }
}

