package mmo.battle.avatar.ext
{
   import flash.display.MovieClip;
   import flash.display.Sprite;
   import flash.geom.Point;
   import mmo.battle.avatar.BattleAvatar;
   import mmo.interfaces.battle.avatar.AvatarPosTypes;
   import mmo.interfaces.battle.data.FighterInfo;
   
   public class BattleAvatar70523 extends BattleAvatar
   {
      
      private static const AVATAR_POS_HEAD:int = 99;
      
      private static const CLOSE_SKILL_DELTA_X:int = -30;
      
      private static const CLOSE_SKILL_DELTA_Y:int = -100;
      
      private static const REMOTE_SKILL_DELTA_X:int = -50;
      
      private static const REMOTE_SKILL_DELTA_Y:int = -190;
      
      private static const BUBBLE_DELTA_X:int = 40;
      
      private static const BUBBLE_DELTA_Y:int = -247;
      
      private static const ATTACKER_DELTA_X:int = 144;
      
      private static const ATTACKER_DELTA_Y:int = 2;
      
      private static const BACK_DELTA_X:int = -60;
      
      private static const BACK_DELTA_Y:int = -100;
      
      private static const SKILL_SCALE:Number = 1.8;
      
      private static const BUFFER_SCALE:Number = 2.3;
      
      private static const POWER_FULL_BUFF_ID2:int = 10002;
      
      public function BattleAvatar70523(param1:FighterInfo, param2:Object, param3:Boolean = false)
      {
         super(param1,param2,param3);
      }
      
      override public function getAvatarPos(param1:int) : Point
      {
         var _loc2_:Point = new Point();
         switch(param1)
         {
            case AvatarPosTypes.REGISTER_POINT:
               _loc2_.x = 0;
               _loc2_.y = 0;
               break;
            case AvatarPosTypes.TOP_FRONT:
               _loc2_.x = this._avatarLayer.scaleX > 0 ? ATTACKER_DELTA_X : -ATTACKER_DELTA_X;
               _loc2_.y = BUBBLE_DELTA_Y;
               break;
            case AvatarPosTypes.TOP:
               _loc2_.x = this._avatarLayer.scaleX > 0 ? CLOSE_SKILL_DELTA_X : -CLOSE_SKILL_DELTA_X;
               _loc2_.y = BUBBLE_DELTA_Y;
               break;
            case AvatarPosTypes.TOP_BACK:
               _loc2_.x = this._avatarLayer.scaleX > 0 ? BACK_DELTA_X : -BACK_DELTA_X;
               _loc2_.y = BUBBLE_DELTA_Y;
               break;
            case AvatarPosTypes.FRONT:
               _loc2_.x = this._avatarLayer.scaleX > 0 ? ATTACKER_DELTA_X : -ATTACKER_DELTA_X;
               _loc2_.y = CLOSE_SKILL_DELTA_Y;
               break;
            case AvatarPosTypes.CENTER:
               _loc2_.x = this._avatarLayer.scaleX > 0 ? CLOSE_SKILL_DELTA_X : -CLOSE_SKILL_DELTA_X;
               _loc2_.y = CLOSE_SKILL_DELTA_Y;
               break;
            case AvatarPosTypes.BACK:
               _loc2_.x = this._avatarLayer.scaleX > 0 ? BACK_DELTA_X : -BACK_DELTA_X;
               _loc2_.y = BACK_DELTA_Y;
               break;
            case AvatarPosTypes.BUTTOM_FRONT:
               _loc2_.x = this._avatarLayer.scaleX > 0 ? ATTACKER_DELTA_X : -ATTACKER_DELTA_X;
               _loc2_.y = ATTACKER_DELTA_Y;
               break;
            case AvatarPosTypes.BUTTOM:
               _loc2_.x = this._avatarLayer.scaleX > 0 ? CLOSE_SKILL_DELTA_X : -CLOSE_SKILL_DELTA_X;
               _loc2_.y = ATTACKER_DELTA_Y;
               break;
            case AvatarPosTypes.BUTTOM_BACK:
               _loc2_.x = this._avatarLayer.scaleX > 0 ? BACK_DELTA_X : -BACK_DELTA_X;
               _loc2_.y = ATTACKER_DELTA_Y;
               break;
            case AVATAR_POS_HEAD:
               _loc2_.x = REMOTE_SKILL_DELTA_X;
               _loc2_.y = REMOTE_SKILL_DELTA_Y;
         }
         return _loc2_;
      }
      
      override protected function getBufferById(param1:int) : MovieClip
      {
         var _loc2_:MovieClip = super.getBufferById(param1);
         _loc2_.scaleX *= BUFFER_SCALE;
         _loc2_.scaleY *= BUFFER_SCALE;
         return _loc2_;
      }
      
      override public function addBuff(param1:int, param2:Function = null) : void
      {
         if(param1 != this._battleConfig.getPowerFullBuffId(this._info.raceId))
         {
            super.addBuff(param1,param2);
            return;
         }
         if(this._mapBuffId2Buff.containsKey(param1))
         {
            return;
         }
         var _loc3_:Sprite = super.getBufferById(param1);
         this._bufferLayer.addChild(_loc3_);
         this._mapBuffId2Buff.add(param1,_loc3_);
         this._buffIdArray.push(param1);
         var _loc4_:Sprite = super.getBufferById(POWER_FULL_BUFF_ID2);
         this._bufferLayer2.addChild(_loc4_);
         this._mapBuffId2Buff.add(POWER_FULL_BUFF_ID2,_loc4_);
         this._buffIdArray.push(POWER_FULL_BUFF_ID2);
      }
      
      override public function removeBuff(param1:int) : void
      {
         super.removeBuff(param1);
         if(param1 == this._battleConfig.getPowerFullBuffId(this._info.raceId))
         {
            super.removeBuff(POWER_FULL_BUFF_ID2);
         }
      }
      
      override protected function getSkillEffectMC(param1:int, param2:Boolean) : MovieClip
      {
         var _loc3_:MovieClip = super.getSkillEffectMC(param1,param2);
         _loc3_.scaleX *= SKILL_SCALE;
         _loc3_.scaleY *= SKILL_SCALE;
         return _loc3_;
      }
   }
}

