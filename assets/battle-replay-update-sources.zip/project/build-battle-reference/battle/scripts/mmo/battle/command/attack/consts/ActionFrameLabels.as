package mmo.battle.command.attack.consts
{
   public class ActionFrameLabels
   {
      
      public static const JUMP:String = "jump";
      
      public static const EFFECT:String = "effect";
      
      public static const COLOR:String = "color";
      
      public static const SCALE:String = "scale";
      
      public static const WHITE:String = "white";
      
      public static const REMOVE_ALL:String = "removeall";
      
      public static const SHOW_ALL:String = "showall";
      
      public static const FADE_OUT:String = "fadeout";
      
      public static const REMOVE_OTHERS:String = "removeothers";
      
      public static const TITLE:String = "title";
      
      public function ActionFrameLabels()
      {
         super();
      }
   }
}

