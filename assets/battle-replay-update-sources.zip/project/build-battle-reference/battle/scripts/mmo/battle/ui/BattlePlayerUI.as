package mmo.battle.ui
{
   import com.adobe.utils.StringUtil;
   import flash.display.MovieClip;
   import flash.display.Sprite;
   import flash.text.TextField;
   import flash.utils.setTimeout;
   import mmo.common.DisplayUtil;
   import mmo.common.utils.tips.TipsManager;
   import mmo.framework.comm.SocketClient;
   import mmo.interfaces.ServiceContainer;
   import mmo.interfaces.avatar.IAvatarService;
   import mmo.interfaces.battle.data.LeagueArsenalResult;
   import mmo.interfaces.battle.data.NpcBlessResult;
   import mmo.interfaces.battle.data.PlayerInfo;
   import mmo.interfaces.battleconfig.IBattleConfig;
   import mmo.interfaces.league.ILeagueArsenalBuffDefine;
   import mmo.interfaces.league.ILeagueService;
   import mmo.interfaces.material.Material;
   import mmo.interfaces.material.MaterialViewContainer;
   import mmo.interfaces.material.clothes.AvatarInfo;
   import mmo.interfaces.material.materialcount.IMaterialCountService;
   import mmo.interfaces.nicknamecard.INickNameCard;
   import mmo.interfaces.nicknamecard.NickNameCardTypes;
   import mmo.interfaces.npcbuddy.INpcBuddy;
   import mmo.interfaces.npcbuddy.NpcBufferData;
   import mmo.interfaces.user.IUserNameManager;
   import mmo.util.component.artnumber.ArtNumberManager;
   
   public class BattlePlayerUI
   {
      
      public static const UI_TYPE_SELF:String = "self";
      
      public static const UI_TYPE_OTHER:String = "other";
      
      private static const UI_TYPE_ARRAY:Array = [UI_TYPE_SELF,UI_TYPE_OTHER];
      
      private var _mcNickCard:Sprite;
      
      private var _resSprite:Sprite;
      
      private var _playerInfo:PlayerInfo;
      
      private var _uiType:String;
      
      private var _showWord:Boolean;
      
      private var _npcBlessResult:NpcBlessResult;
      
      private var _leagueArsenalResult:LeagueArsenalResult;
      
      private var _formationUI:BattleFormationUI;
      
      private var _avatarService:IAvatarService;
      
      private var _nickCardService:INickNameCard = ServiceContainer.getService(INickNameCard);
      
      private var _nickCardStr:String;
      
      private var _isFaceLeft:Boolean;
      
      public function BattlePlayerUI(param1:Sprite, param2:Boolean = true)
      {
         super();
         this._resSprite = param1;
         this._isFaceLeft = param2;
         this._resSprite["hitAreaSp"].mouseChildren = false;
      }
      
      public function get resSprite() : Sprite
      {
         return this._resSprite;
      }
      
      public function get hitAreaSp() : Sprite
      {
         return this._resSprite["hitAreaSp"];
      }
      
      public function setPlayerInfo(param1:PlayerInfo, param2:NpcBlessResult, param3:String, param4:Boolean, param5:String) : void
      {
         this._nickCardStr = param5;
         if(param1.playerType == PlayerInfo.PLAYER_TYPE_AI)
         {
            DisplayUtil.stopAndRemove(this._resSprite);
            return;
         }
         this.initService();
         this.setInfo(param1,param3,param4);
         this.setBuddyBuffer(param2);
         this._formationUI.setPlayerInfo(param1);
         this.setArsenalBuffer(param1.leagueArsenalResult);
      }
      
      private function initService() : void
      {
         this._avatarService = ServiceContainer.getService(IAvatarService) as IAvatarService;
      }
      
      private function setInfo(param1:PlayerInfo, param2:String, param3:Boolean) : void
      {
         var txtName:TextField = null;
         var spHeadContainer:Sprite = null;
         var spWord:Sprite = null;
         var spBoard:Sprite = null;
         var arrBattlePower:Array = null;
         var heroSkill:Sprite = null;
         var mcBattlePower:MovieClip = null;
         var numCount:int = 0;
         var i:int = 0;
         var forUISprite:Sprite = null;
         var battleNum:MovieClip = null;
         var headIcon:Sprite = null;
         var avatarInfo:AvatarInfo = null;
         var hsName:TextField = null;
         var mcBattleNum:MovieClip = null;
         var playerInfo:PlayerInfo = param1;
         var uiType:String = param2;
         var showWord:Boolean = param3;
         this._playerInfo = playerInfo;
         this._uiType = uiType;
         this._showWord = showWord;
         for each(uiType in UI_TYPE_ARRAY)
         {
            txtName = this._resSprite.getChildByName(uiType + "_pname") as TextField;
            spHeadContainer = this._resSprite.getChildByName(uiType + "_hc") as Sprite;
            spWord = this._resSprite.getChildByName(uiType + "_word") as Sprite;
            spBoard = this._resSprite.getChildByName(uiType + "_board") as Sprite;
            arrBattlePower = new Array();
            heroSkill = this._resSprite.getChildByName(uiType + "_hs") as Sprite;
            if(uiType == BattlePlayerUI.UI_TYPE_OTHER)
            {
               mcBattlePower = this._resSprite.getChildByName("mcOtherBattlePower") as MovieClip;
            }
            else
            {
               mcBattlePower = this._resSprite.getChildByName("mcSelfBattlePower") as MovieClip;
            }
            if(playerInfo.battlePower >= 100000)
            {
               numCount = 6;
               mcBattlePower.gotoAndStop(2);
            }
            else
            {
               numCount = 5;
               mcBattlePower.gotoAndStop(1);
            }
            i = 0;
            while(i < numCount)
            {
               battleNum = mcBattlePower.getChildByName(uiType + "_num" + i) as MovieClip;
               arrBattlePower.push(battleNum);
               i++;
            }
            forUISprite = this._resSprite.getChildByName(uiType + "_for") as Sprite;
            if(uiType == this._uiType)
            {
               if(StringUtil.isNullOrEmpty(playerInfo.realName))
               {
                  txtName.text = playerInfo.playerName;
                  if(uiType == UI_TYPE_SELF)
                  {
                     this.setUserNickName(txtName,playerInfo.playerId);
                  }
                  else
                  {
                     setTimeout(function():void
                     {
                        setUserNickName(txtName,playerInfo.playerId);
                     },500);
                  }
               }
               else
               {
                  txtName.text = playerInfo.realName;
               }
               while(spHeadContainer.numChildren > 0)
               {
                  spHeadContainer.removeChildAt(0);
               }
               if(StringUtil.isNullOrEmpty(playerInfo.forceShowClothes))
               {
                  headIcon = this._avatarService.getHeadIcon(null,playerInfo.playerName,60,true,this._isFaceLeft,true,true);
               }
               else
               {
                  avatarInfo = new AvatarInfo();
                  avatarInfo.setAvatarInfoWithString(playerInfo.forceShowClothes);
                  headIcon = this._avatarService.getHeadIconByAvtarInfo(avatarInfo,60,true,this._isFaceLeft,true,true);
               }
               spHeadContainer.addChild(headIcon);
               spWord.visible = this._showWord;
               spBoard.visible = true;
               ArtNumberManager.setNumber(arrBattlePower,playerInfo.battlePower);
               this._formationUI = new BattleFormationUI(forUISprite);
               this._formationUI.setPlayerInfo(playerInfo);
               if(this._playerInfo.heroSkillId > 0)
               {
                  heroSkill.visible = true;
                  hsName = heroSkill.getChildByName("sname") as TextField;
                  ServiceContainer.tryGetService(IBattleConfig,function(param1:IBattleConfig, param2:Object):*
                  {
                     hsName.text = param1.getSkillDefineById(_playerInfo.heroSkillId).name;
                  },null,null,true);
                  hsName.text = "";
               }
               else
               {
                  heroSkill.visible = false;
               }
            }
            else
            {
               txtName.visible = false;
               spHeadContainer.visible = false;
               spWord.visible = false;
               spBoard.visible = false;
               for each(mcBattleNum in arrBattlePower)
               {
                  mcBattleNum.visible = false;
               }
               forUISprite.visible = false;
               heroSkill.visible = false;
            }
         }
      }
      
      private function setUserNickName(param1:TextField, param2:int) : void
      {
         if(this._nickCardStr == null || this._nickCardStr == "" || this._nickCardStr.split("@")[0] == "0")
         {
            return;
         }
         this._nickCardService.getNickNameCardByStr(NickNameCardTypes.NICK_CARD_TXT,this._nickCardStr,this._nickCardStr.split("@")[3],param1);
      }
      
      private function setBuddyBuffer(param1:NpcBlessResult) : void
      {
         var _loc6_:INpcBuddy = null;
         var _loc7_:IMaterialCountService = null;
         var _loc8_:NpcBufferData = null;
         var _loc9_:MaterialViewContainer = null;
         var _loc10_:Material = null;
         this._npcBlessResult = param1;
         var _loc2_:Sprite = this._resSprite.getChildByName("bc") as Sprite;
         var _loc3_:Sprite = this._resSprite.getChildByName("bb") as Sprite;
         var _loc4_:TextField = this._resSprite.getChildByName("bn") as TextField;
         _loc2_.visible = false;
         _loc3_.visible = false;
         _loc4_.visible = false;
         var _loc5_:IUserNameManager = ServiceContainer.getService(IUserNameManager) as IUserNameManager;
         if(this._playerInfo.playerName == _loc5_.getNickName(SocketClient.instance.myUserName) && this._npcBlessResult != null)
         {
            _loc3_.visible = true;
            _loc6_ = ServiceContainer.getService(INpcBuddy) as INpcBuddy;
            _loc7_ = ServiceContainer.getService(IMaterialCountService) as IMaterialCountService;
            _loc8_ = _loc6_.getNpcBuddyDataById(this._npcBlessResult.npcId);
            _loc9_ = _loc7_.getView(_loc8_.materialCountId,33,33);
            _loc10_ = _loc7_.getMaterialById(_loc8_.materialCountId);
            TipsManager.getInstance().addComplexTips(_loc9_,_loc10_.name,_loc8_.desc);
            _loc2_.addChild(_loc9_);
            _loc2_.visible = true;
            _loc4_.text = this._npcBlessResult.leftNum + "/" + _loc8_.totalTimes;
            _loc4_.visible = true;
         }
      }
      
      private function setArsenalBuffer(param1:LeagueArsenalResult) : void
      {
         var spLeagueArsenalIconContainer:Sprite;
         var spLeagueArsenalIconBackground:Sprite;
         var txtLeagueArsenalLeftNum:TextField;
         var userNameManager:IUserNameManager;
         var leagueService:ILeagueService = null;
         var spIcon:Sprite = null;
         var buffDefine:ILeagueArsenalBuffDefine = null;
         var buffDesc:String = null;
         var leagueArsenalRsult:LeagueArsenalResult = param1;
         this._leagueArsenalResult = leagueArsenalRsult;
         spLeagueArsenalIconContainer = this._resSprite.getChildByName("lbc") as Sprite;
         spLeagueArsenalIconBackground = this._resSprite.getChildByName("lbb") as Sprite;
         txtLeagueArsenalLeftNum = this._resSprite.getChildByName("lbn") as TextField;
         spLeagueArsenalIconContainer.visible = false;
         spLeagueArsenalIconBackground.visible = false;
         txtLeagueArsenalLeftNum.visible = false;
         userNameManager = ServiceContainer.getService(IUserNameManager) as IUserNameManager;
         if(this._playerInfo.playerName == userNameManager.getNickName(SocketClient.instance.myUserName) && this._leagueArsenalResult != null && this._leagueArsenalResult.buffId > 0)
         {
            spLeagueArsenalIconBackground.visible = true;
            leagueService = ServiceContainer.getService(ILeagueService);
            spIcon = leagueService.getArsenalBuffIcon(this._leagueArsenalResult.buffId,33,33,true,function(param1:Sprite):void
            {
               var _loc2_:* = param1.getChildByName("mcArsenal") as MovieClip;
               var _loc3_:* = Math.ceil(_leagueArsenalResult.buffLv / 2);
               _loc2_.gotoAndStop(_loc3_);
            });
            buffDefine = leagueService.getArsenalBuffDefine(this._leagueArsenalResult.buffId);
            buffDesc = buffDefine.desc[this._leagueArsenalResult.buffLv - 1];
            TipsManager.getInstance().addComplexTips(spIcon,buffDefine.name,buffDesc);
            spLeagueArsenalIconContainer.addChild(spIcon);
            spLeagueArsenalIconContainer.visible = true;
            txtLeagueArsenalLeftNum.text = leagueArsenalRsult.cnt + "/" + buffDefine.cntLimit;
            txtLeagueArsenalLeftNum.visible = true;
         }
      }
   }
}

