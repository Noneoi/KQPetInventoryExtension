package mmo.battle.bitmap
{
   import flash.display.MovieClip;
   import flash.display.Sprite;
   import flash.system.ApplicationDomain;
   import flash.utils.Dictionary;
   import mmo.common.utils.dt.BitmapDataWrapper;
   import mmo.common.utils.dt.easyview.BitmapMovieClip;
   import mmo.interfaces.IDispose;
   
   public class RegularBitmapData implements IDispose
   {
      
      private var _domain:ApplicationDomain;
      
      private var _map:Dictionary;
      
      public function RegularBitmapData(param1:ApplicationDomain)
      {
         super();
         this._domain = param1;
         this._map = new Dictionary();
      }
      
      public function getSprite(param1:String) : Sprite
      {
         if(this._map[param1] == null)
         {
            this.load(param1);
         }
         var _loc2_:Vector.<BitmapDataWrapper> = this._map[param1];
         var _loc3_:Sprite = new Sprite();
         _loc3_.addChild(this.getBitmapMovieClip(_loc2_));
         return _loc3_;
      }
      
      private function load(param1:String) : void
      {
         var _loc2_:Class = this._domain.getDefinition(param1) as Class;
         var _loc3_:MovieClip = new _loc2_() as MovieClip;
         this._map[param1] = BitmapMovieClip.captureAllFrames(_loc3_,1);
      }
      
      private function getBitmapMovieClip(param1:Vector.<BitmapDataWrapper>) : BitmapMovieClip
      {
         var _loc2_:BitmapMovieClip = null;
         _loc2_ = new BitmapMovieClip();
         _loc2_.setBitmapDatas(param1);
         _loc2_.gotoAndPlay(1);
         return _loc2_;
      }
      
      public function dispose() : void
      {
         this._domain = null;
         this._map = new Dictionary();
      }
   }
}

