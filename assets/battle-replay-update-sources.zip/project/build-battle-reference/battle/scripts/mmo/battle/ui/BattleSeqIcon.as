package mmo.battle.ui
{
   import flash.display.MovieClip;
   import flash.display.Sprite;
   import mmo.interfaces.ServiceContainer;
   import mmo.interfaces.pet.peticon.IPetIcon;
   import mmo.interfaces.pet.peticon.PetIconContainer;
   import mmo.interfaces.pet.peticon.PetIconType;
   
   public class BattleSeqIcon
   {
      
      public static const STATE_KO:int = 1;
      
      public static const STATE_FIGHTING:int = 2;
      
      public static const STATE_WAITING:int = 3;
      
      public static const STATE_LOSE:int = 4;
      
      private static const ICON_WIDTH:int = 60;
      
      private var _res:Sprite;
      
      private var _index:int;
      
      private var _raceId:int;
      
      private var _mcWave:MovieClip;
      
      private var _spIconContainer:Sprite;
      
      private var _mcState:MovieClip;
      
      public function BattleSeqIcon(param1:Sprite, param2:int)
      {
         super();
         this._res = param1;
         this._index = param2;
         this.initComponent();
      }
      
      public function setInfo(param1:int) : void
      {
         this._raceId = param1;
         if(param1 <= 0)
         {
            this._res.visible = false;
            return;
         }
         var _loc2_:IPetIcon = ServiceContainer.getService(IPetIcon) as IPetIcon;
         var _loc3_:PetIconContainer = _loc2_.getPetIcon(this._raceId,PetIconType.FANG);
         this._spIconContainer.addChild(_loc3_);
      }
      
      public function setState(param1:int) : void
      {
         this._mcState.gotoAndStop(param1);
      }
      
      private function initComponent() : void
      {
         this._mcWave = this._res.getChildByName("wave") as MovieClip;
         this._mcWave.gotoAndStop(this._index + 1);
         this._spIconContainer = this._res.getChildByName("ic") as Sprite;
         this._mcState = this._res.getChildByName("state") as MovieClip;
         this._mcState.gotoAndStop(STATE_WAITING);
      }
   }
}

