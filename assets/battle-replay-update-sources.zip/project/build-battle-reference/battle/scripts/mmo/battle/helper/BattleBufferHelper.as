package mmo.battle.helper
{
   import flash.display.FrameLabel;
   import flash.display.MovieClip;
   import flash.display.Sprite;
   import flash.filters.ColorMatrixFilter;
   import flash.geom.Rectangle;
   import mmo.battle.command.attack.consts.ActionFrameLabels;
   import mmo.battle.container.BattleContainer;
   import mmo.battle.entity.BattleBase;
   import mmo.battle.fighter.BattleFighter;
   import mmo.battle.util.BattleContentUtil;
   import mmo.common.DisplayUtil;
   import mmo.common.utils.tips.TipsManager;
   import mmo.interfaces.battle.avatar.IBattleAvatar;
   import mmo.interfaces.battle.data.BattleInfo;
   import mmo.interfaces.battle.data.RoundResult;
   import mmo.interfaces.battle.fighter.IBattleFighter;
   import mmo.interfaces.battle.player.IBattlePlayer;
   import mmo.interfaces.battleconfig.define.SkillDefine;
   import mmo.interfaces.pet.data.IPetDictionaryDataService;
   import mmo.loader.LoaderContainer;
   import mmo.play.globalfunctions.forSvc;
   
   public class BattleBufferHelper
   {
      
      private var actionFrames:Array = [ActionFrameLabels.COLOR,ActionFrameLabels.SCALE,ActionFrameLabels.WHITE,ActionFrameLabels.REMOVE_ALL,ActionFrameLabels.SHOW_ALL,ActionFrameLabels.FADE_OUT,ActionFrameLabels.REMOVE_OTHERS];
      
      private var actionFrameFuncsArray:*;
      
      private var actionBackGround:Sprite;
      
      private var filterTargetFightAvatars:Array = [];
      
      private var targetFighters:Array = [];
      
      private var visibleFighters:Array = [];
      
      private var removeFighters:Array = [];
      
      private var _applyBuffPlayer:IBattlePlayer;
      
      private var _applyBuffFighter:IBattleFighter;
      
      private var _isMulti:Boolean;
      
      private var _container:BattleContainer;
      
      private var _result:RoundResult;
      
      private var _battle:BattleBase;
      
      private var _buffMc:MovieClip;
      
      public function BattleBufferHelper()
      {
         this.actionFrameFuncsArray = [this.handleFrameLabelColor,this.handleFrameLabelScale,this.handleFrameLabelWhite,this.handleFrameLabelRemoveAll,this.handleFrameLabelShowAll,this.handleFrameLabelFadeout,this.handleFrameLabelRemoveOthers];
         super();
      }
      
      public static function setBuffProgress(param1:MovieClip, param2:int, param3:int, param4:SkillDefine, param5:Boolean = true) : void
      {
         var _loc9_:int = 0;
         var _loc10_:int = 0;
         var _loc11_:int = 0;
         var _loc12_:int = 0;
         var _loc6_:MovieClip = param1["mcProgress"];
         if(_loc6_ == null)
         {
            throw new Error("buffMc does not have a child named [mcProgress]!");
         }
         addBuffTip(param1,param4,param2,param3);
         var _loc7_:MovieClip = _loc6_["mcAttributes"];
         if(_loc7_)
         {
            _loc9_ = int(SkillDefine.getRaceIdBySkillId(param4.id));
            _loc10_ = int((forSvc(IPetDictionaryDataService) as IPetDictionaryDataService).getDataItemByRaceId(_loc9_).attr1.id);
            _loc7_.gotoAndStop(_loc10_);
            _loc11_ = _loc6_.width / _loc6_.scaleX;
            _loc12_ = param2 / param3 * _loc11_;
            _loc7_.scrollRect = new Rectangle(0,0,_loc12_,_loc7_.height);
         }
         var _loc8_:MovieClip = _loc6_["mcWalls"];
         if(_loc8_)
         {
            _loc8_.gotoAndStop(param3);
         }
      }
      
      private static function addBuffTip(param1:MovieClip, param2:SkillDefine, param3:int, param4:int) : void
      {
         var _loc5_:String = "";
         var _loc6_:String = "";
         param1.buttonMode = false;
         _loc5_ = "通灵之魂: <font color=\'#FFFFFF\'>" + param3 + "/" + param4 + "</font>";
         _loc6_ = _loc6_.concat("技能名: <font color=\'#FFFFFF\'>" + param2.name + "</font>");
         _loc6_ = _loc6_.concat("\n技能描述：" + param2.description);
         TipsManager.getInstance().removeTips(param1);
         TipsManager.getInstance().addComplexTipsByRes(param1,_loc5_,_loc6_,"mmo.stargod.CommonTips_res");
      }
      
      public function handleFrameLabel(param1:MovieClip, param2:Object, param3:IBattlePlayer, param4:IBattleFighter) : void
      {
         var _loc8_:FrameLabel = null;
         var _loc5_:Array = param1.currentLabels;
         this._buffMc = param1;
         this._applyBuffPlayer = param3;
         this._applyBuffFighter = param4;
         this._result = BattleContentUtil.getContentProperty(param2,BattleContentUtil.PN_ROUND_RESULT);
         this._battle = BattleContentUtil.getContentProperty(param2,BattleContentUtil.PN_BATTLE);
         this._container = BattleContentUtil.getContentProperty(param2,BattleContentUtil.PN_CONTAINER);
         var _loc6_:BattleInfo = this._battle.battleResult.battleInfo;
         if(_loc6_.getTeamInfoById(0).playerInfos.length > 1 || _loc6_.getTeamInfoById(1).playerInfos.length > 1)
         {
            this._isMulti = true;
         }
         var _loc7_:int = 0;
         while(_loc7_ < _loc5_.length)
         {
            _loc8_ = _loc5_[_loc7_];
            if(this.checkIsActionFrame(_loc8_.name))
            {
               param1.addFrameScript(_loc8_.frame - 1,this.onBubbleFrame(param1,_loc8_.name));
            }
            _loc7_++;
         }
      }
      
      private function checkIsActionFrame(param1:String) : Boolean
      {
         var _loc2_:int = 0;
         while(_loc2_ < this.actionFrames.length)
         {
            if(param1.indexOf(this.actionFrames[_loc2_]) != -1)
            {
               return true;
            }
            _loc2_++;
         }
         return false;
      }
      
      private function onBubbleFrame(param1:MovieClip, param2:String) : Function
      {
         var actionMov:MovieClip = param1;
         var labelName:String = param2;
         var fun:Function = function():void
         {
            var _loc1_:Array = null;
            var _loc2_:int = 0;
            if(!_isMulti)
            {
               _loc1_ = labelName.split("=");
               _loc2_ = 0;
               while(_loc2_ < actionFrames.length)
               {
                  if(String(_loc1_[0]).indexOf(actionFrames[_loc2_]) != -1)
                  {
                     actionFrameFuncsArray[_loc2_].apply(null,[_loc1_]);
                     break;
                  }
                  _loc2_++;
               }
            }
         };
         return fun;
      }
      
      private function handleFrameLabelFadeout(param1:Array) : void
      {
         this._applyBuffFighter.fadeOut(null);
      }
      
      private function handleFrameLabelWhite(param1:Array) : void
      {
         var _loc2_:IBattleAvatar = null;
         if(param1[1] == "end")
         {
            this.removeActionBackGround();
            this.clearFilter(Sprite(this._applyBuffFighter.avatar.getBloodLayer()));
            this.clearFilter(Sprite(this._applyBuffFighter.avatar.getBufferLayer()));
            this.clearFilter(Sprite(this._applyBuffFighter.avatar.getBufferLayer2()));
            for each(_loc2_ in this.filterTargetFightAvatars)
            {
               this.clearFilter(Sprite(_loc2_));
            }
            this.setFightVisibleTrue();
         }
         else
         {
            this.colorFilter(Sprite(this._applyBuffFighter.avatar.getBloodLayer()),255);
            this.colorFilter(Sprite(this._applyBuffFighter.avatar.getBufferLayer()),255);
            this.colorFilter(Sprite(this._applyBuffFighter.avatar.getBufferLayer2()),255);
            this.setActionBackGround(0,1);
            this.setFightVisibleFalse();
         }
      }
      
      private function handleFrameLabelScale(param1:Array) : void
      {
         var _loc2_:Number = parseFloat(param1[1]);
         var _loc3_:int = parseInt(param1[2]);
         var _loc4_:BattleZoomHelper = new BattleZoomHelper();
         _loc4_.zoomIn(this._applyBuffFighter.avatar.mcAction,BattleFighter(this._applyBuffFighter),this._battle,this._container,_loc2_,_loc3_);
         Sprite(this._applyBuffFighter.avatar).addChild(_loc4_);
      }
      
      private function handleFrameLabelColor(param1:Array) : void
      {
         if(param1[1] == "end")
         {
            this.removeActionBackGround();
         }
         else
         {
            this.setActionBackGround(parseInt(param1[1]),parseFloat(param1[2]));
         }
      }
      
      private function handleFrameLabelInverseColor(param1:Array) : void
      {
         var _loc2_:Array = null;
         var _loc3_:ColorMatrixFilter = null;
         var _loc4_:Array = null;
         if(param1[1] == "end")
         {
            this._container.filters = null;
         }
         else
         {
            _loc2_ = new Array();
            _loc2_ = _loc2_.concat([-1,0,0,0,255]);
            _loc2_ = _loc2_.concat([0,-1,0,0,255]);
            _loc2_ = _loc2_.concat([0,0,-1,0,255]);
            _loc2_ = _loc2_.concat([0,0,0,1,0]);
            _loc3_ = new ColorMatrixFilter(_loc2_);
            _loc4_ = new Array();
            _loc4_.push(_loc3_);
            this._container.filters = _loc4_;
         }
      }
      
      private function setFightVisibleFalse() : void
      {
         var _loc1_:IBattlePlayer = null;
         var _loc2_:IBattleFighter = null;
         for each(_loc1_ in this._battle.getPlayerList())
         {
            for each(_loc2_ in _loc1_.fighterList)
            {
               if(Sprite(_loc2_.avatar).visible && _loc2_ != this._applyBuffFighter && this.targetFighters.indexOf(_loc2_) == -1)
               {
                  Sprite(_loc2_.avatar).visible = false;
                  this.visibleFighters.push(_loc2_);
               }
            }
         }
      }
      
      private function setFightVisibleTrue() : void
      {
         var _loc1_:int = 0;
         while(_loc1_ < this.visibleFighters.length)
         {
            Sprite(IBattleFighter(this.visibleFighters[_loc1_]).avatar).visible = true;
            _loc1_++;
         }
      }
      
      private function setActionBackGround(param1:int, param2:Number) : void
      {
         if(this.actionBackGround == null)
         {
            this.actionBackGround = new Sprite();
            this.actionBackGround.graphics.beginFill(param1,param2);
            this.actionBackGround.graphics.drawRect(0,0,LoaderContainer.stageWidth,LoaderContainer.stageHeight);
            this.actionBackGround.graphics.endFill();
            this._container.movieLayerBelow.addChild(this.actionBackGround);
         }
      }
      
      private function removeActionBackGround() : void
      {
         DisplayUtil.stopAndRemove(this.actionBackGround);
         this.actionBackGround = null;
      }
      
      private function colorFilter(param1:Sprite, param2:int) : void
      {
         var _loc3_:Array = new Array();
         _loc3_ = _loc3_.concat([1,0,0,0,param2]);
         _loc3_ = _loc3_.concat([0,1,0,0,param2]);
         _loc3_ = _loc3_.concat([0,0,1,0,param2]);
         _loc3_ = _loc3_.concat([0,0,0,1,0]);
         var _loc4_:ColorMatrixFilter = new ColorMatrixFilter(_loc3_);
         var _loc5_:Array = new Array();
         _loc5_.push(_loc4_);
         param1.filters = _loc5_;
      }
      
      private function clearFilter(param1:Sprite) : void
      {
         param1.filters = null;
      }
      
      private function handleFrameLabelRemoveAll(param1:Array) : void
      {
         var _loc2_:IBattlePlayer = null;
         var _loc3_:IBattleFighter = null;
         for each(_loc2_ in this._battle.getPlayerList())
         {
            for each(_loc3_ in _loc2_.fighterList)
            {
               if(Sprite(_loc3_.avatar).visible)
               {
                  Sprite(_loc3_.avatar).visible = false;
                  this.removeFighters.push(_loc3_);
               }
            }
         }
      }
      
      private function handleFrameLabelRemoveOthers(param1:Array) : void
      {
         var _loc2_:IBattlePlayer = null;
         var _loc3_:IBattleFighter = null;
         Sprite(this._applyBuffFighter.avatar).visible = true;
         Sprite(this._applyBuffFighter.avatar).alpha = 1;
         for each(_loc2_ in this._battle.getPlayerList())
         {
            for each(_loc3_ in _loc2_.fighterList)
            {
               if(Sprite(_loc3_.avatar).visible && _loc3_ != this._applyBuffFighter)
               {
                  Sprite(_loc3_.avatar).visible = false;
                  this.removeFighters.push(_loc3_);
               }
            }
         }
      }
      
      private function handleFrameLabelShowAll(param1:Array) : void
      {
         var _loc2_:int = 0;
         while(_loc2_ < this.removeFighters.length)
         {
            Sprite(IBattleFighter(this.removeFighters[_loc2_]).avatar).visible = true;
            _loc2_++;
         }
      }
   }
}

