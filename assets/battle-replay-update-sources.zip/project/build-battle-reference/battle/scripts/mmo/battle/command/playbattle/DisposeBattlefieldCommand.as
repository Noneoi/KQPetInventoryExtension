package mmo.battle.command.playbattle
{
   import flash.display.BitmapData;
   import flash.events.EventDispatcher;
   import mmo.battle.bitmap.RegularBitmapData;
   import mmo.battle.entity.BattleBase;
   import mmo.battle.ui.BattleUI;
   import mmo.battle.util.BattleContentUtil;
   import mmo.common.sound.SoundManager;
   import mmo.common.utils.panel.modaldialog.ModalDialogManager;
   import mmo.interfaces.ServiceContainer;
   import mmo.interfaces.battle.events.BattleEvent;
   import mmo.interfaces.material.battlebarrage.IBattleBarrageService;
   import mmo.interfaces.rentpet.IRentPetService;
   import mmo.loader.FileType;
   import mmo.loader.LoaderContainer;
   import mmo.loader.SpineLoader;
   import mmo.play.globalfunctions.forSvc;
   import mmo.util.command.ISceneCommand;
   import mmo.util.command.SceneSimpleCommand;
   
   public class DisposeBattlefieldCommand extends SceneSimpleCommand implements ISceneCommand
   {
      
      public function DisposeBattlefieldCommand()
      {
         super();
      }
      
      override public function execute(param1:Object) : void
      {
         var battleUI:BattleUI;
         var regularBitmapData:RegularBitmapData;
         var barrageSvc:IBattleBarrageService;
         var orgMusic:String;
         var raceId2BitmapDataMap:Object;
         var prop:* = undefined;
         var dispatcher:EventDispatcher = null;
         var isCurUserWiner:Boolean = false;
         var rentPetSvc:IRentPetService = null;
         var content:Object = param1;
         var battle:BattleBase = BattleContentUtil.getContentProperty(content,BattleContentUtil.PN_BATTLE);
         battle.autoDispose();
         battleUI = BattleContentUtil.getContentProperty(content,BattleContentUtil.PN_UI);
         if(battleUI != null)
         {
            battleUI.dispose();
         }
         regularBitmapData = BattleContentUtil.getContentProperty(content,BattleContentUtil.PN_REGULAR_BITMAP_DATA);
         if(regularBitmapData != null)
         {
            regularBitmapData.dispose();
         }
         BattleContentUtil.getPreDownloadList(content).forEach(function(param1:*, param2:int, param3:Array):void
         {
            if("type" in param1 && param1.type == FileType.AQZ)
            {
               SpineLoader.clear(String(param1.url).replace("." + FileType.AQZ,""));
            }
         });
         barrageSvc = ServiceContainer.getService(IBattleBarrageService);
         barrageSvc.stopCV();
         LoaderContainer.GC();
         orgMusic = BattleContentUtil.getContentProperty(content,BattleContentUtil.PN_ORG_MUSIC);
         SoundManager.instance.playBackgroundMusic(orgMusic);
         raceId2BitmapDataMap = BattleContentUtil.getContentProperty(content,BattleContentUtil.PN_RACE_ID_2_BITMAP_DATA_MAP);
         for(prop in raceId2BitmapDataMap)
         {
            (raceId2BitmapDataMap[prop] as BitmapData).dispose();
         }
         this.succeed(content);
         dispatcher = BattleContentUtil.getContentProperty(content,BattleContentUtil.PN_EVENT_DISPATCHER);
         isCurUserWiner = BattleContentUtil.getContentProperty(content,BattleContentUtil.PN_IS_CUR_USER_WINNER);
         ModalDialogManager.getInstance().clearAll();
         dispatcher.dispatchEvent(new BattleEvent(BattleEvent.ON_BATTLE_DISPOSE,{
            "isCurUserWiner":isCurUserWiner,
            "isChangeScene":content["isChangeScene"]
         }));
         rentPetSvc = forSvc(IRentPetService);
         rentPetSvc.tryPlayRecyclePetMov();
      }
   }
}

