package mmo.battle.command
{
   import mmo.battle.command.attack.common.AfterSequentialAttackCommand;
   import mmo.battle.command.attack.common.BeforeSequentialAttackCommand;
   import mmo.battle.command.attack.common.ClearUniqueSkillEffectCommand;
   import mmo.battle.command.attack.common.PlayEffectCommand;
   import mmo.battle.command.attack.common.ShowSkillNameCommand;
   import mmo.battle.command.attack.common.UniqueSkillEffectCommand;
   import mmo.battle.command.attack.remote.PlayRemoteActionCommand;
   import mmo.battle.command.attack.remote.RecoverActionCommand;
   import mmo.interfaces.battle.command.IBattleCommand;
   
   public class RemoteAttackCommand extends BattleCommand implements IBattleCommand
   {
      
      public function RemoteAttackCommand()
      {
         super();
      }
      
      override protected function initializeMacroCommand() : void
      {
         addSubCommand(BeforeSequentialAttackCommand);
         addSubCommand(UniqueSkillEffectCommand);
         addSubCommand(ShowSkillNameCommand);
         addParallelSubCommand([PlayRemoteActionCommand,PlayEffectCommand]);
         addSubCommand(RecoverActionCommand);
         addSubCommand(ClearUniqueSkillEffectCommand);
         addSubCommand(AfterSequentialAttackCommand);
         super.initializeMacroCommand();
      }
   }
}

