package mmo.battle.helper
{
   import flash.display.FrameLabel;
   import flash.display.MovieClip;
   import flash.display.Sprite;
   import flash.filters.ColorMatrixFilter;
   import flash.system.ApplicationDomain;
   import mmo.battle.command.attack.consts.ActionFrameLabels;
   import mmo.battle.container.BattleContainer;
   import mmo.battle.entity.BattleBase;
   import mmo.battle.fighter.BattleFighter;
   import mmo.battle.player.BattlePlayer;
   import mmo.battle.util.BattleContentUtil;
   import mmo.common.DisplayUtil;
   import mmo.common.aoqi.packer.SetResPacker;
   import mmo.common.utils.dt.SuperPlayer;
   import mmo.interfaces.battle.avatar.IBattleAvatar;
   import mmo.interfaces.battle.data.BattleInfo;
   import mmo.interfaces.battle.data.PetTitleResult;
   import mmo.interfaces.battle.data.RoundResult;
   import mmo.interfaces.battle.data.SkillResult;
   import mmo.interfaces.battle.data.UseItemResult;
   import mmo.interfaces.battle.fighter.IBattleFighter;
   import mmo.interfaces.battle.player.IBattlePlayer;
   import mmo.interfaces.multipleformpet.IMultipleFormPetService;
   import mmo.interfaces.pettitle.IPetTitleService;
   import mmo.interfaces.pettitle.PetTitleData;
   import mmo.loader.LoaderContainer;
   import mmo.play.globalfunctions.forSvc;
   
   public class BattleActionHelper
   {
      
      private var actionFrames:Array = [ActionFrameLabels.COLOR,ActionFrameLabels.SCALE,ActionFrameLabels.WHITE,ActionFrameLabels.REMOVE_ALL,ActionFrameLabels.SHOW_ALL,ActionFrameLabels.FADE_OUT,ActionFrameLabels.REMOVE_OTHERS,ActionFrameLabels.TITLE];
      
      private var actionFrameFuncsArray:*;
      
      private var actionBackGround:Sprite;
      
      private var filterTargetFightAvatars:Array = [];
      
      private var targetFighters:Array = [];
      
      private var visibleFighters:Array = [];
      
      private var removeFighters:Array = [];
      
      private var _sourcePlayer:BattlePlayer;
      
      private var _sourceFighter:BattleFighter;
      
      private var _isMulti:Boolean;
      
      private var _container:BattleContainer;
      
      private var _result:RoundResult;
      
      private var _battle:BattleBase;
      
      private var _domain:ApplicationDomain;
      
      private var _actionMov:MovieClip;
      
      public function BattleActionHelper()
      {
         this.actionFrameFuncsArray = [this.handleFrameLabelColor,this.handleFrameLabelScale,this.handleFrameLabelWhite,this.handleFrameLabelRemoveAll,this.handleFrameLabelShowAll,this.handleFrameLabelFadeout,this.handleFrameLabelRemoveOthers,this.handleFrameLabelTitle];
         super();
      }
      
      public function handleFrameLabel(param1:MovieClip, param2:Object) : void
      {
         var _loc6_:FrameLabel = null;
         var _loc3_:Array = param1.currentLabels;
         this._actionMov = param1;
         this._sourcePlayer = BattleContentUtil.getContentProperty(param2,BattleContentUtil.PN_SOURCE_PLAYER);
         this._sourceFighter = BattleContentUtil.getContentProperty(param2,BattleContentUtil.PN_SOURCE_FIGHTER);
         this._result = BattleContentUtil.getContentProperty(param2,BattleContentUtil.PN_ROUND_RESULT);
         this._battle = BattleContentUtil.getContentProperty(param2,BattleContentUtil.PN_BATTLE);
         this._domain = BattleContentUtil.getContentProperty(param2,BattleContentUtil.PN_DOMAIN);
         this._container = BattleContentUtil.getContentProperty(param2,BattleContentUtil.PN_CONTAINER);
         var _loc4_:BattleInfo = this._battle.battleResult.battleInfo;
         if(_loc4_.getTeamInfoById(0).playerInfos.length > 1 || _loc4_.getTeamInfoById(1).playerInfos.length > 1)
         {
            this._isMulti = true;
         }
         var _loc5_:int = 0;
         while(_loc5_ < _loc3_.length)
         {
            _loc6_ = _loc3_[_loc5_];
            if(this.checkIsActionFrame(_loc6_.name))
            {
               param1.addFrameScript(_loc6_.frame - 1,this.onBubbleFrame(param1,_loc6_.name));
            }
            _loc5_++;
         }
      }
      
      private function checkIsActionFrame(param1:String) : Boolean
      {
         var _loc2_:int = 0;
         while(_loc2_ < this.actionFrames.length)
         {
            if(param1.indexOf(this.actionFrames[_loc2_]) != -1)
            {
               return true;
            }
            _loc2_++;
         }
         return false;
      }
      
      private function onBubbleFrame(param1:MovieClip, param2:String) : Function
      {
         var actionMov:MovieClip = param1;
         var labelName:String = param2;
         var fun:Function = function():void
         {
            var _loc1_:Array = null;
            var _loc2_:int = 0;
            if(!_isMulti)
            {
               _loc1_ = labelName.split("=");
               _loc2_ = 0;
               while(_loc2_ < actionFrames.length)
               {
                  if(String(_loc1_[0]).indexOf(actionFrames[_loc2_]) != -1)
                  {
                     actionFrameFuncsArray[_loc2_].apply(null,[_loc1_]);
                     break;
                  }
                  _loc2_++;
               }
            }
         };
         return fun;
      }
      
      private function handleFrameLabelFadeout(param1:Array) : void
      {
         this._sourceFighter.fadeOut(null);
      }
      
      private function handleFrameLabelWhite(param1:Array) : void
      {
         var _loc2_:IBattleAvatar = null;
         var _loc3_:SkillResult = null;
         var _loc4_:String = null;
         var _loc5_:int = 0;
         var _loc6_:IBattlePlayer = null;
         var _loc7_:IBattleFighter = null;
         var _loc8_:IBattleAvatar = null;
         if(param1[1] == "end")
         {
            this.removeActionBackGround();
            this.clearFilter(Sprite(this._sourceFighter.avatar.getBloodLayer()));
            this.clearFilter(Sprite(this._sourceFighter.avatar.getBufferLayer()));
            this.clearFilter(Sprite(this._sourceFighter.avatar.getBufferLayer2()));
            for each(_loc2_ in this.filterTargetFightAvatars)
            {
               this.clearFilter(Sprite(_loc2_));
            }
            this.setFightVisibleTrue();
         }
         else
         {
            for each(_loc3_ in this._result.targetSkillResults)
            {
               if(_loc3_.effect)
               {
                  _loc4_ = _loc3_.targetPlayerName;
                  _loc5_ = int(_loc3_.targetCharacterId);
                  _loc6_ = this._battle.getPlayerByName(_loc4_);
                  _loc7_ = _loc6_.getFighterById(_loc5_);
                  _loc8_ = _loc7_.avatar;
                  this.colorFilter(Sprite(_loc8_),255);
                  this.filterTargetFightAvatars.push(_loc8_);
                  this.targetFighters.push(_loc7_);
               }
            }
            this.colorFilter(Sprite(this._sourceFighter.avatar.getBloodLayer()),255);
            this.colorFilter(Sprite(this._sourceFighter.avatar.getBufferLayer()),255);
            this.colorFilter(Sprite(this._sourceFighter.avatar.getBufferLayer2()),255);
            this.setActionBackGround(0,1);
            this.setFightVisibleFalse();
         }
      }
      
      private function handleFrameLabelScale(param1:Array) : void
      {
         var _loc2_:Number = parseFloat(param1[1]);
         var _loc3_:int = parseInt(param1[2]);
         var _loc4_:BattleZoomHelper = new BattleZoomHelper();
         _loc4_.zoomIn(this._sourceFighter.avatar.mcAction,this._sourceFighter,this._battle,this._container,_loc2_,_loc3_);
         Sprite(this._sourceFighter.avatar).addChild(_loc4_);
      }
      
      private function handleFrameLabelColor(param1:Array) : void
      {
         if(param1[1] == "end")
         {
            this.removeActionBackGround();
         }
         else
         {
            this.setActionBackGround(parseInt(param1[1]),parseFloat(param1[2]));
         }
      }
      
      private function handleFrameLabelInverseColor(param1:Array) : void
      {
         var _loc2_:Array = null;
         var _loc3_:ColorMatrixFilter = null;
         var _loc4_:Array = null;
         if(param1[1] == "end")
         {
            this._container.filters = null;
         }
         else
         {
            _loc2_ = new Array();
            _loc2_ = _loc2_.concat([-1,0,0,0,255]);
            _loc2_ = _loc2_.concat([0,-1,0,0,255]);
            _loc2_ = _loc2_.concat([0,0,-1,0,255]);
            _loc2_ = _loc2_.concat([0,0,0,1,0]);
            _loc3_ = new ColorMatrixFilter(_loc2_);
            _loc4_ = new Array();
            _loc4_.push(_loc3_);
            this._container.filters = _loc4_;
         }
      }
      
      private function setFightVisibleFalse() : void
      {
         var _loc1_:IBattlePlayer = null;
         var _loc2_:IBattleFighter = null;
         for each(_loc1_ in this._battle.getPlayerList())
         {
            for each(_loc2_ in _loc1_.fighterList)
            {
               if(Sprite(_loc2_.avatar).visible && _loc2_ != this._sourceFighter && this.targetFighters.indexOf(_loc2_) == -1)
               {
                  Sprite(_loc2_.avatar).visible = false;
                  this.visibleFighters.push(_loc2_);
               }
            }
         }
      }
      
      private function setFightVisibleTrue() : void
      {
         var _loc1_:int = 0;
         while(_loc1_ < this.visibleFighters.length)
         {
            Sprite(IBattleFighter(this.visibleFighters[_loc1_]).avatar).visible = true;
            _loc1_++;
         }
      }
      
      private function setActionBackGround(param1:int, param2:Number) : void
      {
         if(this.actionBackGround == null)
         {
            this.actionBackGround = new Sprite();
            this.actionBackGround.graphics.beginFill(param1,param2);
            this.actionBackGround.graphics.drawRect(0,0,LoaderContainer.stageWidth,LoaderContainer.stageHeight);
            this.actionBackGround.graphics.endFill();
            this._container.movieLayerBelow.addChild(this.actionBackGround);
         }
      }
      
      private function removeActionBackGround() : void
      {
         DisplayUtil.stopAndRemove(this.actionBackGround);
         this.actionBackGround = null;
      }
      
      private function colorFilter(param1:Sprite, param2:int) : void
      {
         var _loc3_:Array = new Array();
         _loc3_ = _loc3_.concat([1,0,0,0,param2]);
         _loc3_ = _loc3_.concat([0,1,0,0,param2]);
         _loc3_ = _loc3_.concat([0,0,1,0,param2]);
         _loc3_ = _loc3_.concat([0,0,0,1,0]);
         var _loc4_:ColorMatrixFilter = new ColorMatrixFilter(_loc3_);
         var _loc5_:Array = new Array();
         _loc5_.push(_loc4_);
         param1.filters = _loc5_;
      }
      
      private function clearFilter(param1:Sprite) : void
      {
         param1.filters = null;
      }
      
      private function handleFrameLabelRemoveAll(param1:Array) : void
      {
         var _loc2_:IBattlePlayer = null;
         var _loc3_:IBattleFighter = null;
         for each(_loc2_ in this._battle.getPlayerList())
         {
            for each(_loc3_ in _loc2_.fighterList)
            {
               if(Sprite(_loc3_.avatar).visible)
               {
                  Sprite(_loc3_.avatar).visible = false;
                  this.removeFighters.push(_loc3_);
               }
            }
         }
      }
      
      private function handleFrameLabelRemoveOthers(param1:Array) : void
      {
         var _loc2_:IBattlePlayer = null;
         var _loc3_:IBattleFighter = null;
         for each(_loc2_ in this._battle.getPlayerList())
         {
            for each(_loc3_ in _loc2_.fighterList)
            {
               if(Sprite(_loc3_.avatar).visible && _loc3_ != this._sourceFighter)
               {
                  Sprite(_loc3_.avatar).visible = false;
                  this.removeFighters.push(_loc3_);
               }
            }
         }
      }
      
      private function handleFrameLabelShowAll(param1:Array) : void
      {
         var _loc2_:int = 0;
         while(_loc2_ < this.removeFighters.length)
         {
            Sprite(IBattleFighter(this.removeFighters[_loc2_]).avatar).visible = true;
            _loc2_++;
         }
      }
      
      private function handleFrameLabelTitle(param1:Array) : void
      {
         var nameArray:Array = param1;
         forSvc([IPetTitleService,IMultipleFormPetService],function():*
         {
            var sourceRaceId:int;
            var multiFormRaceIds:Array;
            var findIndex:int;
            var titleData:PetTitleData = null;
            var playTitleId:int = 0;
            var multiformDiffFrame:int = 0;
            var updateFunc:Function = null;
            updateFunc = function(param1:MovieClip):void
            {
               var setResPacker:SetResPacker = null;
               var movie:MovieClip = param1;
               setResPacker = new SetResPacker(movie);
               titleData.getValues(playTitleId).forEach(function(param1:int, param2:int, param3:*):*
               {
                  setResPacker.setArtNum("spFont.spValue_" + param2,param1,true,true);
                  setResPacker.setText("spFont.txtValue_" + param2,param1);
               });
               setResPacker.setFrame("spFont.mcDiff?",multiformDiffFrame);
            };
            var titleService:IPetTitleService = forSvc(IPetTitleService);
            var multiformPetSvc:IMultipleFormPetService = forSvc(IMultipleFormPetService);
            titleData = getCurrentTitle();
            if(titleData == null)
            {
               return;
            }
            playTitleId = 0;
            if(nameArray.length > 1)
            {
               playTitleId = int(nameArray[1]);
            }
            else
            {
               playTitleId = int(titleData.firstTitleId);
            }
            titleService.getTitleMovie(playTitleId,0,0,_domain,function(param1:Sprite):*
            {
               var movie:MovieClip = null;
               var vc:Sprite = param1;
               movie = vc.getChildByName("view") as MovieClip;
               SuperPlayer.playContinuosMovie(movie,function():*
               {
                  DisplayUtil.stopAndRemove(movie);
               },{
                  "updateFunc":updateFunc,
                  "container":_container.movieLayerAbove
               });
            });
            multiformDiffFrame = 1;
            sourceRaceId = int(_sourceFighter.info.raceId);
            multiFormRaceIds = multiformPetSvc.getSwitchPetRaceIds(sourceRaceId);
            findIndex = multiFormRaceIds.indexOf(sourceRaceId);
            if(findIndex != -1)
            {
               multiformDiffFrame = findIndex + 1;
            }
         });
      }
      
      private function getCurrentTitle() : PetTitleData
      {
         var itemResult:UseItemResult = null;
         var sourceTeamId:int = 0;
         var sourceRaceId:int = 0;
         var petTitleResults:Array = null;
         var resultData:PetTitleData = null;
         var result:PetTitleResult = null;
         if(this._sourceFighter.info.petTitleData)
         {
            return this._sourceFighter.info.petTitleData;
         }
         itemResult = this._battle.battleResult.itemResult;
         sourceTeamId = int(this._result.sourceTeamId);
         sourceRaceId = int(this._sourceFighter.info.raceId);
         if(itemResult != null)
         {
            petTitleResults = itemResult.petTitleResults;
            resultData = null;
            for each(result in petTitleResults)
            {
               if(result.teamId == sourceTeamId)
               {
                  result.petTitles.forEach(function(param1:PetTitleData, param2:int, param3:*):*
                  {
                     var _loc4_:Array = param1.getExtIds();
                     var _loc5_:int = int(param1.raceId);
                     if(_loc5_ == sourceRaceId || _loc4_.indexOf(sourceRaceId) != -1)
                     {
                        resultData = param1;
                     }
                  });
               }
            }
            return resultData;
         }
         return null;
      }
   }
}

