package mmo.battle.command
{
   import mmo.battle.command.playbattle.ClearSceneCommand;
   import mmo.battle.command.playbattle.DownloadCardFaceCommand;
   import mmo.battle.command.playbattle.DownloadLoadingStyleCommand;
   import mmo.battle.command.playbattle.RealDownloadCommand;
   import mmo.battle.command.playbattle.SetupBattleMusicCommand;
   import mmo.battle.command.playsequentialbattle.DisposeBattlefieldCommandSeq;
   import mmo.battle.command.playsequentialbattle.DownloadBackgroundCommandSeq;
   import mmo.battle.command.playsequentialbattle.DownloadCommonResCommandSeq;
   import mmo.battle.command.playsequentialbattle.DownloadConfigCommandSeq;
   import mmo.battle.command.playsequentialbattle.DownloadEmbedEffectCommandSeq;
   import mmo.battle.command.playsequentialbattle.DownloadFighterCommandSeq;
   import mmo.battle.command.playsequentialbattle.HandleBattleNodeCommand;
   import mmo.battle.command.playsequentialbattle.NotifyResultCommandSeq;
   import mmo.battle.command.playsequentialbattle.SetupBattlefieldCommandSeq;
   import mmo.battle.command.playsequentialbattle.SetupUICommandSeq;
   import mmo.interfaces.battle.command.IBattleCommand;
   
   public class PlaySequentialBattleCommand extends BattleCommand implements IBattleCommand
   {
      
      public function PlaySequentialBattleCommand()
      {
         super();
      }
      
      override protected function initializeMacroCommand() : void
      {
         addSubCommand(ClearSceneCommand);
         addSubCommand(DownloadConfigCommandSeq);
         addSubCommand(DownloadCommonResCommandSeq);
         addSubCommand(DownloadBackgroundCommandSeq);
         addSubCommand(DownloadFighterCommandSeq);
         addSubCommand(DownloadEmbedEffectCommandSeq);
         addSubCommand(DownloadLoadingStyleCommand);
         addSubCommand(DownloadCardFaceCommand);
         addSubCommand(RealDownloadCommand);
         addSubCommand(SetupBattleMusicCommand);
         addSubCommand(SetupBattlefieldCommandSeq);
         addSubCommand(SetupUICommandSeq);
         addSubCommand(HandleBattleNodeCommand);
         addSubCommand(NotifyResultCommandSeq);
         addSubCommand(DisposeBattlefieldCommandSeq);
         super.initializeMacroCommand();
      }
   }
}

