package mmo.battle.resultpanel
{
   import flash.display.MovieClip;
   import flash.display.SimpleButton;
   import flash.display.Sprite;
   import flash.events.MouseEvent;
   import flash.system.ApplicationDomain;
   import flash.text.TextField;
   import mmo.battle.util.BattleContentUtil;
   import mmo.common.AlignType;
   import mmo.common.DisplayUtil;
   import mmo.common.utils.panel.modaldialog.ModalDialogManager;
   import mmo.interfaces.ServiceContainer;
   import mmo.interfaces.battle.consts.GainExpState;
   import mmo.interfaces.battle.data.ExtExpResult;
   import mmo.interfaces.battle.data.GainExpInfo;
   import mmo.interfaces.battle.data.GainExpResult;
   import mmo.interfaces.battle.entity.IBattle;
   import mmo.interfaces.chat.IChatService;
   
   public class GainExpPanel
   {
      
      private static const GAIN_EXP_PANEL_CLS:String = "mmo.battle.common.GainExpPanelRes";
      
      private static const BATTLE_WIN_PANEL_CLS:String = "mmo.battle.common.BattleWinPanelRes";
      
      private static const GAIN_ITEM_PANEL_CLS:String = "mmo.battle.common.GainItemPanelRes";
      
      private static const EXP_CARD_COUNT:int = 6;
      
      private var _mcTitle:MovieClip;
      
      private var _btnOk:SimpleButton;
      
      private var _arrExpCard:Array;
      
      private var _dropItemPanel:DropItemPanel;
      
      private var _txtVipExtExp:TextField;
      
      private var _txtTimeExtExp:TextField;
      
      private var _txtItemExtExp:TextField;
      
      private var _btnReplay:SimpleButton;
      
      private var _res:Sprite;
      
      private var _content:Object;
      
      private var _evolutionInfos:Array;
      
      private var _callback:Function;
      
      private var _winPanelCls:String;
      
      private var _hasItem:Boolean;
      
      private var _hasExp:Boolean;
      
      private var _gainExpResult:GainExpResult;
      
      private var _dropItemDatas:Array;
      
      public function GainExpPanel(param1:Object, param2:Function, param3:String)
      {
         super();
         this._content = param1;
         this._callback = param2;
         this._winPanelCls = param3;
         this.initData();
         this.initComponent();
         this.initListener();
         this.setData();
      }
      
      public function show() : void
      {
         ModalDialogManager.getInstance().addModalDialog(this._res,AlignType.NONE);
         DisplayUtil.play(this._mcTitle);
      }
      
      public function close() : void
      {
         var _loc1_:EvolutionPanel = null;
         ModalDialogManager.getInstance().removeModalDialog(this._res);
         this.removeListener();
         if(this._evolutionInfos == null || this._evolutionInfos.length == 0)
         {
            this._callback.apply();
         }
         else
         {
            _loc1_ = new EvolutionPanel(this._content,this._callback,this._evolutionInfos);
            _loc1_.show();
         }
         DisplayUtil.stop(this._mcTitle);
      }
      
      private function initComponent() : void
      {
         var cls:Class;
         var clsName:String = null;
         var i:int = 0;
         var expRes:MovieClip = null;
         var expCard:ExpCard = null;
         var dropItemRes:Sprite = null;
         var resDomain:ApplicationDomain = null;
         var battle:IBattle = null;
         var domain:ApplicationDomain = BattleContentUtil.getContentProperty(this._content,BattleContentUtil.PN_DOMAIN);
         if(this._hasExp)
         {
            if(this._winPanelCls == "")
            {
               clsName = GAIN_EXP_PANEL_CLS;
            }
            else
            {
               clsName = this._winPanelCls;
            }
         }
         else if(this._hasItem)
         {
            clsName = GAIN_ITEM_PANEL_CLS;
         }
         else
         {
            clsName = BATTLE_WIN_PANEL_CLS;
         }
         cls = domain.getDefinition(clsName) as Class;
         this._res = new cls() as Sprite;
         this._mcTitle = this._res.getChildByName("title") as MovieClip;
         if(this._mcTitle != null)
         {
            this._mcTitle.gotoAndStop(1);
            this._mcTitle.addFrameScript(this._mcTitle.totalFrames - 1,function():void
            {
               _mcTitle.stop();
            });
         }
         this._btnOk = this._res.getChildByName("ok") as SimpleButton;
         if(this._hasExp)
         {
            this._arrExpCard = new Array();
            i = 0;
            while(i < EXP_CARD_COUNT)
            {
               expRes = this._res.getChildByName("card" + i) as MovieClip;
               expCard = new ExpCard(expRes);
               expCard.setGainExpInfo(null);
               this._arrExpCard.push(expCard);
               i++;
            }
            this._txtVipExtExp = this._res.getChildByName("vipext") as TextField;
            this._txtTimeExtExp = this._res.getChildByName("timeext") as TextField;
            this._txtItemExtExp = this._res.getChildByName("itemext") as TextField;
         }
         if(this._hasExp || this._hasItem)
         {
            dropItemRes = this._res.getChildByName("dires") as Sprite;
            resDomain = this._content["Domain"];
            this._dropItemPanel = new DropItemPanel(dropItemRes,resDomain);
         }
         this._btnReplay = this._res.getChildByName("btnReplay") as SimpleButton;
         if(this._btnReplay != null)
         {
            battle = BattleContentUtil.getContentProperty(this._content,BattleContentUtil.PN_BATTLE);
            if(battle.battleResult.replay)
            {
               this._btnReplay.addEventListener(MouseEvent.CLICK,this.onReplay);
            }
            else
            {
               this._btnReplay.visible = false;
            }
         }
      }
      
      private function onReplay(param1:MouseEvent) : void
      {
         var _loc2_:IChatService = ServiceContainer.getService(IChatService);
         var _loc3_:IBattle = BattleContentUtil.getContentProperty(this._content,BattleContentUtil.PN_BATTLE);
         _loc2_.showSharePanel(3,{"battleId":_loc3_.battleResult.battleId});
      }
      
      private function initData() : void
      {
         var _loc3_:Array = null;
         var _loc4_:GainExpInfo = null;
         var _loc1_:GainExpResult = BattleContentUtil.getContentProperty(this._content,BattleContentUtil.PN_GAIN_EXP_RESULT);
         this._hasExp = false;
         if(_loc1_ != null)
         {
            _loc3_ = _loc1_.gainExpInfoList;
            for each(_loc4_ in _loc3_)
            {
               if(_loc4_.exp > 0)
               {
                  this._hasExp = true;
                  break;
               }
            }
         }
         this._gainExpResult = _loc1_;
         var _loc2_:Array = BattleContentUtil.getContentProperty(this._content,BattleContentUtil.PN_DROP_ITEM_DATA);
         this._hasItem = _loc2_ != null && _loc2_.length > 0;
         this._dropItemDatas = _loc2_;
      }
      
      private function setData() : void
      {
         var _loc1_:int = 0;
         var _loc2_:int = 0;
         var _loc3_:int = 0;
         var _loc4_:ExtExpResult = null;
         var _loc5_:GainExpInfo = null;
         var _loc6_:ExpCard = null;
         if(this._hasExp)
         {
            this._evolutionInfos = new Array();
            _loc1_ = 0;
            _loc2_ = Math.min(EXP_CARD_COUNT,this._gainExpResult.gainExpInfoList.length);
            _loc3_ = 0;
            while(_loc3_ < _loc2_)
            {
               _loc5_ = this._gainExpResult.gainExpInfoList[_loc3_];
               _loc6_ = this._arrExpCard[_loc1_];
               _loc6_.setGainExpInfo(_loc5_);
               _loc1_++;
               if(_loc5_.state == GainExpState.EVOLUTION)
               {
                  this._evolutionInfos.push(_loc5_);
               }
               _loc3_++;
            }
            _loc4_ = BattleContentUtil.getContentProperty(this._content,BattleContentUtil.PN_EXTRA_EXP_RESULT);
            if(_loc4_ != null)
            {
               this._txtVipExtExp.text = _loc4_.vipExtraExp + "%";
               this._txtTimeExtExp.text = _loc4_.timeExtraExp + "%";
               this._txtItemExtExp.text = _loc4_.itemExtraExp + "%";
            }
            else
            {
               this._txtVipExtExp.text = "0%";
               this._txtTimeExtExp.text = "0%";
               this._txtItemExtExp.text = "0%";
            }
         }
         if(this._hasExp || this._hasItem)
         {
            this._dropItemPanel.setGainItemList(this._dropItemDatas);
         }
      }
      
      private function initListener() : void
      {
         this._btnOk.addEventListener(MouseEvent.CLICK,this.onCloseClick);
      }
      
      private function removeListener() : void
      {
         this._btnOk.removeEventListener(MouseEvent.CLICK,this.onCloseClick);
      }
      
      private function onCloseClick(param1:MouseEvent) : void
      {
         this.close();
      }
   }
}

