package mmo.battle.command.playbattle
{
   import flash.display.Sprite;
   import mmo.battle.util.BattleContentUtil;
   import mmo.common.user.UserInfo;
   import mmo.interfaces.ServiceContainer;
   import mmo.interfaces.battle.data.BattleInfo;
   import mmo.interfaces.battle.data.LoadingStyleResult;
   import mmo.interfaces.battle.data.PlayerInfo;
   import mmo.interfaces.battle.data.UseItemResult;
   import mmo.interfaces.material.battleloadingstyle.IBattleLoadingStyleService;
   import mmo.loader.LoadingSpriteType;
   import mmo.util.command.SceneSimpleCommand;
   
   public class DownloadLoadingStyleCommand extends SceneSimpleCommand
   {
      
      private var _content:Object;
      
      private var _loadingStyleSvc:IBattleLoadingStyleService = ServiceContainer.getService(IBattleLoadingStyleService);
      
      public function DownloadLoadingStyleCommand()
      {
         super();
      }
      
      override public function execute(param1:Object) : void
      {
         this._content = param1;
         var _loc2_:Boolean = BattleContentUtil.getContentProperty(param1,BattleContentUtil.PN_IS_MULTIPLAYER);
         if(_loc2_)
         {
            this.loadStyles([]);
         }
         else
         {
            this.loadLoadingStyle();
         }
      }
      
      private function loadLoadingStyle() : void
      {
         var _loc4_:LoadingStyleResult = null;
         var _loc5_:PlayerInfo = null;
         var _loc6_:Boolean = false;
         var _loc1_:BattleInfo = BattleContentUtil.getContentProperty(this._content,BattleContentUtil.PN_BATTLE_INFO);
         var _loc2_:Array = [];
         var _loc3_:UseItemResult = BattleContentUtil.getContentProperty(this._content,BattleContentUtil.PN_ITEM_RESULT);
         if(_loc3_ != null)
         {
            for each(_loc4_ in _loc3_.loadingStyleResults)
            {
               _loc5_ = _loc1_.teamInfos[_loc4_.teamId].playerInfos[0];
               _loc6_ = _loc5_.playerId == UserInfo.userId && this._loadingStyleSvc.getDisplayPreference() == 0 || _loc5_.playerId != UserInfo.userId && this._loadingStyleSvc.getDisplayPreference() == 1;
               if(_loc6_)
               {
                  _loc2_.unshift(_loc4_.serverId);
               }
               else
               {
                  _loc2_.push(_loc4_.serverId);
               }
            }
         }
         this.loadStyles(_loc2_);
      }
      
      private function loadStyles(param1:Array) : void
      {
         var styleIds:Array = param1;
         this._loadingStyleSvc.loadStyleRes(styleIds,function(param1:Sprite):*
         {
            BattleContentUtil.setContentProperty(_content,BattleContentUtil.PN_LOADING_STYLE,LoadingSpriteType.getBattleLoadingStyleSprite(param1));
            tryFinishCommand();
         },BattleContentUtil.getContentProperty(this._content,BattleContentUtil.PN_DOMAIN));
      }
      
      private function tryFinishCommand() : void
      {
         this.succeed(this._content);
      }
   }
}

