package mmo.battle.service
{
   import flash.display.SimpleButton;
   import flash.display.Sprite;
   import flash.events.MouseEvent;
   import mmo.battle.builder.BattleBuilder;
   import mmo.battle.client.BattleClient;
   import mmo.battle.entity.BattleSimpleResManager;
   import mmo.battle.pvpinvite.PvpInviteIcon;
   import mmo.battle.pvpinvite.PvpInvitePanel;
   import mmo.battle.pvpinvite.PvpInviteResult;
   import mmo.battle.pvpinvite.PvpLosePanel;
   import mmo.battle.pvpinvite.PvpWinPanel;
   import mmo.battle.util.BattleContentUtil;
   import mmo.battle.word.BattleWords;
   import mmo.common.GlobalVariable;
   import mmo.common.ProgressFullSprite;
   import mmo.common.dialog.NewDialog;
   import mmo.common.dialog.NewDialogWithCallback;
   import mmo.common.shareobject.OnceKeyUtil;
   import mmo.common.user.UserInfo;
   import mmo.common.utils.tips.TipsManager;
   import mmo.config.ConfigReader;
   import mmo.framework.comm.SocketClient;
   import mmo.framework.comm.SocketClientEvent;
   import mmo.interfaces.InitServiceEvent;
   import mmo.interfaces.ServiceContainer;
   import mmo.interfaces.aoqiguide.IAoqiGuideService;
   import mmo.interfaces.battle.data.BattleResult;
   import mmo.interfaces.battle.entity.IBattle;
   import mmo.interfaces.battle.entity.IBattleSequential;
   import mmo.interfaces.battle.entity.IBattleTeam;
   import mmo.interfaces.battle.events.BattleEvent;
   import mmo.interfaces.battle.service.BattleParams;
   import mmo.interfaces.battle.service.BattleServiceEvent;
   import mmo.interfaces.battle.service.BattleType;
   import mmo.interfaces.battle.service.IBattleService;
   import mmo.interfaces.battle.word.BattleWordResult;
   import mmo.interfaces.battleconfig.IBattleConfig;
   import mmo.interfaces.catalog.CatalogNames;
   import mmo.interfaces.catalog.IBookService;
   import mmo.interfaces.formation.Formation;
   import mmo.interfaces.formation.IFormationService;
   import mmo.interfaces.material.MaterialTypes;
   import mmo.interfaces.team.ITeamService;
   import mmo.loader.FlashJSConnector;
   import mmo.loader.layer.LayerManager;
   import mmo.loader.scheduler.ResScheduler;
   import mmo.play.scene.SceneManager;
   import mmo.play.scene.SceneManagerEvent;
   import mmo.util.component.artnumber.ArtNumberManager;
   
   public class BattleService extends BattleServiceBase implements IBattleService
   {
      
      private static var _instance:BattleService;
      
      private var _isFighting:Boolean;
      
      private var _isInvitingPvp:Boolean = false;
      
      private var _pvpInviteUserId:String = "";
      
      private var _pvpInviteNickname:String = "";
      
      private var _pvpInvitePanel:PvpInvitePanel;
      
      private var _pvpInviteIcon:PvpInviteIcon;
      
      private const LocalkeyH5Bt:String = "battle_H5_res";
      
      public function BattleService()
      {
         super();
         _instance = this;
      }
      
      public static function get instance() : BattleService
      {
         return _instance;
      }
      
      public function setIsFighting(param1:Boolean) : void
      {
         this._isFighting = param1;
      }
      
      public function setForceSimpleBattleRes(param1:*) : void
      {
         if(typeof param1 == "boolean")
         {
            param1 = param1 ? BattleSimpleResManager.ALL_SIMPLE : -1;
         }
         BattleContentUtil.setForceSimpleBattleResValue(param1);
      }
      
      public function setIsuseH5Battle(param1:Boolean) : void
      {
         this.onSetIsuseH5Battle(param1);
      }
      
      private function onSetIsuseH5Battle(param1:Boolean, param2:Boolean = true) : void
      {
         var _loc3_:Boolean = false;
         if(param1)
         {
            _loc3_ = Boolean(FlashJSConnector.canSupportH5WebAssembly());
            if(!_loc3_)
            {
               if(param2)
               {
                  NewDialog.showSucceedMessage("当前浏览器不支持使用H5战斗资源");
               }
               param1 = false;
            }
         }
         OnceKeyUtil.setKeyDone(this.LocalkeyH5Bt,param1);
         ConfigReader.instance.isBattleH5Movie = param1;
      }
      
      private function initUseH5ResState() : void
      {
         if(OnceKeyUtil.getKey(this.LocalkeyH5Bt,false))
         {
            this.onSetIsuseH5Battle(true,false);
         }
         else
         {
            this.onSetIsuseH5Battle(false,false);
         }
      }
      
      public function init() : void
      {
         SceneManager.getInstance().addEventListener(SceneManagerEvent.ON_LOADING_SCENE,this.onJumpScene);
         SocketClient.instance.addEventListener(BattleClient.RSPN_PVP_RESULT,this.onPvpMessage);
         this.initUseH5ResState();
         this.dispatchEvent(new InitServiceEvent(InitServiceEvent.onInited,{}));
      }
      
      public function fightWithWildPet(param1:int, param2:int) : void
      {
         if(!this.checkCanFight())
         {
            dispatchEvent(new BattleServiceEvent(BattleServiceEvent.ON_FIGHT_WITH_WILDPET,{"res":false}));
            return;
         }
         ProgressFullSprite.show();
         SocketClient.instance.addEventListener(BattleClient.cmdFightWildMonster,this.onFightWildPetReturn);
         BattleClient.instance.fightWildMonster(param2,param1);
      }
      
      private function onFightWildPetReturn(param1:SocketClientEvent) : void
      {
         var _loc2_:* = undefined;
         var _loc3_:* = undefined;
         var _loc4_:String = null;
         ProgressFullSprite.close();
         SocketClient.instance.removeEventListener(BattleClient.cmdFightWildMonster,this.onFightWildPetReturn);
         if(param1.params.mi > 0)
         {
            if(param1.params.br.tbt != null)
            {
               for each(_loc3_ in param1.params.br.brs)
               {
                  if(_loc3_.un == UserInfo.userName)
                  {
                     _loc2_ = _loc3_;
                     break;
                  }
               }
            }
            else
            {
               _loc2_ = param1.params.br;
            }
            if(_loc2_["1di"] == null || _loc2_["1di"].length == 0)
            {
               _loc2_["1di"] = MaterialTypes.ITEM + ":" + param1.params.mi + ":" + param1.params.mn;
            }
            else
            {
               _loc2_["1di"] += "#" + MaterialTypes.ITEM + ":" + param1.params.mi + ":" + param1.params.mn;
            }
         }
         if(Object(param1.params.br).hasOwnProperty("2r"))
         {
            _loc4_ = Object(param1.params.br)["2r"].toString();
            if(_loc4_ == "28")
            {
               NewDialog.showFailMessage("你还在战斗中，请稍后！");
            }
            else
            {
               NewDialog.showFailMessage("战斗失败！" + _loc4_);
            }
            dispatchEvent(new BattleServiceEvent(BattleServiceEvent.ON_FIGHT_WITH_WILDPET,{"res":false}));
         }
         else
         {
            dispatchEvent(new BattleServiceEvent(BattleServiceEvent.ON_FIGHT_WITH_WILDPET,{
               "res":true,
               "br":param1.params.br
            }));
         }
      }
      
      public function fightTaskMonster(param1:int, param2:String) : void
      {
         if(!this.checkCanFight(true))
         {
            dispatchEvent(new BattleServiceEvent(BattleServiceEvent.ON_FIGHT_WITH_TASKPET,{"res":false}));
            return;
         }
         ProgressFullSprite.show();
         SocketClient.instance.addEventListener(BattleClient.cmdFightTaskMonster,this.onFightTaskMonster);
         BattleClient.instance.fightTaskMonster(param1,param2,BattleType.FIGHT_WITH_TASK_PET);
      }
      
      private function onFightTaskMonster(param1:SocketClientEvent) : void
      {
         var _loc2_:String = null;
         ProgressFullSprite.close();
         SocketClient.instance.removeEventListener(BattleClient.cmdFightTaskMonster,this.onFightTaskMonster);
         if(Object(param1.params.br).hasOwnProperty("2r"))
         {
            _loc2_ = Object(param1.params.br)["2r"].toString();
            if(_loc2_ == "28")
            {
               NewDialog.showFailMessage("你还在战斗中，请稍后！");
            }
            else
            {
               NewDialog.showFailMessage("战斗失败！" + _loc2_);
            }
            dispatchEvent(new BattleServiceEvent(BattleServiceEvent.ON_FIGHT_WITH_TASKPET,{"res":false}));
         }
         else
         {
            dispatchEvent(new BattleServiceEvent(BattleServiceEvent.ON_FIGHT_WITH_TASKPET,{
               "res":true,
               "br":param1.params.br
            }));
         }
      }
      
      public function homesteadChallenge(param1:int, param2:String) : void
      {
         if(!this.checkCanFight())
         {
            dispatchEvent(new BattleServiceEvent(BattleServiceEvent.ON_HOMESTEAD_CHALLENGE,{
               "res":false,
               "r":0
            }));
            return;
         }
         ProgressFullSprite.show();
         SocketClient.instance.addEventListener(BattleClient.cmdHomesteadChallenge,this.onHomesteadChallenge);
         BattleClient.instance.homesteadChallenge(param1,param2);
      }
      
      private function onHomesteadChallenge(param1:SocketClientEvent) : void
      {
         var _loc2_:int = 0;
         ProgressFullSprite.close();
         SocketClient.instance.removeEventListener(BattleClient.cmdFightTaskMonster,this.onFightTaskMonster);
         if(Object(param1.params.br).hasOwnProperty("2r"))
         {
            _loc2_ = parseInt(Object(param1.params.br)["2r"]);
            dispatchEvent(new BattleServiceEvent(BattleServiceEvent.ON_HOMESTEAD_CHALLENGE,{
               "res":false,
               "r":_loc2_
            }));
         }
         else
         {
            dispatchEvent(new BattleServiceEvent(BattleServiceEvent.ON_HOMESTEAD_CHALLENGE,{
               "res":true,
               "r":param1.params.r,
               "br":param1.params.br
            }));
         }
      }
      
      public function fightMirroPlayer(param1:String) : void
      {
         if(!this.checkCanFight(true))
         {
            dispatchEvent(new BattleServiceEvent(BattleServiceEvent.ON_FIGHT_MIRRO_PLAYER_END,{"res":false}));
            return;
         }
         ProgressFullSprite.show();
         SocketClient.instance.addEventListener(BattleClient.cmdFightMirroPlayer,this.onFightMirroPlayer);
         BattleClient.instance.fightMirroPlayer(param1,BattleType.FIGHT_WITH_MIRRO_PLAYER);
      }
      
      private function onFightMirroPlayer(param1:SocketClientEvent) : void
      {
         var _loc2_:String = null;
         ProgressFullSprite.close();
         SocketClient.instance.removeEventListener(BattleClient.cmdFightMirroPlayer,this.onFightMirroPlayer);
         if(Object(param1.params.br).hasOwnProperty("2r"))
         {
            _loc2_ = Object(param1.params.br)["2r"].toString();
            if(_loc2_ == "28")
            {
               NewDialog.showFailMessage("你还在战斗中，请稍后！");
            }
            else
            {
               NewDialog.showFailMessage("战斗失败！" + _loc2_);
            }
            dispatchEvent(new BattleServiceEvent(BattleServiceEvent.ON_FIGHT_MIRRO_PLAYER_END,{"res":false}));
         }
         else
         {
            dispatchEvent(new BattleServiceEvent(BattleServiceEvent.ON_FIGHT_MIRRO_PLAYER_END,{
               "res":true,
               "br":param1.params.br
            }));
         }
      }
      
      public function fightWithPlayer(param1:String) : void
      {
         if(!this.checkCanFight())
         {
            return;
         }
         SocketClient.instance.addEventListener(BattleClient.CMD_FIGHT_SOMEONE,this.onFightPlayerReturn);
         BattleClient.instance.fightSomeOne(0,param1);
      }
      
      public function invitePvp(param1:String, param2:String) : void
      {
         if(this._isInvitingPvp || this.checkIsFormationEmpty(null))
         {
            return;
         }
         SocketClient.instance.addEventListener(BattleClient.CMD_INVITE_PVP,this.onInvitePvp);
         SocketClient.instance.addEventListener(BattleClient.CMD_ACCEPT_PVP,this.onAcceptPvpInvite);
         SocketClient.instance.addEventListener(BattleClient.CMD_REFUSE_PVP,this.onRefusePvpInvite);
         this._isInvitingPvp = true;
         this._pvpInviteUserId = param1;
         this._pvpInviteNickname = param2;
         ProgressFullSprite.show();
         BattleClient.instance.invitePvp(param1);
      }
      
      public function cancelPvpInvite(param1:String) : void
      {
         if(!this._isInvitingPvp || param1 != this._pvpInviteUserId)
         {
            return;
         }
         SocketClient.instance.addEventListener(BattleClient.CMD_CANCEL_PVP,this.onCancelPvp);
         ProgressFullSprite.show();
         BattleClient.instance.cacenlPvpInvite(this._pvpInviteUserId);
      }
      
      public function acceptPvpInvite(param1:String) : void
      {
         SocketClient.instance.addEventListener(BattleClient.CMD_ACCEPT_PVP,this.onAcceptPvpInvite);
         ProgressFullSprite.show();
         BattleClient.instance.acceptPvpInvite(param1);
      }
      
      public function refusePvpInvite(param1:String) : void
      {
         SocketClient.instance.addEventListener(BattleClient.CMD_REFUSE_PVP,this.onRefusePvpInvite);
         ProgressFullSprite.show();
         BattleClient.instance.refusePvpInvite(param1);
      }
      
      private function showPvpInvitePanel() : void
      {
         if(this._pvpInvitePanel != null)
         {
            this._pvpInvitePanel.close();
         }
         this._pvpInvitePanel = new PvpInvitePanel(this._pvpInviteUserId,this._pvpInviteNickname);
         this._pvpInvitePanel.show();
      }
      
      private function onInvitePvp(param1:SocketClientEvent) : void
      {
         ProgressFullSprite.close();
         var _loc2_:int = int(param1.params.r);
         if(_loc2_ != PvpInviteResult.SUCCESS)
         {
            PvpInviteResult.handleReturnCode(_loc2_);
            this.clearInviteState();
         }
         else
         {
            this.showPvpInvitePanel();
         }
      }
      
      private function onCancelPvp(param1:SocketClientEvent) : void
      {
         ProgressFullSprite.close();
         var _loc2_:int = int(param1.params.r);
         if(_loc2_ != PvpInviteResult.SUCCESS)
         {
            PvpInviteResult.handleReturnCode(_loc2_);
         }
         else
         {
            this.clearInviteState();
         }
      }
      
      private function onAcceptPvpInvite(param1:SocketClientEvent) : void
      {
         var _loc3_:IBattle = null;
         ProgressFullSprite.close();
         var _loc2_:int = int(param1.params.r);
         if(_loc2_ != PvpInviteResult.SUCCESS)
         {
            PvpInviteResult.handleReturnCode(_loc2_);
         }
         else
         {
            this.clearInviteState();
            if(param1.params.br != null)
            {
               _loc3_ = this.playBattleResult(param1.params.br);
               _loc3_.addEventListener(BattleEvent.RESULT_NOTIFICATION,this.onResultNotify);
            }
         }
      }
      
      private function onRefusePvpInvite(param1:SocketClientEvent) : void
      {
         ProgressFullSprite.close();
         var _loc2_:int = int(param1.params.r);
         if(_loc2_ != PvpInviteResult.SUCCESS)
         {
            PvpInviteResult.handleReturnCode(_loc2_);
         }
         else
         {
            this.clearInviteState();
         }
      }
      
      private function clearInviteState() : void
      {
         SocketClient.instance.removeEventListener(BattleClient.CMD_INVITE_PVP,this.onInvitePvp);
         SocketClient.instance.removeEventListener(BattleClient.CMD_CANCEL_PVP,this.onCancelPvp);
         SocketClient.instance.removeEventListener(BattleClient.CMD_ACCEPT_PVP,this.onAcceptPvpInvite);
         SocketClient.instance.removeEventListener(BattleClient.CMD_REFUSE_PVP,this.onRefusePvpInvite);
         this._isInvitingPvp = false;
         this._pvpInviteUserId = "";
         this._pvpInviteNickname = "";
      }
      
      private function onPvpMessage(param1:SocketClientEvent) : void
      {
         var _loc5_:IBattle = null;
         var _loc2_:int = int(param1.params.s);
         var _loc3_:String = param1.params.s1;
         var _loc4_:String = param1.params.n;
         switch(_loc2_)
         {
            case 1:
               if(GlobalVariable.instance.getVar("sceneForbidPK") == true)
               {
                  break;
               }
               if(this._pvpInviteIcon == null)
               {
                  this._pvpInviteIcon = new PvpInviteIcon();
               }
               this._pvpInviteIcon.pushData(_loc3_,_loc4_);
               this._pvpInviteIcon.show();
               break;
            case 2:
               if(this._pvpInvitePanel != null)
               {
                  this._pvpInvitePanel.close();
                  this._pvpInvitePanel = null;
               }
               this.clearInviteState();
               if(param1.params.br != null)
               {
                  _loc5_ = this.playBattleResult(param1.params.br);
                  if(_loc5_ != null)
                  {
                     _loc5_.addEventListener(BattleEvent.RESULT_NOTIFICATION,this.onResultNotify);
                  }
               }
               break;
            case 3:
               if(this._pvpInvitePanel != null)
               {
                  this._pvpInvitePanel.close();
                  this._pvpInvitePanel = null;
               }
               this.clearInviteState();
               NewDialog.showFailMessage(_loc4_ + "拒绝了你的挑战。");
         }
      }
      
      private function onResultNotify(param1:BattleEvent) : void
      {
         var _loc2_:IBattle = param1.currentTarget as IBattle;
         _loc2_.removeEventListener(BattleEvent.RESULT_NOTIFICATION,this.onResultNotify);
         var _loc3_:Function = param1.params.callback;
         var _loc4_:Boolean = Boolean(param1.params.isWin);
         if(_loc4_)
         {
            new PvpWinPanel(_loc3_).show();
         }
         else
         {
            new PvpLosePanel(_loc3_).show();
         }
      }
      
      private function onFightPlayerReturn(param1:SocketClientEvent) : void
      {
         SocketClient.instance.removeEventListener(BattleClient.CMD_FIGHT_SOMEONE,this.onFightPlayerReturn);
         this.playBattleResult(param1.params.br);
      }
      
      public function customFight(param1:Object, param2:Object) : void
      {
         SocketClient.instance.addEventListener(BattleClient.CMD_CUSTOM_FIGHT,this.onCustomFightReturn);
         BattleClient.instance.customFight(param1,param2);
      }
      
      private function onCustomFightReturn(param1:SocketClientEvent) : void
      {
         SocketClient.instance.removeEventListener(BattleClient.CMD_CUSTOM_FIGHT,this.onCustomFightReturn);
         this.playBattleResult(param1.params.br);
      }
      
      public function playBattleResult(param1:Object, param2:BattleParams = null, param3:Boolean = false) : IBattle
      {
         if(this._isFighting)
         {
            return null;
         }
         if(param1 == null)
         {
            throw new Error("战斗信息为空！");
         }
         if(param1.tbt != null)
         {
            return this.playTeamBattleResult(param1.brs,param2);
         }
         var _loc4_:BattleResult = BattleResult.parseServerResponce(param1,param2);
         var _loc5_:IBattle = BattleBuilder.instacne.buildBattle(_loc4_);
         if(param3)
         {
            _loc5_.skipBattleFlowButtonVisible = false;
            _loc5_.mcSwitchBattleFrameVisible = false;
            _loc5_.switchSimpleBattleResVisible = false;
            _loc5_.mcSwitchPlayingFrameVisible = false;
         }
         _loc5_.addEventListener(BattleEvent.ON_BATTLE_DISPOSE,this.onBattleDispose);
         this.dispatchEvent(new BattleServiceEvent(BattleServiceEvent.ON_START_FIGHT,{"br":_loc4_}));
         this._isFighting = true;
         _loc5_.play();
         return _loc5_;
      }
      
      public function playBattleResultWithCallbackAndSetOperionVisible(param1:Object, param2:Function, param3:BattleParams = null, param4:* = false) : void
      {
         var battle:IBattle = null;
         var br:Object = param1;
         var callback:Function = param2;
         var battleParams:BattleParams = param3;
         var isHideOpertion:* = param4;
         battle = this.playBattleResult(br,battleParams,isHideOpertion);
         battle.addEventListener(BattleEvent.ON_BATTLE_DISPOSE,function onDispose(param1:BattleEvent):void
         {
            battle.removeEventListener(BattleEvent.ON_BATTLE_DISPOSE,onDispose);
            callback.apply(null,[BattleResult.parseServerResponce(br).winerTeamId == 0]);
         });
      }
      
      public function playBattleResultWithCallback(param1:Object, param2:Function, param3:BattleParams = null) : void
      {
         var battle:IBattle = null;
         var br:Object = param1;
         var callback:Function = param2;
         var battleParams:BattleParams = param3;
         battle = this.playBattleResult(br,battleParams);
         battle.addEventListener(BattleEvent.ON_BATTLE_DISPOSE,function onDispose(param1:BattleEvent):void
         {
            battle.removeEventListener(BattleEvent.ON_BATTLE_DISPOSE,onDispose);
            callback.apply(null,[BattleResult.parseServerResponce(br).winerTeamId == 0]);
         });
      }
      
      public function playBattleResultWithResultCode(param1:Object, param2:Function, param3:BattleParams = null) : void
      {
         var battle:IBattle = null;
         var br:Object = param1;
         var callback:Function = param2;
         var battleParams:BattleParams = param3;
         battle = this.playBattleResult(br,battleParams);
         battle.addEventListener(BattleEvent.ON_BATTLE_DISPOSE,function onDispose(param1:BattleEvent):void
         {
            battle.removeEventListener(BattleEvent.ON_BATTLE_DISPOSE,onDispose);
            callback.apply(null,[BattleResult.parseServerResponce(br).winerTeamId]);
         });
      }
      
      public function playBattleFlow(param1:Object, param2:BattleParams = null) : IBattle
      {
         if(this._isFighting)
         {
            return null;
         }
         if(param1 == null)
         {
            throw new Error("战斗信息为空！");
         }
         if(param1.tbt != null)
         {
            return this.playTeamBattleFlow(param1.brs,param2);
         }
         var _loc3_:BattleResult = BattleResult.parseServerResponce(param1,param2);
         var _loc4_:IBattle = BattleBuilder.instacne.buildBattle(_loc3_);
         _loc4_.addEventListener(BattleEvent.ON_BATTLE_DISPOSE,this.onBattleDispose);
         this.dispatchEvent(new BattleServiceEvent(BattleServiceEvent.ON_START_FIGHT,{"br":_loc4_.battleResult}));
         this._isFighting = true;
         _loc4_.playBattleFlow();
         return _loc4_;
      }
      
      public function playSequentialBattleResult(param1:Array, param2:Array, param3:BattleParams = null) : IBattleSequential
      {
         var _loc8_:BattleResult = null;
         var _loc9_:IBattle = null;
         if(this._isFighting)
         {
            return null;
         }
         if(param1 == null || param1 == [])
         {
            throw new Error("战斗信息为空！");
         }
         var _loc4_:Array = new Array();
         var _loc5_:int = 0;
         while(_loc5_ < param1.length)
         {
            _loc8_ = BattleResult.parseServerResponce(param1[_loc5_],param3);
            _loc9_ = BattleBuilder.instacne.buildBattle(_loc8_);
            _loc4_.push(_loc9_);
            _loc5_++;
         }
         var _loc6_:IBattleSequential = BattleBuilder.instacne.buildSequentialBattle(_loc4_,param2);
         _loc6_.addEventListener(BattleEvent.ON_BATTLE_DISPOSE,this.onBattleSeqDispose);
         var _loc7_:IBattle = _loc6_.battles[_loc6_.battles.length - 1] as IBattle;
         this.dispatchEvent(new BattleServiceEvent(BattleServiceEvent.ON_START_FIGHT,{"br":_loc7_.battleResult}));
         this._isFighting = true;
         _loc6_.play();
         return _loc6_;
      }
      
      public function playTeamBattleResult(param1:Array, param2:BattleParams = null) : IBattle
      {
         var _loc6_:BattleResult = null;
         var _loc7_:IBattle = null;
         if(this._isFighting)
         {
            return null;
         }
         if(param1 == null || param1 == [])
         {
            throw new Error("战斗信息为空！");
         }
         var _loc3_:Array = new Array();
         var _loc4_:int = 0;
         while(_loc4_ < param1.length)
         {
            _loc6_ = BattleResult.parseServerResponce(param1[_loc4_],param2);
            _loc7_ = BattleBuilder.instacne.buildBattle(_loc6_);
            _loc3_.push(_loc7_);
            _loc4_++;
         }
         var _loc5_:IBattleTeam = BattleBuilder.instacne.buildTeamBattle(_loc3_);
         _loc5_.addEventListener(BattleEvent.ON_BATTLE_DISPOSE,this.onBattleTeamDispose);
         this.dispatchEvent(new BattleServiceEvent(BattleServiceEvent.ON_START_FIGHT,{"br":_loc5_.myBattle.battleResult}));
         this._isFighting = true;
         _loc5_.play();
         return _loc5_;
      }
      
      public function playTeamBattleFlow(param1:Array, param2:BattleParams = null) : IBattle
      {
         var _loc6_:BattleResult = null;
         var _loc7_:IBattle = null;
         if(this._isFighting)
         {
            return null;
         }
         if(param1 == null || param1 == [])
         {
            throw new Error("战斗信息为空！");
         }
         var _loc3_:Array = new Array();
         var _loc4_:int = 0;
         while(_loc4_ < param1.length)
         {
            _loc6_ = BattleResult.parseServerResponce(param1[_loc4_],param2);
            _loc7_ = BattleBuilder.instacne.buildBattle(_loc6_);
            _loc3_.push(_loc7_);
            _loc4_++;
         }
         var _loc5_:IBattleTeam = BattleBuilder.instacne.buildTeamBattle(_loc3_);
         _loc5_.addEventListener(BattleEvent.ON_BATTLE_DISPOSE,this.onBattleTeamDispose);
         this.dispatchEvent(new BattleServiceEvent(BattleServiceEvent.ON_START_FIGHT,{"br":_loc5_.myBattle.battleResult}));
         this._isFighting = true;
         _loc5_.playBattleFlow();
         return _loc5_;
      }
      
      private function onBattleDispose(param1:BattleEvent) : void
      {
         var _loc2_:IBattle = param1.currentTarget as IBattle;
         _loc2_.removeEventListener(BattleEvent.ON_BATTLE_DISPOSE,this.onBattleDispose);
         this._isFighting = false;
         var _loc3_:Boolean = Boolean(param1.params["isChangeScene"]);
         this.dispatchEvent(new BattleServiceEvent(BattleServiceEvent.ON_FIGHT_END,{
            "br":_loc2_.battleResult,
            "isc":_loc3_
         }));
      }
      
      private function onBattleSeqDispose(param1:BattleEvent) : void
      {
         var _loc2_:IBattleSequential = param1.currentTarget as IBattleSequential;
         _loc2_.removeEventListener(BattleEvent.ON_BATTLE_DISPOSE,this.onBattleSeqDispose);
         this._isFighting = false;
         var _loc3_:IBattle = _loc2_.battles[_loc2_.battles.length - 1];
         var _loc4_:Boolean = Boolean(param1.params["isChangeScene"]);
         this.dispatchEvent(new BattleServiceEvent(BattleServiceEvent.ON_FIGHT_END,{
            "br":_loc3_.battleResult,
            "isc":_loc4_
         }));
      }
      
      private function onBattleTeamDispose(param1:BattleEvent) : void
      {
         var _loc2_:IBattleTeam = param1.currentTarget as IBattleTeam;
         _loc2_.removeEventListener(BattleEvent.ON_BATTLE_DISPOSE,this.onBattleTeamDispose);
         this._isFighting = false;
         var _loc3_:Boolean = Boolean(param1.params["isChangeScene"]);
         this.dispatchEvent(new BattleServiceEvent(BattleServiceEvent.ON_FIGHT_END,{
            "br":_loc2_.myBattle.battleResult,
            "isc":_loc3_
         }));
      }
      
      public function checkCanFight(param1:Boolean = false, param2:Formation = null) : Boolean
      {
         var _loc3_:ITeamService = ServiceContainer.getService(ITeamService) as ITeamService;
         if(_loc3_.isLeader())
         {
            return _loc3_.checkCanFight(param1);
         }
         if(!this.hasAvailableTime())
         {
            return false;
         }
         if(this.checkIsFormationEmpty(null,param2))
         {
            return false;
         }
         if(!param1 && !this.hasAvailableMonster(null,param2))
         {
            return false;
         }
         return true;
      }
      
      public function checkCanFightSeries(param1:Array) : Boolean
      {
         var _loc2_:int = 0;
         while(_loc2_ < param1.length)
         {
            if(!this.checkCanFight(false,param1[_loc2_]))
            {
               return false;
            }
            _loc2_++;
         }
         return true;
      }
      
      public function checkCanFightWithoutTeam(param1:Boolean = false, param2:Formation = null) : Boolean
      {
         var _loc3_:ITeamService = ServiceContainer.getService(ITeamService);
         if(_loc3_.getMyTeam() != null)
         {
            NewDialog.showFailMessage("亲爱的小奥奇,请离开队伍后再来挑战吧！");
            return false;
         }
         return this.checkCanFight(param1,param2);
      }
      
      public function checkIsFormationEmptyWithCallback(param1:Function) : Boolean
      {
         return this.checkIsFormationEmpty(param1);
      }
      
      public function checkHasAvailableMonsterWithCallback(param1:Function) : Boolean
      {
         return this.hasAvailableMonster(param1);
      }
      
      public function isFighting() : Boolean
      {
         return this._isFighting;
      }
      
      public function checkFightPowerEnough(param1:int, param2:Function, param3:Function = null, param4:Sprite = null) : Boolean
      {
         var fun:Function;
         var formationService:IFormationService = null;
         var fightPower:int = param1;
         var okCallback:Function = param2;
         var cancelCallback:Function = param3;
         var panel:Sprite = param4;
         formationService = ServiceContainer.getService(IFormationService);
         if(fightPower <= formationService.formationBattlePower)
         {
            okCallback.apply();
            return true;
         }
         fun = function(param1:Sprite):void
         {
            var reArr:Array;
            var arr:Array;
            var btnUp:SimpleButton;
            var i:*;
            var sp:Sprite = param1;
            ProgressFullSprite.close();
            reArr = [];
            arr = [];
            btnUp = sp["btnUbp"];
            TipsManager.getInstance().addTips(btnUp,"如何提升战斗力");
            sp.addEventListener(MouseEvent.CLICK,function(param1:MouseEvent):void
            {
               var evt:MouseEvent = param1;
               var targetName:String = evt.target.name;
               if(targetName == "btnUbp")
               {
                  ProgressFullSprite.show();
                  ServiceContainer.instance.tryGetService(IBookService,function(param1:IBookService, param2:Object):void
                  {
                     ProgressFullSprite.close();
                     param1.showCatalogAt(CatalogNames.PET_CATALOG,8,1);
                  });
               }
               else if(targetName == "btnAoQiGuide")
               {
                  ProgressFullSprite.show();
                  ServiceContainer.tryGetService(IAoqiGuideService,function(param1:IAoqiGuideService, param2:Object):void
                  {
                     ProgressFullSprite.close();
                     param1.showMainPanel();
                  });
               }
            });
            i = 0;
            while(i < 5)
            {
               reArr.push(sp["mcRe" + i]);
               arr.push(sp["mcAll" + i]);
               i++;
            }
            ArtNumberManager.setNumber(reArr,fightPower);
            ArtNumberManager.setNumber(arr,formationService.formationBattlePower);
            NewDialogWithCallback.showCustomDialog(sp,okCallback,cancelCallback);
         };
         if(panel == null)
         {
            ProgressFullSprite.show(false);
            ResScheduler.getResource("battle/noenoughfp_res",fun,"mmo.battle.common.FightPowerIsNotEnough");
         }
         else
         {
            fun.apply(null,[panel]);
         }
         return false;
      }
      
      private function onJumpScene(param1:SceneManagerEvent) : void
      {
         if(this.isFighting() && LayerManager.getCurrentLayer() == LayerManager.FIGHTING_LAYER)
         {
            param1.params.cancel = true;
            NewDialog.showFailMessage("你还在战斗中哦！");
         }
      }
      
      public function playBattleResultByWords(param1:Object, param2:IBattleConfig) : BattleWordResult
      {
         if(param1 == null)
         {
            throw new Error("战斗信息为空！");
         }
         var _loc3_:BattleResult = BattleResult.parseServerResponce(param1);
         var _loc4_:BattleWords = BattleBuilder.instacne.buildBattleWords(_loc3_,param2);
         return _loc4_.wordResult;
      }
      
      public function getShowBuffStateByKey(param1:String) : Boolean
      {
         return BattleContentUtil.getBuffShowValueByKey(param1);
      }
      
      public function setShowBuffStateByKey(param1:Boolean, param2:String) : void
      {
         BattleContentUtil.setBuffShowValueByKey(param1,param2);
      }
      
      public function getSimpleResState() : int
      {
         return BattleContentUtil.getIsSimpleBattleResType(true);
      }
      
      public function setSimpleResState(param1:int) : void
      {
         BattleContentUtil.setSimpleBattleRes(param1);
      }
   }
}

