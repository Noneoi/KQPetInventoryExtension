package mmo.battle.consts
{
   public class BufferConsts
   {
      
      public static const PLAYER_BUFF_NORMAL:int = 0;
      
      public static const PLAYER_BUFF_EXECUTE:int = 1;
      
      public static const PLAYER_BUFF_WITH_STATE:int = 2;
      
      public static const Ignore_Att_Restraint_BuffIds:Array = [4467,5257,5655];
      
      public static const ChangeMaxHpBuffId:int = -2;
      
      public static const ShieldBuffId:int = -9999;
      
      public static const BuffDisplayType_CLEAR:int = 0;
      
      public static const BuffDisplayType_APPEAR:int = 1;
      
      public static const NO_BUFF_POWER:String = "气势不显示";
      
      public static const NO_BUFF_BLOOD:String = "血量不显示";
      
      public static const BUFF_ATTR_CHANGE:Array = ["物攻","魔攻","超攻","攻","命中","暴击","破击","伤害","物防","魔防","超防","防","闪避","格挡","防暴","减伤","受伤加深","全属性","超物攻","超魔攻","超物防","超魔防"];
      
      public static const SPECIAL_BUFF:Array = ["战魂","不灭意志","九天印记*1","九天印记*2","九天印记*3","印记*1","印记*2","印记*3","睡眠","控制","禁锢","清除增益"];
      
      public static const PRO_BUFF:Array = ["潜能爆发"];
      
      public static const BUFF_HARM_SOURCE:Array = ["爆炸","烧伤","冻伤","电伤","中毒","溅射","轮回之门","魔王气息","魔神气息","青龙之怒","天龙之怒","锁链","天火","吸血","阵术","血拼","诅咒","反弹","痛苦","分身偷袭","分身袭击","奇迹圣门","奇迹之门","天堂之门","天国之门","潜能爆发","自爆","守护","过载攻击","七宿之怒","七宿龙怒","血量上限","复仇","天劫","浩劫之门","雷霆惩戒","炎龙之怒","审判之罪","女神圣灵","红莲烈心","无烬爆炸","激光","修罗冥狱"];
      
      public function BufferConsts()
      {
         super();
      }
   }
}

