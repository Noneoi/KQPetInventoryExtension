package mmo.battle.command.attack.summon
{
   import flash.display.MovieClip;
   import flash.system.ApplicationDomain;
   import mmo.battle.avatar.BattleAvatar;
   import mmo.battle.command.attack.consts.ActionFrameLabels;
   import mmo.battle.container.BattleContainer;
   import mmo.battle.entity.BattleBase;
   import mmo.battle.entity.BattleSimpleResManager;
   import mmo.battle.util.BattleContentUtil;
   import mmo.battle.util.BattleUtil;
   import mmo.common.CommonUtil;
   import mmo.interfaces.battle.data.BattleInfo;
   import mmo.interfaces.battle.data.PlayerInfo;
   import mmo.interfaces.battle.data.RoundResult;
   import mmo.interfaces.battle.data.SkillResult;
   import mmo.interfaces.battle.fighter.IBattleFighter;
   import mmo.interfaces.battle.player.IBattlePlayer;
   import mmo.interfaces.battleconfig.IBattleConfig;
   import mmo.interfaces.battleconfig.define.SummonDefine;
   import mmo.util.command.ISceneCommand;
   import mmo.util.command.SceneSimpleCommand;
   
   public class PlaySummonEffectCommand extends SceneSimpleCommand implements ISceneCommand
   {
      
      private var _content:Object;
      
      private var _domain:ApplicationDomain;
      
      private var _result:RoundResult;
      
      private var _timeline:MovieClip;
      
      private var _battle:BattleBase;
      
      private var _battleConfig:IBattleConfig;
      
      private var _sourcePlayer:IBattlePlayer;
      
      private var _sourceFighter:IBattleFighter;
      
      private var _container:BattleContainer;
      
      private var _effectSkillResultNum:int = 0;
      
      private var _effectSemaphore:int = 0;
      
      public function PlaySummonEffectCommand()
      {
         super();
      }
      
      override public function execute(param1:Object) : void
      {
         var _loc8_:String = null;
         this._content = param1;
         this._timeline = BattleContentUtil.getContentProperty(param1,BattleContentUtil.PN_TIME_LINE);
         this._domain = BattleContentUtil.getContentProperty(param1,BattleContentUtil.PN_DOMAIN);
         this._result = BattleContentUtil.getContentProperty(param1,BattleContentUtil.PN_ROUND_RESULT);
         this._container = BattleContentUtil.getContentProperty(param1,BattleContentUtil.PN_CONTAINER);
         if(BattleUtil.getEffectSkillResultNum(this._result.targetSkillResults) == 0)
         {
            this.succeed(this._content);
            this._content = null;
            return;
         }
         this._battle = BattleContentUtil.getContentProperty(param1,BattleContentUtil.PN_BATTLE);
         this._battleConfig = BattleContentUtil.getContentProperty(param1,BattleContentUtil.PN_BATTLE_CONFIG);
         this._sourcePlayer = BattleContentUtil.getContentProperty(param1,BattleContentUtil.PN_SOURCE_PLAYER);
         this._sourceFighter = BattleContentUtil.getContentProperty(param1,BattleContentUtil.PN_SOURCE_FIGHTER);
         var _loc2_:int = int(CommonUtil.getFrameByName(this._timeline,ActionFrameLabels.EFFECT));
         if(_loc2_ == -1)
         {
            _loc2_ = BattleContentUtil.getContentProperty(param1,BattleContentUtil.PN_EFFECT_FRAME);
         }
         if(_loc2_ == 0)
         {
            _loc8_ = "Missing frame label \"eff\" in effect fla";
            BattleContentUtil.setContentProperty(param1,BattleContentUtil.PN_ERROR_MSG,_loc8_);
            this.fail(this._content);
            this._content = null;
            return;
         }
         var _loc3_:BattleSimpleResManager = BattleContentUtil.getContentProperty(this._content,BattleContentUtil.SIMPLE_RES_DATA);
         var _loc4_:BattleInfo = BattleContentUtil.getContentProperty(this._content,BattleContentUtil.PN_BATTLE_INFO);
         var _loc5_:int = int(this._sourceFighter.info.belong2PlayerIndex);
         var _loc6_:PlayerInfo = _loc4_.teamInfos[this._sourceFighter.needFlip ? 1 : 0].playerInfos[_loc5_];
         var _loc7_:Boolean = _loc3_.checkShouldBeSimpleResBySourceFighter(this._content,this._sourceFighter,_loc6_.playerName);
         if(_loc7_)
         {
            this._timeline.addFrameScript(this._timeline.totalFrames - 3,this.onEffectFrame);
         }
         else
         {
            this._timeline.addFrameScript(_loc2_ - 1,this.onEffectFrame);
         }
      }
      
      private function onEffectFrame() : void
      {
         var _loc8_:SkillResult = null;
         var _loc9_:String = null;
         var _loc10_:int = 0;
         var _loc11_:IBattlePlayer = null;
         var _loc12_:IBattleFighter = null;
         var _loc13_:SummonDefine = null;
         var _loc14_:int = 0;
         var _loc15_:MovieClip = null;
         var _loc16_:Array = null;
         var _loc1_:int = BattleContentUtil.getContentProperty(this._content,BattleContentUtil.PN_EFFECT_FRAME);
         var _loc2_:BattleSimpleResManager = BattleContentUtil.getContentProperty(this._content,BattleContentUtil.SIMPLE_RES_DATA);
         var _loc3_:BattleInfo = BattleContentUtil.getContentProperty(this._content,BattleContentUtil.PN_BATTLE_INFO);
         var _loc4_:int = int(this._sourceFighter.info.belong2PlayerIndex);
         var _loc5_:PlayerInfo = _loc3_.teamInfos[this._sourceFighter.needFlip ? 1 : 0].playerInfos[_loc4_];
         var _loc6_:Boolean = _loc2_.checkShouldBeSimpleResBySourceFighter(this._content,this._sourceFighter,_loc5_.playerName);
         if(_loc6_)
         {
            this._timeline.addFrameScript(this._timeline.totalFrames - 3,null);
         }
         else
         {
            this._timeline.addFrameScript(_loc1_ - 1,null);
         }
         var _loc7_:Boolean = true;
         for each(_loc8_ in this._result.targetSkillResults)
         {
            if(_loc8_.effect)
            {
               _loc7_ = false;
               ++this._effectSkillResultNum;
               _loc9_ = _loc8_.targetPlayerName;
               _loc10_ = int(_loc8_.targetCharacterId);
               _loc11_ = this._battle.getPlayerByName(_loc9_);
               _loc12_ = _loc11_.getFighterById(_loc10_);
               _loc13_ = this._battleConfig.getSummonDefine(this._sourceFighter.info.raceId,_loc12_.info.raceId);
               _loc14_ = 0;
               if(_loc13_ != null)
               {
                  _loc14_ = int(_loc13_.effect);
               }
               _loc15_ = _loc12_.showSummonEffect(_loc14_,this.onEffectEnd);
               _loc16_ = _loc15_.currentLabels;
               if(_loc16_ == null || _loc16_.length != 1)
               {
                  throw new Error("Unexpected bubble label in summon" + _loc14_ + ", while targeting at race" + _loc12_.info.raceId);
               }
               _loc15_.addFrameScript(_loc16_[0].frame - 1,this.onBubbleFrame(_loc11_,_loc12_));
            }
         }
         if(_loc7_)
         {
            this.succeed(this._content);
            this._content = null;
         }
      }
      
      private function onBubbleFrame(param1:IBattlePlayer, param2:IBattleFighter) : Function
      {
         var targetPlayer:IBattlePlayer = param1;
         var targetFighter:IBattleFighter = param2;
         var fun:Function = function():void
         {
            BattleAvatar(targetFighter.avatar).summonAppear();
         };
         return fun;
      }
      
      private function onEffectEnd(param1:IBattleFighter) : void
      {
         var targetFighter:IBattleFighter = param1;
         ++this._effectSemaphore;
         if(targetFighter.info.curHp <= 0)
         {
            targetFighter.fadeOut(function():*
            {
               if(targetFighter.curHp > 0)
               {
                  targetFighter.showUp();
               }
            });
         }
         if(this._sourceFighter.info.curHp <= 0)
         {
            this._sourceFighter.fadeOut(function():*
            {
               if(_sourceFighter.curHp > 0)
               {
                  _sourceFighter.showUp();
               }
            });
         }
         if(this._effectSemaphore == this._effectSkillResultNum)
         {
            BattleContentUtil.setContentProperty(this._content,BattleContentUtil.PN_TIME_LINE,this._sourceFighter.curActionTimeline);
            this.succeed(this._content);
            this._content = null;
         }
      }
   }
}

