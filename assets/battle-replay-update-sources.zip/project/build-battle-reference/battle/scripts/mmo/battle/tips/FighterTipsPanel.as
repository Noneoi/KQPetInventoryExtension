package mmo.battle.tips
{
   import flash.display.MovieClip;
   import flash.display.Sprite;
   import flash.text.TextField;
   import mmo.interfaces.battle.data.FighterInfo;
   import mmo.interfaces.battleconfig.IBattleConfig;
   
   public class FighterTipsPanel
   {
      
      protected var _res:Sprite;
      
      protected var _info:FighterInfo;
      
      protected var _battleConfig:IBattleConfig;
      
      public function FighterTipsPanel(param1:Sprite, param2:FighterInfo, param3:IBattleConfig)
      {
         super();
         this._res = param1;
         this._info = param2;
         this._battleConfig = param3;
         this.initComponent();
         this.refreash();
      }
      
      public function getResSprite() : Sprite
      {
         return this._res;
      }
      
      public function get asMovieClip() : MovieClip
      {
         return this._res as MovieClip;
      }
      
      public function refreash() : void
      {
         if(this._info.curSp > 0)
         {
            this.asMovieClip.gotoAndStop(2);
            this.setBar("sb",this._info.curSp,this._info.maxHp,true);
         }
         else
         {
            this.asMovieClip.gotoAndStop(1);
         }
         (this._res.getChildByName("fname") as TextField).text = this._info.name;
         this.setBar("hb",this._info.curHp,this._info.maxHp);
         this.setBar("pb",this._info.curPower,this._info.maxPower);
      }
      
      protected function initComponent() : void
      {
      }
      
      private function setBar(param1:String, param2:Number, param3:Number, param4:Boolean = false) : void
      {
         var _loc5_:Sprite = this._res.getChildByName(param1) as Sprite;
         var _loc6_:PersentBar = new PersentBar(_loc5_,param4);
         _loc6_.setCurValue(param2);
         _loc6_.setMaxValue(param3);
      }
   }
}

