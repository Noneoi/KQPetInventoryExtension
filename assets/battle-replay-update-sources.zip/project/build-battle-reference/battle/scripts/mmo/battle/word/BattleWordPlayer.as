package mmo.battle.word
{
   import mmo.interfaces.battle.data.PlayerInfo;
   import mmo.loader.common.datastructures.HashMap;
   
   public class BattleWordPlayer
   {
      
      private var _info:PlayerInfo;
      
      private var _mapId2Fighter:HashMap;
      
      private var _battleWords:BattleWords;
      
      public function BattleWordPlayer(param1:PlayerInfo, param2:BattleWords)
      {
         super();
         this._info = param1;
         this._battleWords = param2;
         this._mapId2Fighter = new HashMap();
      }
      
      public function get playerInfo() : PlayerInfo
      {
         return this._info;
      }
      
      public function get fighterList() : Array
      {
         return this._mapId2Fighter.getValues();
      }
      
      public function registerFighter(param1:BattleWordFighter) : void
      {
         this._mapId2Fighter.add(param1.info.id,param1);
      }
      
      public function removeFighter(param1:BattleWordFighter) : void
      {
         this._mapId2Fighter.remove(param1.info.id);
      }
      
      public function getFighterById(param1:int) : BattleWordFighter
      {
         return this._mapId2Fighter.getValue(param1);
      }
   }
}

