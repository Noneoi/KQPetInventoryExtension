package mmo.battle.tips
{
   import flash.display.Sprite;
   import mmo.interfaces.battle.data.FighterInfo;
   import mmo.interfaces.battleconfig.IBattleConfig;
   
   public class FighterTipsPanelForBoss extends FighterTipsPanel
   {
      
      public function FighterTipsPanelForBoss(param1:Sprite, param2:FighterInfo, param3:IBattleConfig)
      {
         super(param1,param2,param3);
      }
   }
}

