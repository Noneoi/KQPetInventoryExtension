package mmo.battle.entity
{
   import mmo.battle.command.PlayTeamBattleCommand;
   import mmo.battle.command.PlayTeamBattleFlowCommand;
   import mmo.battle.util.BattleContentUtil;
   import mmo.interfaces.battle.entity.IBattle;
   import mmo.interfaces.battle.entity.IBattleTeam;
   
   public class BattleBaseTeam extends BattleBase implements IBattleTeam
   {
      
      private var _battles:Array;
      
      private var _myBattle:IBattle;
      
      public function BattleBaseTeam(param1:Array)
      {
         this._battles = param1;
         this.setMyBattle();
         super(this._myBattle.battleResult);
      }
      
      private function setMyBattle() : void
      {
         var _loc2_:IBattle = null;
         var _loc1_:int = 0;
         while(_loc1_ < this._battles.length)
         {
            _loc2_ = this._battles[_loc1_];
            if(_loc2_.battleResult.battleInfo != null)
            {
               this._myBattle = _loc2_;
            }
            _loc1_++;
         }
      }
      
      override public function play() : void
      {
         this.handleMultiInstance();
         var _loc1_:Object = this.getFilledBattleContent();
         _loc1_[BattleContentUtil.PN_TEAM_BATTLES] = this._battles;
         this.executeCommand(PlayTeamBattleCommand,_loc1_);
         this.setTeamLeaderState();
      }
      
      override public function playBattleFlow() : void
      {
         this.handleMultiInstance();
         var _loc1_:Object = this.getFilledBattleContent();
         _loc1_[BattleContentUtil.PN_TEAM_BATTLES] = this._battles;
         this.executeCommand(PlayTeamBattleFlowCommand,_loc1_);
         this.setTeamLeaderState();
      }
      
      public function get myBattle() : IBattle
      {
         return this._myBattle;
      }
   }
}

