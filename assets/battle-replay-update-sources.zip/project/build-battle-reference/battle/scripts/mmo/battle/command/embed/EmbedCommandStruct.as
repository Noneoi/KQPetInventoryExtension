package mmo.battle.command.embed
{
   import mmo.util.command.ISceneCommand;
   
   public class EmbedCommandStruct
   {
      
      private var _command:ISceneCommand;
      
      private var _timing:*;
      
      public function EmbedCommandStruct(param1:ISceneCommand, param2:*)
      {
         super();
         this._command = param1;
         this._timing = param2;
      }
      
      public function get command() : *
      {
         return this._command;
      }
      
      public function get timing() : *
      {
         return this._timing;
      }
   }
}

