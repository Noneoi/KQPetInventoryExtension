package mmo.battle.word
{
   import mmo.interfaces.battle.consts.SkillNumUnitType;
   import mmo.interfaces.battle.data.FighterInfo;
   import mmo.interfaces.battle.data.RoundResult;
   import mmo.interfaces.battle.data.SkillNumResult;
   import mmo.interfaces.battle.data.SkillNumUnit;
   import mmo.interfaces.battle.data.SkillNumUnitValueUpdate;
   import mmo.interfaces.battle.data.SkillResult;
   import mmo.interfaces.battleconfig.consts.SkillTypes;
   import mmo.interfaces.battleconfig.define.BufferDefine;
   import mmo.interfaces.battleconfig.define.SkillDefine;
   
   public class BattleWordFighter
   {
      
      private var _info:FighterInfo;
      
      private var _battleWords:BattleWords;
      
      private var _needFlip:Boolean;
      
      public function BattleWordFighter(param1:FighterInfo, param2:BattleWords, param3:Boolean = false)
      {
         super();
         this._info = param1;
         this._battleWords = param2;
         this._needFlip = param3;
      }
      
      public function get info() : FighterInfo
      {
         return this._info;
      }
      
      public function get needFlip() : Boolean
      {
         return this._needFlip;
      }
      
      public function addBuff(param1:int) : void
      {
         var _loc2_:BufferDefine = this._battleWords.battleConfig.getBufferDefineById(param1);
         BattleWordMessageUtil.showBuffMessage(_loc2_,this._battleWords,this._needFlip,this._info.name);
      }
      
      public function attack(param1:RoundResult, param2:Function) : void
      {
         this.beforeAttackResultObject(param1);
         this.beforeAttack(param1);
         this.startAttack(param1);
         this.afterAttack(param1);
         this.attackEnd(param1);
         this.afterAttackResultObject(param1);
         param2.apply();
      }
      
      private function beforeAttack(param1:RoundResult) : void
      {
         var _loc5_:SkillResult = null;
         var _loc6_:BattleWordPlayer = null;
         var _loc7_:BattleWordFighter = null;
         var _loc8_:SkillNumResult = null;
         var _loc2_:BattleWordPlayer = this._battleWords.getPlayerByName(param1.sourcePlayerName);
         var _loc3_:BattleWordFighter = _loc2_.getFighterById(param1.sourceCharacterId);
         BattleWordUtil.handleHpChangesSingle(param1.sourceSkillNumResult.beforeHps,_loc3_);
         BattleWordUtil.handleSpChangesSingle(param1.sourceSkillNumResult.beforeSps,_loc3_);
         BattleWordUtil.handlePowerChangesSingle(param1.sourceSkillNumResult.beforePowers,_loc3_);
         var _loc4_:SkillNumResult = param1.sourceSkillNumResult;
         BattleWordUtil.handleDisplayBuffChangesSingle(_loc4_.beforeDisplayBuff,_loc3_);
         for each(_loc5_ in param1.targetSkillResults)
         {
            _loc6_ = this._battleWords.getPlayerByName(_loc5_.targetPlayerName);
            _loc7_ = _loc6_.getFighterById(_loc5_.targetCharacterId);
            BattleWordUtil.handleHpChangesSingle(_loc5_.numResult.beforeHps,_loc7_);
            BattleWordUtil.handleSpChangesSingle(_loc5_.numResult.beforeSps,_loc7_);
            BattleWordUtil.handlePowerChangesSingle(_loc5_.numResult.beforePowers,_loc7_);
            _loc8_ = _loc5_.numResult;
            BattleWordUtil.handleDisplayBuffChangesSingle(_loc8_.beforeDisplayBuff,_loc7_);
         }
      }
      
      private function startAttack(param1:RoundResult) : void
      {
         var _loc5_:SkillResult = null;
         var _loc6_:Array = null;
         var _loc7_:int = 0;
         var _loc10_:BattleWordPlayer = null;
         var _loc11_:BattleWordFighter = null;
         var _loc12_:Number = NaN;
         var _loc13_:Number = NaN;
         var _loc14_:int = 0;
         var _loc15_:Number = NaN;
         var _loc16_:Number = NaN;
         var _loc17_:int = 0;
         var _loc18_:int = 0;
         var _loc2_:BattleWordPlayer = this._battleWords.getPlayerByName(param1.sourcePlayerName);
         var _loc3_:BattleWordFighter = _loc2_.getFighterById(param1.sourceCharacterId);
         var _loc4_:SkillDefine = this._battleWords.battleConfig.getSkillDefineById(param1.skillId);
         if(_loc4_.type2 == SkillTypes.UNIQUE || _loc4_.type2 == SkillTypes.SUPER_UNIQUE)
         {
            BattleWordMessageUtil.showAttackMessage(_loc4_,this._battleWords,this._needFlip,this._info.name);
         }
         else
         {
            BattleWordMessageUtil.showNormalAttackMessage(_loc4_,this._battleWords,this._needFlip,this._info.name);
         }
         for each(_loc5_ in param1.targetSkillResults)
         {
            _loc10_ = this._battleWords.getPlayerByName(_loc5_.targetPlayerName);
            _loc11_ = _loc10_.getFighterById(_loc5_.targetCharacterId);
            BattleWordMessageUtil.showSkillMissCriticalBlogMessage(_loc11_.info.name,_loc5_,this._battleWords);
            _loc12_ = 0;
            _loc13_ = 0;
            _loc14_ = 0;
            for each(_loc15_ in _loc5_.numResult.attackHps)
            {
               _loc12_ += _loc15_;
            }
            for each(_loc16_ in _loc5_.numResult.attackSps)
            {
               _loc13_ += _loc16_;
            }
            for each(_loc17_ in _loc5_.numResult.attackPowers)
            {
               _loc14_ += _loc17_;
            }
            BattleWordMessageUtil.showHurtMessage(this._battleWords,this._needFlip,_loc11_.info.name,Math.abs(_loc12_));
            _loc11_.curHp += _loc12_;
            _loc11_.curSp += _loc13_;
            _loc11_.curPower += _loc14_;
         }
         _loc6_ = param1.sourceSkillNumResult.attackHps;
         _loc7_ = 0;
         while(_loc7_ < _loc6_.length)
         {
            _loc3_.curHp += _loc6_[_loc7_];
            _loc7_++;
         }
         var _loc8_:Array = param1.sourceSkillNumResult.attackSps;
         _loc7_ = 0;
         while(_loc7_ < _loc8_.length)
         {
            _loc3_.curSp += _loc8_[_loc7_];
            _loc7_++;
         }
         var _loc9_:Array = param1.sourceSkillNumResult.attackPowers;
         _loc7_ = 0;
         while(_loc7_ < _loc9_.length)
         {
            _loc18_ = int(_loc9_[_loc7_]);
            _loc3_.curPower += _loc9_[_loc7_];
            _loc7_++;
         }
      }
      
      private function afterAttack(param1:RoundResult) : void
      {
         var _loc5_:SkillResult = null;
         var _loc6_:BattleWordPlayer = null;
         var _loc7_:BattleWordFighter = null;
         var _loc8_:SkillNumResult = null;
         var _loc2_:BattleWordPlayer = this._battleWords.getPlayerByName(param1.sourcePlayerName);
         var _loc3_:BattleWordFighter = _loc2_.getFighterById(param1.sourceCharacterId);
         BattleWordUtil.handleHpChangesSingle(param1.sourceSkillNumResult.afterHps,_loc3_);
         BattleWordUtil.handleSpChangesSingle(param1.sourceSkillNumResult.afterSps,_loc3_);
         BattleWordUtil.handlePowerChangesSingle(param1.sourceSkillNumResult.afterPowers,_loc3_);
         var _loc4_:SkillNumResult = param1.sourceSkillNumResult;
         BattleWordUtil.handleDisplayBuffChangesSingle(_loc4_.afterDisplayBuff,_loc3_);
         for each(_loc5_ in param1.targetSkillResults)
         {
            _loc6_ = this._battleWords.getPlayerByName(_loc5_.targetPlayerName);
            _loc7_ = _loc6_.getFighterById(_loc5_.targetCharacterId);
            BattleWordUtil.handleHpChangesSingle(_loc5_.numResult.afterHps,_loc7_);
            BattleWordUtil.handleSpChangesSingle(_loc5_.numResult.afterSps,_loc7_);
            BattleWordUtil.handlePowerChangesSingle(_loc5_.numResult.afterPowers,_loc7_);
            _loc8_ = _loc5_.numResult;
            BattleWordUtil.handleDisplayBuffChangesSingle(_loc8_.afterDisplayBuff,_loc7_);
         }
      }
      
      private function attackEnd(param1:RoundResult) : void
      {
         var _loc4_:SkillResult = null;
         var _loc5_:BattleWordPlayer = null;
         var _loc6_:BattleWordFighter = null;
         var _loc2_:BattleWordPlayer = this._battleWords.getPlayerByName(param1.sourcePlayerName);
         var _loc3_:BattleWordFighter = _loc2_.getFighterById(param1.sourceCharacterId);
         _loc3_.curHp = param1.sourceSkillNumResult.finalHp;
         _loc3_.curPower = param1.sourceSkillNumResult.finalPower;
         for each(_loc4_ in param1.targetSkillResults)
         {
            if(_loc4_.numResult != null)
            {
               _loc5_ = this._battleWords.getPlayerByName(_loc4_.targetPlayerName);
               _loc6_ = _loc5_.getFighterById(_loc4_.targetCharacterId);
               _loc6_.curHp = _loc4_.numResult.finalHp;
               _loc6_.curPower = _loc4_.numResult.finalPower;
            }
         }
      }
      
      private function beforeAttackResultObject(param1:RoundResult) : void
      {
         this.handleAttackResultNumUnit(param1,SkillNumUnitType.TRANSFORM);
      }
      
      private function afterAttackResultObject(param1:RoundResult) : void
      {
         this.handleAttackResultNumUnit(param1,SkillNumUnitType.VALUE_UPDATE);
      }
      
      private function handleAttackResultNumUnit(param1:RoundResult, param2:int) : void
      {
         var _loc4_:SkillNumUnit = null;
         var _loc5_:SkillResult = null;
         var _loc6_:BattleWordPlayer = null;
         var _loc7_:BattleWordFighter = null;
         var _loc3_:Array = [];
         _loc3_ = _loc3_.concat(param1.sourceSkillNumResult.beforeNumUnit);
         _loc3_ = _loc3_.concat(param1.sourceSkillNumResult.afterNumUnit);
         for each(_loc4_ in _loc3_)
         {
            if(_loc4_.type == param2)
            {
               _loc6_ = this._battleWords.getPlayerByName(param1.sourcePlayerName);
               _loc7_ = _loc6_.getFighterById(param1.sourceCharacterId);
               this.handleSingleNumUnit(_loc4_,_loc7_);
            }
         }
         for each(_loc5_ in param1.targetSkillResults)
         {
            _loc3_ = [];
            _loc3_ = _loc3_.concat(_loc5_.numResult.beforeNumUnit);
            _loc3_ = _loc3_.concat(_loc5_.numResult.afterNumUnit);
            for each(_loc4_ in _loc3_)
            {
               if(_loc4_.type == param2)
               {
                  _loc6_ = this._battleWords.getPlayerByName(_loc5_.targetPlayerName);
                  _loc7_ = _loc6_.getFighterById(_loc5_.targetCharacterId);
                  this.handleSingleNumUnit(_loc4_,_loc7_);
               }
            }
         }
      }
      
      private function handleSingleNumUnit(param1:SkillNumUnit, param2:BattleWordFighter) : void
      {
         var _loc3_:SkillNumUnitValueUpdate = null;
         if(param1.type == SkillNumUnitType.VALUE_UPDATE)
         {
            _loc3_ = param1 as SkillNumUnitValueUpdate;
            param2.curHp = _loc3_.curHp;
            param2.maxHp = _loc3_.maxHp;
         }
      }
      
      public function get curHp() : Number
      {
         return this._info.curHp;
      }
      
      public function set curHp(param1:Number) : void
      {
         if(this._info.curHp > 0)
         {
            if(param1 <= 0)
            {
               this.setCurHp(param1);
               this.fadeOut();
            }
            else
            {
               this.setCurHp(param1);
            }
         }
         else if(param1 > 0)
         {
            this.setCurHp(param1);
            this.showUp();
         }
      }
      
      public function get curSp() : Number
      {
         return this._info.curSp;
      }
      
      public function set curSp(param1:Number) : void
      {
         this._info.curSp = param1;
      }
      
      private function setCurHp(param1:Number) : void
      {
         this._info.curHp = param1;
         if(this._info.curHp <= 0)
         {
            this._info.curHp = 0;
         }
      }
      
      public function updateCurHp() : void
      {
         this.curHp = this._info.curHp;
      }
      
      public function get maxHp() : Number
      {
         return this._info.maxHp;
      }
      
      public function set maxHp(param1:Number) : void
      {
         this._info.maxHp = param1;
         if(this._info.maxHp <= 0)
         {
            this._info.maxHp = 0;
         }
      }
      
      public function get curPower() : int
      {
         return this._info.curPower;
      }
      
      public function set curPower(param1:int) : void
      {
         var _loc2_:int = int(this._battleWords.battleConfig.getPowerFullBuffId(this._info.faceId));
         if(param1 >= this._info.maxPower)
         {
            if(this._info.curPower < this._info.maxPower)
            {
               BattleWordMessageUtil.showPowerFullMessage(this._battleWords,this._needFlip,this._info.name);
            }
         }
         this._info.curPower = param1;
      }
      
      private function fadeOut() : void
      {
         BattleWordMessageUtil.showDeathMessage(this._battleWords,this._needFlip,this._info.name);
      }
      
      private function showUp() : void
      {
         BattleWordMessageUtil.showReliveMessage(this._battleWords,this._needFlip,this._info.name);
      }
   }
}

