package mmo.battle.resultpanel
{
   import flash.display.MovieClip;
   import flash.display.Sprite;
   import flash.text.TextField;
   import mmo.common.utils.tips.TipsManager;
   import mmo.interfaces.ServiceContainer;
   import mmo.interfaces.battle.consts.GainExpState;
   import mmo.interfaces.battle.data.GainExpInfo;
   import mmo.interfaces.pet.data.IPetDataService;
   import mmo.interfaces.pet.peticon.IPetIcon;
   import mmo.interfaces.pet.peticon.PetIconContainer;
   import mmo.interfaces.pet.peticon.PetIconType;
   
   public class ExpCard
   {
      
      private var _res:MovieClip;
      
      private var _txtName:TextField;
      
      private var _txtLevel:TextField;
      
      private var _txtGainExp:TextField;
      
      private var _txtNextExp:TextField;
      
      private var _spIconContainer:Sprite;
      
      private var _spExpStone:Sprite;
      
      private var _dataService:IPetDataService;
      
      public function ExpCard(param1:MovieClip)
      {
         super();
         this._res = param1;
         this.initService();
         this.initComponent();
      }
      
      public function setGainExpInfo(param1:GainExpInfo) : void
      {
         if(param1 == null)
         {
            this._res.gotoAndStop(3);
            return;
         }
         this._txtName.text = param1.petName;
         this._txtLevel.text = "lv." + param1.level.toString();
         this._txtGainExp.text = param1.exp.toString();
         this._txtNextExp.text = param1.nextExp.toString();
         var _loc2_:int = int(param1.faceId);
         if(param1.state == GainExpState.EXP_ONLY)
         {
            this._res.gotoAndStop(1);
            this._spExpStone = this._res.getChildByName("expstone") as Sprite;
            this._spExpStone.visible = param1.doubleExp;
            TipsManager.getInstance().addTips(this._spExpStone,"单精灵经验水晶");
         }
         else
         {
            this._res.gotoAndStop(2);
            if(param1.state == GainExpState.EVOLUTION)
            {
               _loc2_ = int(param1.orgFaceId);
            }
         }
         ServiceContainer.tryGetService(IPetIcon,this.onGetPetIcon,null,_loc2_);
      }
      
      private function onGetPetIcon(param1:IPetIcon, param2:int) : void
      {
         while(this._spIconContainer.numChildren > 0)
         {
            this._spIconContainer.removeChildAt(0);
         }
         var _loc3_:PetIconContainer = param1.getPetIcon(param2,PetIconType.FIGHT);
         this._spIconContainer.addChild(_loc3_);
      }
      
      private function initService() : void
      {
         this._dataService = ServiceContainer.getService(IPetDataService) as IPetDataService;
      }
      
      private function initComponent() : void
      {
         this._res.gotoAndStop(1);
         this._txtName = this._res.getChildByName("petname") as TextField;
         this._txtLevel = this._res.getChildByName("lv") as TextField;
         this._txtGainExp = this._res.getChildByName("gainexp") as TextField;
         this._txtNextExp = this._res.getChildByName("nextexp") as TextField;
         this._spIconContainer = this._res.getChildByName("ic") as Sprite;
         this._spExpStone = this._res.getChildByName("expstone") as Sprite;
      }
   }
}

