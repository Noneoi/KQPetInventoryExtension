package mmo.battle.word
{
   import mmo.interfaces.battle.data.SkillResult;
   import mmo.interfaces.battleconfig.consts.SkillTypes;
   import mmo.interfaces.battleconfig.define.BufferDefine;
   import mmo.interfaces.battleconfig.define.SkillDefine;
   
   public class BattleWordMessageUtil
   {
      
      public function BattleWordMessageUtil()
      {
         super();
      }
      
      public static function showOverRoundMessage(param1:BattleWords) : void
      {
         param1.addMessage(getColorMessage("超出回合数上限","#FFCC00"));
      }
      
      public static function showPowerFullMessage(param1:BattleWords, param2:Boolean, param3:String) : void
      {
         param1.addMessage(getNameMessgae(param2,param3) + getColorMessage("气势满了","#FFCC00"));
      }
      
      public static function showDeathMessage(param1:BattleWords, param2:Boolean, param3:String) : void
      {
         param1.addMessage(getNameMessgae(param2,param3) + getColorMessage("阵亡了","#FFCC00"));
      }
      
      public static function showReliveMessage(param1:BattleWords, param2:Boolean, param3:String) : void
      {
         param1.addMessage(getNameMessgae(param2,param3) + getColorMessage("复活了","#FFCC00"));
      }
      
      public static function showHurtMessage(param1:BattleWords, param2:Boolean, param3:String, param4:int) : void
      {
         param1.addMessage(getNameMessgae(param2,param3) + getColorMessage("受到","#FFFFFF") + getColorMessage(param4.toString(),"CC0000") + getColorMessage("伤害","#FFFFFF"));
      }
      
      public static function showBuffMessage(param1:BufferDefine, param2:BattleWords, param3:Boolean, param4:String) : void
      {
         if(param1.hidden)
         {
            return;
         }
         var _loc5_:String = param1.uiMessage;
         while(_loc5_.indexOf("#pet#") != -1)
         {
            _loc5_ = _loc5_.replace("#pet#",getNameMessgae(param3,param4));
         }
         param2.addMessage(_loc5_);
      }
      
      public static function showNormalAttackMessage(param1:SkillDefine, param2:BattleWords, param3:Boolean, param4:String) : void
      {
         param2.addMessage(getNameMessgae(param3,param4) + getColorMessage("使用了普通技","#FFFFFF") + getColorMessage(param1.name,"#FF6600"));
      }
      
      public static function showAttackMessage(param1:SkillDefine, param2:BattleWords, param3:Boolean, param4:String) : void
      {
         var _loc5_:String = SkillTypes.ID2CN[param1.type2];
         param2.addMessage(getNameMessgae(param3,param4) + getColorMessage("使用了" + _loc5_,"#FFFFFF") + getColorMessage(param1.name,"#FF6600"));
      }
      
      public static function showSkillMissCriticalBlogMessage(param1:String, param2:SkillResult, param3:BattleWords) : void
      {
         var _loc5_:String = null;
         var _loc4_:String = getColorMessage("[" + param1 + "]",param2.targetTeamId == 1 ? "#CC0000" : "#0098FF");
         if(param2.miss)
         {
            _loc5_ = getColorMessage("闪避","#99CC00");
         }
         else if(param2.block)
         {
            _loc5_ = getColorMessage("格挡","#00FFFF");
         }
         if(_loc5_ != null)
         {
            param3.addMessage(_loc4_ + _loc5_);
         }
         if(param2.critical)
         {
            _loc5_ = getColorMessage("被暴击","#FF3300");
            param3.addMessage(_loc4_ + _loc5_);
         }
      }
      
      private static function getNameMessgae(param1:Boolean, param2:String) : String
      {
         var _loc3_:String = param1 ? "#CC0000" : "#0098FF";
         return getColorMessage("[" + param2 + "]",_loc3_);
      }
      
      private static function getColorMessage(param1:String, param2:String) : String
      {
         return "<font color=\'" + param2 + "\'>" + param1 + "</font>";
      }
   }
}

