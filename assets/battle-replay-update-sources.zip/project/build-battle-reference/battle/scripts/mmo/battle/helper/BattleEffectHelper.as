package mmo.battle.helper
{
   import flash.display.MovieClip;
   import mmo.battle.command.attack.consts.EffectFrameLabels;
   
   public class BattleEffectHelper
   {
      
      private var _elementsName:Array = [EffectFrameLabels.SCALE];
      
      private var _elementsNameFuncs:Array;
      
      public function BattleEffectHelper()
      {
         this._elementsNameFuncs = [this.handleElementScale];
         super();
      }
      
      public function handleElementsName(param1:MovieClip, param2:Object) : void
      {
         var _loc4_:MovieClip = null;
         var _loc5_:Function = null;
         var _loc3_:int = 0;
         while(_loc3_ < this._elementsName.length)
         {
            _loc4_ = param1.getChildByName(this._elementsName[_loc3_]) as MovieClip;
            if(_loc4_ != null)
            {
               _loc5_ = this._elementsNameFuncs[_loc3_] as Function;
               _loc5_.apply(null,[param1,param2]);
            }
            _loc3_++;
         }
      }
      
      public function buildContent(param1:int) : Object
      {
         var _loc2_:Object = new Object();
         _loc2_["targetTeamId"] = param1;
         return _loc2_;
      }
      
      private function handleElementScale(param1:MovieClip, param2:Object) : void
      {
         var _loc3_:int = int(param2["targetTeamId"]);
         if(param1[EffectFrameLabels.SCALE] != null)
         {
            MovieClip(param1[EffectFrameLabels.SCALE]).scaleX = _loc3_ == 1 ? 1 : -1;
         }
      }
   }
}

