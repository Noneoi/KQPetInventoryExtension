package mmo.battle.command.playbattle
{
   import mmo.battle.util.BattleContentUtil;
   import mmo.interfaces.ServiceContainer;
   import mmo.interfaces.battle.data.AbstractItemResult;
   import mmo.interfaces.battle.data.BarrageResult;
   import mmo.interfaces.battle.data.BufferItemResult;
   import mmo.interfaces.battle.data.PetTitleResult;
   import mmo.interfaces.battle.data.UseItemResult;
   import mmo.interfaces.material.battlebarrage.BattleBarrage;
   import mmo.interfaces.material.battlebarrage.IBattleBarrageService;
   import mmo.interfaces.pettitle.PetTitleData;
   import mmo.util.command.ISceneCommand;
   import mmo.util.command.SceneSimpleCommand;
   
   public class DownloadItemCommand extends SceneSimpleCommand implements ISceneCommand
   {
      
      private static const ITEM_FILE_PREFIX:String = "battleitem/item";
      
      private static const BARRAGE_FILE_PREFIX:String = "battlebarrage/barrageres_";
      
      private static const PETTITLE_FILE_PREFIX:String = "pettitle/movie/pettitlemovie";
      
      private static const CATCH_ITEM_DEFAULT_ID:int = 6000002;
      
      private var _content:Object;
      
      private var _itemResult:UseItemResult;
      
      private var _barrageSvc:IBattleBarrageService = ServiceContainer.getService(IBattleBarrageService);
      
      public function DownloadItemCommand()
      {
         super();
      }
      
      override public function execute(param1:Object) : void
      {
         this._content = param1;
         this._itemResult = BattleContentUtil.getContentProperty(param1,BattleContentUtil.PN_ITEM_RESULT);
         if(this._itemResult != null)
         {
            BattleContentUtil.addToPreDownloadList(param1,this.getDownloadFileList());
         }
         this.finish();
      }
      
      private function getDownloadFileList() : Array
      {
         var arr:Array = null;
         var itemResult:AbstractItemResult = null;
         var bufferItemResult:BufferItemResult = null;
         var result:BarrageResult = null;
         var id_index:Array = null;
         var barrageDefine:BattleBarrage = null;
         var titleResult:PetTitleResult = null;
         arr = [];
         var itemResultList:Array = [];
         if(this._itemResult.bufferResults != null)
         {
            for each(bufferItemResult in this._itemResult.bufferResults)
            {
               arr.push(ITEM_FILE_PREFIX + bufferItemResult.itemId);
            }
         }
         if(this._itemResult.damageResults != null)
         {
            itemResultList = itemResultList.concat(this._itemResult.damageResults);
         }
         for each(itemResult in itemResultList)
         {
            arr.push(ITEM_FILE_PREFIX + itemResult.itemId);
         }
         if(this._itemResult.catchResults != null)
         {
            arr.push(ITEM_FILE_PREFIX + CATCH_ITEM_DEFAULT_ID);
         }
         if(this._itemResult.barrageResults != null)
         {
            for each(result in this._itemResult.barrageResults)
            {
               id_index = this._barrageSvc.transformToClientId(result.serverId);
               arr.push(BARRAGE_FILE_PREFIX + id_index[0]);
               barrageDefine = this._barrageSvc.getBarrage(id_index[0]);
               if(Boolean(barrageDefine.hasCV) && Boolean(this._barrageSvc.isOpenCV))
               {
                  arr.push(barrageDefine.getCVUrl());
               }
            }
         }
         if(this._itemResult.petTitleResults != null)
         {
            for each(titleResult in this._itemResult.petTitleResults)
            {
               titleResult.petTitles.forEach(function(param1:PetTitleData, param2:int, param3:*):*
               {
                  arr.push(PETTITLE_FILE_PREFIX + param1.firstTitleId);
               });
            }
         }
         return arr;
      }
      
      private function finish() : void
      {
         this.succeed(this._content);
         this._content = null;
         this._itemResult = null;
      }
   }
}

