package mmo.battle.command.attack.representer
{
   import mmo.battle.command.BattleCommand;
   import mmo.battle.command.attack.common.AfterSequentialAttackCommand;
   import mmo.battle.command.attack.common.BeforeSequentialAttackCommand;
   import mmo.battle.command.attack.common.ClearUniqueSkillEffectCommand;
   import mmo.battle.command.attack.common.UniqueSkillEffectCommand;
   import mmo.battle.command.attack.remote.RecoverActionCommand;
   import mmo.interfaces.battle.command.IBattleCommand;
   
   public class RepresenterRemoteAttackCommand extends BattleCommand implements IBattleCommand
   {
      
      public function RepresenterRemoteAttackCommand()
      {
         super();
      }
      
      public function RepresentRemoteAttackCommand() : *
      {
      }
      
      override protected function initializeMacroCommand() : void
      {
         addSubCommand(BeforeSequentialAttackCommand);
         addSubCommand(UniqueSkillEffectCommand);
         addSubCommand(ShowRepresenterSkillNameCommand);
         addParallelSubCommand([PlayRepresenterRemoteActionCommand,PlayRepresenterEffectCommand]);
         addSubCommand(RecoverActionCommand);
         addSubCommand(ClearUniqueSkillEffectCommand);
         addSubCommand(AfterSequentialAttackCommand);
         super.initializeMacroCommand();
      }
   }
}

