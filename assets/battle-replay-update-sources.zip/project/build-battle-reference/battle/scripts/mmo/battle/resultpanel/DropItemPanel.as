package mmo.battle.resultpanel
{
   import flash.display.MovieClip;
   import flash.display.Sprite;
   import flash.system.ApplicationDomain;
   import mmo.interfaces.material.MaterialCommonData;
   
   public class DropItemPanel
   {
      
      private static const CARD_RES_CLS:String = "mmo.battle.common.GainItemRes";
      
      private static const CARD_CONTAINER_HEIGHT:Number = 45;
      
      private static const CARD_CONST_WIDTH:Number = 84;
      
      private var CARD_CONTAINER_WIDTH:Number = 171;
      
      private var _spResource:Sprite;
      
      private var _resDomain:ApplicationDomain;
      
      private var _mcTitle:MovieClip;
      
      private var _spCardContainer:Sprite;
      
      private var _arrCard:Array;
      
      public function DropItemPanel(param1:Sprite, param2:ApplicationDomain)
      {
         super();
         this._spResource = param1;
         this._resDomain = param2;
         this.initComponent();
      }
      
      public function setGainItemList(param1:Array) : void
      {
         if(param1 == null || param1.length == 0)
         {
            this._mcTitle.gotoAndStop(2);
            return;
         }
         this._mcTitle.gotoAndStop(1);
         this.initData(param1);
         this.adjustCardPosition();
      }
      
      private function initData(param1:Array) : void
      {
         var _loc2_:MaterialCommonData = null;
         var _loc3_:Class = null;
         var _loc4_:Sprite = null;
         var _loc5_:ItemCard = null;
         this._arrCard = new Array();
         for each(_loc2_ in param1)
         {
            _loc3_ = this._resDomain.getDefinition(CARD_RES_CLS) as Class;
            _loc4_ = new _loc3_() as Sprite;
            _loc5_ = new ItemCard(_loc4_);
            _loc5_.setMaterialData(_loc2_);
            this._arrCard.push(_loc5_);
            this._spCardContainer.addChild(_loc5_.resSprite);
         }
      }
      
      private function adjustCardPosition() : void
      {
         var _loc1_:Sprite = null;
         var _loc4_:Number = NaN;
         var _loc5_:int = 0;
         var _loc2_:int = int(this._arrCard.length);
         var _loc3_:Number = 1;
         if(_loc2_ > 2)
         {
            _loc3_ = 1 - (_loc2_ - 2) * 0.2;
            this.CARD_CONTAINER_WIDTH = 210;
         }
         if(_loc3_ < 0)
         {
            _loc3_ = 1;
         }
         if(this._arrCard.length == 1)
         {
            _loc1_ = ItemCard(this._arrCard[0]).resSprite;
            _loc1_.x = (this.CARD_CONTAINER_WIDTH - CARD_CONST_WIDTH) / 2;
         }
         else
         {
            _loc4_ = (this.CARD_CONTAINER_WIDTH - CARD_CONST_WIDTH * _loc2_) / (_loc2_ - 1);
            _loc1_ = ItemCard(this._arrCard[0]).resSprite;
            _loc1_.scaleX = _loc3_;
            _loc1_.scaleY = _loc3_;
            _loc5_ = 1;
            while(_loc5_ < _loc2_)
            {
               _loc1_ = ItemCard(this._arrCard[_loc5_]).resSprite;
               _loc1_.x = (CARD_CONST_WIDTH + _loc4_) * _loc5_;
               _loc1_.scaleX = _loc3_;
               _loc1_.scaleY = _loc3_;
               _loc5_++;
            }
         }
      }
      
      private function initComponent() : void
      {
         this._mcTitle = this._spResource.getChildByName("title") as MovieClip;
         this._mcTitle.gotoAndStop(2);
         this._spCardContainer = this._spResource.getChildByName("ic") as Sprite;
      }
   }
}

