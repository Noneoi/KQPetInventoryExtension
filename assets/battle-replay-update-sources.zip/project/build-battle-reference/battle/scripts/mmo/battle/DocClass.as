package mmo.battle
{
   import flash.display.Sprite;
   import mmo.battle.avatar.ext.CompileAvatar;
   import mmo.battle.service.BattleService;
   
   public class DocClass extends Sprite
   {
      
      public function DocClass()
      {
         super();
      }
      
      private function compile() : void
      {
         var _loc1_:BattleService = null;
         CompileAvatar.compileMe();
      }
   }
}

