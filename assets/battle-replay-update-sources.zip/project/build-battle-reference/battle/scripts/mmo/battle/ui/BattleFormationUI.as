package mmo.battle.ui
{
   import flash.display.MovieClip;
   import flash.display.Sprite;
   import flash.text.TextField;
   import mmo.common.DisplayUtil;
   import mmo.interfaces.ServiceContainer;
   import mmo.interfaces.battle.data.PlayerInfo;
   import mmo.interfaces.formation.FormationDefine;
   import mmo.interfaces.formation.IFormationService;
   
   public class BattleFormationUI
   {
      
      private var _resSprite:Sprite;
      
      private var _playerInfo:PlayerInfo;
      
      private var _formationService:IFormationService;
      
      private var _txtFormationName:TextField;
      
      private var _spFormationView:Sprite;
      
      public function BattleFormationUI(param1:Sprite)
      {
         super();
         this._resSprite = param1;
      }
      
      public function setPlayerInfo(param1:PlayerInfo) : void
      {
         this.initService();
         this.initComponent();
         this.setFormationInfo(param1);
      }
      
      private function initService() : void
      {
         this._formationService = ServiceContainer.getService(IFormationService) as IFormationService;
      }
      
      private function initComponent() : void
      {
         this._txtFormationName = this._resSprite.getChildByName("fname") as TextField;
         this._spFormationView = this._resSprite.getChildByName("fview") as Sprite;
      }
      
      private function setFormationInfo(param1:PlayerInfo) : void
      {
         var _loc4_:MovieClip = null;
         if(param1.playerType == PlayerInfo.PLAYER_TYPE_AI)
         {
            DisplayUtil.stopAndRemove(this._resSprite);
            return;
         }
         this._playerInfo = param1;
         var _loc2_:FormationDefine = this._formationService.getFormationDefine(this._playerInfo.formationId,10);
         this._txtFormationName.text = _loc2_.name + "lv" + param1.formationLevel;
         var _loc3_:int = 0;
         while(_loc3_ < 9)
         {
            _loc4_ = this._spFormationView.getChildByName("p" + _loc3_) as MovieClip;
            if(_loc2_.data.indexOf(_loc3_) == -1)
            {
               _loc4_.filters = null;
               _loc4_.gotoAndStop(2);
            }
            else
            {
               _loc4_.gotoAndStop(1);
            }
            _loc3_++;
         }
      }
   }
}

