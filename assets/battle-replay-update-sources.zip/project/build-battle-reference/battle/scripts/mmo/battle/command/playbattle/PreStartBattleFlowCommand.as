package mmo.battle.command.playbattle
{
   import mmo.battle.util.BattleContentUtil;
   import mmo.interfaces.battle.entity.IBattle;
   import mmo.util.command.ISceneCommand;
   import mmo.util.command.SceneSimpleCommand;
   
   public class PreStartBattleFlowCommand extends SceneSimpleCommand implements ISceneCommand
   {
      
      public function PreStartBattleFlowCommand()
      {
         super();
      }
      
      override public function execute(param1:Object) : void
      {
         var content:Object = param1;
         var battle:IBattle = BattleContentUtil.getContentProperty(content,BattleContentUtil.PN_BATTLE);
         var releaseControl:Function = function():*
         {
            succeed(content);
         };
         var obj:Object = {"releaseControl":releaseControl};
         if(battle.battleResult.battleParams == null || battle.battleResult.battleParams.injectionBeforeStartBattleFlow == null)
         {
            releaseControl();
         }
         else
         {
            battle.battleResult.battleParams.injectionBeforeStartBattleFlow(obj);
         }
      }
   }
}

