package mmo.battle.ui
{
   import com.greensock.TweenLite;
   import flash.display.MovieClip;
   import flash.display.SimpleButton;
   import flash.display.Sprite;
   import flash.events.IEventDispatcher;
   import flash.events.MouseEvent;
   import flash.system.ApplicationDomain;
   import flash.text.TextField;
   import mmo.battle.entity.BattleBase;
   import mmo.battle.entity.BattleSimpleResManager;
   import mmo.battle.util.BattleContentUtil;
   import mmo.common.DisplayUtil;
   import mmo.common.EventBinder;
   import mmo.common.shareobject.LocalStore;
   import mmo.common.utils.counter.Counter;
   import mmo.common.utils.counter.CounterEvent;
   import mmo.common.utils.dt.ClientXT;
   import mmo.common.utils.panel.helper.ClickHelper;
   import mmo.common.utils.tips.TipsManager;
   import mmo.config.ConfigReader;
   import mmo.framework.comm.SocketClient;
   import mmo.interfaces.ServiceContainer;
   import mmo.interfaces.battle.consts.UserBattleConfig;
   import mmo.interfaces.battle.data.BattleInfo;
   import mmo.interfaces.battle.data.NpcBlessResult;
   import mmo.interfaces.battle.data.PlayerInfo;
   import mmo.interfaces.battle.data.TeamInfo;
   import mmo.interfaces.battle.events.BattleEvent;
   import mmo.interfaces.newactivity.INewActivityService;
   import mmo.interfaces.nicknamecard.INickNameCard;
   import mmo.interfaces.user.IUserNameManager;
   import mmo.interfaces.vip.IVipService;
   import mmo.loader.LoaderContainer;
   import mmo.play.globalfunctions.forSvc;
   import mmo.play.scene.SceneManager;
   
   public class BattleUI
   {
      
      private static const SKIP_BATTLE_PET_LIMIT:Object = {"sk":{"raceId":4098}};
      
      private static const SKIP_BATTLE_LIMIT:Object = {"wft":{
         "openValue":0,
         "skipAppearWaitTime":3
      }};
      
      private static const ACT_SKIP_CONFIG:Object = {
         "actName":"everyoneskipbattle0828",
         "params":{
            "action":"getTdFastSkip",
            "callback":null
         },
         "skipAppearWaitTime":3
      };
      
      private static const BATTLE_RES_MODE_CAN_CHANGE_TIPS:String = "battle_res_mode_can_change_tips";
      
      private static const BATTLE_RES_MODE_TIPS_SHOW_BTW:int = 200000;
      
      private static const EXT_NAME:String = "NewTempActivityExtension";
      
      private static const CMD_CLBCD:String = "90_201_5";
      
      private static const CMD_OVER_FIGHT:String = "1008_20200717_vtq_1";
      
      protected var _resSprite:Sprite;
      
      protected var _battleInfo:BattleInfo;
      
      protected var _npcBlessResult:NpcBlessResult;
      
      protected var _domain:ApplicationDomain;
      
      protected var _dispatcher:IEventDispatcher;
      
      protected var _eventBinder:EventBinder;
      
      protected var _txtSceneName:TextField;
      
      protected var _btnSkipBattleFlow:SimpleButton;
      
      protected var _mcSkip:MovieClip;
      
      protected var _playerUI0:BattlePlayerUI;
      
      protected var _playerUI1:BattlePlayerUI;
      
      protected var _messUI:BattleMessageUI;
      
      private var _nickNameCardStrList:Array = [];
      
      private var _battle:BattleBase;
      
      private var _counter:Counter;
      
      private var _clickHelper:ClickHelper;
      
      private var _vipService:IVipService = ServiceContainer.getService(IVipService);
      
      private var _isActTdFastSkip:Boolean;
      
      private var _isBattleResModeChange:* = false;
      
      public function BattleUI(param1:Sprite, param2:ApplicationDomain, param3:IEventDispatcher)
      {
         super();
         this._resSprite = param1;
         this._domain = param2;
         this._dispatcher = param3;
         this._eventBinder = new EventBinder();
         this.initComponent();
         this.initListener();
         this._clickHelper = new ClickHelper(param1);
         this._clickHelper.setStateButtonEnbale(false);
         this._clickHelper.regClickFunc("skip",this.onSkipBattleFlowClick);
      }
      
      public function setInfo(param1:BattleInfo, param2:NpcBlessResult, param3:BattleBase) : void
      {
         var teamInfo0:TeamInfo;
         var teamInfo1:TeamInfo;
         var userNameManager:IUserNameManager;
         var curUserName:String;
         var playerInfo0:PlayerInfo = null;
         var playerInfo1:PlayerInfo = null;
         var uiType0:String = null;
         var uiType1:String = null;
         var showWord:Boolean = false;
         var battleInfo:BattleInfo = param1;
         var npcBlessResult:NpcBlessResult = param2;
         var battle:BattleBase = param3;
         this._battle = battle;
         this.setCommonInfo(battleInfo,npcBlessResult);
         teamInfo0 = this._battleInfo.teamInfos[0] as TeamInfo;
         teamInfo1 = this._battleInfo.teamInfos[1] as TeamInfo;
         playerInfo0 = teamInfo0.playerInfos[0] as PlayerInfo;
         playerInfo1 = teamInfo1.playerInfos[0] as PlayerInfo;
         userNameManager = ServiceContainer.getService(IUserNameManager) as IUserNameManager;
         curUserName = userNameManager.getNickName(SocketClient.instance.myUserName);
         uiType0 = BattlePlayerUI.UI_TYPE_OTHER;
         uiType1 = BattlePlayerUI.UI_TYPE_OTHER;
         showWord = false;
         if(playerInfo0.playerName == curUserName)
         {
            uiType0 = BattlePlayerUI.UI_TYPE_SELF;
         }
         else if(playerInfo1.playerName == curUserName)
         {
            uiType1 = BattlePlayerUI.UI_TYPE_SELF;
         }
         if(playerInfo0.playerType == PlayerInfo.PLAYER_TYPE_USER && playerInfo1.playerType == PlayerInfo.PLAYER_TYPE_USER && (playerInfo0.playerName == curUserName || playerInfo1.playerName == curUserName))
         {
            showWord = true;
         }
         this.getPlayerNickNameCardStr(playerInfo0,playerInfo1,function():void
         {
            _playerUI0.setPlayerInfo(playerInfo0,_npcBlessResult,uiType0,showWord,_nickNameCardStrList[0]);
            _playerUI1.setPlayerInfo(playerInfo1,_npcBlessResult,uiType1,showWord,_nickNameCardStrList[1]);
         });
         this._txtSceneName.text = SceneManager.getInstance().loadedSceneInfo.sceneDesc;
      }
      
      private function getPlayerNickNameCardStr(param1:PlayerInfo, param2:PlayerInfo, param3:Function) : void
      {
         var _nickCardService:INickNameCard = null;
         var playerInfo0:PlayerInfo = param1;
         var playerInfo1:PlayerInfo = param2;
         var callback:Function = param3;
         _nickCardService = ServiceContainer.getService(INickNameCard);
         _nickCardService.getNickNameCardStrByUserId(playerInfo0.playerId,function(param1:String):void
         {
            var str0:String = param1;
            _nickNameCardStrList[0] = str0;
            _nickCardService.getNickNameCardStrByUserId(playerInfo1.playerId,function(param1:String):void
            {
               _nickNameCardStrList[1] = param1;
               callback.apply();
            });
         });
      }
      
      public function get messageUI() : BattleMessageUI
      {
         return this._messUI;
      }
      
      public function show(param1:Sprite) : void
      {
         param1.addChild(this._resSprite);
      }
      
      public function dispose() : void
      {
         this.removeListener();
         DisplayUtil.stopAndRemove(this._resSprite);
         if(this._messUI != null)
         {
            this._messUI.dispose();
         }
         this._clickHelper.dispose();
         this._clickHelper = null;
         this.stopCounter();
      }
      
      protected function setCommonInfo(param1:BattleInfo, param2:NpcBlessResult) : void
      {
         this._battleInfo = param1;
         this._npcBlessResult = param2;
         this.initCommonRes();
      }
      
      protected function initCommonRes() : void
      {
         this.preCheckSkipBattleLimit();
         this.preSetActSkip();
         this.initAboutMcSkip();
         this.initAboutMcSwitchBattleFrame();
         this.initAboutMcSwitchSimpleRes();
         this.initAboutMcPlaying();
      }
      
      private function onRollover(param1:MouseEvent) : void
      {
         var _loc2_:MovieClip = this._resSprite["mcBattleResModeTips"];
         _loc2_.visible = false;
         _loc2_.removeEventListener(MouseEvent.ROLL_OVER,this.onRollover);
      }
      
      private function initAboutMcSwitchSimpleRes() : void
      {
         var _loc1_:TeamInfo = this._battleInfo.teamInfos[0] as TeamInfo;
         var _loc2_:PlayerInfo = _loc1_.playerInfos[0] as PlayerInfo;
         var _loc3_:int = int(_loc2_.battlePower);
         var _loc4_:MovieClip = this._resSprite["mcBattleResModeTips"];
         if(_loc4_)
         {
            _loc4_.visible = !LocalStore.getValue(BATTLE_RES_MODE_CAN_CHANGE_TIPS) && _loc3_ >= BATTLE_RES_MODE_TIPS_SHOW_BTW;
            if(_loc4_.visible)
            {
               _loc4_.addEventListener(MouseEvent.ROLL_OVER,this.onRollover);
               LocalStore.setValue(BATTLE_RES_MODE_CAN_CHANGE_TIPS,true);
            }
         }
         var _loc5_:MovieClip = this._resSprite["mcSwitchSimpleBattleRes"];
         if(!this._battle.mcSwitchBattleFrameVisible)
         {
            _loc5_.visible = false;
            return;
         }
         if(BattleContentUtil.isForceSimpleBattleResFlagEffective())
         {
            _loc5_.visible = false;
            return;
         }
         _loc5_.visible = true;
         if(BattleContentUtil.getIsSimpleBattleResType() == BattleSimpleResManager.NO_SIMPLE)
         {
            _loc5_.gotoAndStop(1);
         }
         else if(BattleContentUtil.getIsSimpleBattleResType() == BattleSimpleResManager.ONLY_ENEMY_SIMPLE)
         {
            _loc5_.gotoAndStop(2);
         }
         else
         {
            _loc5_.gotoAndStop(3);
         }
         _loc5_.addEventListener(MouseEvent.CLICK,this.onClickSwitchSimpleBattleRes);
      }
      
      private function preSetActSkip() : void
      {
         var newActSvc:INewActivityService = forSvc(INewActivityService);
         var actName:String = BattleUI.ACT_SKIP_CONFIG["actName"];
         var params:Object = BattleUI.ACT_SKIP_CONFIG["params"];
         if(newActSvc.hasActivityConfig(actName))
         {
            params.callback = function(param1:Boolean):*
            {
               _isActTdFastSkip = param1;
               if(param1)
               {
                  _battle.skipBattleFlowButtonWaitTime = BattleUI.ACT_SKIP_CONFIG["skipAppearWaitTime"];
               }
            };
            newActSvc.loadAndInitNormalActivity(actName,params);
         }
      }
      
      private function preCheckSkipBattleLimit() : void
      {
         var _loc1_:Object = null;
         var _loc2_:* = undefined;
         var _loc3_:Object = null;
         if(this.isHasAnyServerSkipLimit)
         {
            _loc1_ = this._battle.battleResult.skipBattleLimitObj;
            for(_loc2_ in _loc1_)
            {
               _loc3_ = SKIP_BATTLE_LIMIT[_loc2_];
               if(_loc1_[_loc2_] >= _loc3_["openValue"])
               {
                  this._battle.skipBattleFlowButtonWaitTime = _loc3_["skipAppearWaitTime"];
               }
            }
         }
      }
      
      private function initAboutMcSwitchBattleFrame() : void
      {
         var _loc1_:MovieClip = this._resSprite["mcSwitchBattleFrame"];
         if(!this._battle.mcSwitchBattleFrameVisible)
         {
            _loc1_.visible = false;
            return;
         }
         _loc1_.visible = true;
         if(BattleContentUtil.getIsInVipBattleFrame())
         {
            _loc1_.gotoAndStop(2);
            TipsManager.getInstance().addTips(_loc1_,"战斗动画2倍速");
         }
         else
         {
            _loc1_.gotoAndStop(1);
            TipsManager.getInstance().addTips(_loc1_,"战斗动画1倍速");
         }
         _loc1_.addEventListener(MouseEvent.CLICK,this.onClickSwitchBattleFrame);
      }
      
      private function onClickSwitchBattleFrame(param1:MouseEvent) : void
      {
         var _loc2_:MovieClip = this._resSprite["mcSwitchBattleFrame"];
         if(_loc2_.currentFrame == 1)
         {
            LoaderContainer.instance.stage.frameRate = ConfigReader.instance.vipBattleFrameRate;
            _loc2_.gotoAndStop(2);
            TipsManager.getInstance().addTips(_loc2_,"战斗动画2倍速");
            BattleContentUtil.setVipBattleFrame(1);
         }
         else
         {
            LoaderContainer.instance.stage.frameRate = ConfigReader.instance.battleFrameRate;
            _loc2_.gotoAndStop(1);
            TipsManager.getInstance().addTips(_loc2_,"战斗动画1倍速");
            BattleContentUtil.setVipBattleFrame(null);
         }
      }
      
      private function onClickSwitchSimpleBattleRes(param1:MouseEvent) : void
      {
         var _loc2_:MovieClip = this._resSprite["mcBattleResModeTips"];
         if(Boolean(_loc2_) && _loc2_.visible)
         {
            LocalStore.setValue(BATTLE_RES_MODE_CAN_CHANGE_TIPS,true);
            _loc2_.visible = false;
            _loc2_.removeEventListener(MouseEvent.ROLL_OVER,this.onRollover);
         }
         if(!this._isBattleResModeChange)
         {
            this._isBattleResModeChange = true;
         }
         var _loc3_:MovieClip = this._resSprite["mcSwitchSimpleBattleRes"];
         var _loc4_:* = _loc3_.currentFrame;
         _loc4_ = _loc4_ + 1;
         if(_loc4_ > _loc3_.totalFrames)
         {
            _loc4_ = 1;
         }
         _loc3_.gotoAndStop(_loc4_);
      }
      
      private function initAboutMcPlaying() : void
      {
         var _loc1_:MovieClip = this._resSprite["mcSwitchPlaying"];
         if(!this._battle.mcSwitchPlayingFrameVisible)
         {
            _loc1_.visible = false;
            return;
         }
         _loc1_.visible = true;
         _loc1_.gotoAndStop(1);
         _loc1_.addEventListener(MouseEvent.CLICK,this.onClickSwitchPlaying);
         TipsManager.getInstance().addTips(_loc1_,"战斗暂停");
      }
      
      private function onClickSwitchPlaying(param1:MouseEvent) : void
      {
         var _loc2_:MovieClip = this._resSprite["mcSwitchPlaying"];
         _loc2_.gotoAndStop(3 - _loc2_.currentFrame);
         if(_loc2_.currentFrame == 1)
         {
            TipsManager.getInstance().addTips(_loc2_,"战斗暂停");
         }
         else
         {
            TipsManager.getInstance().addTips(_loc2_,"战斗继续");
         }
         this._dispatcher.dispatchEvent(new BattleEvent(BattleEvent.CHANGE_FLOW_PLAYING_STATE,{"playing":_loc2_.currentFrame == 1}));
      }
      
      protected function initComponent() : void
      {
         this._txtSceneName = this._resSprite.getChildByName("place") as TextField;
         var _loc1_:Sprite = this._resSprite.getChildByName("pui0") as Sprite;
         this._playerUI0 = new BattlePlayerUI(_loc1_,false);
         this._playerUI0.resSprite.alpha = 0.1;
         var _loc2_:Sprite = this._resSprite.getChildByName("pui1") as Sprite;
         this._playerUI1 = new BattlePlayerUI(_loc2_);
         this._playerUI1.resSprite.alpha = 0.1;
         var _loc3_:Sprite = this._resSprite.getChildByName("mcMessage") as Sprite;
         var _loc4_:MovieClip = _loc3_.getChildByName("mcUpAndDown") as MovieClip;
         _loc4_.buttonMode = true;
         _loc4_.gotoAndStop(1);
         _loc4_.addEventListener(MouseEvent.CLICK,this.onClickUpAndDown);
         var _loc5_:TextField = _loc3_.getChildByName("battlemess") as TextField;
         var _loc6_:Sprite = _loc3_.getChildByName("back") as Sprite;
         this._messUI = new BattleMessageUI(_loc5_,_loc6_,this._domain);
      }
      
      protected function initListener() : void
      {
         if(this._playerUI0 != null)
         {
            this._eventBinder.bind(this._playerUI0.hitAreaSp,MouseEvent.ROLL_OVER,this.onUi0MouseRollOverFun);
            this._eventBinder.bind(this._playerUI0.hitAreaSp,MouseEvent.ROLL_OUT,this.onUi0MouseRollOutFun);
         }
         if(this._playerUI1 != null)
         {
            this._eventBinder.bind(this._playerUI1.hitAreaSp,MouseEvent.ROLL_OVER,this.onUi1MouseRollOverFun);
            this._eventBinder.bind(this._playerUI1.hitAreaSp,MouseEvent.ROLL_OUT,this.onUi1MouseRollOutFun);
         }
         this._dispatcher.addEventListener(BattleEvent.ON_BATTLE_DISPOSE,this.onBattleDispose);
         this._eventBinder.bind(this._dispatcher,BattleEvent.Force_Skip_Battle_Flow_Evt,this.onForceSkipBattleFlowEvt);
      }
      
      private function removeListener() : void
      {
         this._eventBinder.unBindAll();
      }
      
      private function onForceSkipBattleFlowEvt(param1:BattleEvent) : void
      {
         this._eventBinder.unBind(this._dispatcher,BattleEvent.Force_Skip_Battle_Flow_Evt,this.onForceSkipBattleFlowEvt);
         this._dispatcher.dispatchEvent(new BattleEvent(BattleEvent.SKIP_BATTLE_FLOW,null));
         this.clearBattleCd();
      }
      
      private function onBattleDispose(param1:BattleEvent) : void
      {
         this._dispatcher.removeEventListener(BattleEvent.ON_BATTLE_DISPOSE,this.onBattleDispose);
         var _loc2_:MovieClip = this._resSprite["mcSwitchSimpleBattleRes"];
         if(_loc2_ == null)
         {
            return;
         }
         if(this._isBattleResModeChange)
         {
            this.changeBattleResMode();
         }
         var _loc3_:MovieClip = this._resSprite["mcBattleResModeTips"];
         if(Boolean(_loc3_) && _loc3_.visible)
         {
            _loc3_.removeEventListener(MouseEvent.ROLL_OVER,this.onRollover);
         }
      }
      
      private function changeBattleResMode() : void
      {
         var _loc1_:MovieClip = this._resSprite["mcSwitchSimpleBattleRes"];
         if(_loc1_.currentFrame == 1)
         {
            BattleContentUtil.setSimpleBattleRes(BattleSimpleResManager.NO_SIMPLE);
            BattleContentUtil.setBuffShowValueByKey(true,UserBattleConfig.SHOW_BUFF_BATTLE_RES_PSY);
            BattleContentUtil.setBuffShowValueByKey(true,UserBattleConfig.SHOW_BUFF_BATTLE_RES_HERO);
            BattleContentUtil.setBuffShowValueByKey(true,UserBattleConfig.SHOW_BUFF_BATTLE_RES_OTHER);
            BattleContentUtil.setBuffShowValueByKey(true,UserBattleConfig.SHOW_ACTION_SEQUENCE);
         }
         else if(_loc1_.currentFrame == 2)
         {
            BattleContentUtil.setSimpleBattleRes(BattleSimpleResManager.ONLY_ENEMY_SIMPLE);
            BattleContentUtil.setBuffShowValueByKey(false,UserBattleConfig.SHOW_BUFF_BATTLE_RES_PSY);
            BattleContentUtil.setBuffShowValueByKey(false,UserBattleConfig.SHOW_BUFF_BATTLE_RES_HERO);
            BattleContentUtil.setBuffShowValueByKey(false,UserBattleConfig.SHOW_BUFF_BATTLE_RES_OTHER);
            BattleContentUtil.setBuffShowValueByKey(false,UserBattleConfig.SHOW_ACTION_SEQUENCE);
         }
         else
         {
            BattleContentUtil.setSimpleBattleRes(BattleSimpleResManager.ALL_SIMPLE);
            BattleContentUtil.setBuffShowValueByKey(false,UserBattleConfig.SHOW_BUFF_BATTLE_RES_PSY);
            BattleContentUtil.setBuffShowValueByKey(false,UserBattleConfig.SHOW_BUFF_BATTLE_RES_HERO);
            BattleContentUtil.setBuffShowValueByKey(false,UserBattleConfig.SHOW_BUFF_BATTLE_RES_OTHER);
            BattleContentUtil.setBuffShowValueByKey(false,UserBattleConfig.SHOW_ACTION_SEQUENCE);
         }
      }
      
      private function onUi0MouseRollOverFun(param1:MouseEvent) : void
      {
         this._playerUI0.resSprite.alpha = 1;
      }
      
      private function onUi1MouseRollOverFun(param1:MouseEvent) : void
      {
         this._playerUI1.resSprite.alpha = 1;
      }
      
      private function onUi0MouseRollOutFun(param1:MouseEvent) : void
      {
         this._playerUI0.resSprite.alpha = 0.1;
      }
      
      private function onUi1MouseRollOutFun(param1:MouseEvent) : void
      {
         this._playerUI1.resSprite.alpha = 0.1;
      }
      
      private function onClickUpAndDown(param1:MouseEvent) : void
      {
         var mcUpAndDown:MovieClip = null;
         var evt:MouseEvent = param1;
         var mcMessage:Sprite = this._resSprite.getChildByName("mcMessage") as Sprite;
         mcUpAndDown = MovieClip(evt.currentTarget);
         if(mcUpAndDown.currentFrame == 1)
         {
            TweenLite.to(mcMessage,0.2,{
               "y":558,
               "useFrames":false,
               "onComplete":function():void
               {
                  mcUpAndDown.gotoAndStop(2);
               }
            });
         }
         else
         {
            TweenLite.to(mcMessage,0.2,{
               "y":456.6,
               "useFrames":false,
               "onComplete":function():void
               {
                  mcUpAndDown.gotoAndStop(1);
               }
            });
         }
      }
      
      private function initAboutMcSkip() : void
      {
         var _loc2_:int = 0;
         var _loc3_:int = 0;
         this._mcSkip = this._resSprite.getChildByName("mcSkip") as MovieClip;
         if(this._mcSkip)
         {
            if(!this._battle.skipBattleFlowButtonVisible)
            {
               this._mcSkip.visible = false;
            }
            else
            {
               this._mcSkip.visible = true;
               if(this.isSpecialPetSkipLimit)
               {
                  this._mcSkip.gotoAndStop(1);
                  TipsManager.getInstance().addTips(this._mcSkip["skip"],"跳过战斗");
               }
               else if(this.checkHasAutoSkipBattleTime() && this._battle.getSkipBattleFlowParams("autoSkipBattleTime") > 0)
               {
                  _loc2_ = this._battle.getSkipBattleFlowParams("autoSkipBattleTime");
                  this._mcSkip.gotoAndStop(2);
                  this.initCounter(_loc2_);
               }
               else if(this._isActTdFastSkip && this._battle.skipBattleFlowButtonWaitTime > 0)
               {
                  this._mcSkip.gotoAndStop(2);
                  this.initCounter(this._battle.skipBattleFlowButtonWaitTime);
               }
               else if(this.isHasAnyServerSkipLimit)
               {
                  this._mcSkip.gotoAndStop(2);
                  this.initCounter(3);
               }
               else
               {
                  _loc3_ = this.getSkipAppearWaitSecond();
                  if(_loc3_ > 0)
                  {
                     this._mcSkip.gotoAndStop(2);
                     this.initCounter(_loc3_);
                  }
                  else
                  {
                     TipsManager.getInstance().addTips(this._mcSkip["skip"],"跳过战斗");
                     this._mcSkip.gotoAndStop(1);
                  }
               }
            }
         }
         var _loc1_:SimpleButton = this._resSprite.getChildByName("skip") as SimpleButton;
         if(_loc1_)
         {
            _loc1_.visible = ConfigReader.instance.debug;
         }
      }
      
      private function checkHasAutoSkipBattleTime() : Boolean
      {
         if(this._battle.getSkipBattleFlowParams("autoSkipBattleTime") != null && this._battle.getSkipBattleFlowParams("autoSkipBattleTime") != undefined)
         {
            return true;
         }
         return false;
      }
      
      private function get isHasAnyServerSkipLimit() : Boolean
      {
         var _loc2_:* = undefined;
         var _loc1_:Object = this._battle.battleResult.skipBattleLimitObj;
         for(_loc2_ in SKIP_BATTLE_LIMIT)
         {
            if(_loc1_[_loc2_] != null)
            {
               return true;
            }
         }
         return false;
      }
      
      private function get isSpecialPetSkipLimit() : Boolean
      {
         var _loc2_:* = undefined;
         var _loc1_:Object = this._battle.battleResult.skipBattleSpecialPetObj;
         for(_loc2_ in SKIP_BATTLE_PET_LIMIT)
         {
            if(_loc1_[_loc2_] != null)
            {
               return true;
            }
         }
         return false;
      }
      
      private function get isBaixingHuiyuan() : Boolean
      {
         return Boolean(this._vipService.isBaixingHuiyuan) || Boolean(this._vipService.isExperienceBaixing);
      }
      
      private function initCounter(param1:int) : void
      {
         var _loc2_:SimpleButton = this._mcSkip.getChildByName("btnTip") as SimpleButton;
         if(_loc2_)
         {
            _loc2_.visible = !this.isHasAnyServerSkipLimit;
         }
         this.stopCounter();
         if(this._mcSkip["spCounter"] != null)
         {
            this._counter = new Counter(this._mcSkip["spCounter"]);
            this._counter.curNum = param1;
            this._counter.addEventListener(CounterEvent.COUNTER_END,this.onCounterEnd);
            this._counter.start();
         }
      }
      
      private function stopCounter() : void
      {
         if(this._counter)
         {
            this._counter.stop();
            this._counter.removeEventListener(CounterEvent.COUNTER_END,this.onCounterEnd);
            this._counter = null;
         }
      }
      
      private function onCounterEnd(param1:CounterEvent) : void
      {
         this.stopCounter();
         if(this.checkHasAutoSkipBattleTime() && this._battle.getSkipBattleFlowParams("autoSkipBattleTime") > 0)
         {
            this._dispatcher.dispatchEvent(new BattleEvent(BattleEvent.SKIP_BATTLE_FLOW,null));
         }
         else
         {
            this._mcSkip.gotoAndStop(1);
            TipsManager.getInstance().addTips(this._mcSkip["skip"],"跳过战斗");
         }
      }
      
      private function getSkipAppearWaitSecond() : int
      {
         var _loc1_:int = 0;
         if(this.isBaixingHuiyuan)
         {
            _loc1_ = Math.max(this._vipService.curBaixingTitleIdx,this._vipService.curExperienceBaixingLv);
            if(_loc1_ >= 3)
            {
               return 3;
            }
            if(_loc1_ >= 2)
            {
               return 6;
            }
            if(_loc1_ >= 1)
            {
               return 8;
            }
         }
         if(this._vipService.isVip())
         {
            return 10;
         }
         return 15;
      }
      
      private function sendClickSkipCmdToServer() : void
      {
         if(Boolean(this._battle) && Boolean(this._battle.battleResult) && (this._battle.battleResult.skipAppearWaitTime > 0 || this.isHasAnyServerSkipLimit))
         {
            return;
         }
         ClientXT.sendXtNoReturnMessage(CMD_OVER_FIGHT);
      }
      
      private function onSkipBattleFlowClick(param1:MouseEvent = null) : void
      {
         if(ConfigReader.instance.debug)
         {
            this._dispatcher.dispatchEvent(new BattleEvent(BattleEvent.SKIP_BATTLE_FLOW,null));
            this.clearBattleCd();
            this.sendClickSkipCmdToServer();
         }
         else if(this._battle.skipBattleFlowButtonVisible)
         {
            this.showConfirmAndDispathEvent();
         }
         else
         {
            this.showConfirmAndDispathEvent();
         }
      }
      
      private function clearBattleCd() : void
      {
         SocketClient.instance.sendXtMessage(EXT_NAME,CMD_CLBCD,{"param":""});
      }
      
      private function showConfirmAndDispathEvent() : void
      {
         this._dispatcher.dispatchEvent(new BattleEvent(BattleEvent.SKIP_BATTLE_FLOW,null));
         this.sendClickSkipCmdToServer();
      }
      
      public function setPlayerUiVisible(param1:int, param2:Boolean) : void
      {
         var _loc3_:Sprite = this._resSprite.getChildByName("pui" + param1) as Sprite;
         if(_loc3_)
         {
            _loc3_.visible = param2;
         }
      }
   }
}

