package mmo.battle.command.playbattle
{
   import mmo.battle.util.BattleContentUtil;
   import mmo.interfaces.battleconfig.IBattleConfig;
   import mmo.interfaces.material.MaterialCommonData;
   import mmo.util.command.ISceneCommand;
   import mmo.util.command.SceneSimpleCommand;
   
   public class DownloadCommonResCommand extends SceneSimpleCommand implements ISceneCommand
   {
      
      public function DownloadCommonResCommand()
      {
         super();
      }
      
      override public function execute(param1:Object) : void
      {
         var _loc4_:String = null;
         var _loc5_:MaterialCommonData = null;
         var _loc2_:Array = BattleContentUtil.getPreDownloadList(param1);
         var _loc3_:IBattleConfig = BattleContentUtil.getContentProperty(param1,BattleContentUtil.PN_BATTLE_CONFIG);
         for each(_loc4_ in _loc3_.preDownloadFileList)
         {
            _loc2_.push(_loc4_);
         }
         _loc5_ = BattleContentUtil.getContentProperty(param1,BattleContentUtil.PN_GAIN_COOLPETSTONE_DATA);
         if(_loc5_ != null)
         {
            _loc2_.push("battle/gaincoolpetstone_res");
         }
         this.succeed(param1);
      }
   }
}

