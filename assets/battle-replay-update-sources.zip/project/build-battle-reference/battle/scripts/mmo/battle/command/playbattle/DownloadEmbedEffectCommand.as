package mmo.battle.command.playbattle
{
   import mmo.battle.util.BattleContentUtil;
   import mmo.interfaces.battle.data.BattleInfo;
   import mmo.interfaces.battle.data.FighterInfo;
   import mmo.interfaces.battle.data.PlayerInfo;
   import mmo.interfaces.battle.data.TeamInfo;
   import mmo.interfaces.battleconfig.IBattleConfig;
   import mmo.interfaces.battleconfig.define.EmbedEffectDefine;
   import mmo.util.command.ISceneCommand;
   import mmo.util.command.SceneSimpleCommand;
   
   public class DownloadEmbedEffectCommand extends SceneSimpleCommand implements ISceneCommand
   {
      
      public function DownloadEmbedEffectCommand()
      {
         super();
      }
      
      override public function execute(param1:Object) : void
      {
         var _loc2_:BattleInfo = BattleContentUtil.getContentProperty(param1,BattleContentUtil.PN_BATTLE_INFO);
         var _loc3_:IBattleConfig = BattleContentUtil.getContentProperty(param1,BattleContentUtil.PN_BATTLE_CONFIG);
         var _loc4_:Array = this.getDownloadFileList(_loc2_,_loc3_);
         BattleContentUtil.addToPreDownloadList(param1,_loc4_);
         this.succeed(param1);
      }
      
      protected function getDownloadFileList(param1:BattleInfo, param2:IBattleConfig) : Array
      {
         var _loc4_:TeamInfo = null;
         var _loc5_:PlayerInfo = null;
         var _loc6_:FighterInfo = null;
         var _loc3_:Array = [];
         for each(_loc4_ in param1.teamInfos)
         {
            for each(_loc5_ in _loc4_.playerInfos)
            {
               for each(_loc6_ in _loc5_.fighterInfos)
               {
                  if(_loc3_.indexOf(_loc6_.raceId) == -1)
                  {
                     _loc3_.push(_loc6_.raceId);
                  }
               }
            }
         }
         return this.getDownloadListFromRaceIdList(param2,_loc3_);
      }
      
      protected function getDownloadListFromRaceIdList(param1:IBattleConfig, param2:Array) : Array
      {
         var _loc5_:int = 0;
         var _loc6_:Array = null;
         var _loc7_:EmbedEffectDefine = null;
         var _loc3_:Array = [];
         var _loc4_:int = 0;
         while(_loc4_ < param2.length)
         {
            _loc5_ = int(param2[_loc4_]);
            _loc6_ = param1.getEmbedEffectDefines(_loc5_);
            if(_loc6_ != null)
            {
               for each(_loc7_ in _loc6_)
               {
                  if(_loc7_.url != "" && _loc3_.indexOf(_loc7_.url) == -1)
                  {
                     _loc3_.push(_loc7_.url);
                  }
               }
            }
            _loc4_++;
         }
         return _loc3_;
      }
   }
}

