package mmo.battle.command.playbattle
{
   import flash.utils.getQualifiedClassName;
   import mmo.common.GlobalVariable;
   import mmo.common.dialog.NewDialogWithCallback;
   import mmo.interfaces.ServiceContainer;
   import mmo.interfaces.pet.ride.IRideService;
   import mmo.interfaces.pet.ride.IRideServiceV2;
   import mmo.interfaces.pet.ride.IRideV2PetCardInfo;
   import mmo.util.command.ISceneCommand;
   import mmo.util.command.SceneSimpleCommand;
   
   public class NotifyRidingHungryCommand extends SceneSimpleCommand implements ISceneCommand
   {
      
      private var _rideSvc:IRideServiceV2 = ServiceContainer.getService(IRideService);
      
      public function NotifyRidingHungryCommand()
      {
         super();
      }
      
      override public function execute(param1:Object) : void
      {
         var packageCards:Array;
         var card:IRideV2PetCardInfo = null;
         var history:Object = null;
         var content:Object = param1;
         var key:String = getQualifiedClassName(this);
         if(this._rideSvc.ridingPetId != 0)
         {
            GlobalVariable.instance.remove(key);
            succeed(content);
            return;
         }
         if(this._rideSvc.ridingPetIdLast <= 0)
         {
            succeed(content);
            return;
         }
         packageCards = this._rideSvc.getUserAllPetCardInfos(1);
         for each(card in packageCards)
         {
            if(card.skillInfo != null && card.cardId == this._rideSvc.ridingPetIdLast)
            {
               if(card.isHungry())
               {
                  history = GlobalVariable.instance.getVar(key);
                  if(history == null || history != "cid" + card.cardId)
                  {
                     GlobalVariable.instance.setVar(key,"cid" + card.cardId);
                     NewDialogWithCallback.showFailMessage("你的灵骑没有上阵次数啦\n已自动取消骑乘\n充能后才能继续使用哦",function():*
                     {
                        succeed(content);
                     });
                     return;
                  }
                  break;
               }
            }
         }
         succeed(content);
      }
   }
}

