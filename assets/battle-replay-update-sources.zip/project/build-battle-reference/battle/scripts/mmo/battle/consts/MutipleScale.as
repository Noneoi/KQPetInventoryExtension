package mmo.battle.consts
{
   public class MutipleScale
   {
      
      public static const PLAYER_SCALE:Number = 0.6;
      
      public function MutipleScale()
      {
         super();
      }
   }
}

