package mmo.battle.command.playsequentialbattle
{
   import mmo.battle.util.BattleContentUtil;
   import mmo.interfaces.battleconfig.IBattleConfig;
   import mmo.util.command.ISceneCommand;
   import mmo.util.command.SceneSimpleCommand;
   
   public class DownloadCommonResCommandSeq extends SceneSimpleCommand implements ISceneCommand
   {
      
      public function DownloadCommonResCommandSeq()
      {
         super();
      }
      
      override public function execute(param1:Object) : void
      {
         var _loc4_:String = null;
         var _loc2_:Array = BattleContentUtil.getPreDownloadList(param1);
         var _loc3_:IBattleConfig = BattleContentUtil.getContentProperty(param1,BattleContentUtil.PN_BATTLE_CONFIG);
         for each(_loc4_ in _loc3_.preDownloadFileListSeq)
         {
            _loc2_.push(_loc4_);
         }
         this.succeed(param1);
      }
   }
}

