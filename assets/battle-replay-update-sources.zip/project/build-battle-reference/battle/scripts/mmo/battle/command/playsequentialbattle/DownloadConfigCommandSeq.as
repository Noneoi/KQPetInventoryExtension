package mmo.battle.command.playsequentialbattle
{
   import mmo.battle.util.BattleContentUtil;
   import mmo.interfaces.ServiceContainer;
   import mmo.interfaces.battleconfig.IBattleConfig;
   import mmo.util.command.ISceneCommand;
   import mmo.util.command.SceneSimpleCommand;
   
   public class DownloadConfigCommandSeq extends SceneSimpleCommand implements ISceneCommand
   {
      
      private var _content:Object;
      
      public function DownloadConfigCommandSeq()
      {
         super();
      }
      
      override public function execute(param1:Object) : void
      {
         this._content = param1;
         ServiceContainer.tryGetService(IBattleConfig,this.onGetBattleConfig,null,null,true);
      }
      
      private function onGetBattleConfig(param1:IBattleConfig, param2:Object) : void
      {
         BattleContentUtil.setContentProperty(this._content,BattleContentUtil.PN_BATTLE_CONFIG,param1);
         BattleContentUtil.setContentProperty(this._content,BattleContentUtil.PN_IS_MULTIPLAYER,false);
         this.succeed(this._content);
         this._content = null;
      }
   }
}

