package mmo.battle.command.attack.common
{
   import mmo.battle.avatar.BattleAvatar;
   import mmo.battle.avatar.BattleChaserAvatar;
   import mmo.battle.container.BattleContainer;
   import mmo.battle.entity.BattleSimpleResManager;
   import mmo.battle.util.BattleContentUtil;
   import mmo.interfaces.battle.data.BattleInfo;
   import mmo.interfaces.battle.data.PlayerInfo;
   import mmo.interfaces.battle.data.RoundResult;
   import mmo.interfaces.battle.entity.IBattle;
   import mmo.interfaces.battle.fighter.IBattleFighter;
   import mmo.interfaces.battle.player.IBattlePlayer;
   import mmo.interfaces.battleconfig.IBattleConfig;
   import mmo.interfaces.battleconfig.define.SkillDefine;
   import mmo.util.command.ISceneCommand;
   import mmo.util.command.SceneSimpleCommand;
   
   public class ClearUniqueSkillEffectCommand extends SceneSimpleCommand implements ISceneCommand
   {
      
      private var _content:Object;
      
      private var _isMulti:Boolean;
      
      private var _skillDefine:SkillDefine;
      
      public function ClearUniqueSkillEffectCommand()
      {
         super();
      }
      
      override public function execute(param1:Object) : void
      {
         this._content = param1;
         var _loc2_:IBattleConfig = BattleContentUtil.getContentProperty(param1,BattleContentUtil.PN_BATTLE_CONFIG);
         var _loc3_:BattleContainer = BattleContentUtil.getContentProperty(param1,BattleContentUtil.PN_CONTAINER);
         var _loc4_:RoundResult = BattleContentUtil.getContentProperty(param1,BattleContentUtil.PN_ROUND_RESULT);
         this._skillDefine = BattleContentUtil.getContentProperty(param1,BattleContentUtil.PN_SKILLDEFINE);
         this._isMulti = BattleContentUtil.getContentProperty(param1,BattleContentUtil.PN_IS_MULTIPLAYER);
         if(this._skillDefine != null && Boolean(this._skillDefine.blackScreen))
         {
            _loc3_.movieLayerBelow.graphics.clear();
         }
         this.handleShowOrgAvatarWhenIsChaser();
         this.handleShowHideOtherAvatar();
         this.succeed(param1);
      }
      
      private function handleShowOrgAvatarWhenIsChaser() : void
      {
         var _loc3_:IBattle = null;
         var _loc4_:IBattlePlayer = null;
         var _loc5_:Array = null;
         var _loc6_:int = 0;
         var _loc7_:IBattleFighter = null;
         var _loc1_:RoundResult = BattleContentUtil.getContentProperty(this._content,BattleContentUtil.PN_ROUND_RESULT);
         var _loc2_:IBattleFighter = BattleContentUtil.getContentProperty(this._content,BattleContentUtil.PN_SOURCE_FIGHTER);
         if(_loc2_.avatar is BattleChaserAvatar)
         {
            _loc3_ = BattleContentUtil.getContentProperty(this._content,BattleContentUtil.PN_BATTLE);
            _loc4_ = _loc3_.getPlayerByName(_loc1_.sourcePlayerName);
            _loc5_ = _loc4_.fighterList;
            _loc6_ = 0;
            while(_loc6_ < _loc5_.length)
            {
               _loc7_ = _loc5_[_loc6_];
               if(_loc2_.info.id != _loc7_.info.id && _loc7_.info.initPosX == _loc2_.info.initPosX && _loc7_.info.initPosY == _loc2_.info.initPosY)
               {
                  BattleAvatar(_loc7_.avatar).visible = true;
               }
               _loc6_++;
            }
         }
      }
      
      private function handleShowHideOtherAvatar() : void
      {
         var _loc7_:Array = null;
         var _loc8_:BattleAvatar = null;
         var _loc1_:IBattleFighter = BattleContentUtil.getContentProperty(this._content,BattleContentUtil.PN_SOURCE_FIGHTER);
         var _loc2_:BattleSimpleResManager = BattleContentUtil.getContentProperty(this._content,BattleContentUtil.SIMPLE_RES_DATA);
         var _loc3_:BattleInfo = BattleContentUtil.getContentProperty(this._content,BattleContentUtil.PN_BATTLE_INFO);
         var _loc4_:int = int(_loc1_.info.belong2PlayerIndex);
         var _loc5_:PlayerInfo = _loc3_.teamInfos[_loc1_.needFlip ? 1 : 0].playerInfos[_loc4_];
         var _loc6_:Boolean = _loc2_.checkShouldBeSimpleResBySourceFighter(this._content,_loc1_,_loc5_.playerName);
         if(!this._isMulti && (this._skillDefine != null && Boolean(this._skillDefine.isHideOtherAvatar) || _loc6_))
         {
            _loc7_ = BattleContentUtil.getContentProperty(this._content,BattleContentUtil.PN_HIDE_FIGHTERS);
            for each(_loc8_ in _loc7_)
            {
               _loc8_.visible = true;
            }
            this.handleUniqueSkillHideOthersLayer(true);
         }
      }
      
      private function handleUniqueSkillHideOthersLayer(param1:Boolean) : void
      {
         var _loc2_:BattleContainer = BattleContentUtil.getContentProperty(this._content,BattleContentUtil.PN_CONTAINER);
         _loc2_.uniqueSkillHideOtherLayer.visible = param1;
         _loc2_.floor.visible = param1;
      }
   }
}

