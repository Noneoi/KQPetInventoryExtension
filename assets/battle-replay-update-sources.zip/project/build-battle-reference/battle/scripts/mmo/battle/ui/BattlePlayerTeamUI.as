package mmo.battle.ui
{
   import flash.display.MovieClip;
   import flash.display.Sprite;
   import flash.text.TextField;
   import mmo.common.DisplayUtil;
   import mmo.common.utils.tips.TipsManager;
   import mmo.framework.comm.SocketClient;
   import mmo.interfaces.ServiceContainer;
   import mmo.interfaces.avatar.IAvatarService;
   import mmo.interfaces.battle.data.NpcBlessResult;
   import mmo.interfaces.battle.data.PlayerInfo;
   import mmo.interfaces.battle.entity.IBattle;
   import mmo.interfaces.battleconfig.IBattleConfig;
   import mmo.interfaces.material.Material;
   import mmo.interfaces.material.MaterialViewContainer;
   import mmo.interfaces.material.materialcount.IMaterialCountService;
   import mmo.interfaces.npcbuddy.INpcBuddy;
   import mmo.interfaces.npcbuddy.NpcBufferData;
   import mmo.interfaces.user.IUserNameManager;
   import mmo.util.component.artnumber.ArtNumberManager;
   
   public class BattlePlayerTeamUI
   {
      
      public static const UI_TYPE_SELF:String = "self";
      
      public static const UI_TYPE_OTHER:String = "other";
      
      private static const UI_TYPE_ARRAY:Array = [UI_TYPE_SELF,UI_TYPE_OTHER];
      
      private var _resSprite:Sprite;
      
      private var _playerInfo:PlayerInfo;
      
      private var _uiType:String;
      
      private var _showWord:Boolean;
      
      private var _npcBlessResult:NpcBlessResult;
      
      private var _formationUI:BattleFormationUI;
      
      private var _avatarService:IAvatarService;
      
      private var _battles:Array = [];
      
      public function BattlePlayerTeamUI(param1:Sprite, param2:Array)
      {
         super();
         this._resSprite = param1;
         this._battles = param2;
      }
      
      public function setPlayerInfo(param1:PlayerInfo, param2:NpcBlessResult, param3:String, param4:Boolean) : void
      {
         if(param1.playerType == PlayerInfo.PLAYER_TYPE_AI)
         {
            DisplayUtil.stopAndRemove(this._resSprite);
            return;
         }
         this.initService();
         this.setInfo(param1,param3,param4);
         this.setBuddyBuffer(param2);
      }
      
      private function initService() : void
      {
         this._avatarService = ServiceContainer.getService(IAvatarService) as IAvatarService;
      }
      
      private function setInfo(param1:PlayerInfo, param2:String, param3:Boolean) : void
      {
         var txtNameArray:Array = null;
         var spHeadContainerArray:Array = null;
         var j:int = 0;
         var spWord:Sprite = null;
         var spBoard:Sprite = null;
         var selfLeader:Sprite = null;
         var heroSkill:Sprite = null;
         var arrBattlePower:Array = null;
         var i:int = 0;
         var txtName:TextField = null;
         var spHeadContainer:Sprite = null;
         var battleNum:MovieClip = null;
         var playerNum:int = 0;
         var battle:IBattle = null;
         var num:int = 0;
         var headIcon:Sprite = null;
         var hsName:TextField = null;
         var mcBattleNum:MovieClip = null;
         var playerInfo:PlayerInfo = param1;
         var uiType:String = param2;
         var showWord:Boolean = param3;
         this._playerInfo = playerInfo;
         this._uiType = uiType;
         this._showWord = showWord;
         for each(uiType in UI_TYPE_ARRAY)
         {
            if(uiType != UI_TYPE_OTHER)
            {
               txtNameArray = [];
               spHeadContainerArray = [];
               j = 0;
               while(j < 3)
               {
                  txtName = this._resSprite.getChildByName(uiType + "_pname" + j) as TextField;
                  spHeadContainer = this._resSprite.getChildByName(uiType + "_hc" + j) as Sprite;
                  txtNameArray.push(txtName);
                  spHeadContainerArray.push(spHeadContainer);
                  j++;
               }
               spWord = this._resSprite.getChildByName(uiType + "_word") as Sprite;
               spBoard = this._resSprite.getChildByName(uiType + "_board") as Sprite;
               selfLeader = this._resSprite.getChildByName(uiType + "_leader") as Sprite;
               heroSkill = this._resSprite.getChildByName(uiType + "_hs") as Sprite;
               arrBattlePower = new Array();
               i = 0;
               while(i < 5)
               {
                  battleNum = this._resSprite.getChildByName(uiType + "_num" + i) as MovieClip;
                  arrBattlePower.push(battleNum);
                  i++;
               }
               if(uiType == this._uiType)
               {
                  playerNum = 1;
                  j = 0;
                  while(j < this._battles.length)
                  {
                     battle = this._battles[j];
                     num = 0;
                     if(battle.battleResult.userName == battle.battleResult.teamLeaderName)
                     {
                        num = 0;
                     }
                     else
                     {
                        num = playerNum;
                        playerNum++;
                     }
                     txtNameArray[num].text = battle.battleResult.nickName;
                     spHeadContainer = spHeadContainerArray[num];
                     while(spHeadContainer.numChildren > 0)
                     {
                        spHeadContainer.removeChildAt(0);
                     }
                     headIcon = this._avatarService.getHeadIcon(null,battle.battleResult.nickName,60,true,true,true,true);
                     spHeadContainer.addChild(headIcon);
                     j++;
                  }
                  spWord.visible = this._showWord;
                  spBoard.visible = true;
                  ArtNumberManager.setNumber(arrBattlePower,playerInfo.battlePower);
                  if(this._playerInfo.heroSkillId > 0)
                  {
                     heroSkill.visible = true;
                     hsName = heroSkill.getChildByName("sname") as TextField;
                     ServiceContainer.tryGetService(IBattleConfig,function(param1:IBattleConfig, param2:Object):*
                     {
                        hsName.text = param1.getSkillDefineById(_playerInfo.heroSkillId).name;
                     },null,null,true);
                     hsName.text = "";
                  }
                  else
                  {
                     heroSkill.visible = false;
                  }
               }
               else
               {
                  j = 0;
                  while(j < 3)
                  {
                     txtNameArray[j].visible = false;
                     spHeadContainerArray[j].visible = false;
                     j++;
                  }
                  spWord.visible = false;
                  spBoard.visible = false;
                  for each(mcBattleNum in arrBattlePower)
                  {
                     mcBattleNum.visible = false;
                  }
                  selfLeader.visible = false;
                  heroSkill.visible = false;
               }
            }
         }
      }
      
      private function setBuddyBuffer(param1:NpcBlessResult) : void
      {
         var _loc6_:INpcBuddy = null;
         var _loc7_:IMaterialCountService = null;
         var _loc8_:NpcBufferData = null;
         var _loc9_:MaterialViewContainer = null;
         var _loc10_:Material = null;
         this._npcBlessResult = param1;
         var _loc2_:Sprite = this._resSprite.getChildByName("bc") as Sprite;
         var _loc3_:Sprite = this._resSprite.getChildByName("bb") as Sprite;
         var _loc4_:TextField = this._resSprite.getChildByName("bn") as TextField;
         _loc2_.visible = false;
         _loc3_.visible = false;
         _loc4_.visible = false;
         var _loc5_:IUserNameManager = ServiceContainer.getService(IUserNameManager) as IUserNameManager;
         if(this._playerInfo.playerName == _loc5_.getNickName(SocketClient.instance.myUserName) && this._npcBlessResult != null)
         {
            _loc3_.visible = true;
            _loc6_ = ServiceContainer.getService(INpcBuddy) as INpcBuddy;
            _loc7_ = ServiceContainer.getService(IMaterialCountService) as IMaterialCountService;
            _loc8_ = _loc6_.getNpcBuddyDataById(this._npcBlessResult.npcId);
            _loc9_ = _loc7_.getView(_loc8_.materialCountId,33,33);
            _loc10_ = _loc7_.getMaterialById(_loc8_.materialCountId);
            TipsManager.getInstance().addComplexTips(_loc9_,_loc10_.name,_loc8_.desc);
            _loc2_.addChild(_loc9_);
            _loc2_.visible = true;
            _loc4_.text = this._npcBlessResult.leftNum + "/" + _loc8_.totalTimes;
            _loc4_.visible = true;
         }
      }
   }
}

