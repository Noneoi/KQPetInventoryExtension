package mmo.battle.command.playbattle
{
   import flash.display.Sprite;
   import flash.events.IEventDispatcher;
   import flash.system.ApplicationDomain;
   import mmo.battle.container.BattleContainer;
   import mmo.battle.entity.BattleBase;
   import mmo.battle.ui.BattlePetDragonUI;
   import mmo.battle.ui.BattleUI;
   import mmo.battle.ui.BattleUIMulti;
   import mmo.battle.util.BattleContentUtil;
   import mmo.interfaces.battle.data.BattleInfo;
   import mmo.interfaces.battle.data.NpcBlessResult;
   import mmo.interfaces.battle.entity.IBattle;
   import mmo.util.command.ISceneCommand;
   import mmo.util.command.SceneSimpleCommand;
   
   public class SetupUICommand extends SceneSimpleCommand implements ISceneCommand
   {
      
      private static const SINGLE_UI_RES_CLS:String = "mmo.battle.common.BattleUIRes";
      
      private static const MULTI_UI_RES_CLS:String = "mmo.battle.common.BattleMultiUIRes";
      
      private static const PET_DRAGON_UI_RES_CLS:String = "mmo.battle.common.PetDragonUIRes";
      
      private var _content:Object;
      
      private var _battle:IBattle;
      
      private var _battleInfo:BattleInfo;
      
      private var _npcBlessResult:NpcBlessResult;
      
      private var _domain:ApplicationDomain;
      
      private var _dispatcher:IEventDispatcher;
      
      private var _bIsMutiple:Boolean;
      
      public function SetupUICommand()
      {
         super();
      }
      
      override public function execute(param1:Object) : void
      {
         this._content = param1;
         this._bIsMutiple = BattleContentUtil.getContentProperty(param1,BattleContentUtil.PN_IS_MULTIPLAYER);
         this._battle = BattleContentUtil.getContentProperty(param1,BattleContentUtil.PN_BATTLE);
         this._battleInfo = BattleContentUtil.getContentProperty(param1,BattleContentUtil.PN_BATTLE_INFO);
         this._npcBlessResult = BattleContentUtil.getContentProperty(param1,BattleContentUtil.PN_NPC_BLESS_RESULT);
         this._domain = BattleContentUtil.getContentProperty(param1,BattleContentUtil.PN_DOMAIN);
         this._dispatcher = BattleContentUtil.getContentProperty(param1,BattleContentUtil.PN_EVENT_DISPATCHER);
         if(this._bIsMutiple)
         {
            this.setupUIHelper(MULTI_UI_RES_CLS,BattleUIMulti);
         }
         else if(this._battleInfo.hasPetDragonInBattle)
         {
            this.setupUIHelper(PET_DRAGON_UI_RES_CLS,BattlePetDragonUI);
         }
         else
         {
            this.setupUIHelper(SINGLE_UI_RES_CLS,BattleUI);
         }
      }
      
      private function setupUIHelper(param1:String, param2:Class) : void
      {
         var _loc3_:Class = this._domain.getDefinition(param1) as Class;
         var _loc4_:Sprite = new _loc3_() as Sprite;
         var _loc5_:BattleUI = new param2(_loc4_,this._domain,this._dispatcher);
         _loc5_.setInfo(this._battleInfo,this._npcBlessResult,BattleBase(this._battle));
         var _loc6_:BattleContainer = BattleContentUtil.getContentProperty(this._content,BattleContentUtil.PN_CONTAINER);
         _loc5_.show(_loc6_.uiLayer);
         BattleContentUtil.setContentProperty(this._content,BattleContentUtil.PN_UI,_loc5_);
         this.succeed(this._content);
         this._content = null;
      }
   }
}

