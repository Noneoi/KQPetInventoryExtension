package mmo.battle.command
{
   import mmo.battle.command.attack.close.ApproachCommand;
   import mmo.battle.command.attack.close.CounterCommand;
   import mmo.battle.command.attack.close.PlayCloseActionCommand;
   import mmo.battle.command.attack.close.ReturnCommand;
   import mmo.battle.command.attack.close.WarmUpCommand;
   import mmo.battle.command.attack.common.AfterSequentialAttackCommand;
   import mmo.battle.command.attack.common.BeforeSequentialAttackCommand;
   import mmo.battle.command.attack.common.ClearUniqueSkillEffectCommand;
   import mmo.battle.command.attack.common.PlayEffectCommand;
   import mmo.battle.command.attack.common.ShowSkillNameCommand;
   import mmo.battle.command.attack.common.UniqueSkillEffectCommand;
   import mmo.interfaces.battle.command.IBattleCommand;
   
   public class CloseAttackCommand extends BattleCommand implements IBattleCommand
   {
      
      public function CloseAttackCommand()
      {
         super();
      }
      
      override protected function initializeMacroCommand() : void
      {
         addSubCommand(BeforeSequentialAttackCommand);
         addSubCommand(UniqueSkillEffectCommand);
         addSubCommand(WarmUpCommand);
         addSubCommand(ApproachCommand);
         addSubCommand(ShowSkillNameCommand);
         addParallelSubCommand([PlayCloseActionCommand,PlayEffectCommand]);
         addSubCommand(ReturnCommand);
         addSubCommand(ClearUniqueSkillEffectCommand);
         addSubCommand(CounterCommand);
         addSubCommand(AfterSequentialAttackCommand);
         super.initializeMacroCommand();
      }
   }
}

