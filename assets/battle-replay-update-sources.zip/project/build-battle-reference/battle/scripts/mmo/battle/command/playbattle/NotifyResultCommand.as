package mmo.battle.command.playbattle
{
   import flash.events.EventDispatcher;
   import mmo.battle.resultpanel.BattleFailPanel;
   import mmo.battle.resultpanel.GainExpPanel;
   import mmo.battle.util.BattleContentUtil;
   import mmo.battle.util.BattleUtil;
   import mmo.common.ModalDialog;
   import mmo.common.ModalDialogEvent;
   import mmo.common.dialog.NewDialog;
   import mmo.framework.comm.SocketClient;
   import mmo.interfaces.ServiceContainer;
   import mmo.interfaces.battle.data.BattleInfo;
   import mmo.interfaces.battle.data.GainExpResult;
   import mmo.interfaces.battle.data.PlayerInfo;
   import mmo.interfaces.battle.events.BattleEvent;
   import mmo.interfaces.battle.service.BattleType;
   import mmo.interfaces.material.IMaterialGetPanel;
   import mmo.interfaces.material.MaterialCommonData;
   import mmo.interfaces.user.IUserNameManager;
   import mmo.util.command.ISceneCommand;
   import mmo.util.command.SceneSimpleCommand;
   
   public class NotifyResultCommand extends SceneSimpleCommand implements ISceneCommand
   {
      
      private static const PK_FAIL_PANEL_CLS:String = "mmo.battle.common.BattlePkLosePanelRes";
      
      protected var _content:Object;
      
      protected var _winerTeamId:int;
      
      private var _dropItemDatas:Array;
      
      private var _extraBonusDatas:Array;
      
      private var _gainExpResult:GainExpResult;
      
      private var _isCurUserWiner:Boolean;
      
      public function NotifyResultCommand()
      {
         super();
      }
      
      override public function execute(param1:Object) : void
      {
         var _loc3_:MaterialCommonData = null;
         this._content = param1;
         this._winerTeamId = BattleContentUtil.getContentProperty(param1,BattleContentUtil.PN_WINNER_TEAM_ID);
         this._dropItemDatas = BattleContentUtil.getContentProperty(param1,BattleContentUtil.PN_DROP_ITEM_DATA);
         this._extraBonusDatas = BattleContentUtil.getContentProperty(param1,BattleContentUtil.PN_EXTRA_BONUS_DATA);
         this._gainExpResult = BattleContentUtil.getContentProperty(param1,BattleContentUtil.PN_GAIN_EXP_RESULT);
         this._isCurUserWiner = this.isCurUserWiner();
         BattleContentUtil.setContentProperty(param1,BattleContentUtil.PN_IS_CUR_USER_WINNER,this._isCurUserWiner);
         var _loc2_:EventDispatcher = BattleContentUtil.getContentProperty(param1,BattleContentUtil.PN_EVENT_DISPATCHER);
         if(_loc2_.hasEventListener(BattleEvent.RESULT_NOTIFICATION))
         {
            _loc2_.dispatchEvent(new BattleEvent(BattleEvent.RESULT_NOTIFICATION,{
               "isWin":this._isCurUserWiner,
               "wi":this._winerTeamId,
               "dropData":this._dropItemDatas,
               "gainExp":this._gainExpResult,
               "callback":this.onResultNotifyCallback
            }));
         }
         else
         {
            _loc3_ = BattleContentUtil.getContentProperty(this._content,BattleContentUtil.PN_GAIN_COOLPETSTONE_DATA);
            if(_loc3_ != null)
            {
               succeed(this._content);
            }
            else
            {
               this.showResultDefault();
               this.showExtraBonus();
            }
         }
      }
      
      private function showResultDefault(param1:String = "", param2:* = "") : void
      {
         if(this._winerTeamId == -1)
         {
            this.showMessage("战成平手");
         }
         else if(this._isCurUserWiner)
         {
            this.handleWinBattle(param1);
         }
         else if(this.isCurUserLoser())
         {
            this.handleLoseBattle(param2);
         }
         else
         {
            this.showMessage("战斗结束");
         }
      }
      
      private function showExtraBonus() : void
      {
         if(this._extraBonusDatas == null)
         {
            return;
         }
         var _loc1_:IMaterialGetPanel = ServiceContainer.getService(IMaterialGetPanel) as IMaterialGetPanel;
         _loc1_.showPanelWithArray(this._extraBonusDatas);
      }
      
      protected function handleWinBattle(param1:String) : void
      {
         var _loc2_:GainExpPanel = new GainExpPanel(this._content,this.onResultNotifyCallback,param1);
         _loc2_.show();
      }
      
      private function handleLoseBattle(param1:String) : void
      {
         var _loc3_:int = 0;
         if(param1 == "")
         {
            _loc3_ = BattleContentUtil.getContentProperty(this._content,BattleContentUtil.PN_BATTLE_TYPE);
            if(this.isBattlePk() || _loc3_ == BattleType.FIGHT_WITH_TASK_PET)
            {
               param1 = PK_FAIL_PANEL_CLS;
            }
         }
         var _loc2_:BattleFailPanel = new BattleFailPanel(this._content,this.onResultNotifyCallback,param1);
         _loc2_.show();
      }
      
      private function isBattlePk() : Boolean
      {
         var _loc1_:Boolean = BattleContentUtil.getContentProperty(this._content,BattleContentUtil.PN_IS_MULTIPLAYER);
         if(_loc1_)
         {
            return false;
         }
         var _loc2_:BattleInfo = BattleContentUtil.getContentProperty(this._content,BattleContentUtil.PN_BATTLE_INFO);
         var _loc3_:PlayerInfo = _loc2_.getTeamInfoById(0).playerInfos[0] as PlayerInfo;
         var _loc4_:PlayerInfo = _loc2_.getTeamInfoById(1).playerInfos[0] as PlayerInfo;
         return _loc3_.playerType == PlayerInfo.PLAYER_TYPE_USER && _loc4_.playerType == PlayerInfo.PLAYER_TYPE_USER;
      }
      
      private function showMessage(param1:String) : void
      {
         var message:String = param1;
         NewDialog.getCofirmDialog(message,function(param1:ModalDialog):void
         {
            var dialog:ModalDialog = param1;
            dialog.addEventListener(ModalDialogEvent.CLOSE,function(param1:ModalDialogEvent):void
            {
               succeed(_content);
            });
            dialog.show();
         });
      }
      
      protected function isCurUserWiner() : Boolean
      {
         var _loc1_:BattleInfo = BattleContentUtil.getContentProperty(this._content,BattleContentUtil.PN_BATTLE_INFO);
         var _loc2_:IUserNameManager = ServiceContainer.getService(IUserNameManager) as IUserNameManager;
         var _loc3_:String = _loc2_.getNickName(SocketClient.instance.myUserName);
         return BattleUtil.isCurUserInTeam(_loc1_,this._winerTeamId,_loc3_);
      }
      
      protected function isCurUserLoser() : Boolean
      {
         var _loc1_:BattleInfo = BattleContentUtil.getContentProperty(this._content,BattleContentUtil.PN_BATTLE_INFO);
         var _loc2_:int = 1 - this._winerTeamId;
         var _loc3_:IUserNameManager = ServiceContainer.getService(IUserNameManager) as IUserNameManager;
         var _loc4_:String = _loc3_.getNickName(SocketClient.instance.myUserName);
         return BattleUtil.isCurUserInTeam(_loc1_,_loc2_,_loc4_);
      }
      
      protected function onResultNotifyCallback(param1:Boolean = false, param2:String = "", param3:String = "") : void
      {
         if(param1)
         {
            this.showResultDefault(param2,param3);
            this.showExtraBonus();
         }
         else
         {
            this.succeed(this._content);
            this._content = null;
         }
      }
   }
}

