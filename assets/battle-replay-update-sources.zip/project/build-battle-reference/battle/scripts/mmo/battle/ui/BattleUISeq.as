package mmo.battle.ui
{
   import flash.display.Sprite;
   import flash.events.IEventDispatcher;
   import flash.system.ApplicationDomain;
   import mmo.battle.entity.BattleBase;
   import mmo.interfaces.battle.data.BattleInfo;
   import mmo.interfaces.battle.data.NpcBlessResult;
   
   public class BattleUISeq extends BattleUI
   {
      
      private static const SEQ_RES_CLS:String = "mmo.battle.common.BattleSeqUIRes";
      
      private var _seqUI:BattleSeqUI;
      
      private var _nodePetRaceIds:Array;
      
      public function BattleUISeq(param1:Sprite, param2:ApplicationDomain, param3:IEventDispatcher, param4:Array)
      {
         super(param1,param2,param3);
         this._nodePetRaceIds = param4;
      }
      
      public function get seqUI() : BattleSeqUI
      {
         return this._seqUI;
      }
      
      override public function setInfo(param1:BattleInfo, param2:NpcBlessResult, param3:BattleBase) : void
      {
         super.setInfo(param1,param2,param3);
         this._seqUI.setInfo(this._nodePetRaceIds);
      }
      
      override protected function initComponent() : void
      {
         super.initComponent();
         var _loc1_:Class = this._domain.getDefinition(SEQ_RES_CLS) as Class;
         var _loc2_:Sprite = new _loc1_() as Sprite;
         this._seqUI = new BattleSeqUI(_loc2_);
         this._resSprite.addChild(this._seqUI.resSprite);
      }
   }
}

