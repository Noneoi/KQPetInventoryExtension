package mmo.battle.command.embed.sub
{
   import mmo.interfaces.battle.embed.IEmbedCode;
   import mmo.interfaces.battleconfig.define.EmbedEffectDefine;
   
   public class EmbedCommandCode extends EmbedCommandBase
   {
      
      public function EmbedCommandCode(param1:EmbedEffectDefine)
      {
         super(param1);
      }
      
      override protected function applyEmbedEffect() : void
      {
         var _loc1_:Class = this._domain.getDefinition(this._embedEffectDefine.params) as Class;
         var _loc2_:IEmbedCode = new _loc1_() as IEmbedCode;
         _loc2_.init(this._content,this.onInitComplete);
      }
      
      private function onInitComplete() : void
      {
         --this._repeatCount;
         this.succeed(this._content);
      }
   }
}

