package mmo.battle.catchpanel
{
   import flash.display.MovieClip;
   import flash.display.Sprite;
   import flash.events.MouseEvent;
   import flash.text.TextField;
   import mmo.interfaces.ServiceContainer;
   import mmo.interfaces.battle.data.CatchPetInfo;
   import mmo.interfaces.pet.data.PetGiftType;
   import mmo.interfaces.pet.peticon.IPetIcon;
   import mmo.interfaces.pet.peticon.PetIconContainer;
   import mmo.interfaces.pet.peticon.PetIconType;
   import mmo.interfaces.stargod.IStarGodService;
   
   public class CatchCard
   {
      
      private var _res:MovieClip;
      
      private var _clickNotify:Function;
      
      private var _txtName:TextField;
      
      private var _spIconContainer:Sprite;
      
      private var _txtLevel:TextField;
      
      private var _txtGift:TextField;
      
      private var _mcPick:MovieClip;
      
      private var _mcStargod:Sprite;
      
      private var _petInfo:CatchPetInfo;
      
      public function CatchCard(param1:MovieClip, param2:Function)
      {
         super();
         this._res = param1;
         this._clickNotify = param2;
         this.initComponent();
         this.initListener();
      }
      
      public function get isCardClicked() : Boolean
      {
         return this._mcPick.currentFrame == 2;
      }
      
      public function set isCardClicked(param1:Boolean) : void
      {
         if(param1)
         {
            this._mcPick.gotoAndStop(2);
         }
         else
         {
            this._mcPick.gotoAndStop(1);
         }
      }
      
      public function get petInfo() : CatchPetInfo
      {
         return this._petInfo;
      }
      
      public function setPetInfo(param1:CatchPetInfo) : void
      {
         this._petInfo = param1;
         if(this._petInfo == null)
         {
            this._res.gotoAndStop(2);
         }
         else
         {
            this._txtName.text = this._petInfo.name;
            this._txtLevel.text = "lv." + this._petInfo.level.toString();
            this._txtGift.text = PetGiftType.valueOf(this._petInfo.gift).name;
            this._res.gotoAndStop(1);
            ServiceContainer.tryGetService(IPetIcon,this.onGetPetIcon);
            this.setStargod(this._petInfo.starGodSlotSeq);
         }
      }
      
      private function setStargod(param1:String) : void
      {
         var _loc2_:IStarGodService = ServiceContainer.getService(IStarGodService) as IStarGodService;
         this._mcStargod.addChild(_loc2_.getStarGod(param1.split("#")[0],0,false));
      }
      
      private function onGetPetIcon(param1:IPetIcon, param2:Object) : void
      {
         while(this._spIconContainer.numChildren > 0)
         {
            this._spIconContainer.removeChildAt(0);
         }
         var _loc3_:PetIconContainer = param1.getPetIcon(this._petInfo.raceId,PetIconType.FIGHT);
         this._spIconContainer.addChild(_loc3_);
      }
      
      private function initComponent() : void
      {
         this._res.gotoAndStop(1);
         this._txtName = this._res.getChildByName("petname") as TextField;
         this._spIconContainer = this._res.getChildByName("ic") as Sprite;
         this._txtLevel = this._res.getChildByName("lv") as TextField;
         this._txtGift = this._res.getChildByName("gift") as TextField;
         this._mcPick = this._res.getChildByName("pick") as MovieClip;
         this._mcPick.gotoAndStop(1);
         this._mcStargod = this._res.getChildByName("stargod") as MovieClip;
      }
      
      private function initListener() : void
      {
         this._mcPick.addEventListener(MouseEvent.CLICK,this.onPickClick);
      }
      
      private function onPickClick(param1:MouseEvent) : void
      {
         this._mcPick.gotoAndStop(2);
         this._mcPick.mouseEnabled = false;
         this._mcPick.mouseChildren = false;
         this._mcPick.removeEventListener(MouseEvent.CLICK,this.onPickClick);
         this._clickNotify.apply();
      }
   }
}

