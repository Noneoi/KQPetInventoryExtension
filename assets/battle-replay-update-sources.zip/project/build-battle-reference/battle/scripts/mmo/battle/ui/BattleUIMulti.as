package mmo.battle.ui
{
   import flash.display.MovieClip;
   import flash.display.Sprite;
   import flash.events.IEventDispatcher;
   import flash.system.ApplicationDomain;
   import mmo.battle.entity.BattleBase;
   import mmo.common.user.UserInfo;
   import mmo.interfaces.battle.consts.FormationConsts;
   import mmo.interfaces.battle.data.BattleInfo;
   import mmo.interfaces.battle.data.NpcBlessResult;
   import mmo.interfaces.battle.data.PlayerInfo;
   import mmo.interfaces.battle.data.TeamInfo;
   import mmo.interfaces.battle.events.BattleSyncEvent;
   import mmo.loader.common.datastructures.HashMap;
   
   public class BattleUIMulti extends BattleUI
   {
      
      private static const MAX_STATE_CARD_COUNT:int = 3;
      
      private var _playerName2Card:HashMap;
      
      private var _playerStateCardList:Array;
      
      private var _myTeamInfo:TeamInfo;
      
      public function BattleUIMulti(param1:Sprite, param2:ApplicationDomain, param3:IEventDispatcher)
      {
         super(param1,param2,param3);
         this.initListener();
      }
      
      override protected function initComponent() : void
      {
         var _loc2_:MovieClip = null;
         var _loc3_:BattlePlayerStateCard = null;
         this._playerName2Card = new HashMap();
         this._playerStateCardList = [];
         var _loc1_:int = 0;
         while(_loc1_ < MAX_STATE_CARD_COUNT)
         {
            _loc2_ = this._resSprite.getChildByName("c" + _loc1_) as MovieClip;
            _loc3_ = new BattlePlayerStateCard(_loc1_,_loc2_);
            _loc3_.setInfo(null);
            this._playerStateCardList.push(_loc3_);
            _loc1_++;
         }
      }
      
      override public function setInfo(param1:BattleInfo, param2:NpcBlessResult, param3:BattleBase) : void
      {
         var _loc5_:PlayerInfo = null;
         var _loc6_:int = 0;
         var _loc7_:BattlePlayerStateCard = null;
         this.setCommonInfo(param1,param2);
         this._myTeamInfo = this.getMyTeamInfo(param1);
         if(this._myTeamInfo == null)
         {
            this._myTeamInfo = param1.teamInfos[0];
         }
         var _loc4_:Array = this._myTeamInfo.playerInfos;
         for each(_loc5_ in _loc4_)
         {
            _loc6_ = _loc5_.initPosX + _loc5_.initPosY * FormationConsts.MAX_ROW_COUNT;
            _loc7_ = this._playerStateCardList[_loc6_];
            if(_loc7_ != null)
            {
               _loc7_.setInfo(_loc5_);
               this.updatePlayerState(_loc7_);
               if(_loc5_ != null)
               {
                  this._playerName2Card.add(_loc5_.playerName,_loc7_);
               }
            }
         }
      }
      
      override protected function initCommonRes() : void
      {
      }
      
      override public function dispose() : void
      {
         super.dispose();
         this._playerName2Card = null;
         this._playerStateCardList = null;
         this._myTeamInfo = null;
      }
      
      override protected function initListener() : void
      {
         _eventBinder.bind(_dispatcher,BattleSyncEvent.PLAYER_SHIFT,this.onPlayerShift);
         _eventBinder.bind(_dispatcher,BattleSyncEvent.PLAYER_DELETE,this.onPlayerDelete);
      }
      
      private function onPlayerShift(param1:BattleSyncEvent) : void
      {
         var _loc2_:String = param1.params.playerName;
         var _loc3_:BattlePlayerStateCard = this._playerName2Card.getValue(_loc2_);
         if(_loc3_ == null)
         {
            return;
         }
         this.updatePlayerState(_loc3_);
      }
      
      private function onPlayerDelete(param1:BattleSyncEvent) : void
      {
         var _loc2_:String = param1.params.playerName;
         var _loc3_:BattlePlayerStateCard = this._playerName2Card.getValue(_loc2_);
         if(_loc3_ == null)
         {
            return;
         }
         _loc3_.setState(BattlePlayerStateCard.STATE_DEAD);
      }
      
      private function updatePlayerState(param1:BattlePlayerStateCard) : void
      {
         if(param1 == null || param1.info == null)
         {
            return;
         }
         if(param1.info.isDead)
         {
            param1.setState(BattlePlayerStateCard.STATE_DEAD);
         }
         else if(this.getIsPlayerFighting(param1.info.playerName))
         {
            param1.setState(BattlePlayerStateCard.STATE_FIGHTING);
         }
         else
         {
            param1.setState(BattlePlayerStateCard.STATE_READY);
         }
      }
      
      private function getIsPlayerFighting(param1:String) : Boolean
      {
         var _loc4_:PlayerInfo = null;
         var _loc2_:TeamInfo = this._battleInfo.teamInfos[0];
         if(_loc2_ == this._myTeamInfo)
         {
            _loc2_ = this._battleInfo.teamInfos[1];
         }
         var _loc3_:PlayerInfo = this._myTeamInfo.getPlayerInfoByName(param1);
         if(_loc3_.curX != 0)
         {
            return false;
         }
         for each(_loc4_ in _loc2_.playerInfos)
         {
            if(_loc4_.curX == 0 && _loc4_.curY == _loc3_.curY)
            {
               return true;
            }
         }
         return false;
      }
      
      private function getMyTeamInfo(param1:BattleInfo) : TeamInfo
      {
         var _loc3_:TeamInfo = null;
         var _loc4_:PlayerInfo = null;
         var _loc2_:String = UserInfo.nickName;
         for each(_loc3_ in param1.teamInfos)
         {
            for each(_loc4_ in _loc3_.playerInfos)
            {
               if(_loc4_.playerName == _loc2_)
               {
                  return _loc3_;
               }
            }
         }
         return null;
      }
   }
}

