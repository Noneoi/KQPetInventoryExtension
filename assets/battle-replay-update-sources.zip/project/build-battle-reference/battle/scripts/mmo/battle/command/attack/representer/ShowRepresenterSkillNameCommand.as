package mmo.battle.command.attack.representer
{
   import flash.display.MovieClip;
   import flash.system.ApplicationDomain;
   import mmo.battle.util.BattleContentUtil;
   import mmo.interfaces.battle.avatar.AvatarPosTypes;
   import mmo.interfaces.battle.data.RoundResult;
   import mmo.interfaces.battle.fighter.IBattleFighter;
   import mmo.util.command.ISceneCommand;
   import mmo.util.command.SceneSimpleCommand;
   
   public class ShowRepresenterSkillNameCommand extends SceneSimpleCommand implements ISceneCommand
   {
      
      private static const EFFECT_NAME_CLS_PREFIX:String = "mmo.effect.EffectName";
      
      public function ShowRepresenterSkillNameCommand()
      {
         super();
      }
      
      override public function execute(param1:Object) : void
      {
         var _loc4_:Class = null;
         var _loc5_:MovieClip = null;
         var _loc6_:IBattleFighter = null;
         var _loc2_:RoundResult = BattleContentUtil.getContentProperty(param1,BattleContentUtil.PN_ROUND_RESULT);
         var _loc3_:ApplicationDomain = BattleContentUtil.getContentProperty(param1,BattleContentUtil.PN_DOMAIN);
         if(_loc3_.hasDefinition(EFFECT_NAME_CLS_PREFIX + _loc2_.skillId))
         {
            _loc4_ = _loc3_.getDefinition(EFFECT_NAME_CLS_PREFIX + _loc2_.skillId) as Class;
            _loc5_ = new _loc4_() as MovieClip;
            _loc6_ = BattleContentUtil.getContentProperty(param1,BattleContentUtil.PN_SOURCE_FIGHTER);
            _loc6_.showEffectMovie(_loc5_,AvatarPosTypes.TOP,null);
         }
         this.succeed(param1);
      }
   }
}

