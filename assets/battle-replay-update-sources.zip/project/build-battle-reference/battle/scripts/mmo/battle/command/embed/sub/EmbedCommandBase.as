package mmo.battle.command.embed.sub
{
   import flash.system.ApplicationDomain;
   import mmo.battle.container.BattleContainer;
   import mmo.battle.util.BattleContentUtil;
   import mmo.common.GlobalVariable;
   import mmo.interfaces.ServiceContainer;
   import mmo.interfaces.battle.data.RoundResult;
   import mmo.interfaces.battle.entity.IBattle;
   import mmo.interfaces.battle.fighter.IBattleFighter;
   import mmo.interfaces.battle.player.IBattlePlayer;
   import mmo.interfaces.battleconfig.IBattleConfig;
   import mmo.interfaces.battleconfig.define.EmbedEffectDefine;
   import mmo.interfaces.task.ITaskService;
   import mmo.util.command.ISceneCommand;
   import mmo.util.command.SceneSimpleCommand;
   
   public class EmbedCommandBase extends SceneSimpleCommand implements ISceneCommand
   {
      
      protected static var playNpcCount:* = 1;
      
      protected var _embedEffectDefine:EmbedEffectDefine;
      
      protected var _repeatCount:int;
      
      protected var _content:Object;
      
      protected var _container:BattleContainer;
      
      protected var _domain:ApplicationDomain;
      
      protected var _roundResult:RoundResult;
      
      protected var _config:IBattleConfig;
      
      public function EmbedCommandBase(param1:EmbedEffectDefine)
      {
         super();
         this._embedEffectDefine = param1;
         this._repeatCount = param1.repeatCount;
      }
      
      override public function execute(param1:Object) : void
      {
         this._content = param1;
         if(this._repeatCount <= 0 || !this.checkAllFitlers())
         {
            this.succeed(this._content);
         }
         else if(this._embedEffectDefine.raceId == 10603 && playNpcCount <= 0)
         {
            this.succeed(this._content);
         }
         else
         {
            this.setupContentParams();
            this.applyEmbedEffect();
         }
      }
      
      protected function checkAllFitlers() : Boolean
      {
         var _loc1_:Boolean = this.checkSkillFilter();
         var _loc2_:Boolean = this.checkTaskFilter();
         var _loc3_:Boolean = this.checkWinerTeamIdFilter();
         var _loc4_:Boolean = this.checkLowerHpFilter();
         var _loc5_:Boolean = this.checkHigherHpFilter();
         var _loc6_:Boolean = this.checkGlobalVariableFilter();
         return _loc1_ && _loc2_ && _loc3_ && _loc4_ && _loc5_ && _loc6_;
      }
      
      protected function checkGlobalVariableFilter() : Boolean
      {
         var _loc2_:String = null;
         var _loc1_:Array = this._embedEffectDefine.globalVariableFilter;
         if(_loc1_.length == 0)
         {
            return true;
         }
         for each(_loc2_ in _loc1_)
         {
            if(GlobalVariable.instance.getVar(_loc2_) == null)
            {
               return false;
            }
         }
         return true;
      }
      
      protected function checkSkillFilter() : Boolean
      {
         var _loc1_:Array = this._embedEffectDefine.skillFilter;
         if(_loc1_.length == 0)
         {
            return true;
         }
         var _loc2_:RoundResult = BattleContentUtil.getContentProperty(this._content,BattleContentUtil.PN_ROUND_RESULT);
         var _loc3_:int = int(_loc2_.skillId);
         return _loc1_.indexOf(_loc3_) != -1;
      }
      
      protected function checkTaskFilter() : Boolean
      {
         var _loc3_:int = 0;
         var _loc1_:Array = this._embedEffectDefine.taskFilter;
         if(_loc1_.length == 0)
         {
            return true;
         }
         var _loc2_:ITaskService = ServiceContainer.getService(ITaskService) as ITaskService;
         for each(_loc3_ in _loc1_)
         {
            if(_loc2_.isUserTaskDoing(_loc3_))
            {
               return true;
            }
         }
         return false;
      }
      
      protected function checkWinerTeamIdFilter() : Boolean
      {
         var _loc1_:Array = this._embedEffectDefine.winerTeamIdFilter;
         if(_loc1_.length == 0)
         {
            return true;
         }
         var _loc2_:int = BattleContentUtil.getContentProperty(this._content,BattleContentUtil.PN_WINNER_TEAM_ID);
         return _loc1_.indexOf(_loc2_) != -1;
      }
      
      protected function checkLowerHpFilter() : Boolean
      {
         var _loc1_:IBattleFighter = this.getSourceFighter();
         return _loc1_.curHp * 100 <= _loc1_.maxHp * this._embedEffectDefine.lowerHpFilter;
      }
      
      protected function checkHigherHpFilter() : Boolean
      {
         var _loc1_:IBattleFighter = this.getSourceFighter();
         return _loc1_.curHp * 100 >= _loc1_.maxHp * this._embedEffectDefine.higherHpFilter;
      }
      
      protected function getSourceFighter() : IBattleFighter
      {
         var _loc1_:IBattle = BattleContentUtil.getContentProperty(this._content,BattleContentUtil.PN_BATTLE);
         var _loc2_:RoundResult = BattleContentUtil.getContentProperty(this._content,BattleContentUtil.PN_ROUND_RESULT);
         var _loc3_:IBattlePlayer = _loc1_.getPlayerByName(_loc2_.sourcePlayerName);
         return _loc3_.getFighterById(_loc2_.sourceCharacterId);
      }
      
      protected function setupContentParams() : void
      {
         this._container = BattleContentUtil.getContentProperty(this._content,BattleContentUtil.PN_CONTAINER);
         this._domain = BattleContentUtil.getContentProperty(this._content,BattleContentUtil.PN_DOMAIN);
         this._roundResult = BattleContentUtil.getContentProperty(this._content,BattleContentUtil.PN_ROUND_RESULT);
         this._config = BattleContentUtil.getContentProperty(this._content,BattleContentUtil.PN_BATTLE_CONFIG);
      }
      
      protected function applyEmbedEffect() : void
      {
         throw new Error("applyEmbedEffect() must be overrided!");
      }
   }
}

