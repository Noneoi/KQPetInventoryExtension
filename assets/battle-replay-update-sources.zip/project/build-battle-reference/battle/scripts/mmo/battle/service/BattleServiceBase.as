package mmo.battle.service
{
   import flash.events.EventDispatcher;
   import mmo.common.dialog.NewDialogWithCallback;
   import mmo.interfaces.ServiceContainer;
   import mmo.interfaces.antiaddiction.IAntiAddiction;
   import mmo.interfaces.formation.Formation;
   import mmo.interfaces.formation.FormationDataType;
   import mmo.interfaces.formation.IFormationService;
   import mmo.interfaces.newbie.NewbieEvent;
   import mmo.interfaces.newbie.NewbieEventDispatcher;
   
   public class BattleServiceBase extends EventDispatcher
   {
      
      private var formationService:IFormationService = ServiceContainer.getService(IFormationService);
      
      public function BattleServiceBase()
      {
         super();
      }
      
      protected function hasAvailableTime() : Boolean
      {
         var _loc1_:IAntiAddiction = null;
         if(this.getAvailableTime() <= 0)
         {
            _loc1_ = ServiceContainer.getService(IAntiAddiction) as IAntiAddiction;
            _loc1_.showAntiPanel("主人啊！今天你已经非常疲倦咯！无法再进行战斗啦！");
            return false;
         }
         return true;
      }
      
      private function getAvailableTime() : int
      {
         var _loc1_:IAntiAddiction = ServiceContainer.getService(IAntiAddiction) as IAntiAddiction;
         return int(_loc1_.getAvailableTime());
      }
      
      protected function hasAvailableMonster(param1:Function, param2:Formation = null) : Boolean
      {
         if(param2 == null && Boolean(this.formationService.isCurrentFormationPetHasHp()))
         {
            return true;
         }
         if(param2 != null && Boolean(this.formationService.isFormationPetHasHp(param2)))
         {
            return true;
         }
         var _loc3_:String = (param2 == null ? "你" : param2.name + "上") + "的精灵受伤了呢，你可以到" + "<font color=\'#FF0000\'>" + "中心大道的精灵医院" + "</font>" + "，或者" + "<font color=\'#FF0000\'>" + "在背包中" + "</font>" + "帮助它们恢复生命哦！";
         NewDialogWithCallback.showComfirmDialog(_loc3_,param1,param1);
         return false;
      }
      
      protected function checkIsFormationEmpty(param1:Function, param2:Formation = null) : Boolean
      {
         var message:String;
         var onOk:Function;
         var onClose:Function;
         var callback:Function = param1;
         var formation:Formation = param2;
         if(formation == null && !this.formationService.isCurrentFormationEmpty())
         {
            return false;
         }
         if(formation != null && !this.formationService.isFormationEmpty(formation))
         {
            return false;
         }
         message = (formation == null ? "你的阵型" : formation.name) + "中没有精灵哦！赶快布置战术吧！";
         onOk = function():void
         {
            var onFormationPanelClose:Function = null;
            if(formation != null)
            {
               return;
            }
            if(callback != null)
            {
               onFormationPanelClose = function(param1:NewbieEvent):void
               {
                  NewbieEventDispatcher.getInstance().removeEventListener(NewbieEvent.CLOSE_FORMATION_PANEL,onFormationPanelClose);
                  callback.apply();
               };
               NewbieEventDispatcher.getInstance().addEventListener(NewbieEvent.CLOSE_FORMATION_PANEL,onFormationPanelClose);
            }
            if(formationService.currentFormationType == FormationDataType.BANE)
            {
               formationService.showBossFormation(true,null,1);
            }
            else
            {
               formationService.showMainPanel(true,true,null,1);
            }
         };
         onClose = function():void
         {
            if(formation != null)
            {
               return;
            }
            if(callback != null)
            {
               callback.apply();
            }
         };
         NewDialogWithCallback.showComfirmDialog(message,onOk,onClose);
         return true;
      }
   }
}

