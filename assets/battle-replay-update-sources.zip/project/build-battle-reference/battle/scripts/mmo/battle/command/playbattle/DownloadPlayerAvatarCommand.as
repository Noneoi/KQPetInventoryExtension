package mmo.battle.command.playbattle
{
   import flash.display.Sprite;
   import mmo.battle.util.BattleContentUtil;
   import mmo.common.user.UserInfo;
   import mmo.interfaces.ServiceContainer;
   import mmo.interfaces.avatar.IAvatarService;
   import mmo.interfaces.battle.data.BattleInfo;
   import mmo.interfaces.battle.data.PlayerInfo;
   import mmo.interfaces.battle.data.TeamInfo;
   import mmo.interfaces.material.MaterialServiceEvent;
   import mmo.interfaces.material.MaterialTypes;
   import mmo.interfaces.material.clothes.AvatarInfo;
   import mmo.interfaces.material.clothes.IClothesService;
   import mmo.interfaces.material.ridepetcard.IRidePetCardService;
   import mmo.interfaces.pet.ride.IRideService;
   import mmo.interfaces.pet.ride.IRideServiceV2;
   import mmo.util.command.ISceneCommand;
   import mmo.util.command.SceneSimpleCommand;
   
   public class DownloadPlayerAvatarCommand extends SceneSimpleCommand implements ISceneCommand
   {
      
      private var _content:Object;
      
      private var _counter:int = 0;
      
      private var _rideV2Svc:IRideServiceV2 = ServiceContainer.getService(IRideService);
      
      private var _ridePetCardSvc:IRidePetCardService = ServiceContainer.getService(IRidePetCardService);
      
      public function DownloadPlayerAvatarCommand()
      {
         super();
      }
      
      override public function execute(param1:Object) : void
      {
         var _loc3_:BattleInfo = null;
         var _loc4_:TeamInfo = null;
         var _loc5_:TeamInfo = null;
         this._content = param1;
         var _loc2_:* = BattleContentUtil.getContentProperty(param1,BattleContentUtil.PN_IS_MULTIPLAYER);
         if(_loc2_)
         {
            this.succeed(this._content);
         }
         else
         {
            _loc3_ = BattleContentUtil.getContentProperty(param1,BattleContentUtil.PN_BATTLE_INFO);
            _loc4_ = _loc3_.teamInfos[0] as TeamInfo;
            _loc5_ = _loc3_.teamInfos[1] as TeamInfo;
            this.setupAvatar(_loc4_.playerInfos[0],true);
            this.setupAvatar(_loc5_.playerInfos[0],false);
         }
      }
      
      private function setupAvatar(param1:PlayerInfo, param2:Boolean) : void
      {
         var clothesService:IClothesService;
         var playerInfo:PlayerInfo = param1;
         var isLeft:Boolean = param2;
         if(playerInfo.playerType == PlayerInfo.PLAYER_TYPE_AI)
         {
            this.tryFinishCommand();
            return;
         }
         clothesService = ServiceContainer.getService(IClothesService);
         clothesService.getOthersAvatarInfo("",function(param1:AvatarInfo):void
         {
            var avatarService:IAvatarService = null;
            var avatar:Sprite = null;
            var key:String = null;
            var avatarInfo:AvatarInfo = param1;
            if(avatarInfo.getClothes().length == 0)
            {
               tryFinishCommand();
            }
            else
            {
               avatarService = ServiceContainer.getService(IAvatarService);
               avatar = avatarService.getFullAvatar(100,100,avatarInfo,true,!isLeft,false,function():void
               {
                  var ridePetCard:* = undefined;
                  var domain:* = undefined;
                  var view:* = undefined;
                  var onGetView:Function = null;
                  if(playerInfo.playerName == UserInfo.nickName)
                  {
                     if(_rideV2Svc.ridingPetId > 0)
                     {
                        onGetView = function(param1:MaterialServiceEvent):void
                        {
                           if(param1.id != ridePetCard.materialId || param1.materialType != MaterialTypes.RIDE_PET_CARD)
                           {
                              return;
                           }
                           view.removeEventListener(MaterialServiceEvent.onGetView,onGetView);
                           tryFinishCommand();
                        };
                        ridePetCard = _rideV2Svc.getRidePetCardInfoByOwnId(_rideV2Svc.ridingPetId);
                        domain = BattleContentUtil.getContentProperty(_content,BattleContentUtil.PN_DOMAIN);
                        view = _ridePetCardSvc.getView(ridePetCard.materialId,120,120,false,domain);
                        view.addEventListener(MaterialServiceEvent.onGetView,onGetView);
                        view.startLoad();
                     }
                     else
                     {
                        tryFinishCommand();
                     }
                  }
                  else
                  {
                     tryFinishCommand();
                  }
               });
               key = isLeft ? BattleContentUtil.PN_PLAYER_AVATAR_L : BattleContentUtil.PN_PLAYER_AVATAR_R;
               BattleContentUtil.setContentProperty(_content,key,avatar);
            }
         },playerInfo.playerName);
      }
      
      private function tryFinishCommand() : void
      {
         ++this._counter;
         if(this._counter >= 2)
         {
            this.succeed(this._content);
         }
      }
   }
}

