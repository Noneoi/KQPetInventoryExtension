package mmo.battle.command
{
   import flash.events.Event;
   import flash.events.EventDispatcher;
   import flash.events.IEventDispatcher;
   import mmo.interfaces.battle.command.IBattleCommand;
   import mmo.util.command.ISceneCommand;
   import mmo.util.command.SceneCommandEvent;
   
   public class BattleCommand implements IBattleCommand, IEventDispatcher
   {
      
      private var _eventDispatcher:EventDispatcher;
      
      private var _subCommands:Array;
      
      private var _executeCommands:Array;
      
      protected var _content:Object;
      
      private var _semaphore:int;
      
      private var _executingList:Array;
      
      public function BattleCommand()
      {
         super();
         this._eventDispatcher = new EventDispatcher();
         this._semaphore = 0;
         this._subCommands = [];
         this.initializeMacroCommand();
      }
      
      public function pushCommand(param1:*) : void
      {
         this.pushParallelCommand([param1]);
      }
      
      public function pushParallelCommand(param1:Array) : void
      {
         this.addParallelSubCommand(param1);
      }
      
      public function unshiftCommand(param1:*) : void
      {
         this.unshiftParallelCommand([param1]);
      }
      
      public function unshiftParallelCommand(param1:Array) : void
      {
         this.unshiftParallelSubCommand(param1);
      }
      
      public function insertCommand(param1:*, param2:*) : void
      {
         this.insertSubCommand(param1,param2);
      }
      
      public function insertParallelCommand(param1:Array, param2:*) : void
      {
         this.insertParallelSubCommand(param1,param2);
      }
      
      public function removeCommand(param1:*) : void
      {
         this.removeSubCommand(param1);
      }
      
      public function removeParallelCommand(param1:Array) : void
      {
         this.removeParallelSubCommand(param1);
      }
      
      final public function execute(param1:Object) : void
      {
         if(this._semaphore > 0)
         {
            return;
         }
         this._executeCommands = this._subCommands.concat();
         this.executeNextCommand(param1);
      }
      
      public function cancel() : void
      {
         var _loc1_:ISceneCommand = null;
         for each(_loc1_ in this._executingList)
         {
            _loc1_.cancel();
         }
         this._semaphore = 0;
         this.dispatchEvent(new SceneCommandEvent(SceneCommandEvent.CANCELED,this));
      }
      
      public function addEventListener(param1:String, param2:Function, param3:Boolean = false, param4:int = 0, param5:Boolean = false) : void
      {
         this._eventDispatcher.addEventListener(param1,param2,param3,param4,param5);
      }
      
      public function removeEventListener(param1:String, param2:Function, param3:Boolean = false) : void
      {
         this._eventDispatcher.removeEventListener(param1,param2,param3);
      }
      
      public function dispatchEvent(param1:Event) : Boolean
      {
         return this._eventDispatcher.dispatchEvent(param1);
      }
      
      public function hasEventListener(param1:String) : Boolean
      {
         return this._eventDispatcher.hasEventListener(param1);
      }
      
      public function willTrigger(param1:String) : Boolean
      {
         return this._eventDispatcher.willTrigger(param1);
      }
      
      protected function initializeMacroCommand() : void
      {
      }
      
      protected function addSubCommand(param1:*) : void
      {
         this.addParallelSubCommand([param1]);
      }
      
      protected function addParallelSubCommand(param1:Array) : void
      {
         this._subCommands.push(param1);
      }
      
      protected function unshiftSubCommand(param1:*) : void
      {
         this.unshiftParallelSubCommand([param1]);
      }
      
      protected function unshiftParallelSubCommand(param1:Array) : void
      {
         this._subCommands.unshift(param1);
      }
      
      protected function insertSubCommand(param1:*, param2:*) : void
      {
         this.insertParallelSubCommand([param1],param2);
      }
      
      protected function insertParallelSubCommand(param1:Array, param2:*) : void
      {
         var _loc3_:int = -1;
         if(param2 is Class)
         {
            _loc3_ = this.getSubCommandIndex([param2]);
         }
         else if(param2 is Array)
         {
            _loc3_ = this.getSubCommandIndex(param2);
         }
         if(_loc3_ != -1)
         {
            this._subCommands.splice(_loc3_,0,param1);
         }
      }
      
      protected function removeSubCommand(param1:*) : void
      {
         this.removeParallelSubCommand([param1]);
      }
      
      protected function removeParallelSubCommand(param1:Array) : void
      {
         var _loc2_:int = this.getSubCommandIndex(param1);
         if(_loc2_ != -1)
         {
            this._subCommands.splice(_loc2_,1);
         }
      }
      
      private function getSubCommandIndex(param1:Array) : int
      {
         var _loc4_:Array = null;
         var _loc5_:int = 0;
         var _loc2_:int = -1;
         var _loc3_:int = 0;
         while(_loc3_ < this._subCommands.length)
         {
            _loc4_ = this._subCommands[_loc3_];
            if(_loc4_.length == param1.length)
            {
               _loc5_ = 0;
               while(_loc5_ < _loc4_.length)
               {
                  if(!this.isEqualCommand(_loc4_[_loc5_],param1[_loc5_]))
                  {
                     break;
                  }
                  _loc5_++;
               }
               if(_loc5_ == _loc4_.length)
               {
                  _loc2_ = _loc3_;
                  break;
               }
            }
            _loc3_++;
         }
         return _loc2_;
      }
      
      private function isEqualCommand(param1:*, param2:*) : Boolean
      {
         if(param1 == param2 || param2 is Class && param1 is param2 || param1 is Class && param2 is param1)
         {
            return true;
         }
         return false;
      }
      
      private function executeNextCommand(param1:Object) : void
      {
         var _loc2_:Array = null;
         var _loc3_:String = null;
         var _loc4_:int = 0;
         var _loc5_:* = undefined;
         var _loc6_:ISceneCommand = null;
         if(this._executeCommands.length > 0)
         {
            _loc2_ = this._executeCommands.shift();
            this._executingList = [];
            this._semaphore = _loc2_.length;
            this._content = {};
            for(_loc3_ in param1)
            {
               this._content[_loc3_] = param1[_loc3_];
            }
            _loc4_ = 0;
            while(_loc4_ < _loc2_.length)
            {
               _loc5_ = _loc2_[_loc4_];
               _loc6_ = this.getCommandInstance(_loc5_);
               this._executingList.push(_loc6_);
               _loc6_.addEventListener(SceneCommandEvent.SUCCEED,this.onCommandSucc);
               _loc6_.addEventListener(SceneCommandEvent.FAILED,this.onCommandFail);
               _loc6_.execute(param1);
               _loc4_++;
            }
         }
         else
         {
            this._semaphore = 0;
            this.succeed(param1);
         }
      }
      
      private function getCommandInstance(param1:*) : ISceneCommand
      {
         if(param1 is ISceneCommand)
         {
            return param1;
         }
         if(param1 is Class)
         {
            return new param1();
         }
         return null;
      }
      
      private function onCommandSucc(param1:SceneCommandEvent) : void
      {
         var _loc4_:String = null;
         var _loc2_:ISceneCommand = param1.command;
         var _loc3_:int = this._executingList.indexOf(_loc2_);
         this._executingList.splice(_loc3_,1);
         _loc2_.removeEventListener(SceneCommandEvent.FAILED,this.onCommandFail);
         _loc2_.removeEventListener(SceneCommandEvent.SUCCEED,this.onCommandSucc);
         for(_loc4_ in param1.params)
         {
            this._content[_loc4_] = param1.params[_loc4_];
         }
         this.checkSemaphore();
      }
      
      private function onCommandFail(param1:SceneCommandEvent) : void
      {
         var _loc4_:String = null;
         var _loc5_:ISceneCommand = null;
         var _loc2_:ISceneCommand = param1.command;
         var _loc3_:int = this._executingList.indexOf(_loc2_);
         this._executingList.splice(_loc3_,1);
         _loc2_.removeEventListener(SceneCommandEvent.FAILED,this.onCommandFail);
         _loc2_.removeEventListener(SceneCommandEvent.SUCCEED,this.onCommandSucc);
         for(_loc4_ in param1.params)
         {
            this._content[_loc4_] = param1.params[_loc4_];
         }
         for each(_loc5_ in this._executingList)
         {
            _loc5_.cancel();
         }
         this.fail(this._content);
      }
      
      private function checkSemaphore() : void
      {
         --this._semaphore;
         if(this._semaphore == 0)
         {
            this.executeNextCommand(this._content);
         }
      }
      
      final private function succeed(param1:Object) : void
      {
         this._semaphore = 0;
         this.dispatchEvent(new SceneCommandEvent(SceneCommandEvent.SUCCEED,this,param1));
      }
      
      final private function fail(param1:Object) : void
      {
         this._semaphore = 0;
         this.dispatchEvent(new SceneCommandEvent(SceneCommandEvent.FAILED,this,param1));
      }
   }
}

