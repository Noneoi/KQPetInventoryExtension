package mmo.battle.entity
{
   import flash.events.EventDispatcher;
   import flash.events.IEventDispatcher;
   import mmo.battle.util.BattleContentUtil;
   import mmo.interfaces.IDispose;
   import mmo.interfaces.battle.consts.FormationConsts;
   import mmo.interfaces.battle.data.BattleUnit;
   import mmo.interfaces.battle.data.DeleteAction;
   import mmo.interfaces.battle.data.RoundResult;
   import mmo.interfaces.battle.data.ShiftAction;
   import mmo.interfaces.battle.events.BattleEvent;
   import mmo.interfaces.battle.events.BattleSyncEvent;
   import mmo.interfaces.battle.fighter.IBattleFighter;
   import mmo.interfaces.battle.player.IBattlePlayer;
   
   public class BattleSyncManager extends EventDispatcher implements IDispose
   {
      
      private var _content:Object;
      
      private var _arrBattleLines:Array;
      
      private var _roundSemaphore:int;
      
      private var _lineState:int;
      
      private var _dispatcher:IEventDispatcher;
      
      private var _battle:BattleBase;
      
      private var _shiftSemaphore:int = 0;
      
      private var _need2StopAll:Boolean = false;
      
      private var _playingPause:Boolean = false;
      
      private var _playingHasBlocked:Boolean = false;
      
      private var _skillNumInjection:Function = null;
      
      public function BattleSyncManager(param1:Object)
      {
         super();
         this._content = param1;
         this._arrBattleLines = [];
         this._dispatcher = BattleContentUtil.getContentProperty(param1,BattleContentUtil.PN_EVENT_DISPATCHER);
         this._battle = BattleContentUtil.getContentProperty(this._content,BattleContentUtil.PN_BATTLE);
         if(this._battle.battleResult.battleParams)
         {
            this._skillNumInjection = this._battle.battleResult.battleParams.injectionWhenSpecSkillNum;
         }
         this._dispatcher.addEventListener(BattleEvent.CHANGE_FLOW_PLAYING_STATE,this.onChangePlaying);
      }
      
      private function onChangePlaying(param1:BattleEvent) : void
      {
         var _loc2_:Boolean = Boolean(param1.params["playing"]);
         this._playingPause = !_loc2_;
         if(!this._playingPause && this._playingHasBlocked)
         {
            this.run();
         }
      }
      
      public function getOnBattleLineNum() : int
      {
         var _loc3_:BattleUnit = null;
         var _loc1_:int = 0;
         var _loc2_:int = 0;
         while(_loc2_ < FormationConsts.MAX_ROW_COUNT)
         {
            _loc3_ = this._arrBattleLines[_loc2_];
            if(_loc3_ != null && _loc3_.roundResults.length > 0)
            {
               _loc1_++;
            }
            _loc2_++;
         }
         return _loc1_;
      }
      
      public function insertBattleUnit(param1:BattleUnit) : Boolean
      {
         var _loc4_:Boolean = false;
         var _loc2_:int = int(param1.battleLineIndex);
         var _loc3_:BattleUnit = this._arrBattleLines[_loc2_];
         if(_loc3_ == null || _loc3_.roundResults.length == 0)
         {
            _loc4_ = this.handleDeleteAction(param1.shiftResult.deleteActions);
            if(!_loc4_)
            {
               return false;
            }
            this.handleShiftActions(param1.shiftResult.shiftActions);
            if(param1.isReallyFight)
            {
               this._lineState |= 1 << _loc2_;
            }
            this._arrBattleLines[_loc2_] = param1;
            return true;
         }
         return false;
      }
      
      public function run() : void
      {
         var _loc2_:BattleUnit = null;
         var _loc3_:RoundResult = null;
         if(this._shiftSemaphore > 0)
         {
            return;
         }
         this._playingHasBlocked = this._playingPause;
         if(this._playingPause)
         {
            return;
         }
         var _loc1_:int = 0;
         while(_loc1_ < FormationConsts.MAX_ROW_COUNT)
         {
            _loc2_ = this._arrBattleLines[_loc1_];
            if(_loc2_ != null && _loc2_.roundResults.length > 0)
            {
               _loc3_ = _loc2_.roundResults.shift();
               this.checkInjection(_loc3_);
            }
            _loc1_++;
         }
      }
      
      private function checkInjection(param1:RoundResult) : void
      {
         var roundResult:RoundResult = param1;
         if(this._skillNumInjection != null)
         {
            this._skillNumInjection(roundResult.sourceSkillNumResult,function():void
            {
               handleRoundResult(roundResult);
            });
            return;
         }
         this.handleRoundResult(roundResult);
      }
      
      private function handleRoundResult(param1:RoundResult) : void
      {
         if(param1.isOverRoundLimit)
         {
            this.dispatchEvent(new SyncInterrupt(SyncInterrupt.OVER_ROUND_LIMIT_WARNING,null));
         }
         ++this._roundSemaphore;
         var _loc2_:IBattlePlayer = this._battle.getPlayerByName(param1.sourcePlayerName);
         var _loc3_:IBattleFighter = _loc2_.getFighterById(param1.sourceCharacterId);
         _loc3_.attack(param1,this.onOneAttackEnd);
      }
      
      private function onOneAttackEnd() : void
      {
         if(!this._need2StopAll)
         {
            --this._roundSemaphore;
            if(this._roundSemaphore == 0)
            {
               if(this.hasNewBattleLineEnd())
               {
                  this.dispatchEvent(new SyncInterrupt(SyncInterrupt.ONE_BATTLELINE_END,null));
               }
               else
               {
                  this.run();
               }
            }
         }
      }
      
      private function handleDeleteAction(param1:Array) : Boolean
      {
         var _loc2_:DeleteAction = null;
         var _loc3_:String = null;
         var _loc4_:IBattlePlayer = null;
         for each(_loc2_ in param1)
         {
            _loc3_ = _loc2_.playerName;
            if(this.isPlayerInBattle(_loc3_))
            {
               return false;
            }
            _loc4_ = this._battle.getPlayerByName(_loc3_);
            _loc4_.fadeOut();
            this._battle.removePlayer(_loc4_);
            this._dispatcher.dispatchEvent(new BattleSyncEvent(BattleSyncEvent.PLAYER_DELETE,{"playerName":_loc3_}));
         }
         return true;
      }
      
      private function handleShiftActions(param1:Array) : void
      {
         var _loc2_:ShiftAction = null;
         var _loc3_:String = null;
         var _loc4_:IBattlePlayer = null;
         this._shiftSemaphore = param1.length;
         for each(_loc2_ in param1)
         {
            _loc3_ = _loc2_.playerName;
            _loc4_ = this._battle.getPlayerByName(_loc3_);
            _loc4_.shiftTo(_loc2_.xTo,_loc2_.yTo,this.onPlayerShiftComplete);
            this._dispatcher.dispatchEvent(new BattleSyncEvent(BattleSyncEvent.PLAYER_SHIFT,{"playerName":_loc3_}));
         }
      }
      
      private function onPlayerShiftComplete() : void
      {
         --this._shiftSemaphore;
         if(this._shiftSemaphore == 0)
         {
            this.run();
         }
      }
      
      private function hasNewBattleLineEnd() : Boolean
      {
         var _loc4_:BattleUnit = null;
         var _loc1_:int = 0;
         var _loc2_:int = 0;
         while(_loc2_ < FormationConsts.MAX_ROW_COUNT)
         {
            _loc4_ = this._arrBattleLines[_loc2_];
            if(_loc4_ != null && _loc4_.roundResults.length > 0)
            {
               _loc1_ |= 1 << _loc2_;
            }
            _loc2_++;
         }
         var _loc3_:Boolean = this._lineState != _loc1_;
         this._lineState = _loc1_;
         return _loc3_;
      }
      
      private function isPlayerInBattle(param1:String) : Boolean
      {
         var _loc3_:BattleUnit = null;
         var _loc2_:int = 0;
         while(_loc2_ < FormationConsts.MAX_ROW_COUNT)
         {
            _loc3_ = this._arrBattleLines[_loc2_];
            if(_loc3_ != null)
            {
               if(!(_loc3_.aPlayerName != param1 && _loc3_.bPlayerName != param1))
               {
                  if(_loc3_.roundResults.length == 0)
                  {
                     return false;
                  }
                  return true;
               }
            }
            _loc2_++;
         }
         return false;
      }
      
      public function dispose() : void
      {
         this._need2StopAll = true;
      }
   }
}

