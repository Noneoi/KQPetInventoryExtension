package mmo.battle.entity
{
   import mmo.common.dialog.NewDialog;
   import mmo.interfaces.IDispose;
   import mmo.interfaces.battle.data.BattleFlow;
   import mmo.interfaces.battle.data.BattleUnit;
   
   public class BattleFlowManager implements IDispose
   {
      
      public static const REACH_THE_END:int = 1;
      
      public static const SKIP_TO_THE_END:int = 2;
      
      private var _syncManager:BattleSyncManager;
      
      private var _battleFlow:BattleFlow;
      
      private var _content:Object;
      
      private var _callback:Function;
      
      private var _disposed:Boolean;
      
      public function BattleFlowManager(param1:BattleFlow, param2:Object, param3:Function)
      {
         super();
         this._battleFlow = param1;
         this._content = param2;
         this._callback = param3;
         this._syncManager = new BattleSyncManager(param2);
      }
      
      public function startBattleFlow() : void
      {
         this._syncManager.addEventListener(SyncInterrupt.OVER_ROUND_LIMIT_WARNING,this.onOverRoundLimitWarning);
         this._syncManager.addEventListener(SyncInterrupt.ONE_BATTLELINE_END,this.onOneBattlelineEnd);
         this.onOneBattlelineEnd(null);
      }
      
      public function dispose() : void
      {
         if(this._disposed)
         {
            return;
         }
         this._disposed = true;
         this._syncManager.removeEventListener(SyncInterrupt.OVER_ROUND_LIMIT_WARNING,this.onOverRoundLimitWarning);
         this._syncManager.removeEventListener(SyncInterrupt.ONE_BATTLELINE_END,this.onOneBattlelineEnd);
         this._syncManager.dispose();
         this._syncManager = null;
         this._callback = null;
      }
      
      private function onOverRoundLimitWarning(param1:SyncInterrupt) : void
      {
         NewDialog.showFailMessage("超出回合数上限！");
      }
      
      private function onOneBattlelineEnd(param1:SyncInterrupt) : void
      {
         var _loc4_:BattleUnit = null;
         var _loc5_:Boolean = false;
         var _loc2_:Array = this._battleFlow.battleUnits;
         if(this._syncManager.getOnBattleLineNum() == 0 && _loc2_.length == 0)
         {
            this._callback.apply(null,[REACH_THE_END]);
            return;
         }
         var _loc3_:Boolean = true;
         while(true)
         {
            _loc4_ = _loc2_.shift();
            if(_loc4_ == null)
            {
               break;
            }
            if(Boolean(_loc4_.isReallyFight) && _loc4_.roundResults.length > 0)
            {
               _loc3_ = false;
            }
            _loc5_ = this._syncManager.insertBattleUnit(_loc4_);
            if(!_loc5_)
            {
               _loc2_.unshift(_loc4_);
               break;
            }
         }
         if(_loc3_ && this._syncManager.getOnBattleLineNum() == 0 && _loc2_.length == 0)
         {
            this._callback.apply(null,[REACH_THE_END]);
            return;
         }
         this._syncManager.run();
      }
   }
}

