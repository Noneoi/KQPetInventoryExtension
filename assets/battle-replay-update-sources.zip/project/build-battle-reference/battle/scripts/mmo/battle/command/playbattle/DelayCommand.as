package mmo.battle.command.playbattle
{
   import flash.utils.setTimeout;
   import mmo.util.command.ISceneCommand;
   import mmo.util.command.SceneSimpleCommand;
   
   public class DelayCommand extends SceneSimpleCommand implements ISceneCommand
   {
      
      public function DelayCommand()
      {
         super();
      }
      
      override public function execute(param1:Object) : void
      {
         var content:Object = param1;
         setTimeout(function():void
         {
            succeed(content);
         },100);
      }
   }
}

