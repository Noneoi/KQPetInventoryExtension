package mmo.battle.avatar
{
   import flash.display.MovieClip;
   import flash.display.Sprite;
   import flash.geom.Point;
   import flash.geom.Rectangle;
   import mmo.battle.tips.FighterTipsPanel;
   import mmo.interfaces.battle.data.FighterInfo;
   import mmo.interfaces.battleconfig.IBattleConfig;
   import mmo.interfaces.battleconfig.define.BufferDefine;
   import mmo.interfaces.jielongzhanchang.JielongZhanchangConsts;
   import mmo.loader.common.datastructures.HashMap;
   
   public class BattleRepresenterAvatar extends BattleAvatar
   {
      
      private static const CLS_BATTLE_REPRESENTER:String = "mmo.battle.common.ActionRepresenter";
      
      private var _map2StateBuff:HashMap = new HashMap();
      
      public function BattleRepresenterAvatar(param1:FighterInfo, param2:Object, param3:Boolean = false)
      {
         super(param1,param2,param3);
      }
      
      override public function addBuff(param1:int, param2:Function = null) : void
      {
         super.addBuff(param1,param2);
      }
      
      override public function get avatarBound() : Rectangle
      {
         return super.avatarBound;
      }
      
      override public function get curActionId() : int
      {
         return super.curActionId;
      }
      
      override public function get curActionTimeline() : MovieClip
      {
         return super.curActionTimeline;
      }
      
      override public function dispose() : void
      {
         super.dispose();
      }
      
      override public function doAction(param1:int) : MovieClip
      {
         return super.doAction(param1);
      }
      
      override public function fadeOut(param1:Function) : void
      {
         super.fadeOut(param1);
      }
      
      override public function flip() : void
      {
         super.flip();
      }
      
      override public function getAction_FullScreen_BackGround(param1:int) : MovieClip
      {
         return super.getAction_FullScreen_BackGround(param1);
      }
      
      override public function getAction_FullScreen_ForeGround(param1:int) : MovieClip
      {
         return super.getAction_FullScreen_ForeGround(param1);
      }
      
      override public function getAvatarLayer() : Sprite
      {
         return super.getAvatarLayer();
      }
      
      override public function getAvatarPos(param1:int) : Point
      {
         return super.getAvatarPos(param1);
      }
      
      override protected function getBloodBarPos() : Point
      {
         return super.getBloodBarPos();
      }
      
      override public function getBloodLayer() : Sprite
      {
         return super.getBloodLayer();
      }
      
      override public function getBubbleLayer() : Sprite
      {
         return super.getBubbleLayer();
      }
      
      override protected function getBubblePos() : Point
      {
         return super.getBubblePos();
      }
      
      override protected function getBubbleSpByNum(param1:FighterInfo, param2:int, param3:Number, param4:BufferDefine = null) : Sprite
      {
         return super.getBubbleSpByNum(param1,param2,param3,param4);
      }
      
      override public function getBuffEffectLayer() : Sprite
      {
         return super.getBuffEffectLayer();
      }
      
      override protected function getBufferById(param1:int) : MovieClip
      {
         return super.getBufferById(param1);
      }
      
      override public function getBufferLayer() : Sprite
      {
         return super.getBufferLayer();
      }
      
      override public function getBufferLayer2() : Sprite
      {
         return super.getBufferLayer2();
      }
      
      override public function getEffectLayer() : Sprite
      {
         return super.getEffectLayer();
      }
      
      override protected function getEffectMCById(param1:int) : MovieClip
      {
         return super.getEffectMCById(param1);
      }
      
      override protected function getFighterTips(param1:Sprite, param2:FighterInfo, param3:IBattleConfig) : FighterTipsPanel
      {
         return super.getFighterTips(param1,param2,param3);
      }
      
      override public function getMovLayer() : Sprite
      {
         return super.getMovLayer();
      }
      
      override public function getPowerResLayer() : Sprite
      {
         return super.getPowerResLayer();
      }
      
      override protected function getSkillEffectMC(param1:int, param2:Boolean) : MovieClip
      {
         return super.getSkillEffectMC(param1,param2);
      }
      
      override protected function getSkillEffectPos(param1:int) : Point
      {
         return super.getSkillEffectPos(param1);
      }
      
      override public function getSkillLayer() : Sprite
      {
         return super.getSkillLayer();
      }
      
      override public function getStateLayer() : Sprite
      {
         return super.getStateLayer();
      }
      
      override protected function getSummonEffectMC(param1:int) : MovieClip
      {
         return super.getSummonEffectMC(param1);
      }
      
      override public function getTargetAction_BackGround(param1:int) : MovieClip
      {
         return super.getTargetAction_BackGround(param1);
      }
      
      override public function getTipsLayer() : Sprite
      {
         return super.getTipsLayer();
      }
      
      override public function hideBufferLayer() : void
      {
         super.hideBufferLayer();
      }
      
      override public function hideEffectLayer() : void
      {
         super.hideEffectLayer();
      }
      
      override public function set hpPersentage(param1:Number) : void
      {
         super.hpPersentage = param1;
      }
      
      override protected function init() : void
      {
         super.init();
      }
      
      override protected function initAvatar() : void
      {
         super.initAvatar();
      }
      
      override protected function initBloodBar() : void
      {
         super.initBloodBar();
      }
      
      override protected function initLayers() : void
      {
         super.initLayers();
      }
      
      override public function set isDead(param1:Boolean) : void
      {
         super.isDead = param1;
      }
      
      override public function jumpTo(param1:Number, param2:Number, param3:Function) : void
      {
         super.jumpTo(param1,param2,param3);
      }
      
      override public function get mcAction() : MovieClip
      {
         return super.mcAction;
      }
      
      override protected function newAvatarAction() : void
      {
         var _loc1_:Class = null;
         var _loc2_:String = null;
         if(this._info.faceId >= JielongZhanchangConsts.JIE_LONG_MIN_SKILL_ID)
         {
            _loc2_ = ACTION_CLS_PREFIX + this._info.faceId;
            if(this._domain.hasDefinition(_loc2_))
            {
               _loc1_ = this._domain.getDefinition(_loc2_) as Class;
            }
            else
            {
               _loc1_ = this._domain.getDefinition(CLS_BATTLE_REPRESENTER) as Class;
            }
         }
         else
         {
            _loc1_ = this._domain.getDefinition(CLS_BATTLE_REPRESENTER) as Class;
         }
         this._mcAction = new _loc1_() as MovieClip;
      }
      
      override public function removeBuff(param1:int) : void
      {
         super.removeBuff(param1);
      }
      
      override protected function removeDeathWing() : void
      {
         super.removeDeathWing();
      }
      
      override public function resetMapBuffId2Buff() : void
      {
         super.resetMapBuffId2Buff();
      }
      
      override public function set scale(param1:Number) : void
      {
         super.scale = param1;
      }
      
      override protected function setBloodLayerVisible(param1:Boolean) : void
      {
         super.setBloodLayerVisible(false);
      }
      
      override protected function setupDeathWing() : void
      {
         super.setupDeathWing();
      }
      
      override public function showBubble(param1:FighterInfo, param2:Number, param3:Number, param4:Function, param5:int = 0) : void
      {
         super.showBubble(param1,param2,param3,param4,param5);
      }
      
      override public function showBufferLayer() : void
      {
         super.showBufferLayer();
      }
      
      override public function showEffect(param1:int, param2:Function, param3:Boolean = false) : void
      {
         super.showEffect(param1,param2,param3);
      }
      
      override public function showEffectLayer() : void
      {
         super.showEffectLayer();
      }
      
      override public function showEffectMovie(param1:MovieClip, param2:int, param3:Function, param4:Boolean = false) : void
      {
         super.showEffectMovie(param1,param2,param3,param4);
      }
      
      override public function showMovie(param1:MovieClip, param2:Function) : void
      {
         super.showMovie(param1,param2);
      }
      
      override public function showPowerBubble(param1:FighterInfo, param2:Number, param3:Number, param4:Function, param5:int = 0) : void
      {
         super.showPowerBubble(param1,param2,param3,param4,param5);
      }
      
      override public function showSkillEffect(param1:int, param2:Boolean, param3:Function, param4:Boolean) : MovieClip
      {
         return super.showSkillEffect(param1,param2,param3,param4);
      }
      
      override public function showSummonEffect(param1:int, param2:Function) : MovieClip
      {
         return super.showSummonEffect(param1,param2);
      }
      
      override public function showTips(param1:Sprite, param2:FighterInfo, param3:IBattleConfig) : void
      {
         super.showTips(param1,param2,param3);
      }
      
      override public function showUp() : void
      {
         super.showUp();
      }
      
      override public function slideBackward(param1:Function) : void
      {
         super.slideBackward(param1);
      }
      
      override public function summonAppear() : void
      {
         super.summonAppear();
      }
      
      override public function summonDisappear() : void
      {
         super.summonDisappear();
      }
      
      override public function updateTips() : void
      {
         super.updateTips();
      }
   }
}

