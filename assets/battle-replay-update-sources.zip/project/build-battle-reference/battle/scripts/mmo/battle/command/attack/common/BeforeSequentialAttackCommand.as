package mmo.battle.command.attack.common
{
   import mmo.battle.entity.BattleBase;
   import mmo.battle.util.BattleContentUtil;
   import mmo.interfaces.battle.data.RoundResult;
   import mmo.interfaces.battle.data.SkillResult;
   import mmo.interfaces.battle.fighter.IBattleFighter;
   import mmo.interfaces.battle.player.IBattlePlayer;
   import mmo.util.command.ISceneCommand;
   import mmo.util.command.SceneCommandEvent;
   import mmo.util.command.SceneSimpleCommand;
   
   public class BeforeSequentialAttackCommand extends SceneSimpleCommand implements ISceneCommand
   {
      
      private var _changeSetIdx:int = 0;
      
      private var _groupCommandNum:int;
      
      private var _content:Object;
      
      private var _battle:BattleBase;
      
      private var _result:RoundResult;
      
      private var _sourcePlayer:IBattlePlayer;
      
      private var _sourceFighter:IBattleFighter;
      
      private var _subCommands:Array = [];
      
      private var bacmd:BeforeAttackCommand;
      
      private var barocmd:BeforeAttackResultObjectCommand;
      
      public function BeforeSequentialAttackCommand()
      {
         super();
      }
      
      override public function execute(param1:Object) : void
      {
         this._content = param1;
         this._battle = BattleContentUtil.getContentProperty(param1,BattleContentUtil.PN_BATTLE);
         this._result = BattleContentUtil.getContentProperty(param1,BattleContentUtil.PN_ROUND_RESULT);
         this.setupSourceFighter();
         this.initSubCommands();
         this.executeSubCommands();
      }
      
      private function setupSourceFighter() : void
      {
         this._sourcePlayer = this._battle.getPlayerByName(this._result.sourcePlayerName);
         this._sourceFighter = this._sourcePlayer.getFighterById(this._result.sourceCharacterId);
         BattleContentUtil.setContentProperty(this._content,BattleContentUtil.PN_SOURCE_PLAYER,this._sourcePlayer);
         BattleContentUtil.setContentProperty(this._content,BattleContentUtil.PN_SOURCE_FIGHTER,this._sourceFighter);
      }
      
      private function initSubCommands() : void
      {
         this.calcGroupCommandNum();
      }
      
      private function calcGroupCommandNum() : void
      {
         var _loc2_:int = 0;
         var _loc3_:SkillResult = null;
         var _loc4_:SkillResult = null;
         var _loc5_:int = 0;
         var _loc6_:int = 0;
         var _loc1_:int = int(this._result.sourceSkillNumResult.changeSetId2BeforeDataMap.length);
         for each(_loc3_ in this._result.targetSkillResults)
         {
            _loc5_ = int(_loc3_.numResult.changeSetId2BeforeDataMap.length);
            _loc2_ = _loc5_ > _loc2_ ? _loc5_ : _loc2_;
         }
         for each(_loc4_ in this._result.targetRepresenterResults)
         {
            _loc6_ = int(_loc4_.numResult.changeSetId2BeforeDataMap.length);
            _loc2_ = _loc6_ > _loc2_ ? _loc6_ : _loc2_;
         }
         this._groupCommandNum = _loc1_ >= _loc2_ ? _loc1_ : _loc2_;
      }
      
      private function executeSubCommands() : void
      {
         if(this._changeSetIdx >= this._groupCommandNum)
         {
            this.resetSkillNumResultData();
            this.succeed(this._content);
         }
         else
         {
            this.seqenceExcuteSubCommands();
         }
      }
      
      private function bacmdsuccFunc(param1:SceneCommandEvent) : void
      {
         this.bacmd.removeEventListener(SceneCommandEvent.SUCCEED,this.bacmdsuccFunc);
         this.bacmd.removeEventListener(SceneCommandEvent.FAILED,this.bacmdfailFunc);
         this.bacmd = null;
         this.barocmd = new BeforeAttackResultObjectCommand();
         this.barocmd.addEventListener(SceneCommandEvent.FAILED,this.barocmdfailFunc);
         this.barocmd.addEventListener(SceneCommandEvent.SUCCEED,this.barocmdsuccFunc);
         this.barocmd.execute(this._content);
      }
      
      private function bacmdfailFunc(param1:SceneCommandEvent) : void
      {
         this.bacmd.removeEventListener(SceneCommandEvent.SUCCEED,this.bacmdsuccFunc);
         this.bacmd.removeEventListener(SceneCommandEvent.FAILED,this.bacmdfailFunc);
         this.bacmd = null;
      }
      
      private function barocmdfailFunc(param1:SceneCommandEvent) : void
      {
         this.barocmd.removeEventListener(SceneCommandEvent.SUCCEED,this.barocmdsuccFunc);
         this.barocmd.removeEventListener(SceneCommandEvent.FAILED,this.barocmdfailFunc);
         this.barocmd = null;
      }
      
      private function barocmdsuccFunc(param1:SceneCommandEvent) : void
      {
         this.barocmd.removeEventListener(SceneCommandEvent.SUCCEED,this.barocmdsuccFunc);
         this.barocmd.removeEventListener(SceneCommandEvent.FAILED,this.barocmdfailFunc);
         this.barocmd = null;
         ++this._changeSetIdx;
         this.updateSkillNumResultData();
         this.executeSubCommands();
      }
      
      private function seqenceExcuteSubCommands() : void
      {
         if(this.isSkillNumResultEmpty())
         {
            ++this._changeSetIdx;
            this.updateSkillNumResultData();
            this.executeSubCommands();
         }
         else
         {
            this.bacmd = new BeforeAttackCommand();
            this.bacmd.addEventListener(SceneCommandEvent.FAILED,this.bacmdfailFunc);
            this.bacmd.addEventListener(SceneCommandEvent.SUCCEED,this.bacmdsuccFunc);
            this.bacmd.execute(this._content);
         }
      }
      
      private function isSkillNumResultEmpty() : Boolean
      {
         return Boolean(this._result.isFillWithMaxChangeSetId) && (Boolean(this._result.targetSkillResults.every(function(param1:SkillResult, ... rest):*
         {
            return param1.numResult.getIsEmpty();
         })) && Boolean(this._result.targetRepresenterResults.every(function(param1:SkillResult, ... rest):*
         {
            return param1.numResult.getIsEmpty();
         })) && Boolean(this._result.sourceSkillNumResult.getIsEmpty()));
      }
      
      private function updateSkillNumResultData() : void
      {
         var _loc1_:SkillResult = null;
         var _loc2_:SkillResult = null;
         ++this._result.sourceSkillNumResult.curChangeSetIdx;
         for each(_loc1_ in this._result.targetSkillResults)
         {
            ++_loc1_.numResult.curChangeSetIdx;
         }
         for each(_loc2_ in this._result.targetRepresenterResults)
         {
            ++_loc2_.numResult.curChangeSetIdx;
         }
      }
      
      private function resetSkillNumResultData() : void
      {
         var _loc1_:SkillResult = null;
         var _loc2_:SkillResult = null;
         this._result.sourceSkillNumResult.curChangeSetIdx = 0;
         for each(_loc1_ in this._result.targetSkillResults)
         {
            _loc1_.numResult.curChangeSetIdx = 0;
         }
         for each(_loc2_ in this._result.targetRepresenterResults)
         {
            _loc2_.numResult.curChangeSetIdx = 0;
         }
      }
   }
}

