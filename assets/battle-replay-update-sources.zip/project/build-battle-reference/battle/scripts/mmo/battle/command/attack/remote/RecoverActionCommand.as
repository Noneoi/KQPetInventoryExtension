package mmo.battle.command.attack.remote
{
   import flash.display.MovieClip;
   import mmo.battle.entity.BattleBase;
   import mmo.battle.util.BattleContentUtil;
   import mmo.interfaces.battle.consts.AvatarActionDefine;
   import mmo.interfaces.battle.data.RoundResult;
   import mmo.interfaces.battle.fighter.IBattleFighter;
   import mmo.interfaces.battle.player.IBattlePlayer;
   import mmo.util.command.ISceneCommand;
   import mmo.util.command.SceneSimpleCommand;
   
   public class RecoverActionCommand extends SceneSimpleCommand implements ISceneCommand
   {
      
      public function RecoverActionCommand()
      {
         super();
      }
      
      override public function execute(param1:Object) : void
      {
         var _loc2_:RoundResult = BattleContentUtil.getContentProperty(param1,BattleContentUtil.PN_ROUND_RESULT);
         var _loc3_:BattleBase = BattleContentUtil.getContentProperty(param1,BattleContentUtil.PN_BATTLE);
         var _loc4_:IBattlePlayer = _loc3_.getPlayerByName(_loc2_.sourcePlayerName);
         var _loc5_:IBattleFighter = _loc4_.getFighterById(_loc2_.sourceCharacterId);
         var _loc6_:MovieClip = _loc5_.doAction(AvatarActionDefine.STAND);
         BattleContentUtil.setContentProperty(param1,BattleContentUtil.PN_TIME_LINE,_loc6_);
         this.succeed(param1);
      }
   }
}

