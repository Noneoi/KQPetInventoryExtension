package mmo.battle.avatar.ext
{
   import flash.geom.Point;
   import mmo.battle.avatar.BattleAvatar;
   import mmo.interfaces.battle.avatar.AvatarPosTypes;
   import mmo.interfaces.battle.data.FighterInfo;
   
   public class BattleAvatar316 extends BattleAvatar
   {
      
      private static const CENTER_X:Number = 22;
      
      private static const CENTER_Y:Number = -46;
      
      private static const BLOOD_BAR_Y:Number = -146;
      
      public function BattleAvatar316(param1:FighterInfo, param2:Object, param3:Boolean = false)
      {
         super(param1,param2,param3);
      }
      
      override protected function getBloodBarPos() : Point
      {
         return new Point(this.x,BLOOD_BAR_Y);
      }
      
      override protected function getBubblePos() : Point
      {
         return new Point(0,BLOOD_BAR_Y);
      }
      
      override public function getAvatarPos(param1:int) : Point
      {
         if(param1 == AvatarPosTypes.CENTER)
         {
            return new Point(this._avatarLayer.scaleX > 0 ? CENTER_X : -CENTER_X,CENTER_Y);
         }
         if(param1 == AvatarPosTypes.TOP)
         {
            return this.getBubblePos();
         }
         return super.getAvatarPos(param1);
      }
   }
}

