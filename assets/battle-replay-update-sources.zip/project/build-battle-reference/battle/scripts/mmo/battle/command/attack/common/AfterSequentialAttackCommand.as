package mmo.battle.command.attack.common
{
   import mmo.battle.entity.BattleBase;
   import mmo.battle.util.BattleContentUtil;
   import mmo.interfaces.battle.data.RoundResult;
   import mmo.interfaces.battle.data.SkillResult;
   import mmo.util.command.ISceneCommand;
   import mmo.util.command.SceneCommandEvent;
   import mmo.util.command.SceneSimpleCommand;
   
   public class AfterSequentialAttackCommand extends SceneSimpleCommand implements ISceneCommand
   {
      
      private var _changeSetIdx:int = 0;
      
      private var _groupCommandNum:int;
      
      private var _content:Object;
      
      private var _battle:BattleBase;
      
      private var _result:RoundResult;
      
      private var aacmd:AfterAttackCommand;
      
      private var aarocmd:AfterAttackResultObjectCommand;
      
      public function AfterSequentialAttackCommand()
      {
         super();
      }
      
      override public function execute(param1:Object) : void
      {
         this._content = param1;
         this._battle = BattleContentUtil.getContentProperty(param1,BattleContentUtil.PN_BATTLE);
         this._result = BattleContentUtil.getContentProperty(param1,BattleContentUtil.PN_ROUND_RESULT);
         this.initSubCommands();
         this.executeSubCommands();
      }
      
      private function initSubCommands() : void
      {
         this.calcGroupCommandNum();
      }
      
      private function calcGroupCommandNum() : void
      {
         var _loc3_:SkillResult = null;
         var _loc4_:SkillResult = null;
         var _loc5_:int = 0;
         var _loc6_:int = 0;
         var _loc1_:int = int(this._result.sourceSkillNumResult.changeSetId2AfterDataMap.length);
         var _loc2_:int = 0;
         for each(_loc3_ in this._result.targetSkillResults)
         {
            _loc5_ = int(_loc3_.numResult.changeSetId2AfterDataMap.length);
            _loc2_ = _loc5_ > _loc2_ ? _loc5_ : _loc2_;
         }
         for each(_loc4_ in this._result.targetRepresenterResults)
         {
            _loc6_ = int(_loc4_.numResult.changeSetId2AfterDataMap.length);
            _loc2_ = _loc6_ > _loc2_ ? _loc6_ : _loc2_;
         }
         this._groupCommandNum = _loc1_ >= _loc2_ ? _loc1_ : _loc2_;
      }
      
      private function executeSubCommands() : void
      {
         if(this._changeSetIdx >= this._groupCommandNum)
         {
            this.succeed(this._content);
            this.resetSkillNumResultData();
         }
         else
         {
            this.seqenceExcuteSubCommands();
         }
      }
      
      private function aacmdsuccFunc(param1:SceneCommandEvent) : void
      {
         this.aacmd.removeEventListener(SceneCommandEvent.SUCCEED,this.aacmdsuccFunc);
         this.aacmd.removeEventListener(SceneCommandEvent.FAILED,this.aacmdfailFunc);
         this.aacmd = null;
         this.aarocmd = new AfterAttackResultObjectCommand();
         this.aarocmd.addEventListener(SceneCommandEvent.FAILED,this.aarocmdfailFunc);
         this.aarocmd.addEventListener(SceneCommandEvent.SUCCEED,this.aarocmdsuccFunc);
         this.aarocmd.execute(this._content);
      }
      
      private function aacmdfailFunc(param1:SceneCommandEvent) : void
      {
         this.aacmd.removeEventListener(SceneCommandEvent.SUCCEED,this.aacmdsuccFunc);
         this.aacmd.removeEventListener(SceneCommandEvent.FAILED,this.aacmdfailFunc);
         this.aacmd = null;
      }
      
      private function aarocmdfailFunc(param1:SceneCommandEvent) : void
      {
         this.aarocmd.removeEventListener(SceneCommandEvent.SUCCEED,this.aarocmdsuccFunc);
         this.aarocmd.removeEventListener(SceneCommandEvent.FAILED,this.aarocmdfailFunc);
         this.aarocmd = null;
      }
      
      private function aarocmdsuccFunc(param1:SceneCommandEvent) : void
      {
         this.aarocmd.removeEventListener(SceneCommandEvent.SUCCEED,this.aarocmdsuccFunc);
         this.aarocmd.removeEventListener(SceneCommandEvent.FAILED,this.aarocmdfailFunc);
         this.aarocmd = null;
         ++this._changeSetIdx;
         this.updateSkillNumResultData();
         this.executeSubCommands();
      }
      
      private function seqenceExcuteSubCommands() : void
      {
         if(this.isSkillNumResultEmpty())
         {
            ++this._changeSetIdx;
            this.updateSkillNumResultData();
            this.executeSubCommands();
         }
         else
         {
            this.aacmd = new AfterAttackCommand();
            this.aacmd.addEventListener(SceneCommandEvent.FAILED,this.aacmdfailFunc);
            this.aacmd.addEventListener(SceneCommandEvent.SUCCEED,this.aacmdsuccFunc);
            this.aacmd.execute(this._content);
         }
      }
      
      private function isSkillNumResultEmpty() : Boolean
      {
         return Boolean(this._result.isFillWithMaxChangeSetId) && (Boolean(this._result.targetSkillResults.every(function(param1:SkillResult, ... rest):*
         {
            return param1.numResult.getIsEmpty(false);
         })) && Boolean(this._result.targetRepresenterResults.every(function(param1:SkillResult, ... rest):*
         {
            return param1.numResult.getIsEmpty(false);
         })) && Boolean(this._result.sourceSkillNumResult.getIsEmpty(false)));
      }
      
      private function updateSkillNumResultData() : void
      {
         var _loc1_:SkillResult = null;
         var _loc2_:SkillResult = null;
         ++this._result.sourceSkillNumResult.curChangeSetIdx;
         for each(_loc1_ in this._result.targetSkillResults)
         {
            ++_loc1_.numResult.curChangeSetIdx;
         }
         for each(_loc2_ in this._result.targetRepresenterResults)
         {
            ++_loc2_.numResult.curChangeSetIdx;
         }
      }
      
      private function resetSkillNumResultData() : void
      {
         var _loc1_:SkillResult = null;
         var _loc2_:SkillResult = null;
         this._result.sourceSkillNumResult.curChangeSetIdx = 0;
         for each(_loc1_ in this._result.targetSkillResults)
         {
            _loc1_.numResult.curChangeSetIdx = 0;
         }
         for each(_loc2_ in this._result.targetRepresenterResults)
         {
            _loc2_.numResult.curChangeSetIdx = 0;
         }
      }
   }
}

