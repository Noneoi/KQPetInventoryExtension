package mmo.battle.entity
{
   import flash.system.ApplicationDomain;
   import mmo.battle.command.PlaySequentialBattleCommand;
   import mmo.battle.util.BattleContentUtil;
   import mmo.common.ProgressFullSprite;
   import mmo.interfaces.battle.command.IBattleCommand;
   import mmo.interfaces.battle.entity.IBattle;
   import mmo.interfaces.battle.entity.IBattleSequential;
   import mmo.loader.CustomLoader;
   import mmo.loader.scheduler.ResPriority;
   import mmo.play.scene.Disposer;
   import mmo.util.command.SceneCommandEvent;
   
   public class BattleBaseSequential extends BattleBase implements IBattleSequential
   {
      
      private var _battles:Array;
      
      private var _nodePetRaceIds:Array;
      
      public function BattleBaseSequential(param1:Array, param2:Array)
      {
         var _loc3_:IBattle = param1[param1.length - 1];
         super(_loc3_.battleResult);
         this._battles = param1;
         this._nodePetRaceIds = param2;
      }
      
      override public function play() : void
      {
         var _loc1_:ApplicationDomain = new ApplicationDomain(ApplicationDomain.currentDomain);
         var _loc2_:CustomLoader = new CustomLoader(ResPriority.HIGHEST,true,_loc1_);
         var _loc3_:Object = new Object();
         _loc3_[BattleContentUtil.PN_BATTLE_SEQ] = this;
         _loc3_[BattleContentUtil.PN_BATTLE] = this;
         _loc3_[BattleContentUtil.PN_DOMAIN] = _loc1_;
         _loc3_[BattleContentUtil.PN_LOADER] = _loc2_;
         _loc3_[BattleContentUtil.PN_EVENT_DISPATCHER] = this;
         _loc3_[BattleContentUtil.PN_CONTAINER] = this._container;
         _loc3_[BattleContentUtil.PN_BATTLES] = this._battles;
         _loc3_[BattleContentUtil.PN_NODE_RACE_ID] = this._nodePetRaceIds;
         _loc3_[BattleContentUtil.PN_BATTLE_TYPE] = this._battleResult.battleType;
         this.executeCommand(PlaySequentialBattleCommand,_loc3_);
         this.setTeamLeaderState();
      }
      
      public function get battles() : Array
      {
         return this._battles;
      }
      
      override protected function executeCommand(param1:Class, param2:Object) : void
      {
         var command:IBattleCommand;
         var succFunc:Function = null;
         var failFunc:Function = null;
         var commandClsRef:Class = param1;
         var content:Object = param2;
         if(this._executingCommand != null)
         {
            return;
         }
         command = new commandClsRef() as IBattleCommand;
         this._executingCommand = command;
         succFunc = function(param1:SceneCommandEvent):void
         {
            _executingCommand.removeEventListener(SceneCommandEvent.SUCCEED,succFunc);
            _executingCommand.removeEventListener(SceneCommandEvent.FAILED,failFunc);
            _executingCommand = null;
            ProgressFullSprite.close();
            Disposer.instance.tryDisposeResources();
         };
         failFunc = function(param1:SceneCommandEvent):void
         {
            _executingCommand.removeEventListener(SceneCommandEvent.SUCCEED,succFunc);
            _executingCommand.removeEventListener(SceneCommandEvent.FAILED,failFunc);
            _executingCommand = null;
            ProgressFullSprite.close();
            Disposer.instance.tryDisposeResources();
            var _loc2_:String = param1.params.ErrMessage;
            throw new Error(_loc2_);
         };
         this._executingCommand.addEventListener(SceneCommandEvent.SUCCEED,succFunc);
         this._executingCommand.addEventListener(SceneCommandEvent.FAILED,failFunc);
         ProgressFullSprite.show();
         command.execute(content);
      }
   }
}

