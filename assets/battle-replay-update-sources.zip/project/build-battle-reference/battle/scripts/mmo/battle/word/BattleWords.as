package mmo.battle.word
{
   import mmo.interfaces.battle.data.BattleResult;
   import mmo.interfaces.battle.data.FighterInfo;
   import mmo.interfaces.battle.data.PlayerInfo;
   import mmo.interfaces.battle.data.TeamInfo;
   import mmo.interfaces.battle.word.BattleWordInfo;
   import mmo.interfaces.battle.word.BattleWordResult;
   import mmo.interfaces.battleconfig.IBattleConfig;
   import mmo.loader.common.datastructures.HashMap;
   
   public class BattleWords
   {
      
      private var _wordResult:BattleWordResult;
      
      private var _mapName2Player:HashMap = new HashMap();
      
      private var _result:BattleResult;
      
      private var _battleConfig:IBattleConfig;
      
      private var _player0s:Array = [];
      
      private var _player1s:Array = [];
      
      private var _player0Names:Array = [];
      
      private var _player1Names:Array = [];
      
      public function BattleWords(param1:BattleResult, param2:IBattleConfig)
      {
         super();
         this._result = param1;
         this._battleConfig = param2;
         this._mapName2Player = new HashMap();
         this.setupPlayerNames(this._result.battleInfo.getTeamInfoById(0),this._player0Names);
         this.setupPlayerNames(this._result.battleInfo.getTeamInfoById(1),this._player1Names);
         this._wordResult = new BattleWordResult(param1.winerTeamId,[],this._player0Names,this._player1Names);
         this.setupTeam(this._result.battleInfo.getTeamInfoById(0),false,this._player0s);
         this.setupTeam(this._result.battleInfo.getTeamInfoById(1),true,this._player1s);
         this.buildword();
      }
      
      public function get wordResult() : BattleWordResult
      {
         return this._wordResult;
      }
      
      public function addMessage(param1:String) : void
      {
         var _loc2_:BattleWordInfo = new BattleWordInfo(param1,this.getTeamCurHp(this._player0s),this.getTeamMaxHp(this._player0s),this.getTeamCurHp(this._player1s),this.getTeamMaxHp(this._player1s));
         this._wordResult.wordInfos.push(_loc2_);
      }
      
      private function getTeamCurHp(param1:Array) : int
      {
         var _loc2_:Number = NaN;
         var _loc4_:BattleWordPlayer = null;
         var _loc5_:Array = null;
         var _loc6_:int = 0;
         var _loc7_:BattleWordFighter = null;
         var _loc3_:int = 0;
         while(_loc3_ < param1.length)
         {
            _loc4_ = param1[_loc3_];
            _loc5_ = _loc4_.fighterList;
            _loc6_ = 0;
            while(_loc6_ < _loc5_.length)
            {
               _loc7_ = _loc5_[_loc6_];
               _loc2_ += _loc7_.curHp;
               _loc6_++;
            }
            _loc3_++;
         }
         return _loc2_;
      }
      
      private function getTeamMaxHp(param1:Array) : int
      {
         var _loc2_:Number = NaN;
         var _loc4_:BattleWordPlayer = null;
         var _loc5_:Array = null;
         var _loc6_:int = 0;
         var _loc7_:BattleWordFighter = null;
         var _loc3_:int = 0;
         while(_loc3_ < param1.length)
         {
            _loc4_ = param1[_loc3_];
            _loc5_ = _loc4_.fighterList;
            _loc6_ = 0;
            while(_loc6_ < _loc5_.length)
            {
               _loc7_ = _loc5_[_loc6_];
               _loc2_ += _loc7_.maxHp;
               _loc6_++;
            }
            _loc3_++;
         }
         return _loc2_;
      }
      
      public function get battleConfig() : IBattleConfig
      {
         return this._battleConfig;
      }
      
      private function buildword() : void
      {
         var _loc1_:BattleWordFlowManager = new BattleWordFlowManager(this._result.battleFlow,this);
         _loc1_.startBattleFlow();
      }
      
      public function getPlayerByName(param1:String) : BattleWordPlayer
      {
         return this._mapName2Player.getValue(param1) as BattleWordPlayer;
      }
      
      public function removePlayer(param1:BattleWordPlayer) : void
      {
         this._mapName2Player.remove(param1.playerInfo.playerName);
      }
      
      private function registerPlayer(param1:BattleWordPlayer) : void
      {
         this._mapName2Player.add(param1.playerInfo.playerName,param1);
      }
      
      private function setupTeam(param1:TeamInfo, param2:Boolean, param3:Array) : void
      {
         var _loc5_:PlayerInfo = null;
         var _loc6_:Array = null;
         var _loc7_:BattleWordPlayer = null;
         var _loc8_:FighterInfo = null;
         var _loc9_:BattleWordFighter = null;
         var _loc10_:int = 0;
         var _loc4_:Array = param1.playerInfos;
         for each(_loc5_ in _loc4_)
         {
            _loc6_ = _loc5_.fighterInfos;
            _loc7_ = new BattleWordPlayer(_loc5_,this);
            for each(_loc8_ in _loc6_)
            {
               _loc9_ = new BattleWordFighter(_loc8_,this,param2);
               for each(_loc10_ in _loc8_.initBufferIds)
               {
                  _loc9_.addBuff(_loc10_);
               }
               _loc7_.registerFighter(_loc9_);
            }
            this.registerPlayer(_loc7_);
            param3.push(_loc7_);
         }
      }
      
      private function setupPlayerNames(param1:TeamInfo, param2:Array) : void
      {
         var _loc4_:PlayerInfo = null;
         var _loc3_:Array = param1.playerInfos;
         for each(_loc4_ in _loc3_)
         {
            param2.push(_loc4_.playerName);
         }
      }
   }
}

