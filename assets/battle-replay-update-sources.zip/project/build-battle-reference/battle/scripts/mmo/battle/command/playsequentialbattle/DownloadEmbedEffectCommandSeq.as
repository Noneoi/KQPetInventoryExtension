package mmo.battle.command.playsequentialbattle
{
   import mmo.battle.command.playbattle.DownloadEmbedEffectCommand;
   import mmo.battle.util.BattleContentUtil;
   import mmo.interfaces.battle.data.BattleInfo;
   import mmo.interfaces.battle.entity.IBattle;
   import mmo.interfaces.battleconfig.IBattleConfig;
   
   public class DownloadEmbedEffectCommandSeq extends DownloadEmbedEffectCommand
   {
      
      public function DownloadEmbedEffectCommandSeq()
      {
         super();
      }
      
      override public function execute(param1:Object) : void
      {
         var _loc4_:IBattle = null;
         var _loc5_:BattleInfo = null;
         var _loc6_:Array = null;
         var _loc2_:Array = BattleContentUtil.getContentProperty(param1,BattleContentUtil.PN_BATTLES);
         var _loc3_:IBattleConfig = BattleContentUtil.getContentProperty(param1,BattleContentUtil.PN_BATTLE_CONFIG);
         for each(_loc4_ in _loc2_)
         {
            _loc5_ = _loc4_.battleResult.battleInfo;
            _loc6_ = this.getDownloadFileList(_loc5_,_loc3_);
            BattleContentUtil.addToPreDownloadList(param1,_loc6_);
         }
         this.succeed(param1);
      }
   }
}

