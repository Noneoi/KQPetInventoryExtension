package mmo.battle.util
{
   import flash.display.MovieClip;
   import flash.display.Sprite;
   import flash.events.Event;
   import flash.events.IEventDispatcher;
   import flash.geom.Point;
   import flash.system.ApplicationDomain;
   import flash.utils.setTimeout;
   import mmo.battle.consts.BubbleConsts;
   import mmo.battle.consts.BufferConsts;
   import mmo.battle.container.BattleContainer;
   import mmo.battle.entity.BattleBase;
   import mmo.battle.helper.BattleBufferHelper;
   import mmo.common.DisplayUtil;
   import mmo.common.EventUtil;
   import mmo.common.helper.ActUtil;
   import mmo.interfaces.battle.data.RepresentRoundResult;
   import mmo.interfaces.battle.data.SkillNumUnit;
   import mmo.interfaces.battle.data.SkillNumUnitBuffChangedState;
   import mmo.interfaces.battle.data.SkillNumUnitNothing;
   import mmo.interfaces.battle.data.SkillNumUnitReplication;
   import mmo.interfaces.battle.data.SkillNumUnitSummon;
   import mmo.interfaces.battle.data.SkillNumUnitTransform;
   import mmo.interfaces.battle.data.SkillNumUnitTransformAttr;
   import mmo.interfaces.battle.data.SkillNumUnitValueUpdate;
   import mmo.interfaces.battle.fighter.IBattleFighter;
   import mmo.interfaces.battle.player.IBattlePlayer;
   import mmo.interfaces.battleconfig.IBattleConfig;
   import mmo.interfaces.battleconfig.define.BufferDefine;
   import mmo.interfaces.battleconfig.define.BufferExecuteDefine;
   import mmo.interfaces.battleconfig.define.SkillDefine;
   import mmo.loader.LoaderContainer;
   import mmo.play.dialog.InteractUtil;
   
   public class BattleNumUnitUtil
   {
      
      private static const CHANGE_AVATAR_NAME_CLS:String = "mmo.battlechangeavatar.MovieName";
      
      private static const CHANGE_AVATAR_CLS:String = "mmo.battlechangeavatar.Movie";
      
      private static const DEFAULT_CHANGE_AVATAR_CLS:String = "mmo.battlechangeavatar.Movie_default";
      
      private static const BUFFER_STATE_CHANGE_MOVIE_CLS:String = "mmo.bufferstate.ChangedMovie";
      
      private var _battleContent:Object;
      
      private var _domain:ApplicationDomain;
      
      private var _container:BattleContainer;
      
      private var _battle:BattleBase;
      
      private var _blackScreen:Sprite;
      
      private var _arrComList:Array = [];
      
      private var _callback:Function;
      
      private var _unitCnt:int;
      
      private var _battleConfig:IBattleConfig;
      
      public function BattleNumUnitUtil(param1:Object)
      {
         super();
         this._battleContent = param1;
         this._domain = BattleContentUtil.getContentProperty(this._battleContent,BattleContentUtil.PN_DOMAIN);
         this._container = BattleContentUtil.getContentProperty(this._battleContent,BattleContentUtil.PN_CONTAINER);
         this._battle = BattleContentUtil.getContentProperty(this._battleContent,BattleContentUtil.PN_BATTLE);
         this._battleConfig = BattleContentUtil.getContentProperty(param1,BattleContentUtil.PN_BATTLE_CONFIG);
      }
      
      public function addFighterUnitPair(param1:IBattlePlayer, param2:IBattleFighter, param3:SkillNumUnit) : void
      {
         var _loc4_:PlayerAndFighterAndUnit = new PlayerAndFighterAndUnit(param1,param2,param3);
         this._arrComList.push(_loc4_);
      }
      
      public function handleNumUnitList(param1:Function) : void
      {
         this._unitCnt = 0;
         this._callback = param1;
         if(this._arrComList.length == 0)
         {
            this.finish();
         }
         else
         {
            this.handleUnit();
         }
      }
      
      private function addAndcheckUnitFinish() : void
      {
         ++this._unitCnt;
         if(this._unitCnt >= this._arrComList.length)
         {
            this.finish();
         }
      }
      
      private function handleUnit() : void
      {
         var _loc1_:PlayerAndFighterAndUnit = null;
         var _loc2_:SkillNumUnit = null;
         var _loc3_:IBattleFighter = null;
         var _loc4_:SkillNumUnitValueUpdate = null;
         var _loc5_:Number = NaN;
         var _loc6_:SkillNumUnitTransform = null;
         for each(_loc1_ in this._arrComList)
         {
            _loc2_ = _loc1_.unit;
            _loc3_ = _loc1_.fighter;
            if(_loc2_ is SkillNumUnitValueUpdate)
            {
               _loc4_ = _loc2_ as SkillNumUnitValueUpdate;
               _loc3_.showBubble(null,_loc4_.changedMaxHp,this._battleConfig.strongEffRestraintCoeff + 1,null,0,BufferConsts.ChangeMaxHpBuffId);
               _loc3_.showBubble(null,_loc4_.changedCurHp,this._battleConfig.strongEffRestraintCoeff + 1,null,BubbleConsts.BUBBLE_INTERVAL * 2);
               _loc5_ = Number(_loc3_.info.curHp);
               _loc3_.info.curHp = _loc4_.curHp;
               _loc3_.info.maxHp = _loc4_.maxHp;
               if(_loc5_ <= 0 && _loc3_.info.curHp > 0)
               {
                  _loc3_.showUp();
               }
               _loc3_.updateCurHp();
               this.addAndcheckUnitFinish();
            }
            else if(_loc2_ is SkillNumUnitTransform)
            {
               _loc6_ = _loc2_ as SkillNumUnitTransform;
               _loc3_.info.transFromRaceId = _loc3_.info.getShowRaceIdWithOrigin();
               _loc3_.info.raceId = _loc6_.curRaceId;
               _loc3_.info.faceId = _loc6_.curFaceId;
               _loc3_.info.normalSkill = _loc6_.normalSkillId;
               _loc3_.info.uniqueSkill = _loc6_.uniqueSkillId == 0 ? int(_loc6_.superUniqueSkillId) : int(_loc6_.uniqueSkillId);
               _loc3_.info.raceTypeIds = _loc6_.raceTypeIds;
               if(_loc6_.curFaceId != _loc6_.orgFaceId)
               {
                  this.handleChangeAvatar(_loc1_);
               }
               else
               {
                  this.addAndcheckUnitFinish();
               }
            }
            else if(_loc2_ is SkillNumUnitReplication)
            {
               this.handleReplicationChanged(_loc1_);
            }
            else if(_loc2_ is SkillNumUnitSummon)
            {
               this.addAndcheckUnitFinish();
            }
            else if(_loc2_ is SkillNumUnitBuffChangedState)
            {
               this.handleBuffChangedState(_loc1_);
            }
            else if(_loc2_ is SkillNumUnitTransformAttr)
            {
               this.handleTransformAttr(_loc1_);
            }
            else if(_loc2_ is SkillNumUnitNothing)
            {
               this.addAndcheckUnitFinish();
            }
         }
      }
      
      private function handleReplicationChanged(param1:PlayerAndFighterAndUnit) : void
      {
         var _loc2_:IBattlePlayer = param1.player;
         var _loc3_:SkillNumUnitReplication = SkillNumUnitReplication(param1.unit);
         var _loc4_:IBattleFighter = _loc2_.getFighterById(_loc3_.fighterId);
         _loc4_.info.isSelfReplication = _loc4_.info.isSelfReplicationCalledOut = true;
         _loc4_.avatar.showUp();
         _loc4_.avatar.summonAppear();
         this.addAndcheckUnitFinish();
      }
      
      private function handleBuffChangedState(param1:PlayerAndFighterAndUnit) : void
      {
         var _loc6_:BufferDefine = null;
         var _loc7_:BufferExecuteDefine = null;
         var _loc8_:Point = null;
         var _loc2_:IBattlePlayer = param1.player;
         var _loc3_:SkillNumUnitBuffChangedState = SkillNumUnitBuffChangedState(param1.unit);
         var _loc4_:IBattleFighter = _loc2_.getFighterById(RepresentRoundResult.REPRESENTER_SOURCE_CHARACTER_ID);
         var _loc5_:MovieClip = _loc4_.avatar.getBuffMcByBuffId(_loc3_.buffId);
         if(_loc5_)
         {
            _loc6_ = this._battleConfig.getBufferDefineById(_loc3_.buffId);
            _loc7_ = this._battleConfig.getBufferExecutDefine(_loc3_.buffId);
            _loc8_ = _loc4_.avatar.getAvatarPos(_loc6_.posId);
            if(_loc3_.changedValue > 0)
            {
               if(_loc4_.needFlip)
               {
                  _loc8_.x = 960;
               }
               if(!this._domain.hasDefinition(BUFFER_STATE_CHANGE_MOVIE_CLS + _loc6_.displayId))
               {
                  throw new Error("bufferstatemovie" + _loc3_.buffId + ".fla should has has definition:" + BUFFER_STATE_CHANGE_MOVIE_CLS + _loc6_.displayId + ",but not found!");
               }
               this.playMovie(BUFFER_STATE_CHANGE_MOVIE_CLS + _loc6_.displayId,_loc4_.needFlip,this._container.movieLayerAbove,this.afterPlayBufferStateChangedMovie,"",param1,_loc8_);
            }
            else if(_loc3_.changedValue < 0 && _loc7_ != null && _loc7_.maxValue > 0 && _loc3_.curValue < _loc7_.maxValue && !(_loc3_.oldValue >= _loc7_.maxValue && _loc3_.curValue == 0) && !_loc3_.isSkillEffected)
            {
               if(_loc4_.needFlip)
               {
                  _loc8_.x = 960;
               }
               this.playMovie("mmo.battle.common.PsyPonitDown",_loc4_.needFlip,this._container.movieLayerAbove,this.afterPlayBufferStateChangedMovie,"",param1,_loc8_);
            }
            else
            {
               this.afterPlayBufferStateChangedMovie(param1);
            }
         }
      }
      
      private function handleTransformAttr(param1:PlayerAndFighterAndUnit) : void
      {
         var _loc2_:IBattleFighter = param1.fighter;
         var _loc3_:SkillNumUnitTransformAttr = param1.unit as SkillNumUnitTransformAttr;
         _loc2_.info.raceTypeIds = _loc3_.raceTypeIds;
         _loc2_.avatar.updateAttr();
         this.addAndcheckUnitFinish();
      }
      
      private function afterPlayBufferStateChangedMovie(param1:PlayerAndFighterAndUnit) : void
      {
         var _loc2_:IBattlePlayer = param1.player;
         var _loc3_:SkillNumUnitBuffChangedState = SkillNumUnitBuffChangedState(param1.unit);
         var _loc4_:IBattleFighter = _loc2_.getFighterById(RepresentRoundResult.REPRESENTER_SOURCE_CHARACTER_ID);
         var _loc5_:MovieClip = _loc4_.avatar.getBuffMcByBuffId(_loc3_.buffId);
         var _loc6_:BufferExecuteDefine = this._battleConfig.getBufferExecutDefine(_loc3_.buffId);
         if(_loc6_ == null && Boolean(ActUtil.isDebug()))
         {
            throw new Error("buff未定义!" + _loc3_.buffId);
         }
         var _loc7_:SkillDefine = this._battleConfig.getSkillDefineById(_loc6_.skillId);
         BattleBufferHelper.setBuffProgress(_loc5_,_loc3_.curValue,_loc3_.maxValue,_loc7_);
         this.addAndcheckUnitFinish();
      }
      
      private function handleSummonPet(param1:SkillNumUnitSummon) : void
      {
         var fighter:IBattleFighter = null;
         var unit:SkillNumUnitSummon = param1;
         var battlePlayer:IBattlePlayer = this._battle.getPlayerByName(unit.playerName);
         fighter = battlePlayer.getFighterById(unit.fighterId);
         var dispather:IEventDispatcher = BattleContentUtil.getContentProperty(this._battleContent,BattleContentUtil.PN_EVENT_DISPATCHER);
         EventUtil.addEventListenerOnce(dispather,"summonUp",function(param1:Event):void
         {
            fighter.avatar.summonAppear();
            fighter.info.bSummonedCallOut = true;
         });
         EventUtil.addEventListenerOnce(dispather,"summonFinish",function(param1:Event):void
         {
            addAndcheckUnitFinish();
         });
      }
      
      private function handleChangeAvatar(param1:PlayerAndFighterAndUnit) : void
      {
         this.tryApplyBlackScreen();
         this.hideFigherEffectLayer(param1);
         this.playMovie(CHANGE_AVATAR_NAME_CLS + param1.fighter.info.faceId,false,this._container.movieLayerAbove,null,"",param1);
         this.playMovie(CHANGE_AVATAR_CLS + param1.fighter.info.faceId,true,this._container.movieLayerAbove,this.onChangeAvatarMovieEnd,DEFAULT_CHANGE_AVATAR_CLS,param1);
      }
      
      private function onChangeAvatarMovieEnd(param1:PlayerAndFighterAndUnit) : void
      {
         var curCom:PlayerAndFighterAndUnit = param1;
         var changeAvatarMovieEnd:Function = function():void
         {
            removeBlackScreen();
            showFigherEffectLayer(curCom);
            resetAvatar(curCom);
            setTimeout(addAndcheckUnitFinish,500);
         };
         if(curCom.fighter.avatar == null)
         {
            setTimeout(changeAvatarMovieEnd,500);
         }
         else
         {
            changeAvatarMovieEnd.apply();
         }
      }
      
      private function tryApplyBlackScreen() : void
      {
         var _loc1_:Boolean = BattleContentUtil.getContentProperty(this._battleContent,BattleContentUtil.PN_IS_MULTIPLAYER);
         if(_loc1_)
         {
            return;
         }
         if(this._blackScreen != null)
         {
            return;
         }
         this._blackScreen = new Sprite();
         this._blackScreen.graphics.beginFill(0,0.8);
         this._blackScreen.graphics.drawRect(0,0,LoaderContainer.stageWidth,LoaderContainer.stageHeight);
         this._blackScreen.graphics.endFill();
         this._container.movieLayerAbove.addChild(this._blackScreen);
      }
      
      private function removeBlackScreen() : void
      {
         if(this._blackScreen != null)
         {
            DisplayUtil.stopAndRemove(this._blackScreen);
            this._blackScreen = null;
         }
      }
      
      private function hideFigherEffectLayer(param1:PlayerAndFighterAndUnit) : void
      {
         param1.fighter.avatar.hideEffectLayer();
      }
      
      private function showFigherEffectLayer(param1:PlayerAndFighterAndUnit) : void
      {
         param1.fighter.avatar.showEffectLayer();
      }
      
      private function resetAvatar(param1:PlayerAndFighterAndUnit) : void
      {
         var curCom:PlayerAndFighterAndUnit = param1;
         curCom.fighter.resetAvatar(function():void
         {
            handleSummon(curCom);
         });
      }
      
      private function handleSummon(param1:PlayerAndFighterAndUnit) : void
      {
         if(param1.fighter.info.isSummoned)
         {
            param1.fighter.avatar.summonAppear();
         }
      }
      
      private function playMovie(param1:String, param2:Boolean, param3:Sprite, param4:Function = null, param5:String = "", param6:PlayerAndFighterAndUnit = null, param7:Point = null) : void
      {
         var cls:Class;
         var mov:MovieClip;
         var clsName:String = param1;
         var needFlip:Boolean = param2;
         var container:Sprite = param3;
         var callback:Function = param4;
         var defaultClsName:String = param5;
         var curCom:PlayerAndFighterAndUnit = param6;
         var pos:Point = param7;
         if(!this._domain.hasDefinition(clsName))
         {
            clsName = defaultClsName;
         }
         if(!this._domain.hasDefinition(clsName))
         {
            if(callback != null)
            {
               this.removeBlackScreen();
               setTimeout(function():*
               {
                  InteractUtil.applyCallback(callback,[curCom]);
               },300);
            }
            return;
         }
         cls = this._domain.getDefinition(clsName) as Class;
         mov = new cls() as MovieClip;
         if(pos == null)
         {
            mov.x = curCom.fighter.x;
            mov.y = curCom.fighter.y;
         }
         else
         {
            mov.x = pos.x;
            mov.y = pos.y;
         }
         if(needFlip)
         {
            mov.scaleX = curCom.fighter.needFlip ? -1 : 1;
         }
         container.addChild(mov);
         mov.addFrameScript(mov.totalFrames - 1,this.onMoveEnd(mov,callback,[curCom]));
         mov.gotoAndPlay(1);
      }
      
      private function onMoveEnd(param1:MovieClip, param2:Function, param3:* = null) : Function
      {
         var mov:MovieClip = param1;
         var callback:Function = param2;
         var argArray:* = param3;
         var fun:Function = function():void
         {
            DisplayUtil.stopAndRemove(mov);
            if(callback != null)
            {
               callback.apply(null,argArray);
            }
         };
         return fun;
      }
      
      private function finish() : void
      {
         if(this._callback != null)
         {
            this._callback.apply();
         }
      }
   }
}

import mmo.interfaces.battle.data.SkillNumUnit;
import mmo.interfaces.battle.fighter.IBattleFighter;
import mmo.interfaces.battle.player.IBattlePlayer;

class PlayerAndFighterAndUnit
{
   
   private var _player:IBattlePlayer;
   
   private var _fighter:IBattleFighter;
   
   private var _unit:SkillNumUnit;
   
   public function PlayerAndFighterAndUnit(param1:IBattlePlayer, param2:IBattleFighter, param3:SkillNumUnit)
   {
      super();
      this._player = param1;
      this._fighter = param2;
      this._unit = param3;
   }
   
   public function get player() : IBattlePlayer
   {
      return this._player;
   }
   
   public function get fighter() : IBattleFighter
   {
      return this._fighter;
   }
   
   public function get unit() : SkillNumUnit
   {
      return this._unit;
   }
}
