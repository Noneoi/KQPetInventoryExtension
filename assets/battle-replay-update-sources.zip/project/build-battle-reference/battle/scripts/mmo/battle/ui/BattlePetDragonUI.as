package mmo.battle.ui
{
   import flash.display.Sprite;
   import flash.events.IEventDispatcher;
   import flash.system.ApplicationDomain;
   import mmo.battle.entity.BattleBase;
   import mmo.interfaces.ServiceContainer;
   import mmo.interfaces.battle.data.BattleInfo;
   import mmo.interfaces.battle.data.NpcBlessResult;
   import mmo.interfaces.petdragon.IPetDragonService;
   
   public class BattlePetDragonUI extends BattleUI
   {
      
      private var leftPetDrgonBar:PetDragonSeqBar;
      
      private var rightPetDragonBar:PetDragonSeqBar;
      
      public function BattlePetDragonUI(param1:Sprite, param2:ApplicationDomain, param3:IEventDispatcher)
      {
         super(param1,param2,param3);
      }
      
      override public function setInfo(param1:BattleInfo, param2:NpcBlessResult, param3:BattleBase) : void
      {
         var battleInfo:BattleInfo = param1;
         var npcBlessResult:NpcBlessResult = param2;
         var battle:BattleBase = param3;
         super.setInfo(battleInfo,npcBlessResult,battle);
         ServiceContainer.tryGetService(IPetDragonService,function(param1:IPetDragonService, param2:Object):void
         {
            var _loc3_:Sprite = _resSprite["petDragonBar_0"];
            leftPetDrgonBar = new PetDragonSeqBar(_loc3_,0,_dispatcher);
            var _loc4_:Sprite = _resSprite["petDragonBar_1"];
            rightPetDragonBar = new PetDragonSeqBar(_loc4_,1,_dispatcher);
            leftPetDrgonBar.setInfo(_battleInfo.teamInfos[0].playerInfos[0].fightPetDragonInfos);
            rightPetDragonBar.setInfo(_battleInfo.teamInfos[1].playerInfos[0].fightPetDragonInfos);
         });
      }
      
      override protected function initComponent() : void
      {
         super.initComponent();
      }
   }
}

