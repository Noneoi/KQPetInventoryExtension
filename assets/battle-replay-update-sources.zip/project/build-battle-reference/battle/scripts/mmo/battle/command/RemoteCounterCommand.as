package mmo.battle.command
{
   import mmo.battle.command.attack.common.AfterSequentialAttackCommand;
   import mmo.battle.command.attack.common.BeforeSequentialAttackCommand;
   import mmo.battle.command.attack.common.PlayEffectCommand;
   import mmo.battle.command.attack.remote.PlayRemoteActionCommand;
   import mmo.battle.command.attack.remote.RecoverActionCommand;
   import mmo.interfaces.battle.command.IBattleCommand;
   
   public class RemoteCounterCommand extends BattleCommand implements IBattleCommand
   {
      
      public function RemoteCounterCommand()
      {
         super();
      }
      
      override protected function initializeMacroCommand() : void
      {
         addSubCommand(BeforeSequentialAttackCommand);
         addParallelSubCommand([PlayRemoteActionCommand,PlayEffectCommand]);
         addSubCommand(RecoverActionCommand);
         addSubCommand(AfterSequentialAttackCommand);
         super.initializeMacroCommand();
      }
   }
}

