package mmo.battle.command.playbattle
{
   import mmo.battle.util.BattleContentUtil;
   import mmo.loader.CustomLoader;
   import mmo.util.command.ISceneCommand;
   import mmo.util.command.SceneSimpleCommand;
   
   public class CloseLoaderCommand extends SceneSimpleCommand implements ISceneCommand
   {
      
      public function CloseLoaderCommand()
      {
         super();
      }
      
      override public function execute(param1:Object) : void
      {
         var _loc2_:CustomLoader = BattleContentUtil.getContentProperty(param1,BattleContentUtil.PN_LOADER);
         _loc2_.close();
         this.succeed(param1);
      }
   }
}

