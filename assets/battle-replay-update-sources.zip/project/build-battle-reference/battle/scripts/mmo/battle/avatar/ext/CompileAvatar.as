package mmo.battle.avatar.ext
{
   public class CompileAvatar
   {
      
      public function CompileAvatar()
      {
         super();
      }
      
      public static function compileMe() : void
      {
         var _loc1_:BattleAvatar312 = null;
         var _loc2_:BattleAvatar316 = null;
         var _loc3_:BattleAvatar70522 = null;
         var _loc4_:BattleAvatar70523 = null;
         var _loc5_:BattleAvatar70524 = null;
         var _loc6_:BattleAvatar70525 = null;
         var _loc7_:BattleAvatar70515 = null;
         var _loc8_:BattleAvatar70735 = null;
      }
   }
}

