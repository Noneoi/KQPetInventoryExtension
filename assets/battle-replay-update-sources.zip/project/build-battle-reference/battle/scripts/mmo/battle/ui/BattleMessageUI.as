package mmo.battle.ui
{
   import fl.controls.TextArea;
   import flash.display.DisplayObjectContainer;
   import flash.display.Sprite;
   import flash.events.MouseEvent;
   import flash.system.ApplicationDomain;
   import flash.text.TextField;
   import mmo.interfaces.IDispose;
   import mmo.region.Translator;
   
   public class BattleMessageUI implements IDispose
   {
      
      public static var battleInfoStr:String;
      
      private var _container:DisplayObjectContainer;
      
      private var _txtArea:TextArea;
      
      private var _backboard:Sprite;
      
      public function BattleMessageUI(param1:TextField, param2:Sprite, param3:ApplicationDomain)
      {
         super();
         this._container = param1.parent;
         this._container.removeChild(param1);
         this._backboard = param2;
         this._backboard.mouseChildren = this._backboard.mouseEnabled = false;
         this._txtArea = new TextArea();
         this._txtArea.textField.background = true;
         this._txtArea.textField.backgroundColor = 2955031;
         this._txtArea.textField.mouseEnabled = false;
         this._txtArea.editable = false;
         this._txtArea.textField.tabEnabled = false;
         this._txtArea.textField.focusRect = null;
         this._txtArea.setStyle("downArrowDownSkin",param3.getDefinition("BattleMessage_ScrollArrowDown_downSkin"));
         this._txtArea.setStyle("downArrowOverSkin",param3.getDefinition("BattleMessage_ScrollArrowDown_overSkin"));
         this._txtArea.setStyle("downArrowUpSkin",param3.getDefinition("BattleMessage_ScrollArrowDown_upSkin"));
         this._txtArea.setStyle("downArrowDisabledSkin",param3.getDefinition("BattleMessage_ScrollArrowDown_upSkin"));
         this._txtArea.setStyle("upSkin",Sprite);
         this._txtArea.setStyle("upArrowDownSkin",param3.getDefinition("BattleMessage_ScrollArrowUp_downSkin"));
         this._txtArea.setStyle("upArrowOverSkin",param3.getDefinition("BattleMessage_ScrollArrowUp_overSkin"));
         this._txtArea.setStyle("upArrowUpSkin",param3.getDefinition("BattleMessage_ScrollArrowUp_upSkin"));
         this._txtArea.setStyle("upArrowDisabledSkin",param3.getDefinition("BattleMessage_ScrollArrowUp_upSkin"));
         this._txtArea.setStyle("thumbDownSkin",param3.getDefinition("BattleMessage_ScrollThumb_downSkin"));
         this._txtArea.setStyle("thumbOverSkin",param3.getDefinition("BattleMessage_ScrollThumb_upSkin"));
         this._txtArea.setStyle("thumbUpSkin",param3.getDefinition("BattleMessage_ScrollThumb_upSkin"));
         this._txtArea.setStyle("thumbDisableSkin",param3.getDefinition("BattleMessage_ScrollThumb_upSkin"));
         this._txtArea.setStyle("trackDownSkin",param3.getDefinition("BattleMessage_cb_ScrollTrack_skin"));
         this._txtArea.setStyle("trackOverSkin",param3.getDefinition("BattleMessage_cb_ScrollTrack_skin"));
         this._txtArea.setStyle("trackUpSkin",param3.getDefinition("BattleMessage_cb_ScrollTrack_skin"));
         this._txtArea.setStyle("trackDisabledSkin",param3.getDefinition("BattleMessage_cb_ScrollTrack_skin"));
         this._txtArea.width = param1.width;
         this._txtArea.height = param1.height;
         this._txtArea.x = param1.x;
         this._txtArea.y = param1.y;
         this._container.addChild(this._txtArea);
         battleInfoStr = "";
         this.println("战斗进行中......");
         this._backboard.alpha = 0.1;
         this._txtArea.alpha = 0.5;
         this.initListener();
      }
      
      public function println(param1:String) : void
      {
         this._txtArea.htmlText += "<font color=\'#FFFFFF\' size=\'12\' bold=\'true\'>" + Translator.translate(param1) + "</font>\n";
         this._txtArea.verticalScrollPosition = this._txtArea.maxVerticalScrollPosition;
         battleInfoStr = this._txtArea.htmlText;
      }
      
      public function dispose() : void
      {
         this.removeListener();
      }
      
      private function initListener() : void
      {
         this._txtArea.addEventListener(MouseEvent.ROLL_OVER,this.onMouseRollOver);
         this._txtArea.addEventListener(MouseEvent.ROLL_OUT,this.onMouseRollOut);
      }
      
      private function removeListener() : void
      {
         this._txtArea.removeEventListener(MouseEvent.ROLL_OVER,this.onMouseRollOver);
         this._txtArea.removeEventListener(MouseEvent.ROLL_OUT,this.onMouseRollOut);
      }
      
      private function onMouseRollOver(param1:MouseEvent) : void
      {
         this._backboard.alpha = 1;
         this._txtArea.alpha = 1;
      }
      
      private function onMouseRollOut(param1:MouseEvent) : void
      {
         this._backboard.alpha = 0.1;
         this._txtArea.alpha = 0.5;
      }
   }
}

import flash.display.Bitmap;
import flash.display.BitmapData;
import flash.display.Sprite;
import flash.display.Stage;
import flash.events.Event;
import flash.events.MouseEvent;
import flash.system.ApplicationDomain;
import flash.text.TextField;
import flash.text.TextFieldAutoSize;
import flash.utils.clearTimeout;
import flash.utils.setTimeout;
import mmo.common.EventBinder;
import mmo.common.InstanceUtil;

class MyTextArea extends Sprite
{
   
   private static const SCROLL_WIDTH:Number = 15;
   
   private var _container:Sprite;
   
   private var _widthF:Number;
   
   private var _heightF:Number;
   
   private var _offset:Number = 0;
   
   private var _totalHeight:Number = 0;
   
   private var _textFieldsNow:Vector.<TextField>;
   
   private var _textFieldsPool:Vector.<TextField>;
   
   private var _strList:Vector.<String>;
   
   private var _strHeightList:Vector.<Number>;
   
   private var _thumb:Sprite;
   
   private var _thumbU:Sprite;
   
   private var _thumbD:Sprite;
   
   private var _thumbIcon:Sprite;
   
   private var _thumbTrackHeight:Number;
   
   private var _thumbBeginHeight:Number;
   
   private var _thumbBeginY:Number;
   
   private var _downY:Number = NaN;
   
   private var _downOffset:Number = 0;
   
   public function MyTextArea(param1:Number, param2:Number, param3:ApplicationDomain)
   {
      var maskBitmapData:BitmapData;
      var maskBitmap:Bitmap;
      var btnUp:Sprite;
      var btnDown:Sprite;
      var track:Sprite;
      var width:Number = param1;
      var height:Number = param2;
      var domain:ApplicationDomain = param3;
      this._container = new Sprite();
      this._textFieldsNow = new Vector.<TextField>();
      this._textFieldsPool = new Vector.<TextField>();
      this._strList = new Vector.<String>();
      this._strHeightList = new Vector.<Number>();
      super();
      this._widthF = width;
      this._heightF = height;
      this.addChild(this._container);
      maskBitmapData = new BitmapData(width,height,false,1118481);
      maskBitmap = new Bitmap(maskBitmapData);
      this._container.addChild(maskBitmap);
      this._container.mask = maskBitmap;
      btnUp = this.createButton(domain,function(param1:int):*
      {
         setOffset(_offset + (10 + param1 * 2));
      },"BattleMessage_ScrollArrowUp_upSkin","BattleMessage_ScrollArrowUp_downSkin");
      btnDown = this.createButton(domain,function(param1:int):*
      {
         setOffset(_offset - (10 + param1 * 2));
      },"BattleMessage_ScrollArrowDown_upSkin","BattleMessage_ScrollArrowDown_downSkin");
      btnUp.width = SCROLL_WIDTH;
      btnUp.x = width - SCROLL_WIDTH;
      btnDown.width = SCROLL_WIDTH;
      btnDown.x = width - SCROLL_WIDTH;
      btnDown.y = height - btnDown.height;
      addChild(btnUp);
      addChild(btnDown);
      track = InstanceUtil.getInstance("BattleMessage_cb_ScrollTrack_skin",domain);
      track.width = SCROLL_WIDTH;
      track.height = height - btnUp.height - btnDown.height;
      track.x = width - SCROLL_WIDTH;
      track.y = btnUp.height;
      addChild(track);
      this._thumbU = InstanceUtil.getInstance("BattleMessage_ScrollThumb_upSkin",domain);
      this._thumbU.width = SCROLL_WIDTH;
      this._thumbD = InstanceUtil.getInstance("BattleMessage_ScrollThumb_downSkin",domain);
      this._thumbD.width = SCROLL_WIDTH;
      this._thumbD.visible = false;
      this._thumb = new Sprite();
      this._thumb.mouseChildren = false;
      this._thumb.buttonMode = false;
      this._thumb.addEventListener(MouseEvent.MOUSE_DOWN,function(param1:MouseEvent):*
      {
         _thumbU.visible = false;
         _thumbD.visible = true;
      });
      this._thumb.addEventListener(MouseEvent.MOUSE_UP,function(param1:MouseEvent):*
      {
         _thumbU.visible = true;
         _thumbD.visible = false;
      });
      this._thumb.addEventListener(Event.ADDED_TO_STAGE,function(param1:Event):*
      {
         var binder:EventBinder = null;
         var evt:Event = param1;
         var stage:Stage = _thumb.stage;
         binder = new EventBinder();
         _thumb.addEventListener(Event.REMOVED_FROM_STAGE,function(param1:Event):*
         {
            binder.unBindAll();
         });
         binder.bind(stage,MouseEvent.MOUSE_MOVE,function(param1:MouseEvent):*
         {
            if(isNaN(_downY))
            {
               return;
            }
            setOffset(_downOffset + (_downY - param1.stageY) / getThumbFactor());
         });
         binder.bind(stage,MouseEvent.MOUSE_DOWN,function(param1:MouseEvent):*
         {
            _downY = param1.stageY;
            _downOffset = _offset;
         });
         binder.bind(stage,MouseEvent.MOUSE_UP,function(param1:MouseEvent):*
         {
            _downY = Number.NaN;
         });
      });
      this._thumbIcon = InstanceUtil.getInstance("ScrollBar_thumbIcon",domain);
      this._thumbIcon.mouseEnabled = false;
      this._thumbIcon.x = (this._thumbU.width - this._thumbIcon.width) / 2;
      this._thumb.addChild(this._thumbU);
      this._thumb.addChild(this._thumbD);
      this._thumb.addChild(this._thumbIcon);
      this._thumb.x = width - SCROLL_WIDTH;
      addChild(this._thumb);
      this._thumbTrackHeight = track.height;
      this._thumbBeginHeight = this._thumbU.height;
      this._thumbBeginY = btnUp.height;
   }
   
   public function addHtmlStr(param1:String) : void
   {
      this._strList.push(param1);
      var _loc2_:TextField = this.getTextField();
      _loc2_.htmlText = param1;
      this._strHeightList.push(_loc2_.height);
      this._totalHeight += _loc2_.height;
      this.recycleTextField(_loc2_);
      if(isNaN(this._downY))
      {
         this.setOffset(this._heightF - this._totalHeight);
      }
   }
   
   private function setOffset(param1:Number) : void
   {
      var _loc4_:int = 0;
      var _loc5_:TextField = null;
      if(param1 < this._heightF - this._totalHeight)
      {
         param1 = this._heightF - this._totalHeight;
      }
      else if(param1 > 0)
      {
         param1 = 0;
      }
      var _loc2_:int = 0;
      var _loc3_:Number = 0;
      _loc4_ = 0;
      while(_loc4_ < this._strHeightList.length)
      {
         if(param1 + _loc3_ + this._strHeightList[_loc4_] >= 0)
         {
            _loc2_ = _loc4_;
            break;
         }
         _loc3_ += this._strHeightList[_loc4_];
         _loc4_++;
      }
      _loc4_ = 0;
      while(param1 + _loc3_ < this._heightF && _loc2_ + _loc4_ < this._strHeightList.length)
      {
         if(_loc4_ < this._textFieldsNow.length)
         {
            _loc5_ = this._textFieldsNow[_loc4_];
         }
         else
         {
            this._textFieldsNow.push(_loc5_ = this.getTextField());
            this._container.addChild(_loc5_);
         }
         _loc5_.htmlText = this._strList[_loc2_ + _loc4_];
         _loc5_.y = param1 + _loc3_;
         _loc3_ += this._strHeightList[_loc2_ + _loc4_];
         _loc4_++;
      }
      while(this._textFieldsNow.length > 0 && this._textFieldsNow.length - 1 >= _loc4_)
      {
         _loc5_ = this._textFieldsNow.pop();
         _loc5_.parent.removeChild(_loc5_);
         this.recycleTextField(_loc5_);
      }
      this._offset = param1;
      var _loc6_:Number = this._thumbTrackHeight * (this._heightF / this._totalHeight) / this._thumbBeginHeight;
      if(_loc6_ < 1)
      {
         _loc6_ = 1;
      }
      this._thumbU.scaleY = _loc6_;
      this._thumbD.scaleY = _loc6_;
      this._thumbIcon.y = (this._thumb.height - this._thumbIcon.height) / 2;
      this._thumb.y = this._thumbBeginY - param1 * this.getThumbFactor();
   }
   
   private function getThumbFactor() : Number
   {
      return (this._thumbTrackHeight - this._thumb.height) / (this._totalHeight - this._heightF);
   }
   
   private function getTextField() : TextField
   {
      if(this._textFieldsPool.length > 0)
      {
         return this._textFieldsPool.shift();
      }
      var _loc1_:TextField = new TextField();
      _loc1_.mouseEnabled = false;
      _loc1_.mouseWheelEnabled = false;
      _loc1_.width = this._widthF - SCROLL_WIDTH;
      _loc1_.multiline = true;
      _loc1_.wordWrap = true;
      _loc1_.autoSize = TextFieldAutoSize.LEFT;
      return _loc1_;
   }
   
   private function recycleTextField(param1:TextField) : void
   {
      this._textFieldsPool.push(param1);
   }
   
   private function createButton(param1:ApplicationDomain, param2:Function, param3:String, param4:String) : Sprite
   {
      var upSp:Sprite = null;
      var downSp:Sprite = null;
      var ctrlState:Object = null;
      var domain:ApplicationDomain = param1;
      var clickCallback:Function = param2;
      var upCls:String = param3;
      var downCls:String = param4;
      var callClickCallback:Function = function():void
      {
         clickCallback(ctrlState["tickTimes"]);
         ctrlState["uid"] = setTimeout(function():*
         {
            if(ctrlState["uidEffective"])
            {
               ctrlState["uidEffective"] = false;
               clearTimeout(ctrlState["uid"]);
               callClickCallback();
            }
         },100);
         ctrlState["uidEffective"] = true;
         ctrlState["tickTimes"] += 1;
      };
      var buttonSp:Sprite = new Sprite();
      upSp = InstanceUtil.getInstance(upCls,domain);
      downSp = InstanceUtil.getInstance(downCls,domain);
      ctrlState = {
         "tickTimes":0,
         "uid":0,
         "uidEffective":false
      };
      buttonSp.addChild(upSp);
      buttonSp.addChild(downSp);
      buttonSp.mouseChildren = false;
      buttonSp.buttonMode = true;
      buttonSp.addEventListener(MouseEvent.MOUSE_DOWN,function(param1:MouseEvent):*
      {
         upSp.visible = false;
         downSp.visible = true;
         callClickCallback();
      });
      buttonSp.addEventListener(MouseEvent.MOUSE_UP,function(param1:MouseEvent):*
      {
         upSp.visible = true;
         downSp.visible = false;
         if(ctrlState["uidEffective"])
         {
            ctrlState["uidEffective"] = false;
            clearTimeout(ctrlState["uid"]);
         }
         ctrlState["tickTimes"] = 0;
      });
      return buttonSp;
   }
}
