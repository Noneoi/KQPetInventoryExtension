package mmo.battle.util
{
   import mmo.battle.entity.BattleSimpleResManager;
   import mmo.common.DateUtil;
   import mmo.common.shareobject.LocalStore;
   import mmo.common.user.UserInfo;
   import mmo.interfaces.battle.consts.UserBattleConfig;
   
   public class BattleContentUtil
   {
      
      public static const PN_EVENT_DISPATCHER:String = "EventDispatcher";
      
      public static const PN_BATTLE_CONFIG:String = "Config";
      
      public static const PN_BATTLE_INFO:String = "BattleInfo";
      
      public static const PN_BATTLE_TYPE:String = "BattleType";
      
      public static const PN_IS_MULTIPLAYER:String = "isMulti";
      
      public static const PN_DOWNLOAD_LIST:String = "DownloadList";
      
      public static const PN_ORG_MUSIC:String = "OrgMusic";
      
      public static const PN_BATTLE:String = "Battle";
      
      public static const PN_UI:String = "UI";
      
      public static const PN_MISS_NUM_UI:String = "MissNumUI";
      
      public static const PN_BLOCK_NUM_UI:String = "BlockNumUI";
      
      public static const PN_CRITICAL_NUM_UI:String = "CriticalNumUI";
      
      public static const PN_CONTAINER:String = "Container";
      
      public static const PN_DOMAIN:String = "Domain";
      
      public static const PN_LOADER:String = "Loader";
      
      public static const PN_LOCATOR:String = "Locator";
      
      public static const PN_WINNER_TEAM_ID:String = "WinerTeamId";
      
      public static const PN_ERROR_MSG:String = "ErrMessage";
      
      public static const PN_BATTLE_FLOW:String = "BattleFlow";
      
      public static const PN_ITEM_RESULT:String = "ItemResult";
      
      public static const PN_CATCH_RESULT:String = "CatchResult";
      
      public static const PN_NPC_BLESS_RESULT:String = "NpcBlessResult";
      
      public static const PN_BUFFER_NEEDED:String = "BufferNeeded";
      
      public static const PN_DROP_ITEM_DATA:String = "DropItemDatas";
      
      public static const PN_EXTRA_BONUS_DATA:String = "ExtraBonusDatas";
      
      public static const PN_EXTRA_EXP_RESULT:String = "ExtraExpResult";
      
      public static const PN_GAIN_EXP_RESULT:String = "GainExpResult";
      
      public static const PN_IS_CUR_USER_WINNER:String = "isCurUserWiner";
      
      public static const PN_BATTLE_SEQ:String = "BattleSeq";
      
      public static const PN_BATTLES:String = "Battles";
      
      public static const PN_NODE_RACE_ID:String = "NodeRaceIds";
      
      public static const PN_ROUND_RESULT:String = "RoundResult";
      
      public static const PN_SKILLDEFINE:String = "SkillDefine";
      
      public static const PN_SOURCE_PLAYER:String = "SourcePlayer";
      
      public static const PN_SOURCE_FIGHTER:String = "SourceFighter";
      
      public static const PN_TIME_LINE:String = "Timeline";
      
      public static const PN_TARGETACTION_BACKGROUND_ARRAY:String = "TargetActionBackgroundArray";
      
      public static const PN_ACTION_FULLSCREEN_BACKGROUD:String = "ActionFullscreenBackgroud";
      
      public static const PN_ACTION_FULLSCREEN_FOREGROUD:String = "ActionFullscreenForegroud";
      
      public static const PN_JUMP_FRAME:String = "JumpFrame";
      
      public static const PN_EFFECT_FRAME:String = "EffectFrame";
      
      public static const PN_FIGHTER_ORG_X:String = "OrginalX";
      
      public static const PN_FIGHTER_ORG_Y:String = "OrginalY";
      
      public static const PN_HIDE_FIGHTERS:String = "hidefighters";
      
      public static const PN_TEAM_BATTLES:String = "TeamBattles";
      
      public static const PN_GAIN_COOLPETSTONE_DATA:String = "GainCoolPetStoneData";
      
      public static const PN_SOURCE_REPRESENTER:String = "SourceRepresenter";
      
      public static const PN_PET_DRAGON_SERVICE:String = "PetDragonService";
      
      public static const PN_PLAYER_AVATAR_L:String = "PlayerAvatarL";
      
      public static const PN_PLAYER_AVATAR_R:String = "PlayerAvatarR";
      
      public static const PN_LOADING_STYLE:String = "LoadingStyle";
      
      public static const PN_ART_NUM_CACHE_MAP:String = "ArtNumCacheMap";
      
      public static const BACKGROUND:String = "Background";
      
      public static const FlashToH5_DATA:String = "FlashToH5Data";
      
      public static const SIMPLE_RES_DATA:String = "SIMPLE_RES_DATA";
      
      public static const PN_BATTLE_ROUND_UI:String = "BattleRoundUI";
      
      public static const PN_REGULAR_BITMAP_DATA:String = "RegularBitmapData";
      
      public static const PN_RACE_ID_2_BITMAP_DATA_MAP:String = "RACE_ID_2_BITMAP_DATA_MAP";
      
      private static const VIP_BATTLE_FRAME_KEY:String = "vip_battle_frame_key";
      
      private static const SIMPLE_BATTLE_RES_KEY:String = "simple_battle_res_key";
      
      private static const SIMPLE_BATTLE_RES_START_TIME:String = "20210319";
      
      private static var _isForceSimpleBattleRes:int = -1;
      
      public function BattleContentUtil()
      {
         super();
      }
      
      public static function getContentProperty(param1:Object, param2:String) : *
      {
         return param1[param2];
      }
      
      public static function setContentProperty(param1:Object, param2:String, param3:*) : void
      {
         param1[param2] = param3;
      }
      
      public static function getIsInVipBattleFrame() : Boolean
      {
         var _loc1_:* = LocalStore.getValue(VIP_BATTLE_FRAME_KEY,UserInfo.userName);
         return _loc1_ != null;
      }
      
      public static function setVipBattleFrame(param1:Object) : void
      {
         LocalStore.setValue(VIP_BATTLE_FRAME_KEY,param1,UserInfo.userName);
      }
      
      public static function getIsSimpleBattleOpen() : Boolean
      {
         return DateUtil.getServerTimeInMS() > DateUtil.parseDate(SIMPLE_BATTLE_RES_START_TIME).getTime();
      }
      
      public static function setForceSimpleBattleResValue(param1:int) : void
      {
         _isForceSimpleBattleRes = param1;
      }
      
      public static function isForceSimpleBattleResFlagEffective() : Boolean
      {
         return _isForceSimpleBattleRes != -1;
      }
      
      public static function getIsSimpleBattleResType(param1:Boolean = false) : int
      {
         if(!param1 && _isForceSimpleBattleRes != -1)
         {
            return _isForceSimpleBattleRes;
         }
         var _loc2_:* = LocalStore.getValue(SIMPLE_BATTLE_RES_KEY,UserInfo.userName);
         if(_loc2_ != null)
         {
            return parseInt(_loc2_.toString());
         }
         return BattleSimpleResManager.NO_SIMPLE;
      }
      
      public static function setSimpleBattleRes(param1:Object) : void
      {
         if(getIsSimpleBattleOpen())
         {
            LocalStore.setValue(SIMPLE_BATTLE_RES_KEY,param1,UserInfo.userName);
         }
      }
      
      public static function setBuffShowValueByKey(param1:Object, param2:String) : void
      {
         LocalStore.setValue(param2,param1,UserInfo.userName);
      }
      
      public static function getBuffShowValueByKey(param1:String) : Boolean
      {
         var _loc2_:* = LocalStore.getValue(param1,UserInfo.userName);
         if(_loc2_ == null || _loc2_ === true)
         {
            return true;
         }
         return false;
      }
      
      public static function checkIsBuffSkip(param1:String) : Boolean
      {
         if(param1.indexOf(UserBattleConfig.BUFF_RES_CTRL_PSY_DESC) > -1 && !BattleContentUtil.getBuffShowValueByKey(UserBattleConfig.SHOW_BUFF_BATTLE_RES_PSY))
         {
            return true;
         }
         if(param1.indexOf(UserBattleConfig.BUFF_RES_CTRL_HERO_DESC) > -1 && !BattleContentUtil.getBuffShowValueByKey(UserBattleConfig.SHOW_BUFF_BATTLE_RES_HERO))
         {
            return true;
         }
         if(param1.indexOf(UserBattleConfig.BUFF_RES_CTRL_OTHER_DESC) > -1 && !BattleContentUtil.getBuffShowValueByKey(UserBattleConfig.SHOW_BUFF_BATTLE_RES_OTHER))
         {
            return true;
         }
         return false;
      }
      
      public static function tracePreDownloadList(param1:Object) : void
      {
         var _loc2_:Array = getPreDownloadList(param1);
         var _loc3_:int = 0;
         while(_loc3_ < _loc2_.length)
         {
            _loc3_++;
         }
      }
      
      public static function getPreDownloadList(param1:Object) : Array
      {
         var _loc2_:Array = getContentProperty(param1,BattleContentUtil.PN_DOWNLOAD_LIST);
         if(_loc2_ == null)
         {
            _loc2_ = [];
            BattleContentUtil.setContentProperty(param1,BattleContentUtil.PN_DOWNLOAD_LIST,_loc2_);
         }
         return _loc2_;
      }
      
      public static function addToPreDownloadList(param1:Object, param2:Array) : void
      {
         var _loc3_:Array = getPreDownloadList(param1);
         _loc3_ = BattleUtil.mergeArray(_loc3_,param2);
         BattleContentUtil.setContentProperty(param1,BattleContentUtil.PN_DOWNLOAD_LIST,_loc3_);
      }
   }
}

