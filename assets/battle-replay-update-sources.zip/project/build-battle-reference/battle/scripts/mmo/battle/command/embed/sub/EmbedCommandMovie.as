package mmo.battle.command.embed.sub
{
   import flash.display.MovieClip;
   import mmo.common.DisplayUtil;
   import mmo.interfaces.battleconfig.define.EmbedEffectDefine;
   import mmo.loader.LoaderContainer;
   
   public class EmbedCommandMovie extends EmbedCommandBase
   {
      
      public function EmbedCommandMovie(param1:EmbedEffectDefine)
      {
         super(param1);
      }
      
      override protected function applyEmbedEffect() : void
      {
         var movie:MovieClip = null;
         var cls:Class = this._domain.getDefinition(this._embedEffectDefine.params) as Class;
         movie = new cls() as MovieClip;
         if(this._roundResult.sourceTeamId == 1)
         {
            movie.scaleX = -1;
            movie.x = LoaderContainer.stageWidth - movie.x;
         }
         movie.addFrameScript(movie.totalFrames - 1,function():void
         {
            DisplayUtil.stopAndRemove(movie);
            --_repeatCount;
            succeed(_content);
         });
         this._container.movieLayerAbove.addChild(movie);
         movie.gotoAndPlay(1);
      }
   }
}

