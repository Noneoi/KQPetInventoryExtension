package mmo.battle.client
{
   import mmo.framework.comm.SocketClient;
   
   public class BattleClient
   {
      
      private static var _instance:BattleClient;
      
      private static const EXTENSION_NAME:String = "PJXExtension";
      
      public static const cmdFightWildMonster:String = "2_3_0";
      
      public static const cmdFightTaskMonster:String = "2_3_2";
      
      public static const cmdHomesteadChallenge:String = "2_3_3";
      
      public static const cmdFightMirroPlayer:String = "2_3_5";
      
      public static const CMD_FIGHT_SOMEONE:String = "2_3_1";
      
      public static const CMD_CUSTOM_FIGHT:String = "2_3_99";
      
      public static const CMD_PICK_NOTIFICATION:String = "2_1_13";
      
      private static const EXTENSION_NAME2:String = "UserDisplayExtension";
      
      public static const CMD_INVITE_PVP:String = "17_3";
      
      public static const CMD_CANCEL_PVP:String = "17_4";
      
      public static const CMD_ACCEPT_PVP:String = "17_5";
      
      public static const CMD_REFUSE_PVP:String = "17_6";
      
      public static const RSPN_PVP_RESULT:String = "17_7";
      
      public function BattleClient()
      {
         super();
      }
      
      public static function get instance() : BattleClient
      {
         if(_instance == null)
         {
            _instance = new BattleClient();
         }
         return _instance;
      }
      
      public function fightWildMonster(param1:int, param2:int) : void
      {
         this.sendXtMessage(cmdFightWildMonster,{
            "sid":param1,
            "cmid":param2
         });
      }
      
      public function fightTaskMonster(param1:int, param2:String, param3:int) : void
      {
         this.sendXtMessage(cmdFightTaskMonster,{
            "tmid":param1,
            "fp":param2,
            "t":param3
         });
      }
      
      public function homesteadChallenge(param1:int, param2:String) : void
      {
         this.sendXtMessage(cmdHomesteadChallenge,{
            "t":param1,
            "tn":param2
         });
      }
      
      public function fightMirroPlayer(param1:String, param2:int) : void
      {
         this.sendXtMessage(cmdFightMirroPlayer,{
            "fp":param1,
            "t":param2
         });
      }
      
      public function fightSomeOne(param1:int, param2:String) : void
      {
         this.sendXtMessage(CMD_FIGHT_SOMEONE,{
            "t":param1,
            "tn":param2
         });
      }
      
      public function customFight(param1:Object, param2:Object) : void
      {
         this.sendXtMessage(CMD_CUSTOM_FIGHT,{
            "ta":param1,
            "tb":param2
         });
      }
      
      public function notifyCatchRusult(param1:Number, param2:Array) : void
      {
         if(param2 == null || param2.length == 0)
         {
            this.sendXtMessage(CMD_PICK_NOTIFICATION,{"bid":param1});
         }
         else
         {
            this.sendXtMessage(CMD_PICK_NOTIFICATION,{
               "c":param2.join(","),
               "bid":param1
            });
         }
      }
      
      public function invitePvp(param1:String) : void
      {
         this.sendXtMessage2(CMD_INVITE_PVP,{"tun":param1});
      }
      
      public function cacenlPvpInvite(param1:String) : void
      {
         this.sendXtMessage2(CMD_CANCEL_PVP,{"tun":param1});
      }
      
      public function acceptPvpInvite(param1:String) : void
      {
         this.sendXtMessage2(CMD_ACCEPT_PVP,{"run":param1});
      }
      
      public function refusePvpInvite(param1:String) : void
      {
         this.sendXtMessage2(CMD_REFUSE_PVP,{"run":param1});
      }
      
      private function sendXtMessage(param1:String, param2:Object) : void
      {
         SocketClient.instance.sendXtMessage(EXTENSION_NAME,param1,param2);
      }
      
      private function sendXtMessage2(param1:String, param2:Object) : void
      {
         SocketClient.instance.sendXtMessage(EXTENSION_NAME2,param1,param2);
      }
   }
}

