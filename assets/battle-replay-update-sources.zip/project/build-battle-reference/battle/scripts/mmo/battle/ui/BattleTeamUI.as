package mmo.battle.ui
{
   import flash.display.SimpleButton;
   import flash.display.Sprite;
   import flash.events.IEventDispatcher;
   import flash.system.ApplicationDomain;
   import flash.text.TextField;
   import mmo.battle.entity.BattleBase;
   import mmo.interfaces.ServiceContainer;
   import mmo.interfaces.battle.data.BattleInfo;
   import mmo.interfaces.battle.data.NpcBlessResult;
   import mmo.interfaces.battle.data.PlayerInfo;
   import mmo.interfaces.battle.data.TeamInfo;
   import mmo.interfaces.chat.IChatService;
   import mmo.play.scene.SceneManager;
   
   public class BattleTeamUI extends BattleUI
   {
      
      private var _battles:Array = [];
      
      private var _playerTeamUI0:BattlePlayerTeamUI;
      
      private var _playerTeamUI1:BattlePlayerTeamUI;
      
      private var _chatPanel:Sprite;
      
      public function BattleTeamUI(param1:Sprite, param2:ApplicationDomain, param3:IEventDispatcher, param4:Array)
      {
         this._battles = param4;
         super(param1,param2,param3);
      }
      
      override public function setInfo(param1:BattleInfo, param2:NpcBlessResult, param3:BattleBase) : void
      {
         this.setCommonInfo(param1,param2);
         var _loc4_:TeamInfo = this._battleInfo.teamInfos[0] as TeamInfo;
         var _loc5_:TeamInfo = this._battleInfo.teamInfos[1] as TeamInfo;
         var _loc6_:PlayerInfo = _loc4_.playerInfos[0] as PlayerInfo;
         var _loc7_:PlayerInfo = _loc5_.playerInfos[0] as PlayerInfo;
         var _loc8_:String = this._battles[0].battleResult.teamLeaderNickName;
         var _loc9_:String = BattlePlayerUI.UI_TYPE_OTHER;
         var _loc10_:String = BattlePlayerUI.UI_TYPE_OTHER;
         var _loc11_:Boolean = false;
         if(_loc6_.playerName == _loc8_)
         {
            _loc9_ = BattlePlayerUI.UI_TYPE_SELF;
         }
         else if(_loc7_.playerName == _loc8_)
         {
            _loc10_ = BattlePlayerUI.UI_TYPE_SELF;
         }
         if(_loc6_.playerType == PlayerInfo.PLAYER_TYPE_TEAM && _loc7_.playerType == PlayerInfo.PLAYER_TYPE_TEAM && (_loc6_.playerName == _loc8_ || _loc7_.playerName == _loc8_))
         {
            _loc11_ = true;
         }
         this._playerTeamUI0.setPlayerInfo(_loc6_,this._npcBlessResult,_loc9_,_loc11_);
         this._playerTeamUI1.setPlayerInfo(_loc7_,this._npcBlessResult,_loc10_,_loc11_);
         this._txtSceneName.text = SceneManager.getInstance().loadedSceneInfo.sceneDesc;
      }
      
      override protected function initComponent() : void
      {
         this._txtSceneName = this._resSprite.getChildByName("place") as TextField;
         this._btnSkipBattleFlow = this._resSprite.getChildByName("skip") as SimpleButton;
         var _loc1_:Sprite = this._resSprite.getChildByName("pui0") as Sprite;
         this._playerTeamUI0 = new BattlePlayerTeamUI(_loc1_,this._battles);
         var _loc2_:Sprite = this._resSprite.getChildByName("pui1") as Sprite;
         this._playerTeamUI1 = new BattlePlayerTeamUI(_loc2_,this._battles);
         var _loc3_:TextField = this._resSprite.getChildByName("battlemess") as TextField;
         var _loc4_:Sprite = this._resSprite.getChildByName("back") as Sprite;
         this._messUI = new BattleMessageUI(_loc3_,_loc4_,this._domain);
         this.initChatPanel();
      }
      
      private function initChatPanel() : void
      {
         var _loc1_:IChatService = ServiceContainer.getService(IChatService);
         this._chatPanel = _loc1_.getChatPanel();
         this._chatPanel.x = 0;
         this._chatPanel.y = 560;
         this._resSprite.addChild(this._chatPanel);
      }
      
      override public function dispose() : void
      {
         super.dispose();
         if(this._chatPanel.parent != null)
         {
            this._resSprite.removeChild(this._chatPanel);
         }
      }
   }
}

