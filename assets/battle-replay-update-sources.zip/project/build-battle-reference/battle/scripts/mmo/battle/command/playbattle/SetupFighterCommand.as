package mmo.battle.command.playbattle
{
   import flash.display.Sprite;
   import flash.geom.Point;
   import flash.system.ApplicationDomain;
   import mmo.battle.consts.MutipleScale;
   import mmo.battle.container.BattleContainer;
   import mmo.battle.entity.BattleBase;
   import mmo.battle.fighter.BattleFighter;
   import mmo.battle.fighter.BattleRepresenter;
   import mmo.battle.player.BattlePlayer;
   import mmo.battle.util.BattleContentUtil;
   import mmo.interfaces.ServiceContainer;
   import mmo.interfaces.battle.consts.FormationConsts;
   import mmo.interfaces.battle.data.BattleInfo;
   import mmo.interfaces.battle.data.FighterInfo;
   import mmo.interfaces.battle.data.PlayerInfo;
   import mmo.interfaces.battle.data.TeamInfo;
   import mmo.interfaces.battle.events.BattleEvent;
   import mmo.interfaces.battle.fighter.IBattleFighter;
   import mmo.interfaces.battle.player.IBattlePlayer;
   import mmo.interfaces.pet.data.IPetDictionaryDataService;
   import mmo.interfaces.pet.data.PetDictionaryDataItem;
   import mmo.loader.common.datastructures.HashMap;
   import mmo.util.command.ISceneCommand;
   import mmo.util.command.SceneSimpleCommand;
   
   public class SetupFighterCommand extends SceneSimpleCommand implements ISceneCommand
   {
      
      private static const FIGHTER_TIPS_CLS:String = "mmo.battle.common.FighterTipsRes";
      
      private static const PLAYER_NAME_CLS:String = "mmo.battle.common.PlayerNameRes";
      
      private var _content:Object;
      
      private var _battleInfo:BattleInfo;
      
      private var _domain:ApplicationDomain;
      
      private var _container:BattleContainer;
      
      private var _battle:BattleBase;
      
      private var _bIsMutiple:Boolean;
      
      public function SetupFighterCommand()
      {
         super();
      }
      
      override public function execute(param1:Object) : void
      {
         this._content = param1;
         this._battleInfo = BattleContentUtil.getContentProperty(param1,BattleContentUtil.PN_BATTLE_INFO);
         this._domain = BattleContentUtil.getContentProperty(param1,BattleContentUtil.PN_DOMAIN);
         this._container = BattleContentUtil.getContentProperty(param1,BattleContentUtil.PN_CONTAINER);
         this._battle = BattleContentUtil.getContentProperty(param1,BattleContentUtil.PN_BATTLE);
         this._bIsMutiple = BattleContentUtil.getContentProperty(param1,BattleContentUtil.PN_IS_MULTIPLAYER);
         var _loc2_:Sprite = BattleContentUtil.getContentProperty(param1,BattleContentUtil.PN_LOCATOR);
         BattleContentUtil.setContentProperty(param1,BattleContentUtil.PN_ART_NUM_CACHE_MAP,{});
         this.setupTeam(this._battleInfo.getTeamInfoById(0),_loc2_.getChildByName("t0") as Sprite,false);
         this.setupTeam(this._battleInfo.getTeamInfoById(1),_loc2_.getChildByName("t1") as Sprite,true);
         this._battle.reorderAllPlayer();
         if(this._battle.hasEventListener(BattleEvent.FIGHTERS_SETUP_COMPLETE))
         {
            this._battle.dispatchEvent(new BattleEvent(BattleEvent.FIGHTERS_SETUP_COMPLETE,null));
         }
         this.succeed(param1);
      }
      
      private function setupTeam(param1:TeamInfo, param2:Sprite, param3:Boolean) : void
      {
         var playerInfo:PlayerInfo = null;
         var playerIndex:int = 0;
         var pLocator:Sprite = null;
         var fighterInfos:Array = null;
         var battlePlayer:IBattlePlayer = null;
         var getFighterByInitPXPY:Function = null;
         var fighterInfo:FighterInfo = null;
         var pos:Point = null;
         var battleFighter:IBattleFighter = null;
         var bufferId:int = 0;
         var tipsRes:Sprite = null;
         var sourceRaceId:int = 0;
         var teamInfo:TeamInfo = param1;
         var teamLocator:Sprite = param2;
         var needFlip:Boolean = param3;
         var cid2fighter:HashMap = new HashMap();
         var tipsCls:Class = this._domain.getDefinition(FIGHTER_TIPS_CLS) as Class;
         var playerInfos:Array = teamInfo.playerInfos;
         for each(playerInfo in playerInfos)
         {
            playerIndex = playerInfo.initPosX + playerInfo.initPosY * FormationConsts.MAX_ROW_COUNT;
            pLocator = teamLocator.getChildByName("p" + playerIndex) as Sprite;
            fighterInfos = playerInfo.fighterInfos;
            battlePlayer = new BattlePlayer(playerInfo,this._content,teamLocator);
            this._battle.registerPlayer(battlePlayer);
            getFighterByInitPXPY = function(param1:int, param2:int):int
            {
               var _loc4_:FighterInfo = null;
               var _loc3_:int = 0;
               while(_loc3_ < fighterInfos.length)
               {
                  _loc4_ = fighterInfos[_loc3_];
                  if(!_loc4_.isChaser && _loc4_.initPosX == param1 && _loc4_.initPosY == param2)
                  {
                     return _loc4_.raceId;
                  }
                  _loc3_++;
               }
               return -1;
            };
            for each(fighterInfo in fighterInfos)
            {
               fighterInfo.belong2PlayerIndex = playerIndex;
               pos = this.getFighterPos(fighterInfo,pLocator);
               battleFighter = new BattleFighter(fighterInfo,this._content,needFlip);
               if(fighterInfo.isChaser)
               {
                  sourceRaceId = getFighterByInitPXPY(fighterInfo.initPosX,fighterInfo.initPosY);
                  if(sourceRaceId > 0)
                  {
                     battleFighter.info.transFromRaceId = sourceRaceId;
                  }
               }
               battlePlayer.registerFighter(battleFighter);
               battleFighter.addToStage(this._container.fighterLayer,pos.x,pos.y);
               for each(bufferId in fighterInfo.initBufferIds)
               {
                  battleFighter.addBuff(bufferId);
               }
               tipsRes = new tipsCls() as Sprite;
               battleFighter.showTips(tipsRes);
               if(Boolean(fighterInfo.isSelfReplication) && Boolean(fighterInfo.needShowSelfReplication))
               {
                  battleFighter.avatar.showUp();
               }
            }
            this.setupRepresenter(playerIndex,pLocator,battlePlayer,needFlip);
            if(this._bIsMutiple)
            {
               battlePlayer.scale = MutipleScale.PLAYER_SCALE;
            }
            this._battle.registerPlayer(battlePlayer);
         }
      }
      
      private function getFighterPos(param1:FighterInfo, param2:Sprite) : Point
      {
         var _loc7_:Point = null;
         var _loc8_:Number = NaN;
         var _loc9_:Number = NaN;
         var _loc10_:Sprite = null;
         var _loc11_:int = 0;
         var _loc12_:Point = null;
         var _loc13_:int = 0;
         var _loc3_:int = param1.initPosX + param1.initPosY * FormationConsts.MAX_ROW_COUNT;
         var _loc4_:IPetDictionaryDataService = ServiceContainer.getService(IPetDictionaryDataService);
         var _loc5_:PetDictionaryDataItem = _loc4_.getDataItemByRaceId(param1.raceId);
         var _loc6_:Array = [];
         _loc6_.push(_loc3_);
         for each(_loc7_ in _loc5_.extPosition)
         {
            if(!_loc5_.isLargePet())
            {
               break;
            }
            _loc13_ = _loc3_ + _loc7_.x + _loc7_.y * FormationConsts.MAX_ROW_COUNT;
            _loc6_.push(_loc13_);
         }
         _loc8_ = 0;
         _loc9_ = 0;
         for each(_loc11_ in _loc6_)
         {
            _loc10_ = param2.getChildByName("f" + _loc11_) as Sprite;
            _loc8_ += _loc10_.x;
            _loc9_ += _loc10_.y;
         }
         _loc12_ = new Point(_loc8_ / _loc6_.length,_loc9_ / _loc6_.length);
         return param2.localToGlobal(_loc12_);
      }
      
      private function setupRepresenter(param1:int, param2:Sprite, param3:IBattlePlayer, param4:Boolean) : void
      {
         var _loc10_:int = 0;
         var _loc11_:PlayerInfo = null;
         var _loc12_:int = 0;
         var _loc5_:FighterInfo = FighterInfo.representFighterInfo;
         _loc5_.belong2PlayerIndex = param1;
         var _loc6_:int = _loc5_.initPosX + _loc5_.initPosY * FormationConsts.MAX_ROW_COUNT;
         var _loc7_:Sprite = param2.getChildByName("f" + _loc6_) as Sprite;
         var _loc8_:Point = param2.localToGlobal(new Point(_loc7_.x,_loc7_.y));
         var _loc9_:IBattleFighter = new BattleRepresenter(_loc5_,this._content,param4);
         _loc9_.addToStage(this._container.fighterLayer,_loc8_.x,_loc8_.y);
         for each(_loc10_ in _loc5_.initBufferIds)
         {
            _loc9_.addBuff(_loc10_);
         }
         _loc11_ = param3.playerInfo;
         if(_loc11_.psychicsBuffData != null)
         {
            _loc9_.addBuff(_loc11_.psychicsBuffData.bufferId);
         }
         for each(_loc12_ in _loc11_.init2addPlayerBuffs)
         {
            _loc9_.addBuff(_loc12_);
         }
         param3.registerFighter(_loc9_);
      }
   }
}

