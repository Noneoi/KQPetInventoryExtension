package mmo.battle.avatar
{
   import flash.display.MovieClip;
   import flash.display.Sprite;
   import mmo.interfaces.battle.consts.AvatarActionDefine;
   import mmo.interfaces.battle.data.FighterInfo;
   import mmo.interfaces.battleconfig.IBattleConfig;
   import mmo.play.dialog.InteractUtil;
   
   public class BattleChaserAvatar extends BattleAvatar
   {
      
      public function BattleChaserAvatar(param1:FighterInfo, param2:Object, param3:Boolean = false)
      {
         super(param1,param2,param3);
         hideBufferLayer();
      }
      
      override public function set hpPersentage(param1:Number) : void
      {
      }
      
      override protected function initBloodBar() : void
      {
      }
      
      override protected function setPowerResLayerVisible(param1:Boolean) : void
      {
      }
      
      override public function set spPersentage(param1:Number) : void
      {
      }
      
      override public function set powerPersentage(param1:Number) : void
      {
      }
      
      override public function summonDisappear() : void
      {
      }
      
      override public function summonAppear() : void
      {
      }
      
      override public function showTips(param1:Sprite, param2:FighterInfo, param3:IBattleConfig) : void
      {
      }
      
      override public function updateTips() : void
      {
      }
      
      override public function updateAttr() : void
      {
      }
      
      override public function showBufferLayer() : void
      {
      }
      
      override protected function initPowerBar() : void
      {
      }
      
      override public function fadeOut(param1:Function) : void
      {
         InteractUtil.applyCallback(param1);
      }
      
      override public function doAction(param1:int) : MovieClip
      {
         var _loc2_:MovieClip = null;
         if(param1 != AvatarActionDefine.NORMAL_SKILL)
         {
            this._mcAction.gotoAndStop(param1);
            _loc2_ = curActionTimeline;
            _loc2_.gotoAndStop(1);
            _loc2_.visible = false;
            return _loc2_;
         }
         return super.doAction(param1);
      }
   }
}

