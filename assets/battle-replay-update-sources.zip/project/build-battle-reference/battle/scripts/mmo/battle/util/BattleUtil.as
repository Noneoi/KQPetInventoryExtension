package mmo.battle.util
{
   import com.greensock.TweenLite;
   import com.greensock.plugins.ColorMatrixFilterPlugin;
   import com.greensock.plugins.TweenPlugin;
   import flash.display.DisplayObject;
   import flash.display.MovieClip;
   import mmo.battle.avatar.BattleAvatar;
   import mmo.battle.consts.BubbleConsts;
   import mmo.battle.consts.BufferConsts;
   import mmo.common.DisplayUtil;
   import mmo.interfaces.ServiceContainer;
   import mmo.interfaces.battle.consts.AvatarActionDefine;
   import mmo.interfaces.battle.consts.BuffWaitType;
   import mmo.interfaces.battle.data.BattleInfo;
   import mmo.interfaces.battle.data.BufferNumResult;
   import mmo.interfaces.battle.data.FighterInfo;
   import mmo.interfaces.battle.data.PlayerInfo;
   import mmo.interfaces.battle.data.SkillResult;
   import mmo.interfaces.battle.data.TeamInfo;
   import mmo.interfaces.battle.entity.IBattle;
   import mmo.interfaces.battle.fighter.IBattleFighter;
   import mmo.interfaces.battle.player.IBattlePlayer;
   import mmo.interfaces.battleconfig.IBattleConfig;
   import mmo.interfaces.battleconfig.define.BufferDefine;
   import mmo.interfaces.battleconfig.define.RaceTypeDefine;
   import mmo.interfaces.material.MaterialCommonData;
   import mmo.interfaces.material.MaterialTypes;
   import mmo.play.dialog.InteractUtil;
   
   public class BattleUtil
   {
      
      public function BattleUtil()
      {
         super();
      }
      
      public static function isCurUserInTeam(param1:BattleInfo, param2:int, param3:String) : Boolean
      {
         var _loc5_:PlayerInfo = null;
         var _loc4_:TeamInfo = param1.getTeamInfoById(param2);
         if(_loc4_ == null)
         {
            return false;
         }
         for each(_loc5_ in _loc4_.playerInfos)
         {
            if(_loc5_.playerName == param3 || _loc5_.playerName == "#username#")
            {
               return true;
            }
         }
         return false;
      }
      
      public static function mergeArray(param1:Array, param2:Array) : Array
      {
         var _loc4_:Object = null;
         var _loc3_:Array = param1.concat();
         for each(_loc4_ in param2)
         {
            if(_loc3_.indexOf(_loc4_) == -1)
            {
               _loc3_.push(_loc4_);
            }
         }
         return _loc3_;
      }
      
      public static function splitNumIntoNumArray(param1:Number, param2:int, param3:Number) : Array
      {
         var _loc8_:Number = NaN;
         var _loc9_:Number = NaN;
         var _loc4_:Array = [];
         var _loc5_:Number = Math.round(Number(param1) / param2);
         var _loc6_:Number = param1;
         var _loc7_:int = 0;
         while(_loc7_ < param2 - 1)
         {
            _loc8_ = Math.floor((Math.random() - 0.5) * 2 * _loc5_ * param3);
            _loc9_ = _loc5_ + _loc8_;
            _loc4_.push(_loc9_);
            _loc6_ -= _loc9_;
            _loc7_++;
         }
         _loc4_.push(_loc6_);
         return _loc4_;
      }
      
      public static function handleHpChangesSingle(param1:Array, param2:Array, param3:IBattleFighter, param4:int, param5:Function = null) : void
      {
         var i:int = 0;
         var bufferEffect:BufferNumResult = null;
         var bufferId:int = 0;
         var delta:Number = NaN;
         var beHitMC:MovieClip = null;
         var hpChanges:Array = param1;
         var spChanges:Array = param2;
         var fighter:IBattleFighter = param3;
         var recoverActionId:int = param4;
         var onBeHitActionEnd:Function = param5;
         var minusFlag:Boolean = false;
         var lastHp:Number = Number(fighter.curHp);
         i = 0;
         while(i < hpChanges.length)
         {
            bufferEffect = hpChanges[i];
            delta = Number(bufferEffect.effect);
            bufferId = int(bufferEffect.bufferId);
            if(delta < 0)
            {
               minusFlag = true;
            }
            fighter.curHp += delta;
            fighter.showBubble(null,delta,1,null,BubbleConsts.BUBBLE_INTERVAL * i,bufferId);
            lastHp = Number(fighter.curHp);
            if(fighter.info.curHp <= 0)
            {
               fighter.fadeOut(function():*
               {
               });
               if(fighter.curHp > 0)
               {
                  fighter.showUp();
               }
            }
            i++;
         }
         i = 0;
         while(i < spChanges.length)
         {
            bufferEffect = spChanges[i];
            delta = Number(bufferEffect.effect);
            bufferId = int(bufferEffect.bufferId);
            fighter.curSp += delta;
            fighter.showBubble(null,delta,1,null,BubbleConsts.BUBBLE_INTERVAL * i,BufferConsts.ShieldBuffId);
            i++;
         }
         if(minusFlag)
         {
            beHitMC = fighter.doAction(AvatarActionDefine.BE_HIT);
            if(beHitMC.totalFrames == 1)
            {
               if(onBeHitActionEnd != null)
               {
                  onBeHitActionEnd.apply();
               }
            }
            else
            {
               beHitMC.addFrameScript(beHitMC.totalFrames - 1,function():void
               {
                  if(fighter.curActionId != AvatarActionDefine.BE_HIT)
                  {
                     return;
                  }
                  var _loc1_:MovieClip = fighter.doAction(recoverActionId);
                  if(onBeHitActionEnd != null)
                  {
                     onBeHitActionEnd.apply();
                  }
               });
            }
         }
         else if(onBeHitActionEnd != null)
         {
            onBeHitActionEnd.apply();
         }
      }
      
      public static function handlePowerChangesSingle(param1:Array, param2:IBattleFighter) : void
      {
         var _loc4_:BufferNumResult = null;
         var _loc5_:int = 0;
         var _loc6_:int = 0;
         var _loc3_:int = 0;
         while(_loc3_ < param1.length)
         {
            _loc4_ = param1[_loc3_];
            _loc5_ = int(_loc4_.effect);
            _loc6_ = int(_loc4_.bufferId);
            param2.curPower += _loc5_;
            param2.showPowerBubble(null,_loc5_,1,null,BubbleConsts.POWER_INTERVAL * _loc3_,_loc6_);
            _loc3_++;
         }
      }
      
      public static function handleBuffChangesSingle(param1:Array, param2:Array, param3:IBattleFighter) : void
      {
         var _loc4_:int = 0;
         var _loc5_:int = 0;
         for each(_loc4_ in param2)
         {
            param3.removeBuff(_loc4_);
         }
         for each(_loc5_ in param1)
         {
            param3.addBuff(_loc5_);
         }
      }
      
      public static function handleDisplayBuffChangesSingle(param1:Array, param2:IBattleFighter, param3:Function = null) : void
      {
         if(param1.length == 0)
         {
            InteractUtil.applyCallback(param3);
         }
         else if(!checkHasWaitTypeBuff(param1))
         {
            InteractUtil.applyCallback(param3);
            handleOneBuff(param1.concat(),param2);
         }
         else
         {
            handleOneBuff(param1.concat(),param2,param3);
         }
      }
      
      private static function handleOneBuff(param1:Array, param2:IBattleFighter, param3:Function = null) : void
      {
         var _loc4_:IBattleConfig = ServiceContainer.getService(IBattleConfig);
         var _loc5_:String = param1[0];
         var _loc6_:Array = _loc5_.split("_");
         var _loc7_:int = int(_loc6_[0]);
         var _loc8_:int = int(_loc6_[1]);
         var _loc9_:BufferDefine = _loc4_.getBufferDefineById(_loc8_);
         param1.shift();
         if(_loc7_ == BufferConsts.BuffDisplayType_CLEAR)
         {
            removeBuffWithOutWait(_loc8_,param1,param2,param3);
         }
         else if(_loc7_ == BufferConsts.BuffDisplayType_APPEAR)
         {
            if(_loc9_.buffWaitType > 0)
            {
               if(Boolean(param2.info.isSummoned) || Boolean(param2.info.isSelfReplication) && Boolean(param2.info.isSelfReplicationCalledOut))
               {
                  param2.avatar.summonAppear();
               }
               if(_loc9_.buffWaitType == BuffWaitType.WAIT_MUTI_CONTINUE_ON_ONE_FIGHTER)
               {
                  if(BattleAvatar(param2.avatar).alpha == 0)
                  {
                     InteractUtil.applyCallback(param3);
                     addBuffWithOutWait(_loc8_,param1,param2);
                  }
                  else
                  {
                     addWaitBuffOneByOne(_loc8_,param1,param2,param3);
                  }
               }
               else if(_loc9_.buffWaitType == BuffWaitType.WAIT_AND_FORCE_SHOW_FIGHTER)
               {
                  if(BattleAvatar(param2.avatar).alpha == 0)
                  {
                     param2.showUp();
                  }
                  addWaitBuffAllAtOnce(_loc8_,param1,param2,param3);
               }
               else if(BattleAvatar(param2.avatar).alpha == 0)
               {
                  InteractUtil.applyCallback(param3);
                  addBuffWithOutWait(_loc8_,param1,param2);
               }
               else
               {
                  addWaitBuffAllAtOnce(_loc8_,param1,param2,param3);
               }
            }
            else
            {
               addBuffWithOutWait(_loc8_,param1,param2,param3);
            }
         }
      }
      
      private static function addBuffWithOutWait(param1:int, param2:Array, param3:IBattleFighter, param4:Function = null) : void
      {
         param3.addBuff(param1,true);
         if(param2.length > 0)
         {
            handleOneBuff(param2,param3,param4);
         }
         else
         {
            InteractUtil.applyCallback(param4);
         }
      }
      
      private static function removeBuffWithOutWait(param1:int, param2:Array, param3:IBattleFighter, param4:Function = null) : void
      {
         param3.removeBuff(param1);
         if(param2.length > 0)
         {
            handleOneBuff(param2,param3,param4);
         }
         else
         {
            InteractUtil.applyCallback(param4);
         }
      }
      
      private static function addWaitBuffOneByOne(param1:int, param2:Array, param3:IBattleFighter, param4:Function = null) : void
      {
         var bufferId:int = param1;
         var buffChangeArr:Array = param2;
         var fighter:IBattleFighter = param3;
         var callback:Function = param4;
         fighter.addBuff(bufferId,true,function():void
         {
            if(checkHasWaitTypeBuff(buffChangeArr))
            {
               handleOneBuff(buffChangeArr,fighter,callback);
            }
            else if(buffChangeArr.length > 0)
            {
               handleOneBuff(buffChangeArr,fighter,callback);
            }
            else
            {
               InteractUtil.applyCallback(callback);
            }
         });
      }
      
      private static function addWaitBuffAllAtOnce(param1:int, param2:Array, param3:IBattleFighter, param4:Function = null) : void
      {
         var bufferId:int = param1;
         var buffChangeArr:Array = param2;
         var fighter:IBattleFighter = param3;
         var callback:Function = param4;
         if(checkHasWaitTypeBuff(buffChangeArr))
         {
            fighter.addBuff(bufferId,true);
            handleOneBuff(buffChangeArr,fighter,callback);
         }
         else
         {
            fighter.addBuff(bufferId,true,function():void
            {
               InteractUtil.applyCallback(callback);
               if(buffChangeArr.length > 0)
               {
                  handleOneBuff(buffChangeArr,fighter);
               }
            });
         }
      }
      
      public static function calcWaitTypeBuffNum(param1:Array) : int
      {
         var _loc4_:String = null;
         var _loc5_:Array = null;
         var _loc6_:int = 0;
         var _loc7_:int = 0;
         var _loc8_:BufferDefine = null;
         var _loc2_:int = 0;
         var _loc3_:IBattleConfig = ServiceContainer.getService(IBattleConfig);
         for each(_loc4_ in param1)
         {
            _loc5_ = _loc4_.split("_");
            _loc6_ = int(_loc5_[0]);
            _loc7_ = int(_loc5_[1]);
            _loc8_ = _loc3_.getBufferDefineById(_loc7_);
            if(_loc8_.buffWaitType > 0 && _loc6_ == BufferConsts.BuffDisplayType_APPEAR)
            {
               _loc2_++;
            }
         }
         return _loc2_;
      }
      
      public static function checkHasWaitTypeBuff(param1:Array) : Boolean
      {
         if(calcWaitTypeBuffNum(param1) > 0)
         {
            return true;
         }
         return false;
      }
      
      public static function getRestraintCoefficient(param1:IBattleFighter, param2:IBattleFighter, param3:IBattleConfig) : Number
      {
         var _loc4_:FighterInfo = param1.info;
         var _loc5_:FighterInfo = param2.info;
         var _loc6_:int = getOneRaceTypeByPriority(_loc4_.raceTypeIds,param3);
         var _loc7_:int = getOneRaceTypeByPriority(_loc5_.raceTypeIds,param3);
         return Number(param3.getRaceTypeDefineById(_loc6_).getRestraintCoefficientById(_loc7_));
      }
      
      public static function getOneRaceTypeByPriority(param1:Array, param2:IBattleConfig) : int
      {
         var _loc5_:int = 0;
         var _loc6_:RaceTypeDefine = null;
         var _loc3_:int = 0;
         var _loc4_:int = 0;
         for each(_loc5_ in param1)
         {
            _loc6_ = param2.getRaceTypeDefineById(_loc5_);
            if(_loc6_.priority > _loc3_)
            {
               _loc3_ = int(_loc6_.priority);
               _loc4_ = int(_loc6_.id);
            }
         }
         return _loc4_;
      }
      
      public static function applyTweenGray(param1:DisplayObject, param2:uint) : void
      {
         clearTweenGray(param1);
         var _loc3_:Array = new Array();
         _loc3_ = _loc3_.concat([0.3086,0.6094,0.082,0,0]);
         _loc3_ = _loc3_.concat([0.3086,0.6094,0.082,0,0]);
         _loc3_ = _loc3_.concat([0.3086,0.6094,0.082,0,0]);
         _loc3_ = _loc3_.concat([0,0,0,1,0]);
         TweenPlugin.activate([ColorMatrixFilterPlugin]);
         TweenLite.to(param1,2,{"colorMatrixFilter":{"matrix":_loc3_}});
      }
      
      public static function clearTweenGray(param1:DisplayObject) : void
      {
         TweenLite.killTweensOf(param1);
         DisplayUtil.clearFilters(param1);
      }
      
      public static function getTargetFighter(param1:IBattle, param2:SkillResult) : IBattleFighter
      {
         var _loc3_:IBattlePlayer = param1.getPlayerByName(param2.targetPlayerName);
         return _loc3_.getFighterById(param2.targetCharacterId);
      }
      
      public static function getFighterByNameAndId(param1:IBattle, param2:String, param3:int) : IBattleFighter
      {
         var _loc4_:IBattlePlayer = param1.getPlayerByName(param2);
         return _loc4_.getFighterById(param3);
      }
      
      public static function getDropCoolPetStoneMCD(param1:Array, param2:IBattleConfig) : MaterialCommonData
      {
         var _loc3_:String = null;
         var _loc4_:int = 0;
         var _loc5_:MaterialCommonData = null;
         for(_loc3_ in param2.coolPetStoneBGInfo)
         {
            _loc4_ = parseInt(_loc3_);
            for each(_loc5_ in param1)
            {
               if(_loc5_.type == MaterialTypes.ITEM && _loc5_.id == _loc4_)
               {
                  return _loc5_;
               }
            }
         }
         return null;
      }
      
      public static function getEffectSkillResultNum(param1:Array) : int
      {
         var _loc2_:int = 0;
         var _loc3_:int = 0;
         while(_loc3_ < param1.length)
         {
            if(SkillResult(param1[_loc3_]).effect)
            {
               _loc2_++;
            }
            _loc3_++;
         }
         return _loc2_;
      }
   }
}

