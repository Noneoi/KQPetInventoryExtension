package mmo.battle.command
{
   import flash.events.EventDispatcher;
   import mmo.battle.command.playbattle.ClearSceneCommand;
   import mmo.battle.command.playbattle.CloseLoaderCommand;
   import mmo.battle.command.playbattle.DisposeBattlefieldCommand;
   import mmo.battle.command.playbattle.DownloadBackgroundCommand;
   import mmo.battle.command.playbattle.DownloadCommonResCommand;
   import mmo.battle.command.playbattle.DownloadConfigCommand;
   import mmo.battle.command.playbattle.DownloadFighterCommand;
   import mmo.battle.command.playbattle.DownloadLoadingStyleCommand;
   import mmo.battle.command.playbattle.NotifyGainCoolPetStoneCommand;
   import mmo.battle.command.playbattle.RealDownloadCommand;
   import mmo.battle.command.playbattle.SetupBattleMusicCommand;
   import mmo.battle.command.playbattle.SetupBattlefieldCommand;
   import mmo.battle.command.playbattle.SetupFighterCommand;
   import mmo.battle.command.playbattle.ShowItemResultCommand;
   import mmo.battle.command.playbattle.StartBattleFlowCommand;
   import mmo.battle.command.playteambattle.SetupTeamUICommand;
   import mmo.battle.entity.BattleBase;
   import mmo.battle.ui.BattleUI;
   import mmo.battle.util.BattleContentUtil;
   import mmo.battle.util.BattleUtil;
   import mmo.common.sound.SoundManager;
   import mmo.interfaces.ServiceContainer;
   import mmo.interfaces.battle.command.IBattleCommand;
   import mmo.interfaces.battle.data.BattleInfo;
   import mmo.interfaces.battle.events.BattleEvent;
   import mmo.interfaces.user.IUserNameManager;
   
   public class PlayTeamBattleFlowCommand extends BattleCommand implements IBattleCommand
   {
      
      public function PlayTeamBattleFlowCommand()
      {
         super();
      }
      
      override protected function initializeMacroCommand() : void
      {
         addSubCommand(ClearSceneCommand);
         addSubCommand(DownloadConfigCommand);
         addSubCommand(DownloadCommonResCommand);
         addSubCommand(DownloadBackgroundCommand);
         addSubCommand(DownloadFighterCommand);
         addSubCommand(DownloadLoadingStyleCommand);
         addSubCommand(RealDownloadCommand);
         addSubCommand(SetupBattleMusicCommand);
         addSubCommand(SetupBattlefieldCommand);
         addSubCommand(SetupTeamUICommand);
         addSubCommand(SetupFighterCommand);
         addSubCommand(ShowItemResultCommand);
         addSubCommand(CloseLoaderCommand);
         addSubCommand(StartBattleFlowCommand);
         addSubCommand(NotifyGainCoolPetStoneCommand);
         addSubCommand(DisposeBattlefieldCommand);
         super.initializeMacroCommand();
      }
      
      override public function cancel() : void
      {
         var _loc1_:BattleBase = BattleContentUtil.getContentProperty(_content,BattleContentUtil.PN_BATTLE);
         var _loc2_:BattleUI = BattleContentUtil.getContentProperty(_content,BattleContentUtil.PN_UI);
         if(_loc2_ != null)
         {
            _loc2_.dispose();
         }
         var _loc3_:String = BattleContentUtil.getContentProperty(_content,BattleContentUtil.PN_ORG_MUSIC);
         if(_loc3_ != null)
         {
            SoundManager.instance.playBackgroundMusic(_loc3_);
         }
         var _loc4_:EventDispatcher = BattleContentUtil.getContentProperty(_content,BattleContentUtil.PN_EVENT_DISPATCHER);
         var _loc5_:Boolean = this.isCurUserWiner();
         _loc4_.dispatchEvent(new BattleEvent(BattleEvent.ON_BATTLE_DISPOSE,{"isCurUserWiner":_loc5_}));
         super.cancel();
      }
      
      protected function isCurUserWiner() : Boolean
      {
         var _loc1_:BattleInfo = BattleContentUtil.getContentProperty(this._content,BattleContentUtil.PN_BATTLE_INFO);
         var _loc2_:IUserNameManager = ServiceContainer.getService(IUserNameManager) as IUserNameManager;
         var _loc3_:BattleBase = BattleContentUtil.getContentProperty(_content,BattleContentUtil.PN_BATTLE);
         var _loc4_:String = _loc2_.getNickName(_loc3_.battleResult.teamLeaderName);
         var _loc5_:int = BattleContentUtil.getContentProperty(_content,BattleContentUtil.PN_WINNER_TEAM_ID);
         return BattleUtil.isCurUserInTeam(_loc1_,_loc5_,_loc4_);
      }
   }
}

