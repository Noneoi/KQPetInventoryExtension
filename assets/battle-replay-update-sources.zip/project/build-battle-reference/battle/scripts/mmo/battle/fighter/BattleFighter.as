package mmo.battle.fighter
{
   import flash.display.DisplayObjectContainer;
   import flash.display.MovieClip;
   import flash.display.Sprite;
   import flash.events.Event;
   import flash.events.TimerEvent;
   import flash.system.ApplicationDomain;
   import flash.utils.Timer;
   import mmo.battle.avatar.BattleAvatar;
   import mmo.battle.avatar.BattleAvatarWithConfig;
   import mmo.battle.avatar.BattleChaserAvatar;
   import mmo.battle.command.CloseAttackCommand;
   import mmo.battle.command.CloseAttackCommandSimpleRes;
   import mmo.battle.command.CloseCounterCommand;
   import mmo.battle.command.CloseCounterCommandSimpleRes;
   import mmo.battle.command.RemoteAttackCommand;
   import mmo.battle.command.RemoteAttackCommandSimpleRes;
   import mmo.battle.command.RemoteCounterCommand;
   import mmo.battle.command.RemoteCounterCommandSimpleRes;
   import mmo.battle.command.SummonCommand;
   import mmo.battle.command.SummonCommandSimpleRes;
   import mmo.battle.command.attack.disable.AttackDisalbeCommand;
   import mmo.battle.command.embed.EmbedCommandStruct;
   import mmo.battle.consts.SkillPlayOrderType;
   import mmo.battle.entity.BattleSimpleResManager;
   import mmo.battle.ui.BattleNumUI;
   import mmo.battle.ui.BattleRoundUI;
   import mmo.battle.ui.BattleUI;
   import mmo.battle.util.BattleContentUtil;
   import mmo.battle.util.BattleMessageUtil;
   import mmo.interfaces.battle.avatar.IBattleAvatar;
   import mmo.interfaces.battle.command.IBattleCommand;
   import mmo.interfaces.battle.consts.AvatarEffectIds;
   import mmo.interfaces.battle.data.BattleInfo;
   import mmo.interfaces.battle.data.FighterInfo;
   import mmo.interfaces.battle.data.PlayerInfo;
   import mmo.interfaces.battle.data.RepresentRoundResult;
   import mmo.interfaces.battle.data.RoundResult;
   import mmo.interfaces.battle.data.SkillResult;
   import mmo.interfaces.battle.entity.IBattle;
   import mmo.interfaces.battle.fighter.IBattleFighter;
   import mmo.interfaces.battle.player.IBattlePlayer;
   import mmo.interfaces.battleconfig.IBattleConfig;
   import mmo.interfaces.battleconfig.consts.SkillTypes;
   import mmo.interfaces.battleconfig.define.BattleAvatarDefine;
   import mmo.interfaces.battleconfig.define.BufferDefine;
   import mmo.interfaces.battleconfig.define.SkillDefine;
   import mmo.interfaces.battleconfig.define.SkillExecuteDefine;
   import mmo.util.command.ISceneCommand;
   import mmo.util.command.SceneCommandEvent;
   
   public class BattleFighter implements IBattleFighter
   {
      
      protected var _info:FighterInfo;
      
      protected var _avatar:BattleAvatar;
      
      protected var _needFlip:Boolean;
      
      protected var _tipsRes:Sprite;
      
      protected var _content:Object;
      
      protected var _battleConfig:IBattleConfig;
      
      protected var _domain:ApplicationDomain;
      
      protected var _battleUI:BattleUI;
      
      protected var _battle:IBattle;
      
      protected var _buffIdList:Array = [];
      
      protected var _embedCmdStructList:Array = [];
      
      protected var _attackCommand:IBattleCommand;
      
      protected var _scale:Number = 1;
      
      public function BattleFighter(param1:FighterInfo, param2:Object, param3:Boolean = false)
      {
         super();
         this._info = param1;
         this._content = param2;
         this._battleConfig = BattleContentUtil.getContentProperty(param2,BattleContentUtil.PN_BATTLE_CONFIG);
         this._domain = BattleContentUtil.getContentProperty(param2,BattleContentUtil.PN_DOMAIN);
         this._battleUI = BattleContentUtil.getContentProperty(param2,BattleContentUtil.PN_UI);
         this._battle = BattleContentUtil.getContentProperty(param2,BattleContentUtil.PN_BATTLE);
         this._needFlip = param3;
         this.setupAvatar();
      }
      
      private function isUseSimpleResBySkillId(param1:int) : Boolean
      {
         var _loc2_:BattleSimpleResManager = BattleContentUtil.getContentProperty(this._content,BattleContentUtil.SIMPLE_RES_DATA);
         var _loc3_:BattleInfo = BattleContentUtil.getContentProperty(this._content,BattleContentUtil.PN_BATTLE_INFO);
         var _loc4_:int = int(this._info.belong2PlayerIndex);
         var _loc5_:PlayerInfo = _loc3_.teamInfos[this._needFlip ? 1 : 0].playerInfos[_loc4_];
         var _loc6_:int = int(SkillDefine.getRaceIdBySkillId(param1));
         return _loc2_.isSimpleRes || _loc2_.checkShouldBeSimpleResByRaceId(this._info.getShowRaceIdWithOrigin()) || _loc2_.isOnlyEnemySimpleRes && !BattleSimpleResManager.isMyFormationByUsername(_loc5_.playerName);
      }
      
      public function attack(param1:RoundResult, param2:Function) : void
      {
         var skillDefine:SkillDefine;
         var skillExecuteDefine:SkillExecuteDefine;
         var enableEmbedCommand:Boolean;
         var attackCallback:Function;
         var attackCmdContent:Object;
         var cmdClsRef:Class = null;
         var tarRusult:SkillResult = null;
         var targetPlayer:IBattlePlayer = null;
         var targetFighter:IBattleFighter = null;
         var roundResult:RoundResult = param1;
         var callback:Function = param2;
         var timeline:MovieClip = this._avatar.curActionTimeline;
         var skillId:int = int(this._battleConfig.getComboTargetSkillIds(roundResult.skillId,this._buffIdList));
         if(skillId > 0)
         {
            roundResult.skillId = skillId;
         }
         else
         {
            skillId = int(roundResult.skillId);
         }
         skillDefine = this._battleConfig.getSkillDefineById(skillId);
         if(skillDefine.playOrderType == SkillPlayOrderType.SEQUENCE_PLAY_ORDER_TYPE)
         {
            roundResult.fillWithMaxChangeSetId();
         }
         if(!SkillDefine.checkSkillDefineAvailableInBattle(skillDefine))
         {
            throw new Error("缺少技能配置 in skill-config.xml,skill id=" + skillDefine.id);
         }
         skillExecuteDefine = this._battleConfig.getSkillExecutDefine(roundResult.skillExecuteCode);
         enableEmbedCommand = true;
         if(skillExecuteDefine.type == SkillExecuteDefine.TYPE_ATTACK_DISABLE)
         {
            cmdClsRef = AttackDisalbeCommand;
            enableEmbedCommand = false;
         }
         else
         {
            if(Boolean(roundResult.isLastRound) && Boolean(skillDefine.hasLastEffect))
            {
               skillDefine = this._battleConfig.getLastSkillDefineById(roundResult.skillId);
            }
            if(skillDefine.type == SkillTypes.CLOSE)
            {
               cmdClsRef = this.isUseSimpleResBySkillId(skillDefine.id) ? CloseAttackCommandSimpleRes : CloseAttackCommand;
            }
            else if(skillDefine.type2 == SkillTypes.SUMMON)
            {
               cmdClsRef = this.isUseSimpleResBySkillId(skillDefine.id) ? SummonCommandSimpleRes : SummonCommand;
            }
            else
            {
               cmdClsRef = this.isUseSimpleResBySkillId(skillDefine.id) ? RemoteAttackCommandSimpleRes : RemoteAttackCommand;
            }
         }
         attackCallback = function():void
         {
            setupNumUI(roundResult);
            callback.apply();
         };
         attackCmdContent = this.getCloneContent(this._content);
         this.setupOtherParam(attackCmdContent,skillDefine,timeline,roundResult);
         this.executeCommand(cmdClsRef,attackCmdContent,attackCallback,enableEmbedCommand);
         if(this._battleUI != null)
         {
            if(skillDefine.type2 == SkillTypes.UNIQUE || skillDefine.type2 == SkillTypes.SUPER_UNIQUE)
            {
               BattleMessageUtil.showAttackMessage(skillDefine,this._battleUI,this._needFlip,this._info.name);
            }
            for each(tarRusult in roundResult.targetSkillResults)
            {
               if(tarRusult.effect)
               {
                  targetPlayer = this._battle.getPlayerByName(tarRusult.targetPlayerName);
                  targetFighter = targetPlayer.getFighterById(tarRusult.targetCharacterId);
                  BattleMessageUtil.showSkillMissCriticalBlogMessage(targetFighter.info.name,tarRusult,this._battleUI);
               }
            }
         }
         this.setBattleRoundUI(roundResult,true);
      }
      
      protected function setupNumUI(param1:RoundResult) : void
      {
         var _loc2_:SkillResult = null;
         var _loc3_:String = null;
         var _loc4_:IBattlePlayer = null;
         var _loc5_:int = 0;
         for each(_loc2_ in param1.targetSkillResults)
         {
            if(_loc2_.effect)
            {
               _loc3_ = _loc2_.targetPlayerName;
               _loc4_ = this._battle.getPlayerByName(_loc3_);
               _loc5_ = int(_loc4_.playerInfo.playerType);
               if(_loc5_ == PlayerInfo.PLAYER_TYPE_USER)
               {
                  if(_loc2_.miss)
                  {
                     this.setNumUI(BattleContentUtil.PN_MISS_NUM_UI);
                  }
                  if(_loc2_.block)
                  {
                     this.setNumUI(BattleContentUtil.PN_BLOCK_NUM_UI);
                  }
               }
               else if(_loc5_ == PlayerInfo.PLAYER_TYPE_AI)
               {
                  if(_loc2_.critical)
                  {
                     this.setNumUI(BattleContentUtil.PN_CRITICAL_NUM_UI);
                  }
               }
            }
         }
      }
      
      private function setNumUI(param1:String) : void
      {
         var _loc2_:BattleNumUI = BattleContentUtil.getContentProperty(this._content,param1);
         if(_loc2_ != null)
         {
            _loc2_.increase();
         }
      }
      
      protected function setBattleRoundUI(param1:RoundResult, param2:Boolean = false) : void
      {
         var _loc3_:BattleRoundUI = BattleContentUtil.getContentProperty(this._content,BattleContentUtil.PN_BATTLE_ROUND_UI);
         if(_loc3_ != null)
         {
            _loc3_.setByRoundResult(param1,param2);
         }
      }
      
      public function counterAttack(param1:RoundResult, param2:Function) : void
      {
         this.showEffect(AvatarEffectIds.COUNTER,null);
         var _loc3_:SkillDefine = this._battleConfig.getSkillDefineById(param1.skillId);
         var _loc4_:MovieClip = this._avatar.doAction(_loc3_.actionFrame);
         var _loc5_:Object = this.getCloneContent(this._content);
         this.setupOtherParam(_loc5_,_loc3_,_loc4_,param1);
         var _loc6_:Class = _loc3_.type == SkillTypes.CLOSE ? (this.isUseSimpleResBySkillId(_loc3_.id) ? CloseCounterCommandSimpleRes : CloseCounterCommand) : (this.isUseSimpleResBySkillId(_loc3_.id) ? RemoteCounterCommandSimpleRes : RemoteCounterCommand);
         this.executeCommand(_loc6_,_loc5_,param2,false);
      }
      
      protected function getCloneContent(param1:Object) : Object
      {
         var _loc2_:Object = {};
         _loc2_[BattleContentUtil.PN_BATTLE_INFO] = param1[BattleContentUtil.PN_BATTLE_INFO];
         _loc2_[BattleContentUtil.PN_BATTLE] = param1[BattleContentUtil.PN_BATTLE];
         _loc2_[BattleContentUtil.PN_DOMAIN] = param1[BattleContentUtil.PN_DOMAIN];
         _loc2_[BattleContentUtil.PN_BATTLE_CONFIG] = param1[BattleContentUtil.PN_BATTLE_CONFIG];
         _loc2_[BattleContentUtil.PN_CONTAINER] = param1[BattleContentUtil.PN_CONTAINER];
         _loc2_[BattleContentUtil.PN_EVENT_DISPATCHER] = param1[BattleContentUtil.PN_EVENT_DISPATCHER];
         _loc2_[BattleContentUtil.PN_WINNER_TEAM_ID] = param1[BattleContentUtil.PN_WINNER_TEAM_ID];
         _loc2_[BattleContentUtil.PN_ROUND_RESULT] = param1[BattleContentUtil.PN_ROUND_RESULT];
         _loc2_[BattleContentUtil.SIMPLE_RES_DATA] = param1[BattleContentUtil.SIMPLE_RES_DATA];
         return _loc2_;
      }
      
      protected function setupOtherParam(param1:Object, param2:SkillDefine, param3:MovieClip, param4:RoundResult) : void
      {
         BattleContentUtil.setContentProperty(param1,BattleContentUtil.PN_SKILLDEFINE,param2);
         BattleContentUtil.setContentProperty(param1,BattleContentUtil.PN_TIME_LINE,param3);
         BattleContentUtil.setContentProperty(param1,BattleContentUtil.PN_JUMP_FRAME,param2.jumpFrame);
         BattleContentUtil.setContentProperty(param1,BattleContentUtil.PN_EFFECT_FRAME,param2.effectFrame);
         BattleContentUtil.setContentProperty(param1,BattleContentUtil.PN_ROUND_RESULT,param4);
      }
      
      protected function executeCommand(param1:Class, param2:Object, param3:Function, param4:Boolean = true) : void
      {
         var succFunc:Function = null;
         var failFunc:Function = null;
         var commandClsRef:Class = param1;
         var content:Object = param2;
         var callback:Function = param3;
         var enableEmbed:Boolean = param4;
         if(this._attackCommand != null)
         {
            return;
         }
         this._attackCommand = this.getCmdInstanceAndSetupEmbedCmd(commandClsRef,enableEmbed);
         succFunc = function(param1:SceneCommandEvent):void
         {
            _attackCommand.removeEventListener(SceneCommandEvent.SUCCEED,succFunc);
            _attackCommand.removeEventListener(SceneCommandEvent.FAILED,failFunc);
            _attackCommand = null;
            if(callback != null)
            {
               callback.apply();
            }
         };
         failFunc = function(param1:SceneCommandEvent):void
         {
            _attackCommand.removeEventListener(SceneCommandEvent.SUCCEED,succFunc);
            _attackCommand.removeEventListener(SceneCommandEvent.FAILED,failFunc);
            _attackCommand = null;
            if(callback != null)
            {
               callback.apply();
            }
         };
         this._attackCommand.addEventListener(SceneCommandEvent.SUCCEED,succFunc);
         this._attackCommand.addEventListener(SceneCommandEvent.FAILED,failFunc);
         this._attackCommand.execute(content);
      }
      
      private function getCmdInstanceAndSetupEmbedCmd(param1:Class, param2:Boolean) : IBattleCommand
      {
         var _loc4_:int = 0;
         var _loc5_:EmbedCommandStruct = null;
         var _loc3_:IBattleCommand = new param1() as IBattleCommand;
         if(param2)
         {
            _loc4_ = 0;
            while(_loc4_ < this._embedCmdStructList.length)
            {
               _loc5_ = this._embedCmdStructList[_loc4_];
               _loc3_.insertCommand(_loc5_.command,_loc5_.timing);
               _loc4_++;
            }
         }
         return _loc3_;
      }
      
      public function get avatar() : IBattleAvatar
      {
         return this._avatar;
      }
      
      public function get x() : Number
      {
         return this._avatar.x;
      }
      
      public function get y() : Number
      {
         return this._avatar.y;
      }
      
      public function get info() : FighterInfo
      {
         return this._info;
      }
      
      public function get needFlip() : Boolean
      {
         return this._needFlip;
      }
      
      public function addToStage(param1:DisplayObjectContainer, param2:Number, param3:Number, param4:int = -1) : void
      {
         if(param4 < 0)
         {
            param1.addChild(this._avatar);
         }
         else
         {
            param1.addChildAt(this._avatar,param4);
         }
         this._avatar.x = param2;
         this._avatar.y = param3;
      }
      
      public function get curHp() : Number
      {
         return this._info.curHp;
      }
      
      public function set curHp(param1:Number) : void
      {
         var _loc2_:Number = Number(this._info.curHp);
         if(param1 < 0)
         {
            param1 = 0;
         }
         this._info.curHp = param1;
         this._avatar.hpPersentage = Number(this._info.curHp) / this._info.maxHp;
         this._avatar.updateTips();
         if(_loc2_ <= 0 && param1 > 0)
         {
            this.showUp();
         }
      }
      
      public function get curSp() : Number
      {
         return this._info.curSp;
      }
      
      public function set curSp(param1:Number) : void
      {
         this._info.curSp = param1;
         if(this._info.maxHp <= 0)
         {
            this._avatar.spPersentage = 0;
         }
         else
         {
            this._avatar.spPersentage = this._info.curSp / this._info.maxHp;
         }
         this._avatar.updateTips();
      }
      
      public function fadeOut(param1:Function) : void
      {
         this._avatar.fadeOut(param1);
      }
      
      public function showUp() : void
      {
         this._avatar.showUp();
      }
      
      public function updateCurHp() : void
      {
         this.curHp = this._info.curHp;
      }
      
      public function get maxHp() : Number
      {
         return this._info.maxHp;
      }
      
      public function set maxHp(param1:Number) : void
      {
         this._info.maxHp = param1;
         if(this._info.maxHp <= 0)
         {
            this._info.maxHp = 0;
         }
      }
      
      public function get curPower() : int
      {
         return this._info.curPower;
      }
      
      public function set curPower(param1:int) : void
      {
         var _loc2_:int = int(this._battleConfig.getPowerFullBuffId(this._info.faceId));
         if(param1 >= this._info.maxPower)
         {
            if(this._info.curPower < this._info.maxPower)
            {
               this._avatar.addBuff(_loc2_);
               if(this._battleUI != null)
               {
                  BattleMessageUtil.shwoPowerFullMessage(this._battleUI,this._needFlip,this._info.name);
               }
            }
         }
         else
         {
            this._avatar.removeBuff(_loc2_);
         }
         this._info.curPower = param1;
         this._avatar.powerPersentage = param1 / this._info.maxPower;
         this._avatar.updateTips();
      }
      
      public function addBuff(param1:int, param2:Boolean = true, param3:Function = null) : void
      {
         this._avatar.addBuff(param1,param3);
         var _loc4_:BufferDefine = this._battleConfig.getBufferDefineById(param1);
         this._buffIdList.push(param1);
         this.checkNeed2HidePlayerUi();
         if(this._battleUI != null && param2)
         {
            BattleMessageUtil.showBuffMessage(_loc4_,this._battleUI,this._needFlip,this._info.name);
         }
      }
      
      private function checkNeed2HidePlayerUi() : void
      {
         var _loc2_:int = 0;
         var _loc3_:BattleUI = null;
         var _loc4_:BufferDefine = null;
         var _loc1_:Boolean = false;
         for each(_loc2_ in this._buffIdList)
         {
            _loc4_ = this._battleConfig.getBufferDefineById(_loc2_);
            if(_loc4_.need2HidePlayerUi)
            {
               _loc1_ = true;
               break;
            }
         }
         _loc3_ = BattleContentUtil.getContentProperty(this._content,BattleContentUtil.PN_UI);
         if(this._info.id == RepresentRoundResult.REPRESENTER_SOURCE_CHARACTER_ID)
         {
            _loc3_.setPlayerUiVisible(this.needFlip ? 1 : 0,!_loc1_);
         }
      }
      
      public function removeBuff(param1:int) : void
      {
         this._avatar.removeBuff(param1);
         var _loc2_:int = this._buffIdList.indexOf(param1);
         if(_loc2_ != -1)
         {
            this._buffIdList.splice(_loc2_,1);
         }
         this.checkNeed2HidePlayerUi();
      }
      
      public function doAction(param1:int) : MovieClip
      {
         return this._avatar.doAction(param1);
      }
      
      public function getTargetAction_BackGround(param1:int) : MovieClip
      {
         return this._avatar.getTargetAction_BackGround(param1);
      }
      
      public function getAction_FullScreen_BackGround(param1:int) : MovieClip
      {
         return this._avatar.getAction_FullScreen_BackGround(param1);
      }
      
      public function getAction_FullScreen_ForeGround(param1:int) : MovieClip
      {
         return this._avatar.getAction_FullScreen_ForeGround(param1);
      }
      
      public function get curActionTimeline() : MovieClip
      {
         return this._avatar.curActionTimeline;
      }
      
      public function get curActionId() : int
      {
         return this._avatar.curActionId;
      }
      
      public function showEffect(param1:int, param2:Function, param3:Boolean = false) : void
      {
         this._avatar.showEffect(param1,param2,param3);
      }
      
      public function showEffectMovie(param1:MovieClip, param2:int, param3:Function, param4:Boolean = false) : void
      {
         this._avatar.showEffectMovie(param1,param2,param3,param4);
      }
      
      public function showMovie(param1:MovieClip, param2:Function) : void
      {
         this._avatar.showMovie(param1,param2);
      }
      
      public function showSkillEffect(param1:int, param2:Boolean, param3:Function, param4:Boolean) : MovieClip
      {
         var thisObj:IBattleFighter = null;
         var skillId:int = param1;
         var isLastEffect:Boolean = param2;
         var callback:Function = param3;
         var useSimpleRes:Boolean = param4;
         thisObj = this;
         var avatarCallback:Function = function():void
         {
            callback.apply(null,[thisObj]);
         };
         return this._avatar.showSkillEffect(skillId,isLastEffect,avatarCallback,useSimpleRes);
      }
      
      public function showSummonEffect(param1:int, param2:Function) : MovieClip
      {
         var thisObj:IBattleFighter = null;
         var effect:int = param1;
         var callback:Function = param2;
         thisObj = this;
         var avatarCallback:Function = function():void
         {
            callback.apply(null,[thisObj]);
         };
         return this._avatar.showSummonEffect(effect,avatarCallback);
      }
      
      public function showTips(param1:Sprite) : void
      {
         this._tipsRes = param1;
         this._avatar.showTips(param1,this._info,this._battleConfig);
      }
      
      public function jumpTo(param1:Number, param2:Number, param3:Function) : void
      {
         if(this._avatar.alpha == 0)
         {
            param3.apply();
            return;
         }
         this._avatar.jumpTo(param1,param2,param3);
      }
      
      public function slideBackward(param1:Function) : void
      {
         this._avatar.slideBackward(param1);
      }
      
      public function showBubble(param1:FighterInfo, param2:Number, param3:Number, param4:Function, param5:int = 0, param6:int = 0) : void
      {
         var timer:Timer = null;
         var sourceFighterInfo:FighterInfo = param1;
         var bubbleNum:Number = param2;
         var restraintCoeff:Number = param3;
         var callback:Function = param4;
         var delayInMs:int = param5;
         var buffId:int = param6;
         if(delayInMs == 0)
         {
            this._avatar.showBubble(sourceFighterInfo,bubbleNum,restraintCoeff,callback,buffId);
         }
         else
         {
            timer = new Timer(delayInMs,1);
            timer.addEventListener(TimerEvent.TIMER,function(param1:TimerEvent):void
            {
               _avatar.showBubble(sourceFighterInfo,bubbleNum,restraintCoeff,callback,buffId);
            });
            timer.start();
         }
      }
      
      public function showPowerBubble(param1:FighterInfo, param2:Number, param3:Number, param4:Function, param5:int = 0, param6:int = 0) : void
      {
         var timer:Timer = null;
         var sourceFighterInfo:FighterInfo = param1;
         var bubbleNum:Number = param2;
         var restraintCoeff:Number = param3;
         var callback:Function = param4;
         var delayInMs:int = param5;
         var buffId:int = param6;
         if(delayInMs == 0)
         {
            this._avatar.showPowerBubble(sourceFighterInfo,bubbleNum,restraintCoeff,callback,buffId);
         }
         else
         {
            timer = new Timer(delayInMs,1);
            timer.addEventListener(TimerEvent.TIMER,function(param1:TimerEvent):void
            {
               _avatar.showPowerBubble(sourceFighterInfo,bubbleNum,restraintCoeff,callback,buffId);
            });
            timer.start();
         }
      }
      
      public function set scale(param1:Number) : void
      {
         this._scale = param1;
         this._avatar.scale = param1;
      }
      
      public function embedCommand(param1:ISceneCommand, param2:*) : void
      {
         var _loc3_:EmbedCommandStruct = new EmbedCommandStruct(param1,param2);
         this._embedCmdStructList.push(_loc3_);
      }
      
      public function resetAvatar(param1:Function) : void
      {
         var _loc2_:BattleAvatar = this._avatar;
         _loc2_.addEventListener(Event.ADDED_TO_STAGE,this.onAdded);
         var _loc3_:Sprite = _loc2_.parent as Sprite;
         var _loc4_:int = _loc3_.getChildIndex(_loc2_);
         if(this._avatar != null)
         {
            this._avatar.dispose();
            this._avatar = null;
         }
         this.setupAvatar();
         this.recoverBuffers();
         this.addToStage(_loc3_,_loc2_.x,_loc2_.y,_loc4_);
         this.showTips(this._tipsRes);
         if(param1 != null)
         {
            param1.apply();
         }
      }
      
      private function onAdded(param1:Event) : void
      {
         var _loc2_:BattleAvatar = param1.currentTarget as BattleAvatar;
         _loc2_.removeEventListener(Event.ADDED_TO_STAGE,this.onAdded);
         throw new Error("Disposed avatar add to stage");
      }
      
      protected function setupAvatar() : void
      {
         var _loc1_:String = null;
         var _loc2_:BattleAvatarDefine = null;
         var _loc3_:Class = null;
         var _loc4_:int = 0;
         if(this._info.isChaser)
         {
            this._avatar = new BattleChaserAvatar(this._info,this._content,this._needFlip);
         }
         else
         {
            _loc1_ = "mmo.battle.avatar.ext.BattleAvatar" + this._info.faceId;
            _loc2_ = this._battleConfig.getBattleAvatarDefineById(this._info.faceId);
            if(_loc2_ != null)
            {
               this._avatar = new BattleAvatarWithConfig(_loc2_,this._info,this._content,this._needFlip);
            }
            else if(this._domain.hasDefinition(_loc1_))
            {
               _loc3_ = this._domain.getDefinition(_loc1_) as Class;
               this._avatar = new _loc3_(this._info,this._content,this._needFlip) as BattleAvatar;
            }
            else
            {
               this._avatar = new BattleAvatar(this._info,this._content,this._needFlip);
            }
         }
         this._avatar.scale = this._scale;
         this.curHp = this._info.curHp;
         this.curSp = this._info.curSp;
         this.curPower = this._info.curPower;
         this._avatar.resetMapBuffId2Buff();
         if(this._info.curPower >= this._info.maxPower)
         {
            _loc4_ = int(this._battleConfig.getPowerFullBuffId(this._info.faceId));
            this._avatar.addBuff(_loc4_);
         }
         if(Boolean(this._info.isSummoned) && !this._info.isSummonedCallOut || Boolean(this._info.isSelfReplication) && !this._info.needShowSelfReplication)
         {
            this._avatar.summonDisappear();
         }
      }
      
      protected function recoverBuffers() : void
      {
         var _loc2_:int = 0;
         var _loc3_:BufferDefine = null;
         var _loc1_:Array = this._buffIdList.concat();
         for each(_loc2_ in _loc1_)
         {
            _loc3_ = this._battleConfig.getBufferDefineById(_loc2_);
            if(!_loc3_.displayOnce)
            {
               this.removeBuff(_loc2_);
               this.addBuff(_loc2_,false);
            }
         }
      }
   }
}

