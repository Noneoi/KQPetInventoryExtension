package mmo.battle.entity
{
   import flash.display.DisplayObject;
   import flash.display.DisplayObjectContainer;
   import mmo.interfaces.battle.fighter.IBattleFighter;
   
   public class BattleDepthManager
   {
      
      private var _container:DisplayObjectContainer;
      
      private var _registList:Vector.<IBattleFighter>;
      
      public function BattleDepthManager(param1:DisplayObjectContainer)
      {
         super();
         this._container = param1;
         this._registList = new Vector.<IBattleFighter>();
      }
      
      public function register(param1:IBattleFighter) : void
      {
         this._registList.push(param1);
      }
      
      public function remove(param1:IBattleFighter) : void
      {
         var _loc2_:int = this._registList.indexOf(param1);
         if(_loc2_ != -1)
         {
            this._registList.splice(_loc2_,1);
         }
      }
      
      public function sortNow() : void
      {
         var _loc2_:IBattleFighter = null;
         if(this._registList.length < 2)
         {
            return;
         }
         this._registList = this._registList.sort(this.sortFunction);
         var _loc1_:int = 0;
         while(_loc1_ < this._registList.length)
         {
            _loc2_ = this._registList[_loc1_];
            this._container.addChild(_loc2_.avatar as DisplayObject);
            _loc1_++;
         }
      }
      
      private function sortFunction(param1:IBattleFighter, param2:IBattleFighter) : int
      {
         return param1.y - param2.y;
      }
   }
}

