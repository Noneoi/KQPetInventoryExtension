package mmo.battle.ui
{
   import com.greensock.TweenLite;
   import com.greensock.plugins.BlurFilterPlugin;
   import com.greensock.plugins.TweenPlugin;
   import flash.display.MovieClip;
   import flash.display.Sprite;
   import flash.events.TimerEvent;
   import flash.system.ApplicationDomain;
   import flash.utils.Timer;
   import mmo.common.DisplayUtil;
   import mmo.common.NumberUtil;
   import mmo.loader.LoaderContainer;
   import mmo.loader.layer.LayerManager;
   
   public class BattleMultiHitEffectUI
   {
      
      private static const RES_CLS:String = "mmo.battle.common.MultiHitEffectUIRes";
      
      private static const CUR_HIT_NUM_CLS:String = "mmo.battle.common.CurHitNumRes";
      
      private static const RED_SCREEN_CLS:String = "mmo.battle.common.RedScreenRes";
      
      private static const TOTAL_HEALTH_DAMAGE_CLS:String = "mmo.battle.common.digit.HealthDamageNum";
      
      private static const TOTAL_HEALTH_DAMAGE_UNIT_CLS:String = "mmo.battle.common.digit.HealthDamageUnit";
      
      private static const TOTAL_SHIELD_DAMAGE_CLS:String = "mmo.battle.common.digit.ShieldDamageNum";
      
      private static const TOTAL_SHIELD_DAMAGE_UNIT_CLS:String = "mmo.battle.common.digit.ShieldDamageUnit";
      
      private static const MIN_GAP_TO_SCREEN_H:Number = 200;
      
      private static const MIN_GAP_TO_SCREEN_V:Number = 175;
      
      private static const OFFSET_TO_SECONDARY:Number = -45;
      
      private var _domain:ApplicationDomain;
      
      private var _resSprite:Sprite;
      
      private var _curHitNumContainer:Sprite;
      
      private var _multiHitWord:MovieClip;
      
      private var _locatedSpot:Sprite;
      
      private var _hpDamageContainer:Sprite;
      
      private var _spDamageContainer:Sprite;
      
      private var _redMC:MovieClip;
      
      private var _alreadyHitNum:int = 0;
      
      private var _totalHitNum:int = 0;
      
      private var _totalHpChange:int = 0;
      
      private var _totalSpChange:int = 0;
      
      private var _tarX:Number;
      
      private var _tarY:Number;
      
      private var _alreadyShowIndex:Array = [];
      
      public function BattleMultiHitEffectUI(param1:ApplicationDomain, param2:int)
      {
         super();
         this._domain = param1;
         this._totalHitNum = param2;
      }
      
      public function showOneHit(param1:int, param2:int, param3:Sprite, param4:Number, param5:Number, param6:int) : void
      {
         if(this._alreadyShowIndex.indexOf(param6) == -1)
         {
            ++this._alreadyHitNum;
            this._totalHpChange += param1;
            this._totalSpChange += param2;
            this._alreadyShowIndex.push(param6);
            if(this._totalHitNum > 1)
            {
               this.setRedScreen();
            }
         }
         if(this._alreadyHitNum == 1)
         {
            return;
         }
         if(this._alreadyHitNum == 2)
         {
            this.showEnterTween(param1,param2,param3,param4,param5);
         }
         this.showOneHitHelper(param1,param2);
      }
      
      public function get totalHitNum() : int
      {
         return this._totalHitNum;
      }
      
      public function set totalHitNum(param1:int) : void
      {
         this._totalHitNum = param1;
         if(this._totalHitNum <= this._alreadyHitNum)
         {
            this.showExitTween();
         }
      }
      
      private function showOneHitHelper(param1:int, param2:int) : void
      {
         this.showCurTween(param1,param2);
         if(this._totalHitNum <= this._alreadyHitNum)
         {
            this.showExitTween();
         }
      }
      
      private function showEnterTween(param1:int, param2:int, param3:Sprite, param4:Number, param5:Number) : void
      {
         var hpDamage:int = param1;
         var spDamage:int = param2;
         var container:Sprite = param3;
         var x:Number = param4;
         var y:Number = param5;
         this.initComponent();
         this.setUIDisplayParam(container,x,y);
         this.setTarXY(this._resSprite.x,this._resSprite.y);
         TweenPlugin.activate([BlurFilterPlugin]);
         TweenLite.to(this._resSprite,1,{
            "useFrames":true,
            "blurFilter":{"blurX":30},
            "scaleX":1.5,
            "scaleY":1.5,
            "onComplete":function():void
            {
               TweenLite.to(_resSprite,3,{
                  "useFrames":true,
                  "scaleX":1,
                  "scaleY":1,
                  "x":_tarX,
                  "y":_tarY,
                  "blurFilter":{"blurX":0}
               });
            }
         });
      }
      
      private function showCurTween(param1:int, param2:int) : void
      {
         this.setupHitNum();
         this.setupTotalHpDamageNum();
         this.setupTotalSpDamageNum();
         this.setupMultiHitWord();
      }
      
      private function setupHitNum() : void
      {
         this.clearContainerHelper(this._curHitNumContainer);
         var _loc1_:Class = this._domain.getDefinition(CUR_HIT_NUM_CLS) as Class;
         var _loc2_:Sprite = new _loc1_() as Sprite;
         var _loc3_:Sprite = NumberUtil.instance.getArtNum2(_loc2_,this._alreadyHitNum,-10,true,this._domain);
         this._curHitNumContainer.addChild(_loc3_);
      }
      
      private function setupTotalHpDamageNum() : void
      {
         this.clearContainerHelper(this._hpDamageContainer);
         if(this._totalHpChange == 0 && this._totalSpChange != 0)
         {
            return;
         }
         var _loc1_:BattleMultiHitEffectDamageUI = new BattleMultiHitEffectDamageUI(this._domain,TOTAL_HEALTH_DAMAGE_UNIT_CLS,TOTAL_HEALTH_DAMAGE_CLS);
         _loc1_.setDamage(this._totalHpChange);
         _loc1_.show(this._hpDamageContainer);
      }
      
      private function setupTotalSpDamageNum() : void
      {
         this.clearContainerHelper(this._spDamageContainer);
         if(this._totalSpChange == 0)
         {
            return;
         }
         var _loc1_:BattleMultiHitEffectDamageUI = new BattleMultiHitEffectDamageUI(this._domain,TOTAL_SHIELD_DAMAGE_UNIT_CLS,TOTAL_SHIELD_DAMAGE_CLS);
         _loc1_.setDamage(this._totalSpChange);
         _loc1_.show(this._spDamageContainer);
         if(this._totalHpChange != 0)
         {
            this._spDamageContainer.y = this._locatedSpot.y + OFFSET_TO_SECONDARY;
         }
      }
      
      private function setupMultiHitWord() : void
      {
         this._multiHitWord.gotoAndPlay(1);
      }
      
      private function setRedScreen() : void
      {
         var resCls:Class = null;
         if(this._redMC == null)
         {
            resCls = this._domain.getDefinition(RED_SCREEN_CLS) as Class;
            this._redMC = new resCls() as MovieClip;
            this._redMC.addFrameScript(this._redMC.totalFrames - 1,function():void
            {
               DisplayUtil.stopAndRemove(_redMC);
            });
         }
         LayerManager.getFightingTop().addChild(this._redMC);
         this._redMC.gotoAndPlay(1);
      }
      
      private function clearContainerHelper(param1:Sprite) : void
      {
         while(param1.numChildren > 0)
         {
            param1.removeChildAt(0);
         }
      }
      
      private function setUIDisplayParam(param1:Sprite, param2:Number, param3:Number) : void
      {
         var _loc4_:int = 0;
         if(this._resSprite.parent != param1)
         {
            param1.addChild(this._resSprite);
         }
         this._resSprite.x = param2;
         this._resSprite.y = param3;
         _loc4_ = 0;
         while(_loc4_ < param1.numChildren)
         {
            if(param1.getChildAt(_loc4_) != this._resSprite && param1.getChildAt(_loc4_).y == param3)
            {
               this._resSprite.y += 30;
               break;
            }
            _loc4_++;
         }
      }
      
      private function setTarXY(param1:Number, param2:Number) : void
      {
         this._tarX = param1;
         this._tarY = param2;
         var _loc3_:Number = MIN_GAP_TO_SCREEN_H;
         var _loc4_:Number = Number(LoaderContainer.stageWidth);
         if(this._tarX < _loc3_)
         {
            this._tarX = _loc3_;
         }
         else if(this._tarX > _loc4_)
         {
            this._tarX = _loc4_;
         }
         var _loc5_:Number = MIN_GAP_TO_SCREEN_V;
         var _loc6_:Number = Number(LoaderContainer.stageHeight);
         if(this._tarY < _loc5_)
         {
            this._tarY = _loc5_;
         }
         else if(this._tarY > _loc6_)
         {
            this._tarY = _loc6_;
         }
      }
      
      private function showExitTween() : void
      {
         var waitTimer:Timer = null;
         this.setTarXY(this._resSprite.x - 20,this._resSprite.y);
         TweenPlugin.activate([BlurFilterPlugin]);
         waitTimer = new Timer(2000,1);
         waitTimer.addEventListener(TimerEvent.TIMER_COMPLETE,function fun(param1:TimerEvent):void
         {
            waitTimer.stop();
            waitTimer.removeEventListener(TimerEvent.TIMER_COMPLETE,fun);
            clearContainerHelper(_curHitNumContainer);
            clearContainerHelper(_hpDamageContainer);
            TweenLite.to(_resSprite,3,{
               "useFrames":true,
               "x":_tarX,
               "blurFilter":{"blurX":30},
               "onComplete":disposeComponent
            });
         });
         waitTimer.start();
      }
      
      private function initComponent() : void
      {
         var cls:Class = this._domain.getDefinition(RES_CLS) as Class;
         this._resSprite = new cls() as Sprite;
         this._curHitNumContainer = this._resSprite.getChildByName("hitnum") as Sprite;
         this._locatedSpot = this._resSprite.getChildByName("damagespot") as Sprite;
         this._hpDamageContainer = new Sprite();
         this._hpDamageContainer.x = this._locatedSpot.x;
         this._hpDamageContainer.y = this._locatedSpot.y;
         this._resSprite.addChild(this._hpDamageContainer);
         this._spDamageContainer = new Sprite();
         this._spDamageContainer.x = this._locatedSpot.x;
         this._spDamageContainer.y = this._locatedSpot.y;
         this._resSprite.addChild(this._spDamageContainer);
         this._multiHitWord = this._resSprite.getChildByName("hitword") as MovieClip;
         this._multiHitWord.gotoAndStop(1);
         this._multiHitWord.addFrameScript(this._multiHitWord.totalFrames - 1,function():void
         {
            _multiHitWord.gotoAndStop(1);
         });
      }
      
      private function disposeComponent() : void
      {
         DisplayUtil.stopAndRemove(this._resSprite);
         DisplayUtil.stopAndRemove(this._redMC);
      }
   }
}

