package mmo.battle.command.attack.close
{
   import flash.display.MovieClip;
   import mmo.battle.entity.BattleBase;
   import mmo.battle.util.BattleContentUtil;
   import mmo.battle.util.BattleUtil;
   import mmo.interfaces.battle.consts.AvatarActionDefine;
   import mmo.interfaces.battle.data.RoundResult;
   import mmo.interfaces.battle.fighter.IBattleFighter;
   import mmo.util.command.ISceneCommand;
   import mmo.util.command.SceneSimpleCommand;
   
   public class ReturnCommand extends SceneSimpleCommand implements ISceneCommand
   {
      
      private var _content:Object;
      
      private var _source:IBattleFighter;
      
      public function ReturnCommand()
      {
         super();
      }
      
      override public function execute(param1:Object) : void
      {
         this._content = param1;
         this._source = BattleContentUtil.getContentProperty(param1,BattleContentUtil.PN_SOURCE_FIGHTER);
         var _loc2_:RoundResult = BattleContentUtil.getContentProperty(param1,BattleContentUtil.PN_ROUND_RESULT);
         if(BattleUtil.getEffectSkillResultNum(_loc2_.targetSkillResults) == 0)
         {
            this.succeed(this._content);
            this._content = null;
            return;
         }
         var _loc3_:Number = BattleContentUtil.getContentProperty(param1,BattleContentUtil.PN_FIGHTER_ORG_X);
         var _loc4_:Number = BattleContentUtil.getContentProperty(param1,BattleContentUtil.PN_FIGHTER_ORG_Y);
         this._source.jumpTo(_loc3_,_loc4_,this.onJumpEnd);
      }
      
      private function onJumpEnd() : void
      {
         var _loc1_:MovieClip = this._source.doAction(AvatarActionDefine.STAND);
         BattleContentUtil.setContentProperty(this._content,BattleContentUtil.PN_TIME_LINE,_loc1_);
         var _loc2_:BattleBase = BattleContentUtil.getContentProperty(this._content,BattleContentUtil.PN_BATTLE);
         _loc2_.reorderAllPlayer();
         this.succeed(this._content);
         this._content = null;
      }
   }
}

