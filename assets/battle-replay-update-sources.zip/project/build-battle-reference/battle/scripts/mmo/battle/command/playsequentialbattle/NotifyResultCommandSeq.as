package mmo.battle.command.playsequentialbattle
{
   import flash.events.EventDispatcher;
   import mmo.battle.resultpanel.BattleFailPanel;
   import mmo.battle.resultpanel.GainExpPanel;
   import mmo.battle.util.BattleContentUtil;
   import mmo.common.ModalDialog;
   import mmo.common.ModalDialogEvent;
   import mmo.common.dialog.NewDialog;
   import mmo.framework.comm.SocketClient;
   import mmo.interfaces.ServiceContainer;
   import mmo.interfaces.battle.data.BattleInfo;
   import mmo.interfaces.battle.data.PlayerInfo;
   import mmo.interfaces.battle.data.TeamInfo;
   import mmo.interfaces.battle.entity.IBattle;
   import mmo.interfaces.battle.events.BattleEvent;
   import mmo.interfaces.user.IUserNameManager;
   import mmo.util.command.ISceneCommand;
   import mmo.util.command.SceneSimpleCommand;
   
   public class NotifyResultCommandSeq extends SceneSimpleCommand implements ISceneCommand
   {
      
      private static const PK_FAIL_PANEL_CLS:String = "mmo.battle.common.BattlePkLosePanelRes";
      
      private var _content:Object;
      
      private var _battles:Array;
      
      private var _lastBattle:IBattle;
      
      private var _winerTeamId:int;
      
      private var _isCurUserWiner:Boolean;
      
      public function NotifyResultCommandSeq()
      {
         super();
      }
      
      override public function execute(param1:Object) : void
      {
         this._content = param1;
         this._battles = BattleContentUtil.getContentProperty(param1,BattleContentUtil.PN_BATTLES);
         this._lastBattle = this._battles[this._battles.length - 1] as IBattle;
         this._winerTeamId = this._lastBattle.battleResult.winerTeamId;
         this._isCurUserWiner = this.isCurUserWiner();
         BattleContentUtil.setContentProperty(param1,BattleContentUtil.PN_IS_CUR_USER_WINNER,this._isCurUserWiner);
         var _loc2_:EventDispatcher = BattleContentUtil.getContentProperty(param1,BattleContentUtil.PN_EVENT_DISPATCHER);
         if(_loc2_.hasEventListener(BattleEvent.RESULT_NOTIFICATION))
         {
            _loc2_.dispatchEvent(new BattleEvent(BattleEvent.RESULT_NOTIFICATION,{
               "isWin":this._isCurUserWiner,
               "wi":this._winerTeamId,
               "callback":this.onResultNotifyCallback
            }));
         }
         else
         {
            this.showResultDefault();
         }
      }
      
      private function showResultDefault(param1:String = "", param2:* = "") : void
      {
         if(this._winerTeamId == -1)
         {
            this.showMessage("战成平手");
         }
         else if(this._isCurUserWiner)
         {
            this.handleWinBattle(param1);
         }
         else if(this.isCurUserLoser())
         {
            this.handleLoseBattle(param2);
         }
         else
         {
            this.showMessage("战斗结束");
         }
      }
      
      private function handleWinBattle(param1:String) : void
      {
         var _loc2_:GainExpPanel = new GainExpPanel(this._content,this.onResultNotifyCallback,param1);
         _loc2_.show();
      }
      
      private function handleLoseBattle(param1:String) : void
      {
         var _loc2_:BattleFailPanel = new BattleFailPanel(this._content,this.onResultNotifyCallback,param1);
         _loc2_.show();
      }
      
      private function showMessage(param1:String) : void
      {
         var message:String = param1;
         NewDialog.getCofirmDialog(message,function(param1:ModalDialog):void
         {
            var dialog:ModalDialog = param1;
            dialog.addEventListener(ModalDialogEvent.CLOSE,function(param1:ModalDialogEvent):void
            {
               succeed(_content);
            });
            dialog.show();
         });
      }
      
      private function isCurUserWiner() : Boolean
      {
         return this.isCurUserInTeam(this._winerTeamId);
      }
      
      private function isCurUserLoser() : Boolean
      {
         var _loc1_:int = 1 - this._winerTeamId;
         return this.isCurUserInTeam(_loc1_);
      }
      
      private function isCurUserInTeam(param1:int) : Boolean
      {
         var _loc6_:PlayerInfo = null;
         var _loc2_:BattleInfo = this._lastBattle.battleResult.battleInfo;
         var _loc3_:TeamInfo = _loc2_.getTeamInfoById(param1);
         if(_loc3_ == null)
         {
            return false;
         }
         var _loc4_:IUserNameManager = ServiceContainer.getService(IUserNameManager) as IUserNameManager;
         var _loc5_:String = _loc4_.getNickName(SocketClient.instance.myUserName);
         for each(_loc6_ in _loc3_.playerInfos)
         {
            if(_loc6_.playerName == _loc5_)
            {
               return true;
            }
         }
         return false;
      }
      
      private function onResultNotifyCallback(param1:Boolean = false, param2:String = "", param3:String = "") : void
      {
         if(param1)
         {
            this.showResultDefault(param2,param3);
         }
         else
         {
            this.succeed(this._content);
            this._content = null;
         }
      }
   }
}

