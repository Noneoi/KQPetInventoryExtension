package mmo.battle.command.attack.common
{
   import flash.display.FrameLabel;
   import flash.display.MovieClip;
   import flash.geom.Point;
   import flash.system.ApplicationDomain;
   import mmo.battle.command.attack.consts.ActionFrameLabels;
   import mmo.battle.command.attack.consts.EffectFrameLabels;
   import mmo.battle.command.attack.consts.EffectSplitData;
   import mmo.battle.consts.BubbleConsts;
   import mmo.battle.consts.BufferConsts;
   import mmo.battle.container.BattleContainer;
   import mmo.battle.entity.BattleBase;
   import mmo.battle.entity.BattleSimpleResManager;
   import mmo.battle.helper.BattleEffectHelper;
   import mmo.battle.ui.BattleMultiHitEffectUI;
   import mmo.battle.util.BattleContentUtil;
   import mmo.battle.util.BattleUtil;
   import mmo.common.CommonUtil;
   import mmo.common.DisplayUtil;
   import mmo.interfaces.ServiceContainer;
   import mmo.interfaces.battle.avatar.AvatarPosTypes;
   import mmo.interfaces.battle.consts.AvatarActionDefine;
   import mmo.interfaces.battle.consts.AvatarEffectIds;
   import mmo.interfaces.battle.data.BattleInfo;
   import mmo.interfaces.battle.data.PlayerInfo;
   import mmo.interfaces.battle.data.RoundResult;
   import mmo.interfaces.battle.data.SkillNumResult;
   import mmo.interfaces.battle.data.SkillResult;
   import mmo.interfaces.battle.fighter.IBattleFighter;
   import mmo.interfaces.battle.player.IBattlePlayer;
   import mmo.interfaces.battleconfig.IBattleConfig;
   import mmo.interfaces.battleconfig.consts.RaceTypePriority;
   import mmo.interfaces.battleconfig.define.RaceTypeDefine;
   import mmo.interfaces.battleconfig.define.SkillDefine;
   import mmo.interfaces.pet.data.IPetDictionaryDataService;
   import mmo.interfaces.pet.data.PetJob;
   import mmo.loader.layer.LayerManager;
   import mmo.play.camera.CameraController;
   import mmo.util.command.ISceneCommand;
   import mmo.util.command.SceneSimpleCommand;
   
   public class PlayEffectCommand extends SceneSimpleCommand implements ISceneCommand
   {
      
      private static const RED_SCREEN_CLS:String = "mmo.battle.common.RedScreenRes";
      
      private var _content:Object;
      
      private var _domain:ApplicationDomain;
      
      private var _result:RoundResult;
      
      private var _timeline:MovieClip;
      
      private var _battle:BattleBase;
      
      private var _battleConfig:IBattleConfig;
      
      private var _sourcePlayer:IBattlePlayer;
      
      private var _sourceFighter:IBattleFighter;
      
      private var _container:BattleContainer;
      
      private var _effectSemaphore:int = 0;
      
      private var _isSourceNumResultPlayed:Boolean = false;
      
      private var _redMC:MovieClip;
      
      private var _effectSkillResultNum:int = 0;
      
      public function PlayEffectCommand()
      {
         super();
      }
      
      override public function execute(param1:Object) : void
      {
         var _loc8_:String = null;
         this._content = param1;
         this._timeline = BattleContentUtil.getContentProperty(param1,BattleContentUtil.PN_TIME_LINE);
         this._domain = BattleContentUtil.getContentProperty(param1,BattleContentUtil.PN_DOMAIN);
         this._result = BattleContentUtil.getContentProperty(param1,BattleContentUtil.PN_ROUND_RESULT);
         this._container = BattleContentUtil.getContentProperty(param1,BattleContentUtil.PN_CONTAINER);
         if(BattleUtil.getEffectSkillResultNum(this._result.targetSkillResults) == 0)
         {
            this.succeed(this._content);
            this._content = null;
            return;
         }
         this._battle = BattleContentUtil.getContentProperty(param1,BattleContentUtil.PN_BATTLE);
         this._battleConfig = BattleContentUtil.getContentProperty(param1,BattleContentUtil.PN_BATTLE_CONFIG);
         this._sourcePlayer = BattleContentUtil.getContentProperty(param1,BattleContentUtil.PN_SOURCE_PLAYER);
         this._sourceFighter = BattleContentUtil.getContentProperty(param1,BattleContentUtil.PN_SOURCE_FIGHTER);
         var _loc2_:int = int(CommonUtil.getFrameByName(this._timeline,ActionFrameLabels.EFFECT));
         if(_loc2_ == -1)
         {
            _loc2_ = BattleContentUtil.getContentProperty(param1,BattleContentUtil.PN_EFFECT_FRAME);
         }
         if(_loc2_ == 0)
         {
            _loc8_ = "Missing frame label \"eff\" in effect fla";
            BattleContentUtil.setContentProperty(param1,BattleContentUtil.PN_ERROR_MSG,_loc8_);
            this.fail(this._content);
            this._content = null;
            return;
         }
         var _loc3_:BattleSimpleResManager = BattleContentUtil.getContentProperty(this._content,BattleContentUtil.SIMPLE_RES_DATA);
         var _loc4_:BattleInfo = BattleContentUtil.getContentProperty(this._content,BattleContentUtil.PN_BATTLE_INFO);
         var _loc5_:int = int(this._sourceFighter.info.belong2PlayerIndex);
         var _loc6_:PlayerInfo = _loc4_.teamInfos[this._sourceFighter.needFlip ? 1 : 0].playerInfos[_loc5_];
         var _loc7_:Boolean = _loc3_.checkShouldBeSimpleResBySourceFighter(this._content,this._sourceFighter,_loc6_.playerName);
         if(_loc7_)
         {
            this.onEffectFrame();
         }
         else if(this._timeline.totalFrames < _loc2_)
         {
            this._timeline.addFrameScript(this._timeline.totalFrames - 2,this.onEffectFrame);
         }
         else
         {
            this._timeline.addFrameScript(_loc2_ - 1,this.onEffectFrame);
         }
      }
      
      private function onEffectFrame() : void
      {
         var _loc9_:SkillResult = null;
         var _loc10_:String = null;
         var _loc11_:int = 0;
         var _loc12_:IBattlePlayer = null;
         var _loc13_:IBattleFighter = null;
         var _loc14_:Boolean = false;
         var _loc15_:MovieClip = null;
         var _loc16_:BattleEffectHelper = null;
         var _loc17_:Object = null;
         var _loc18_:Array = null;
         var _loc19_:EffectSplitData = null;
         var _loc20_:BattleMultiHitEffectUI = null;
         var _loc21_:int = 0;
         var _loc22_:FrameLabel = null;
         var _loc23_:Array = null;
         var _loc24_:int = 0;
         var _loc1_:int = BattleContentUtil.getContentProperty(this._content,BattleContentUtil.PN_EFFECT_FRAME);
         var _loc2_:BattleSimpleResManager = BattleContentUtil.getContentProperty(this._content,BattleContentUtil.SIMPLE_RES_DATA);
         var _loc3_:BattleInfo = BattleContentUtil.getContentProperty(this._content,BattleContentUtil.PN_BATTLE_INFO);
         var _loc4_:int = int(this._sourceFighter.info.belong2PlayerIndex);
         var _loc5_:PlayerInfo = _loc3_.teamInfos[this._sourceFighter.needFlip ? 1 : 0].playerInfos[_loc4_];
         var _loc6_:Boolean = _loc2_.checkShouldBeSimpleResBySourceFighter(this._content,this._sourceFighter,_loc5_.playerName);
         if(!_loc6_)
         {
            if(this._timeline.totalFrames < _loc1_)
            {
               this._timeline.addFrameScript(this._timeline.totalFrames - 2,null);
            }
            else
            {
               this._timeline.addFrameScript(_loc1_ - 1,null);
            }
         }
         var _loc7_:SkillDefine = BattleContentUtil.getContentProperty(this._content,BattleContentUtil.PN_SKILLDEFINE);
         var _loc8_:Boolean = true;
         for each(_loc9_ in this._result.targetSkillResults)
         {
            if(_loc9_.effect)
            {
               _loc8_ = false;
               ++this._effectSkillResultNum;
               _loc10_ = _loc9_.targetPlayerName;
               _loc11_ = int(_loc9_.targetCharacterId);
               _loc12_ = this._battle.getPlayerByName(_loc10_);
               _loc13_ = _loc12_.getFighterById(_loc11_);
               _loc14_ = false;
               if(Boolean(this._result.isLastRound) && Boolean(_loc7_.hasLastEffect))
               {
                  _loc14_ = true;
               }
               _loc15_ = _loc13_.showSkillEffect(this._result.skillId,_loc14_,this.onEffectEnd,!BattleSimpleResManager.isMyFormationByUsername(_loc5_.playerName));
               _loc16_ = new BattleEffectHelper();
               _loc17_ = _loc16_.buildContent(_loc9_.targetTeamId);
               _loc16_.handleElementsName(_loc15_,_loc17_);
               _loc18_ = _loc15_.currentLabels;
               if(_loc18_ == null || _loc18_.length == 0)
               {
                  throw new Error("Unexpected bubble label in battleeffect" + this._result.skillId);
               }
               _loc19_ = EffectSplitData.valueFrom(_loc9_,_loc18_.length);
               _loc20_ = new BattleMultiHitEffectUI(this._domain,_loc18_.length);
               _loc21_ = 0;
               while(_loc21_ < _loc18_.length)
               {
                  _loc22_ = _loc18_[_loc21_];
                  if(_loc22_.name.indexOf(EffectFrameLabels.BUBBLE) == -1)
                  {
                     --_loc20_.totalHitNum;
                  }
                  else
                  {
                     _loc23_ = [];
                     _loc24_ = _loc22_.frame - 1;
                     if(_loc24_ >= _loc15_.totalFrames - 1)
                     {
                        _loc24_ = _loc15_.totalFrames - 2;
                     }
                     _loc15_.addFrameScript(_loc24_,this.onBubbleFrame(_loc12_,_loc13_,_loc9_,_loc19_.hpChangeArr[_loc21_],_loc19_.powerChangeArr[_loc21_],_loc20_,_loc24_,_loc23_,_loc19_.spChangeArr[_loc21_]));
                  }
                  _loc21_++;
               }
            }
         }
         if(_loc8_)
         {
            this.succeed(this._content);
            this._content = null;
         }
      }
      
      private function onEffectEnd(param1:IBattleFighter) : void
      {
         var targetFighter:IBattleFighter = param1;
         ++this._effectSemaphore;
         if(targetFighter.info.curHp <= 0)
         {
            targetFighter.fadeOut(function():void
            {
               if(targetFighter.curHp > 0)
               {
                  targetFighter.showUp();
               }
            });
         }
         if(this._sourceFighter.info.curHp <= 0)
         {
            this._sourceFighter.fadeOut(function():void
            {
               if(_sourceFighter.curHp > 0)
               {
                  _sourceFighter.showUp();
               }
            });
         }
         if(this._effectSemaphore == this._effectSkillResultNum)
         {
            BattleContentUtil.setContentProperty(this._content,BattleContentUtil.PN_TIME_LINE,this._sourceFighter.curActionTimeline);
            this.succeed(this._content);
            this._content = null;
         }
      }
      
      private function onBubbleFrame(param1:IBattlePlayer, param2:IBattleFighter, param3:SkillResult, param4:Number, param5:int, param6:BattleMultiHitEffectUI, param7:int, param8:Array, param9:Number) : Function
      {
         var targetPlayer:IBattlePlayer = param1;
         var targetFighter:IBattleFighter = param2;
         var skillResult:SkillResult = param3;
         var hpChange:Number = param4;
         var powerChange:int = param5;
         var multiHitEffectUI:BattleMultiHitEffectUI = param6;
         var frameIndex:int = param7;
         var frameRecordArr:Array = param8;
         var spChange:Number = param9;
         var fun:Function = function():void
         {
            var skillDefine:SkillDefine;
            var angle:int = 0;
            var beHitMC:MovieClip = null;
            var playerDeltaPos:Point = null;
            var tarUIPos:Point = null;
            if(frameRecordArr.indexOf(frameIndex) != -1)
            {
               return;
            }
            frameRecordArr.push(frameIndex);
            skillDefine = BattleContentUtil.getContentProperty(_content,BattleContentUtil.PN_SKILLDEFINE);
            handleHpAndPowerChanges(skillResult,targetPlayer,targetFighter,hpChange,powerChange,spChange);
            if(skillResult.miss)
            {
               targetFighter.showEffect(AvatarEffectIds.MISS,null);
               targetFighter.slideBackward(null);
            }
            else if(skillResult.immunity)
            {
               targetFighter.showEffect(AvatarEffectIds.IMMUNITY,null);
               targetFighter.slideBackward(null);
            }
            else
            {
               if(skillResult.block)
               {
                  targetFighter.showEffect(AvatarEffectIds.BLOCK_EFFECT,null);
                  targetFighter.showEffect(AvatarEffectIds.BLOCK,null);
               }
               if(skillResult.critical)
               {
                  targetFighter.showEffect(AvatarEffectIds.CRITICAL,null);
                  angle = (Math.random() - 0.5) * 180;
                  CameraController.instance.shockScreen(15,angle);
                  setRedScreen();
               }
               if(hpChange < 0 || spChange < 0)
               {
                  beHitMC = targetFighter.doAction(AvatarActionDefine.BE_HIT);
                  BattleContentUtil.setContentProperty(_content,BattleContentUtil.PN_TIME_LINE,beHitMC);
                  beHitMC.addFrameScript(beHitMC.totalFrames - 1,function():void
                  {
                     if(targetFighter.curActionId != AvatarActionDefine.BE_HIT)
                     {
                        return;
                     }
                     var _loc1_:MovieClip = targetFighter.doAction(AvatarActionDefine.STAND);
                     if(_content != null)
                     {
                        BattleContentUtil.setContentProperty(_content,BattleContentUtil.PN_TIME_LINE,_loc1_);
                     }
                  });
                  playerDeltaPos = targetFighter.avatar.getAvatarPos(AvatarPosTypes.TOP);
                  tarUIPos = new Point(targetFighter.x + playerDeltaPos.x,targetFighter.y + playerDeltaPos.y);
                  multiHitEffectUI.showOneHit(hpChange,spChange,_container,tarUIPos.x,tarUIPos.y,frameIndex);
               }
               if(skillDefine.shockScreen)
               {
                  CameraController.instance.shockScreen(15,angle);
               }
            }
         };
         return fun;
      }
      
      private function setRedScreen() : void
      {
         var resCls:Class = null;
         if(this._redMC == null)
         {
            resCls = this._domain.getDefinition(RED_SCREEN_CLS) as Class;
            this._redMC = new resCls() as MovieClip;
            this._redMC.addFrameScript(this._redMC.totalFrames - 1,function():void
            {
               DisplayUtil.stopAndRemove(_redMC);
            });
         }
         LayerManager.getFightingTop().addChild(this._redMC);
         this._redMC.gotoAndPlay(1);
      }
      
      private function handleHpAndPowerChanges(param1:SkillResult, param2:IBattlePlayer, param3:IBattleFighter, param4:Number, param5:int, param6:Number) : void
      {
         var _loc11_:Number = NaN;
         var _loc12_:Boolean = false;
         var _loc13_:int = 0;
         var _loc14_:int = 0;
         var _loc15_:RaceTypeDefine = null;
         this.playSourceSkillNumResult();
         if(param1.numResult == null)
         {
            return;
         }
         var _loc7_:Boolean = this.isIgnoreAttRestraint(param1);
         if(!_loc7_)
         {
            _loc11_ = BattleUtil.getRestraintCoefficient(this._sourceFighter,param3,this._battleConfig);
            if(_loc11_ <= this._battleConfig.weakEffRestraintCoeff)
            {
               param3.showEffect(AvatarEffectIds.WEAK_EFFECT,null);
            }
            else if(_loc11_ >= this._battleConfig.strongEffRestraintCoeff)
            {
               _loc12_ = false;
               _loc13_ = 0;
               while(_loc13_ < this._sourceFighter.info.raceTypeIds.length)
               {
                  _loc14_ = int(this._sourceFighter.info.raceTypeIds[_loc13_]);
                  _loc15_ = this._battleConfig.getRaceTypeDefineById(_loc14_);
                  if(_loc15_.priority == RaceTypePriority.GOD || _loc15_.priority == RaceTypePriority.TRANSFORM)
                  {
                     _loc12_ = true;
                     param3.showEffect(AvatarEffectIds.STRONG_EFFECT + _loc14_,null);
                  }
                  _loc13_++;
               }
               if(!_loc12_)
               {
                  param3.showEffect(AvatarEffectIds.STRONG_EFFECT,null);
               }
            }
         }
         var _loc8_:Boolean = Boolean(PetJob.valueOfId(this._sourceFighter.info.jobTypeId).isGodJob());
         var _loc9_:Boolean = Boolean(PetJob.valueOfId(param3.info.jobTypeId).isGodJob());
         if(_loc8_ != _loc9_)
         {
            if(_loc8_)
            {
               this._sourceFighter.showEffect(AvatarEffectIds.SUPER_JOB_ATTACK,null);
            }
            else
            {
               param3.showEffect(AvatarEffectIds.SUPER_JOB_ATTACKED,null,true);
            }
         }
         if(param1.numResult.attackHps.length > 0 || param1.numResult.attackSps.length > 0)
         {
            if(_loc7_)
            {
               param3.showBubble(this._sourceFighter.info,param6 != 0 ? param6 : param4,_loc11_ + 0.1,null,0,param6 != 0 ? BufferConsts.ShieldBuffId : 0);
            }
            else
            {
               param3.showBubble(this._sourceFighter.info,param6 != 0 ? param6 : param4,_loc11_,null,0,param6 != 0 ? BufferConsts.ShieldBuffId : 0);
            }
         }
         var _loc10_:IPetDictionaryDataService = ServiceContainer.getService(IPetDictionaryDataService);
         if(_loc12_ && param3.curHp + param4 <= 0 && Boolean(_loc10_.getDataItemByRaceId(this._sourceFighter.info.raceId).isTianQi()))
         {
            this._sourceFighter.showEffect(AvatarEffectIds.TIAN_QI_EFFECT + int(this._sourceFighter.info.raceTypeIds[0]) % 10000,null);
         }
         param3.curHp += param4;
         param3.curSp += param6;
         param3.curPower += param5;
      }
      
      private function isIgnoreAttRestraint(param1:SkillResult) : Boolean
      {
         var _loc4_:String = null;
         var _loc5_:Array = null;
         var _loc6_:int = 0;
         var _loc2_:Array = param1.numResult.getAllChangeSetIdArrValueByProName(SkillNumResult.beforeDisplayBuff_Key);
         var _loc3_:Boolean = false;
         for each(_loc4_ in _loc2_)
         {
            _loc5_ = _loc4_.split("_");
            _loc6_ = int(_loc5_[1]);
            if(BufferConsts.Ignore_Att_Restraint_BuffIds.indexOf(_loc6_) != -1)
            {
               _loc3_ = true;
               break;
            }
         }
         return _loc3_;
      }
      
      private function playSourceSkillNumResult() : void
      {
         var _loc3_:int = 0;
         var _loc6_:Number = NaN;
         var _loc7_:int = 0;
         if(this._isSourceNumResultPlayed || this._result.sourceSkillNumResult == null)
         {
            return;
         }
         this._isSourceNumResultPlayed = true;
         var _loc1_:Array = this._result.sourceSkillNumResult.attackHps;
         var _loc2_:Number = Number(this._sourceFighter.curHp);
         _loc3_ = 0;
         while(_loc3_ < _loc1_.length)
         {
            _loc6_ = Number(_loc1_[_loc3_]);
            this._sourceFighter.showBubble(null,_loc6_,1,null,BubbleConsts.BUBBLE_INTERVAL * _loc3_);
            this._sourceFighter.curHp += _loc6_;
            _loc2_ = Number(this._sourceFighter.curHp);
            _loc3_++;
         }
         var _loc4_:Array = this._result.sourceSkillNumResult.attackSps;
         _loc3_ = 0;
         while(_loc3_ < _loc4_.length)
         {
            this._sourceFighter.curSp += _loc4_[_loc3_];
            _loc3_++;
         }
         var _loc5_:Array = this._result.sourceSkillNumResult.attackPowers;
         _loc3_ = 0;
         while(_loc3_ < _loc5_.length)
         {
            _loc7_ = int(_loc5_[_loc3_]);
            this._sourceFighter.curPower += _loc7_;
            _loc3_++;
         }
      }
   }
}

