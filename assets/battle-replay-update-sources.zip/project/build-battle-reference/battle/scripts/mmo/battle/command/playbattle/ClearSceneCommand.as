package mmo.battle.command.playbattle
{
   import flash.events.EventDispatcher;
   import mmo.battle.util.BattleContentUtil;
   import mmo.common.ProgressFullSprite;
   import mmo.common.utils.panel.floatpanel.FloatPanelManager;
   import mmo.common.utils.panel.modaldialog.ModalDialogManager;
   import mmo.interfaces.battle.events.BattleEvent;
   import mmo.util.command.ISceneCommand;
   import mmo.util.command.SceneSimpleCommand;
   
   public class ClearSceneCommand extends SceneSimpleCommand implements ISceneCommand
   {
      
      public function ClearSceneCommand()
      {
         super();
      }
      
      override public function execute(param1:Object) : void
      {
         ModalDialogManager.getInstance().clearAll();
         FloatPanelManager.getInstance().clearAll();
         ProgressFullSprite.close();
         ProgressFullSprite.show(false);
         var _loc2_:EventDispatcher = BattleContentUtil.getContentProperty(param1,BattleContentUtil.PN_EVENT_DISPATCHER);
         _loc2_.dispatchEvent(new BattleEvent(BattleEvent.ON_BATTLE_INITING));
         this.succeed(param1);
      }
   }
}

