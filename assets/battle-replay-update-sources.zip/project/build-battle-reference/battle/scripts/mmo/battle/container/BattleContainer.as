package mmo.battle.container
{
   import flash.display.Sprite;
   import mmo.common.DisplayUtil;
   import mmo.interfaces.IDispose;
   
   public class BattleContainer extends Sprite implements IDispose
   {
      
      private var _backgroundLayer:Sprite;
      
      private var _fullScreenBuffLayerBelow:Sprite;
      
      private var _movieLayerBelow:Sprite;
      
      private var _floor:Sprite;
      
      private var _fighterLayer:Sprite;
      
      private var _movieLayerAbove:Sprite;
      
      private var _fullScreenBuffLayerAbove:Sprite;
      
      private var _uniqueSkillHideOtherLayer:Sprite;
      
      private var _response2mouseFullScreenFrontLayer:Sprite;
      
      private var _uiLayer:Sprite;
      
      private var _uiLayerBelow:Sprite;
      
      public function BattleContainer()
      {
         super();
         this.initLayers();
      }
      
      public function get response2mouseFullScreenFrontLayer() : Sprite
      {
         return this._response2mouseFullScreenFrontLayer;
      }
      
      public function get floor() : Sprite
      {
         return this._floor;
      }
      
      public function get uniqueSkillHideOtherLayer() : Sprite
      {
         return this._uniqueSkillHideOtherLayer;
      }
      
      public function dispose() : void
      {
         DisplayUtil.stopAndRemove(this);
      }
      
      public function get backgroundLayer() : Sprite
      {
         return this._backgroundLayer;
      }
      
      public function get fullScreenBuffLayerBelow() : Sprite
      {
         return this._fullScreenBuffLayerBelow;
      }
      
      public function get movieLayerBelow() : Sprite
      {
         return this._movieLayerBelow;
      }
      
      public function get fighterLayer() : Sprite
      {
         return this._fighterLayer;
      }
      
      public function get movieLayerAbove() : Sprite
      {
         return this._movieLayerAbove;
      }
      
      public function get fullScreenBuffLayerAbove() : Sprite
      {
         return this._fullScreenBuffLayerAbove;
      }
      
      public function get uiLayer() : Sprite
      {
         return this._uiLayer;
      }
      
      public function get uiLayerBelow() : Sprite
      {
         return this._uiLayerBelow;
      }
      
      private function initLayers() : void
      {
         this._backgroundLayer = new Sprite();
         this._fullScreenBuffLayerBelow = new Sprite();
         this._movieLayerBelow = new Sprite();
         this._fighterLayer = new Sprite();
         this._movieLayerAbove = new Sprite();
         this._fullScreenBuffLayerAbove = new Sprite();
         this._uniqueSkillHideOtherLayer = new Sprite();
         this._floor = new Sprite();
         this._response2mouseFullScreenFrontLayer = new Sprite();
         this._uiLayer = new Sprite();
         this._uiLayerBelow = new Sprite();
         this.addChild(this._backgroundLayer);
         this.addChild(this._fullScreenBuffLayerBelow);
         this.addChild(this._uiLayerBelow);
         this.addChild(this._movieLayerBelow);
         this.addChild(this._floor);
         this.addChild(this._fighterLayer);
         this.addChild(this._movieLayerAbove);
         this.addChild(this._fullScreenBuffLayerAbove);
         this.addChild(this._uniqueSkillHideOtherLayer);
         this.addChild(this._response2mouseFullScreenFrontLayer);
         this.addChild(this._uiLayer);
         this._backgroundLayer.mouseChildren = this._backgroundLayer.mouseEnabled = false;
         this._movieLayerBelow.mouseChildren = this._movieLayerBelow.mouseEnabled = false;
         this._movieLayerAbove.mouseChildren = this._movieLayerAbove.mouseEnabled = false;
         this._fullScreenBuffLayerBelow.mouseChildren = this._fullScreenBuffLayerBelow.mouseEnabled = false;
         this._fullScreenBuffLayerAbove.mouseChildren = this._fullScreenBuffLayerAbove.mouseEnabled = false;
         this._uniqueSkillHideOtherLayer.mouseChildren = this._uniqueSkillHideOtherLayer.mouseEnabled = false;
         this._floor.mouseChildren = this._floor.mouseEnabled = false;
      }
   }
}

