package mmo.battle.command.attack.remote
{
   import com.greensock.TweenLite;
   import flash.display.MovieClip;
   import mmo.battle.avatar.BattleChaserAvatar;
   import mmo.battle.container.BattleContainer;
   import mmo.battle.entity.BattleBase;
   import mmo.battle.fighter.BattleFighter;
   import mmo.battle.helper.BattleActionHelper;
   import mmo.battle.util.BattleContentUtil;
   import mmo.battle.util.BattleUtil;
   import mmo.common.DisplayUtil;
   import mmo.interfaces.battle.consts.AvatarActionDefine;
   import mmo.interfaces.battle.data.RoundResult;
   import mmo.interfaces.battle.data.SkillResult;
   import mmo.interfaces.battle.fighter.IBattleFighter;
   import mmo.interfaces.battle.player.IBattlePlayer;
   import mmo.interfaces.battleconfig.IBattleConfig;
   import mmo.interfaces.battleconfig.define.SkillDefine;
   import mmo.util.command.ISceneCommand;
   import mmo.util.command.SceneSimpleCommand;
   
   public class PlayRemoteActionCommand extends SceneSimpleCommand implements ISceneCommand
   {
      
      private static const EFFECT_NAME_CLS_PREFIX:String = "mmo.effect.EffectName";
      
      private var _content:Object;
      
      private var _timeline:MovieClip;
      
      private var _targetAction_backgrounds:Array = [];
      
      private var _action_fullScreen_Background:MovieClip;
      
      private var _action_fullScreen_Foreground:MovieClip;
      
      private var _result:RoundResult;
      
      private var _battle:BattleBase;
      
      public function PlayRemoteActionCommand()
      {
         super();
      }
      
      override public function execute(param1:Object) : void
      {
         var config:IBattleConfig = null;
         var skillDefine:SkillDefine = null;
         var actionFrame:int = 0;
         var sourceFighter:BattleFighter = null;
         var isUseSimpleEffect:Boolean = false;
         var content:Object = param1;
         this._content = content;
         this._result = BattleContentUtil.getContentProperty(content,BattleContentUtil.PN_ROUND_RESULT);
         this._battle = BattleContentUtil.getContentProperty(content,BattleContentUtil.PN_BATTLE);
         if(BattleUtil.getEffectSkillResultNum(this._result.targetSkillResults) == 0)
         {
            this.succeed(this._content);
            this._content = null;
         }
         else
         {
            config = BattleContentUtil.getContentProperty(content,BattleContentUtil.PN_BATTLE_CONFIG);
            skillDefine = BattleContentUtil.getContentProperty(this._content,BattleContentUtil.PN_SKILLDEFINE);
            actionFrame = int(skillDefine.actionFrame);
            sourceFighter = BattleContentUtil.getContentProperty(content,BattleContentUtil.PN_SOURCE_FIGHTER);
            isUseSimpleEffect = false;
            if(sourceFighter.avatar is BattleChaserAvatar)
            {
               this._timeline = sourceFighter.doAction(actionFrame);
            }
            else
            {
               this._timeline = sourceFighter.doAction(isUseSimpleEffect ? int(AvatarActionDefine.STAND) : actionFrame);
            }
            BattleContentUtil.setContentProperty(content,BattleContentUtil.PN_TIME_LINE,this._timeline);
            if(isUseSimpleEffect)
            {
               BattleContentUtil.setContentProperty(content,BattleContentUtil.PN_TIME_LINE,this._timeline);
               TweenLite.to(this._timeline,3,{
                  "useFrames":true,
                  "scaleX":1.5,
                  "scaleY":1.5,
                  "onComplete":function():*
                  {
                     TweenLite.to(_timeline,3,{
                        "useFrames":true,
                        "scaleX":1,
                        "scaleY":1,
                        "onComplete":function():*
                        {
                           TweenLite.killTweensOf(_timeline);
                        }
                     });
                  }
               });
               this.handleBattleActionHelper();
               this._timeline.gotoAndPlay(this._timeline.totalFrames - 6);
               this._timeline.addFrameScript(this._timeline.totalFrames - 1,this.onActionEnd);
            }
            else
            {
               this.handleBattleActionHelper();
               this._timeline.gotoAndPlay(1);
               this._timeline.addFrameScript(this._timeline.totalFrames - 1,this.onActionEnd);
               this.handleTargetActionBackground(sourceFighter,actionFrame);
               this.handleAction_FullScreen_BackGround(sourceFighter,actionFrame);
               this.handleAction_FullScreen_ForeGround(sourceFighter,actionFrame);
            }
         }
      }
      
      private function handleAction_FullScreen_BackGround(param1:BattleFighter, param2:int) : void
      {
         var _loc3_:BattleContainer = null;
         var _loc4_:BattleActionHelper = null;
         this._action_fullScreen_Background = param1.getAction_FullScreen_BackGround(param2);
         if(this._action_fullScreen_Background != null)
         {
            _loc3_ = BattleContentUtil.getContentProperty(this._content,BattleContentUtil.PN_CONTAINER);
            _loc4_ = new BattleActionHelper();
            _loc4_.handleFrameLabel(this._action_fullScreen_Background,this._content);
            _loc3_.movieLayerBelow.addChild(this._action_fullScreen_Background);
         }
         BattleContentUtil.setContentProperty(this._content,BattleContentUtil.PN_ACTION_FULLSCREEN_BACKGROUD,this._action_fullScreen_Background);
      }
      
      private function handleAction_FullScreen_ForeGround(param1:BattleFighter, param2:int) : void
      {
         var _loc3_:BattleContainer = null;
         var _loc4_:BattleActionHelper = null;
         this._action_fullScreen_Foreground = param1.getAction_FullScreen_ForeGround(param2);
         if(this._action_fullScreen_Foreground != null)
         {
            _loc3_ = BattleContentUtil.getContentProperty(this._content,BattleContentUtil.PN_CONTAINER);
            _loc4_ = new BattleActionHelper();
            _loc4_.handleFrameLabel(this._action_fullScreen_Foreground,this._content);
            _loc3_.movieLayerAbove.addChild(this._action_fullScreen_Foreground);
         }
         BattleContentUtil.setContentProperty(this._content,BattleContentUtil.PN_ACTION_FULLSCREEN_FOREGROUD,this._action_fullScreen_Foreground);
      }
      
      private function handleTargetActionBackground(param1:BattleFighter, param2:int) : void
      {
         var _loc3_:Boolean = false;
         var _loc4_:SkillResult = null;
         var _loc5_:MovieClip = null;
         var _loc6_:IBattlePlayer = null;
         var _loc7_:IBattleFighter = null;
         if(param1.getTargetAction_BackGround(param2) != null)
         {
            _loc3_ = true;
            for each(_loc4_ in this._result.targetSkillResults)
            {
               if(_loc4_.effect)
               {
                  _loc3_ = false;
                  _loc5_ = param1.getTargetAction_BackGround(param2);
                  _loc6_ = this._battle.getPlayerByName(_loc4_.targetPlayerName);
                  _loc7_ = _loc6_.getFighterById(_loc4_.targetCharacterId);
                  _loc7_.avatar.getBufferLayer2().addChild(_loc5_);
                  this._targetAction_backgrounds.push(_loc5_);
               }
            }
            if(_loc3_)
            {
               this.succeed(this._content);
               this._content = null;
            }
         }
      }
      
      private function handleBattleActionHelper() : void
      {
         var _loc1_:BattleActionHelper = new BattleActionHelper();
         _loc1_.handleFrameLabel(this._timeline,this._content);
      }
      
      private function onActionEnd() : void
      {
         this._timeline.addFrameScript(this._timeline.totalFrames - 6,null);
         this._timeline.addFrameScript(this._timeline.totalFrames - 1,null);
         var _loc1_:int = 0;
         while(_loc1_ < this._targetAction_backgrounds.length)
         {
            DisplayUtil.stopAndRemove(this._targetAction_backgrounds[_loc1_]);
            _loc1_++;
         }
         if(this._action_fullScreen_Background != null)
         {
            DisplayUtil.stopAndRemove(this._action_fullScreen_Background);
         }
         if(this._action_fullScreen_Foreground != null)
         {
            DisplayUtil.stopAndRemove(this._action_fullScreen_Foreground);
         }
         var _loc2_:Boolean = false;
         if(!_loc2_)
         {
            this._timeline.stop();
         }
         this.succeed(this._content);
         this._content = null;
      }
   }
}

