package mmo.battle.entity
{
   import mmo.battle.util.BattleContentUtil;
   import mmo.common.user.UserInfo;
   import mmo.interfaces.ServiceContainer;
   import mmo.interfaces.battle.consts.UserBattleConfig;
   import mmo.interfaces.battle.fighter.IBattleFighter;
   import mmo.interfaces.changepetskin.IChangePetSkinService;
   import mmo.interfaces.multipleformpet.IMultipleFormPetService;
   import mmo.interfaces.pet.data.IPetDataService;
   
   public class BattleSimpleResManager
   {
      
      public static const NO_SIMPLE:int = UserBattleConfig.SIMPLE_RES_CTRL_NO;
      
      public static const ONLY_ENEMY_SIMPLE:int = UserBattleConfig.SIMPLE_RES_CTRL_ENEMY_ONLY;
      
      public static const ALL_SIMPLE:int = UserBattleConfig.SIMPLE_RES_CTRL_ALL;
      
      private var _isSimpleRes:Boolean;
      
      private var _isOnlyEnemySimpleRes:Boolean;
      
      private var _simpleResRaceIds:Array;
      
      public function BattleSimpleResManager()
      {
         super();
      }
      
      public static function createNewBattleSimpleResManager() : BattleSimpleResManager
      {
         var _loc1_:BattleSimpleResManager = new BattleSimpleResManager();
         var _loc2_:int = BattleContentUtil.getIsSimpleBattleResType();
         if(_loc2_ == NO_SIMPLE)
         {
            _loc1_._isSimpleRes = false;
            _loc1_._isOnlyEnemySimpleRes = false;
         }
         else if(_loc2_ == ALL_SIMPLE)
         {
            _loc1_._isSimpleRes = true;
            _loc1_._isOnlyEnemySimpleRes = false;
         }
         else
         {
            if(_loc2_ != ONLY_ENEMY_SIMPLE)
            {
               throw new Error("createNewBattleSimpleResManager no such type :" + _loc2_);
            }
            _loc1_._isSimpleRes = false;
            _loc1_._isOnlyEnemySimpleRes = true;
         }
         _loc1_._simpleResRaceIds = (ServiceContainer.getService(IPetDataService) as IPetDataService).getClosedEffectRaceIds();
         return _loc1_;
      }
      
      public static function isMyFormationByUsername(param1:String) : Boolean
      {
         return param1 == "#username#" || param1 == UserInfo.nickName;
      }
      
      public function checkShouldBeSimpleResBySourceFighter(param1:Object, param2:IBattleFighter, param3:String) : Boolean
      {
         if(this.checkShouldBeSimpleResByRaceId(param2.info.getShowRaceIdWithOrigin()))
         {
            return true;
         }
         if(this._isOnlyEnemySimpleRes && !BattleSimpleResManager.isMyFormationByUsername(param3))
         {
            return true;
         }
         return this._isSimpleRes;
      }
      
      public function checkShouldBeSimpleResByRaceId(param1:int) : Boolean
      {
         var changetPetSkinSvc:IChangePetSkinService;
         var gsArray:Array;
         var matchSkinGroup:Boolean;
         var raceId:int = param1;
         raceId = parseInt(raceId.toString().substr(0,6)) % 10000;
         var mfSvc:IMultipleFormPetService = ServiceContainer.getService(IMultipleFormPetService);
         var mfArray:Array = mfSvc.getSwitchPetRaceIds(raceId);
         var matchMuti:Boolean = false;
         if(mfArray.length > 0)
         {
            matchMuti = mfArray.some(function(param1:int, ... rest):*
            {
               return _simpleResRaceIds.indexOf(param1) > -1;
            });
         }
         changetPetSkinSvc = ServiceContainer.getService(IChangePetSkinService);
         gsArray = changetPetSkinSvc.getGroupAllSkinIdByOne(raceId);
         matchSkinGroup = false;
         if(gsArray.length > 0)
         {
            matchSkinGroup = gsArray.some(function(param1:int, ... rest):*
            {
               return _simpleResRaceIds.indexOf(param1) > -1;
            });
         }
         if(matchMuti || matchSkinGroup)
         {
            return true;
         }
         return this._simpleResRaceIds.indexOf(raceId) > -1;
      }
      
      public function get isSimpleRes() : Boolean
      {
         return this._isSimpleRes;
      }
      
      public function get isOnlyEnemySimpleRes() : Boolean
      {
         return this._isOnlyEnemySimpleRes;
      }
   }
}

