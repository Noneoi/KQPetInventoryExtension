package mmo.battle.entity
{
   import flash.display.Sprite;
   import flash.events.EventDispatcher;
   import flash.system.ApplicationDomain;
   import mmo.battle.bitmap.RegularBitmapData;
   import mmo.battle.command.PlayBattleCommand;
   import mmo.battle.command.PlayBattleFlowCommand;
   import mmo.battle.command.PlayBattleH5Command;
   import mmo.battle.command.SkipBattleCommand;
   import mmo.battle.container.BattleContainer;
   import mmo.battle.service.BattleService;
   import mmo.battle.util.BattleContentUtil;
   import mmo.common.ProgressFullSprite;
   import mmo.common.shareobject.LocalStore;
   import mmo.common.user.UserInfo;
   import mmo.config.ConfigReader;
   import mmo.interfaces.ServiceContainer;
   import mmo.interfaces.battle.command.IBattleCommand;
   import mmo.interfaces.battle.data.BattleResult;
   import mmo.interfaces.battle.entity.IBattle;
   import mmo.interfaces.battle.fighter.IBattleFighter;
   import mmo.interfaces.battle.player.IBattlePlayer;
   import mmo.interfaces.team.ITeamService;
   import mmo.interfaces.team.LeaderState;
   import mmo.loader.LoaderContainer;
   import mmo.loader.common.datastructures.HashMap;
   import mmo.loader.layer.HangUpLevel;
   import mmo.loader.layer.LayerManager;
   import mmo.play.scene.Disposer;
   import mmo.util.command.SceneCommandEvent;
   
   public class BattleBase extends EventDispatcher implements IBattle
   {
      
      protected static var LAST_UNDISPOSE_INSTANCE:BattleBase;
      
      protected var _battleResult:BattleResult;
      
      protected var _executingCommand:IBattleCommand;
      
      protected var _depthManager:BattleDepthManager;
      
      protected var _mapName2Player:HashMap = new HashMap();
      
      protected var _container:BattleContainer;
      
      protected var _skipBattleFlowButtonVisible:Boolean = true;
      
      protected var _switchSimpleBattleResVisible:Boolean = true;
      
      protected var _mcSwitchBattleFrameVisible:Boolean = true;
      
      protected var _mcSwitchPlayingFrameVisible:Boolean = true;
      
      protected var _skipBattleFlowButtonWaitTime:int;
      
      private var _playerNames:Array = [];
      
      private var _skipBattleFlowParams:Object = {};
      
      public function BattleBase(param1:BattleResult)
      {
         super();
         this._battleResult = param1;
         this._mapName2Player = new HashMap();
         this._container = new BattleContainer();
         this._depthManager = new BattleDepthManager(this._container.fighterLayer);
      }
      
      public function get skipBattleFlowButtonWaitTime() : int
      {
         return this._skipBattleFlowButtonWaitTime;
      }
      
      public function set skipBattleFlowButtonWaitTime(param1:int) : void
      {
         this.setSkipBattleFlowParams("skipBattleFlowButtonWaitTime",param1);
         this._skipBattleFlowButtonWaitTime = param1;
      }
      
      public function get battleResult() : BattleResult
      {
         return this._battleResult;
      }
      
      public function play() : void
      {
         this.handleMultiInstance();
         var _loc1_:Object = this.getFilledBattleContent();
         this.executeCommand(this.isBattleSkip ? SkipBattleCommand : (ConfigReader.instance.isBattleH5Movie ? PlayBattleH5Command : PlayBattleCommand),_loc1_);
         this.setTeamLeaderState();
      }
      
      public function playBattleFlow() : void
      {
         this.handleMultiInstance();
         var _loc1_:Object = this.getFilledBattleContent();
         this.executeCommand(this.isBattleSkip ? SkipBattleCommand : (ConfigReader.instance.isBattleH5Movie ? PlayBattleH5Command : PlayBattleFlowCommand),_loc1_);
         this.setTeamLeaderState();
      }
      
      public function getDisplaySprite() : Sprite
      {
         return this._container;
      }
      
      public function getPlayerByName(param1:String) : IBattlePlayer
      {
         return this._mapName2Player.getValue(param1) as IBattlePlayer;
      }
      
      public function getPlayerList() : Array
      {
         return this._mapName2Player.getValues();
      }
      
      public function autoDispose() : void
      {
         LayerManager.switchLayer(LayerManager.BASE_LAYER,HangUpLevel.DESTROY);
         this._container.dispose();
         LAST_UNDISPOSE_INSTANCE = null;
         BattleService.instance.setIsFighting(false);
         this.setBackTeamLeaderState();
      }
      
      public function dispose() : void
      {
         this.autoDispose();
         if(this._executingCommand != null)
         {
            this._executingCommand.cancel();
         }
      }
      
      public function registerPlayer(param1:IBattlePlayer) : void
      {
         var _loc2_:IBattleFighter = null;
         if(this._playerNames.indexOf(param1.playerInfo.playerName) == -1)
         {
            this._playerNames.push(param1.playerInfo.playerName);
         }
         this._mapName2Player.add(param1.playerInfo.playerName,param1);
         for each(_loc2_ in param1.fighterList)
         {
            this._depthManager.register(_loc2_);
         }
      }
      
      public function removePlayer(param1:IBattlePlayer) : void
      {
         var _loc2_:IBattleFighter = null;
         this._mapName2Player.remove(param1.playerInfo.playerName);
         for each(_loc2_ in param1.fighterList)
         {
            this._depthManager.remove(_loc2_);
         }
      }
      
      public function reorderAllPlayer() : void
      {
         this._depthManager.sortNow();
      }
      
      public function get skipBattleFlowButtonVisible() : Boolean
      {
         return this._skipBattleFlowButtonVisible;
      }
      
      public function set skipBattleFlowButtonVisible(param1:Boolean) : void
      {
         this.setSkipBattleFlowParams("skipBattleFlowButtonVisible",param1);
         this._skipBattleFlowButtonVisible = param1;
      }
      
      public function get switchSimpleBattleResVisible() : Boolean
      {
         return this._switchSimpleBattleResVisible;
      }
      
      public function set switchSimpleBattleResVisible(param1:Boolean) : void
      {
         if(!param1)
         {
            BattleContentUtil.setSimpleBattleRes(BattleSimpleResManager.NO_SIMPLE);
         }
         this._switchSimpleBattleResVisible = param1;
      }
      
      public function get mcSwitchBattleFrameVisible() : Boolean
      {
         return this._mcSwitchBattleFrameVisible;
      }
      
      public function set mcSwitchBattleFrameVisible(param1:Boolean) : void
      {
         if(!param1)
         {
            LoaderContainer.instance.stage.frameRate = ConfigReader.instance.battleFrameRate;
            BattleContentUtil.setVipBattleFrame(null);
         }
         this._mcSwitchBattleFrameVisible = param1;
      }
      
      public function get mcSwitchPlayingFrameVisible() : Boolean
      {
         return this._mcSwitchPlayingFrameVisible;
      }
      
      public function set mcSwitchPlayingFrameVisible(param1:Boolean) : void
      {
         this._mcSwitchPlayingFrameVisible = param1;
      }
      
      public function getSkipBattleFlowParams(param1:String) : *
      {
         return this._skipBattleFlowParams[param1];
      }
      
      public function setSkipBattleFlowParams(param1:String, param2:*) : *
      {
         this._skipBattleFlowParams[param1] = param2;
      }
      
      protected function executeCommand(param1:Class, param2:Object) : void
      {
         var command:IBattleCommand;
         var succFunc:Function = null;
         var failFunc:Function = null;
         var commandClsRef:Class = param1;
         var content:Object = param2;
         if(this._executingCommand != null)
         {
            return;
         }
         command = new commandClsRef() as IBattleCommand;
         this._executingCommand = command;
         succFunc = function(param1:SceneCommandEvent):void
         {
            _executingCommand.removeEventListener(SceneCommandEvent.SUCCEED,succFunc);
            _executingCommand.removeEventListener(SceneCommandEvent.FAILED,failFunc);
            _executingCommand = null;
            ProgressFullSprite.close();
            Disposer.instance.tryDisposeResources();
         };
         failFunc = function(param1:SceneCommandEvent):void
         {
            _executingCommand.removeEventListener(SceneCommandEvent.SUCCEED,succFunc);
            _executingCommand.removeEventListener(SceneCommandEvent.FAILED,failFunc);
            _executingCommand = null;
            ProgressFullSprite.close();
            Disposer.instance.tryDisposeResources();
            var _loc2_:String = param1.params.ErrMessage;
            throw new Error(_loc2_);
         };
         this._executingCommand.addEventListener(SceneCommandEvent.SUCCEED,succFunc);
         this._executingCommand.addEventListener(SceneCommandEvent.FAILED,failFunc);
         ProgressFullSprite.show();
         command.execute(content);
      }
      
      protected function handleMultiInstance() : void
      {
         if(LAST_UNDISPOSE_INSTANCE != null)
         {
            LAST_UNDISPOSE_INSTANCE.autoDispose();
         }
         LAST_UNDISPOSE_INSTANCE = this;
      }
      
      protected function getFilledBattleContent() : Object
      {
         var _loc1_:Object = new Object();
         _loc1_[BattleContentUtil.PN_EVENT_DISPATCHER] = this;
         _loc1_[BattleContentUtil.PN_BATTLE_INFO] = this._battleResult.battleInfo;
         _loc1_[BattleContentUtil.PN_BATTLE_FLOW] = this._battleResult.battleFlow;
         _loc1_[BattleContentUtil.PN_ITEM_RESULT] = this._battleResult.itemResult;
         _loc1_[BattleContentUtil.PN_CATCH_RESULT] = this._battleResult.catchPetResult;
         _loc1_[BattleContentUtil.PN_GAIN_EXP_RESULT] = this._battleResult.gainExpResult;
         _loc1_[BattleContentUtil.PN_EXTRA_EXP_RESULT] = this._battleResult.extraExpResult;
         _loc1_[BattleContentUtil.PN_NPC_BLESS_RESULT] = this._battleResult.npcBlessResult;
         _loc1_[BattleContentUtil.PN_DROP_ITEM_DATA] = this._battleResult.dropItemDatas;
         _loc1_[BattleContentUtil.PN_EXTRA_BONUS_DATA] = this._battleResult.extraBonusDatas;
         _loc1_[BattleContentUtil.PN_BUFFER_NEEDED] = this._battleResult.buffersNeeded;
         _loc1_[BattleContentUtil.PN_DOMAIN] = new ApplicationDomain(ApplicationDomain.currentDomain);
         _loc1_[BattleContentUtil.PN_CONTAINER] = this._container;
         _loc1_[BattleContentUtil.PN_WINNER_TEAM_ID] = this._battleResult.winerTeamId;
         _loc1_[BattleContentUtil.PN_BATTLE_TYPE] = this._battleResult.battleType;
         _loc1_[BattleContentUtil.PN_BATTLE] = this;
         _loc1_[BattleContentUtil.FlashToH5_DATA] = this._battleResult.flashToH5Info;
         _loc1_[BattleContentUtil.SIMPLE_RES_DATA] = BattleSimpleResManager.createNewBattleSimpleResManager();
         _loc1_[BattleContentUtil.PN_REGULAR_BITMAP_DATA] = new RegularBitmapData(_loc1_[BattleContentUtil.PN_DOMAIN]);
         return _loc1_;
      }
      
      protected function setTeamLeaderState() : void
      {
         var _loc1_:ITeamService = ServiceContainer.getService(ITeamService) as ITeamService;
         _loc1_.changeLeaderState(LeaderState.BATTLE);
      }
      
      private function setBackTeamLeaderState() : void
      {
         var _loc1_:ITeamService = ServiceContainer.getService(ITeamService) as ITeamService;
         _loc1_.changeLeaderState(LeaderState.NONE);
      }
      
      private function get isBattleSkip() : Boolean
      {
         var _loc1_:* = LocalStore.getValue("global_battle_skip",UserInfo.userName);
         return Boolean(ConfigReader.isTesting) && Boolean(_loc1_);
      }
   }
}

