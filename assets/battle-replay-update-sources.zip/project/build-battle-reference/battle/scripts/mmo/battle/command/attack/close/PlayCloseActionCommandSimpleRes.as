package mmo.battle.command.attack.close
{
   import flash.display.MovieClip;
   import mmo.battle.command.attack.consts.ActionFrameLabels;
   import mmo.battle.util.BattleContentUtil;
   import mmo.common.CommonUtil;
   import mmo.common.DisplayUtil;
   import mmo.interfaces.battle.data.RoundResult;
   import mmo.interfaces.battle.data.SkillResult;
   import mmo.util.command.ISceneCommand;
   import mmo.util.command.SceneSimpleCommand;
   
   public class PlayCloseActionCommandSimpleRes extends SceneSimpleCommand implements ISceneCommand
   {
      
      private var _content:Object;
      
      private var _timeline:MovieClip;
      
      private var _targetAction_backgrounds:Array = [];
      
      private var _action_fullScreen_Background:MovieClip;
      
      private var _action_fullScreen_Foreground:MovieClip;
      
      public function PlayCloseActionCommandSimpleRes()
      {
         super();
      }
      
      override public function execute(param1:Object) : void
      {
         var _loc3_:Boolean = false;
         var _loc4_:int = 0;
         var _loc5_:int = 0;
         this._content = param1;
         this._timeline = BattleContentUtil.getContentProperty(param1,BattleContentUtil.PN_TIME_LINE);
         var _loc2_:RoundResult = BattleContentUtil.getContentProperty(param1,BattleContentUtil.PN_ROUND_RESULT);
         this._targetAction_backgrounds = BattleContentUtil.getContentProperty(param1,BattleContentUtil.PN_TARGETACTION_BACKGROUND_ARRAY);
         this._action_fullScreen_Background = BattleContentUtil.getContentProperty(param1,BattleContentUtil.PN_ACTION_FULLSCREEN_BACKGROUD);
         this._action_fullScreen_Foreground = BattleContentUtil.getContentProperty(param1,BattleContentUtil.PN_ACTION_FULLSCREEN_FOREGROUD);
         if(this.getEffectSkillResultNum(_loc2_.targetSkillResults) == 0)
         {
            this.succeed(this._content);
            this._content = null;
         }
         else
         {
            _loc3_ = true;
            if(_loc3_)
            {
               this.onActionEnd();
            }
            else
            {
               _loc4_ = int(CommonUtil.getFrameByName(this._timeline,ActionFrameLabels.JUMP));
               if(_loc4_ == -1)
               {
                  _loc4_ = BattleContentUtil.getContentProperty(param1,BattleContentUtil.PN_JUMP_FRAME);
               }
               this._timeline.gotoAndPlay(_loc4_ + 1);
               this._timeline.addFrameScript(this._timeline.totalFrames - 1,this.onActionEnd);
               _loc5_ = 0;
               while(_loc5_ < this._targetAction_backgrounds.length)
               {
                  this._targetAction_backgrounds[_loc5_].play();
                  _loc5_++;
               }
               if(this._action_fullScreen_Background != null)
               {
                  this._action_fullScreen_Background.play();
               }
               if(this._action_fullScreen_Foreground != null)
               {
                  this._action_fullScreen_Foreground.play();
               }
            }
         }
      }
      
      private function getEffectSkillResultNum(param1:Array) : int
      {
         var _loc2_:int = 0;
         var _loc3_:int = 0;
         while(_loc3_ < param1.length)
         {
            if(SkillResult(param1[_loc3_]).effect)
            {
               _loc2_++;
            }
            _loc3_++;
         }
         return _loc2_;
      }
      
      private function onActionEnd() : void
      {
         var _loc2_:int = 0;
         var _loc1_:Boolean = true;
         if(!_loc1_)
         {
            _loc2_ = 0;
            while(_loc2_ < this._targetAction_backgrounds.length)
            {
               DisplayUtil.stopAndRemove(this._targetAction_backgrounds[_loc2_]);
               _loc2_++;
            }
            if(this._action_fullScreen_Background != null)
            {
               DisplayUtil.stopAndRemove(this._action_fullScreen_Background);
            }
            if(this._action_fullScreen_Foreground != null)
            {
               DisplayUtil.stopAndRemove(this._action_fullScreen_Foreground);
            }
         }
         this._timeline.stop();
         this.succeed(this._content);
         this._content = null;
      }
   }
}

