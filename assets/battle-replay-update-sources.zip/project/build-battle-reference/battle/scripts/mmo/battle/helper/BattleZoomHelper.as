package mmo.battle.helper
{
   import flash.display.Bitmap;
   import flash.display.BitmapData;
   import flash.display.DisplayObject;
   import flash.display.Sprite;
   import flash.events.Event;
   import flash.geom.Matrix;
   import flash.geom.Rectangle;
   import mmo.battle.entity.BattleBase;
   import mmo.battle.fighter.BattleFighter;
   import mmo.common.DisplayUtil;
   import mmo.interfaces.battle.fighter.IBattleFighter;
   import mmo.interfaces.battle.player.IBattlePlayer;
   import mmo.loader.LoaderContainer;
   
   public class BattleZoomHelper extends Sprite
   {
      
      private static const STAGE_WIDTH:Number = LoaderContainer.stageWidth;
      
      private static const STAGE_HEIGHT:Number = LoaderContainer.stageHeight;
      
      private var target:DisplayObject;
      
      private var battleFighter:BattleFighter;
      
      private var battleBase:BattleBase;
      
      private var bitmapContainer:Sprite;
      
      private var targetContainer:Sprite;
      
      private var zoomScale:Number;
      
      private var autoRemoveFrame:int;
      
      private var visibleFighters:Array = [];
      
      private var rectX:Number;
      
      private var rectY:Number;
      
      private var zoomBitmap:Bitmap;
      
      public function BattleZoomHelper()
      {
         super();
      }
      
      public function zoomIn(param1:DisplayObject, param2:BattleFighter, param3:BattleBase, param4:Sprite, param5:Number, param6:int) : void
      {
         this.target = param1;
         this.battleFighter = param2;
         this.battleBase = param3;
         this.targetContainer = param4;
         this.zoomScale = param5;
         this.autoRemoveFrame = param6;
         this.bitmapContainer = new Sprite();
         param4.addChild(this.bitmapContainer);
         this.getPosition();
         this.setFightVisibleFalse();
         this.addEventListener(Event.ENTER_FRAME,this.onEnter_Frame);
      }
      
      private function setFightVisibleFalse() : void
      {
         var _loc1_:IBattlePlayer = null;
         var _loc2_:IBattleFighter = null;
         for each(_loc1_ in this.battleBase.getPlayerList())
         {
            for each(_loc2_ in _loc1_.fighterList)
            {
               if(_loc2_ != this.battleFighter)
               {
                  Sprite(_loc2_.avatar).visible = false;
                  this.visibleFighters.push(_loc2_);
               }
            }
         }
      }
      
      private function setFightVisibleTrue() : void
      {
         var _loc1_:int = 0;
         while(_loc1_ < this.visibleFighters.length)
         {
            Sprite(IBattleFighter(this.visibleFighters[_loc1_]).avatar).visible = true;
            _loc1_++;
         }
      }
      
      private function onEnter_Frame(param1:Event) : void
      {
         --this.autoRemoveFrame;
         if(this.autoRemoveFrame == -1)
         {
            this.removeZoomBitmap();
            this.removeEventListener(Event.ENTER_FRAME,this.onEnter_Frame);
            DisplayUtil.stopAndRemove(this);
            this.setFightVisibleTrue();
         }
         else if(this.autoRemoveFrame % 2 == 0)
         {
            this.removeZoomBitmap();
            this.drawBitmap();
         }
      }
      
      private function removeZoomBitmap() : void
      {
         while(this.bitmapContainer.numChildren > 0)
         {
            DisplayUtil.stopAndRemove(this.bitmapContainer.getChildAt(0));
         }
      }
      
      private function getPosition() : void
      {
         var _loc1_:Rectangle = this.target.getBounds(this.targetContainer);
         var _loc2_:Number = _loc1_.x - (STAGE_WIDTH / this.zoomScale - _loc1_.width) / 2;
         var _loc3_:Number = _loc1_.y - (STAGE_HEIGHT / this.zoomScale - _loc1_.height) / 2;
         this.rectX = _loc2_ > 0 ? _loc2_ : 0;
         this.rectY = _loc3_ > 0 ? _loc3_ : 0;
         this.rectX = _loc2_ + STAGE_WIDTH / this.zoomScale > STAGE_WIDTH ? STAGE_WIDTH - STAGE_WIDTH / this.zoomScale : _loc2_;
         this.rectY = _loc3_ + STAGE_HEIGHT / this.zoomScale > STAGE_HEIGHT ? STAGE_HEIGHT - STAGE_HEIGHT / this.zoomScale : _loc3_;
      }
      
      private function drawBitmap() : void
      {
         var _loc1_:Number = STAGE_WIDTH / this.zoomScale;
         var _loc2_:Number = STAGE_HEIGHT / this.zoomScale;
         var _loc3_:BitmapData = new BitmapData(_loc1_,_loc2_);
         _loc3_.draw(this.targetContainer,new Matrix(1,0,0,1,-this.rectX,-this.rectY),null,null,null,true);
         this.zoomBitmap = new Bitmap(_loc3_);
         this.zoomBitmap.width = STAGE_WIDTH;
         this.zoomBitmap.height = STAGE_HEIGHT;
         this.bitmapContainer.addChild(this.zoomBitmap);
      }
   }
}

