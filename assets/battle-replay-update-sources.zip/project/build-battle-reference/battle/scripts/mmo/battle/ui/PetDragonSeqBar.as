package mmo.battle.ui
{
   import flash.display.Sprite;
   import flash.events.Event;
   import flash.events.IEventDispatcher;
   import mmo.interfaces.battle.data.FightPetDragonInfo;
   import mmo.interfaces.battle.events.BattlePetDragonEvent;
   
   public class PetDragonSeqBar
   {
      
      private static const MAX_JIELONG_NUM_IN_BATTLE:int = 2;
      
      private var _idx:int;
      
      private var _resSprite:Sprite;
      
      private var _fightPetDragonInfos:Array;
      
      private var _dragonIcons:Array = [];
      
      private var _dispatcher:IEventDispatcher;
      
      private var _curPetDragonIdx:int = 0;
      
      private var _executeBufferId:int;
      
      private var _roundNum:int = -1;
      
      public function PetDragonSeqBar(param1:Sprite, param2:int, param3:IEventDispatcher)
      {
         super();
         this._resSprite = param1;
         this._idx = param2;
         this._dispatcher = param3;
         this.initComponent();
         this.initListener();
      }
      
      public function setInfo(param1:Array) : void
      {
         var _loc3_:PetDragonSeqIcon = null;
         this._fightPetDragonInfos = param1;
         var _loc2_:int = 0;
         while(_loc2_ < MAX_JIELONG_NUM_IN_BATTLE)
         {
            _loc3_ = this._dragonIcons[_loc2_];
            if(this._fightPetDragonInfos == null || this._fightPetDragonInfos[_loc2_] == null)
            {
               _loc3_.setInfo(null,this._idx == 0);
               _loc3_.setState(PetDragonSeqIcon.STATE_EMPTYE_PETDRAGON);
            }
            else
            {
               _loc3_.setInfo(this._fightPetDragonInfos[_loc2_],this._idx == 0);
            }
            _loc2_++;
         }
      }
      
      public function get resSprite() : Sprite
      {
         return this._resSprite;
      }
      
      private function initComponent() : void
      {
         var _loc2_:Sprite = null;
         var _loc3_:PetDragonSeqIcon = null;
         var _loc1_:int = 0;
         while(_loc1_ < MAX_JIELONG_NUM_IN_BATTLE)
         {
            _loc2_ = this._resSprite.getChildByName("c" + _loc1_) as Sprite;
            _loc3_ = new PetDragonSeqIcon(_loc2_,_loc1_);
            _loc3_.setState(PetDragonSeqIcon.STATE_READY);
            this._dragonIcons.push(_loc3_);
            _loc1_++;
         }
      }
      
      private function initListener() : void
      {
         this._resSprite.addEventListener(Event.REMOVED_FROM_STAGE,this.onRemoved);
         this._dispatcher.addEventListener(BattlePetDragonEvent.PET_DRAGON_ATTACK_START,this.onAttackStart);
         this._dispatcher.addEventListener(BattlePetDragonEvent.PET_DRAGON_ATTACK_FINISHED,this.onAttackFinished);
      }
      
      private function onAttackStart(param1:BattlePetDragonEvent) : void
      {
         var _loc7_:FightPetDragonInfo = null;
         var _loc2_:int = int(param1.params.executeBufferId);
         var _loc3_:int = int(param1.params.roundNum);
         var _loc4_:int = int(param1.params.teamId);
         var _loc5_:Array = param1.params.executePetDragonIds;
         var _loc6_:int = 0;
         while(_loc6_ < this._fightPetDragonInfos.length)
         {
            _loc7_ = this._fightPetDragonInfos[_loc6_];
            if(_loc7_ != null && _loc7_.getDragonId() == int(_loc5_[0]))
            {
               this._curPetDragonIdx = _loc6_;
               break;
            }
            _loc6_++;
         }
         if(_loc4_ == this._idx && !this.hadAllFinished)
         {
            this._dragonIcons[this._curPetDragonIdx].setState(PetDragonSeqIcon.STATE_FIGHTING);
         }
      }
      
      private function onAttackFinished(param1:BattlePetDragonEvent) : void
      {
         var _loc2_:int = int(param1.params.executeBufferId);
         var _loc3_:int = int(param1.params.roundNum);
         var _loc4_:int = int(param1.params.teamId);
         if(_loc4_ == this._idx && _loc3_ != this._roundNum && !this.hadAllFinished)
         {
            this._dragonIcons[this._curPetDragonIdx].setState(PetDragonSeqIcon.STATE_FINISHED);
            this._curPetDragonIdx = this.findNextPetDragonIdx();
            this._executeBufferId = _loc2_;
            this._roundNum = _loc3_;
            if(!this.hadAllFinished)
            {
               this._dragonIcons[this._curPetDragonIdx].setState(PetDragonSeqIcon.STATE_READY);
            }
         }
      }
      
      private function findNextPetDragonIdx() : int
      {
         var _loc3_:FightPetDragonInfo = null;
         var _loc1_:int = MAX_JIELONG_NUM_IN_BATTLE;
         var _loc2_:int = this._curPetDragonIdx + 1;
         while(_loc2_ < this._fightPetDragonInfos.length)
         {
            _loc3_ = this._fightPetDragonInfos[_loc2_];
            if(_loc3_ != null && _loc3_.getDragonId() > 0)
            {
               _loc1_ = _loc2_;
               break;
            }
            _loc2_++;
         }
         return _loc1_;
      }
      
      private function get hadAllFinished() : Boolean
      {
         return this._curPetDragonIdx >= MAX_JIELONG_NUM_IN_BATTLE;
      }
      
      private function removeListener() : void
      {
         this._resSprite.removeEventListener(Event.REMOVED_FROM_STAGE,this.onRemoved);
         this._dispatcher.removeEventListener(BattlePetDragonEvent.PET_DRAGON_ATTACK_START,this.onAttackStart);
         this._dispatcher.removeEventListener(BattlePetDragonEvent.PET_DRAGON_ATTACK_FINISHED,this.onAttackFinished);
      }
      
      private function onRemoved(param1:Event) : void
      {
         this.removeListener();
      }
   }
}

