package mmo.battle.command
{
   import mmo.battle.command.attack.close.ApproachCommand;
   import mmo.battle.command.attack.close.CounterCommand;
   import mmo.battle.command.attack.close.PlayCloseActionCommand;
   import mmo.battle.command.attack.close.ReturnCommand;
   import mmo.battle.command.attack.close.WarmUpCommand;
   import mmo.battle.command.attack.common.AfterSequentialAttackCommand;
   import mmo.battle.command.attack.common.BeforeSequentialAttackCommand;
   import mmo.battle.command.attack.common.PlayEffectCommand;
   import mmo.interfaces.battle.command.IBattleCommand;
   
   public class CloseCounterCommand extends BattleCommand implements IBattleCommand
   {
      
      public function CloseCounterCommand()
      {
         super();
      }
      
      override protected function initializeMacroCommand() : void
      {
         addSubCommand(BeforeSequentialAttackCommand);
         addSubCommand(WarmUpCommand);
         addSubCommand(ApproachCommand);
         addParallelSubCommand([PlayCloseActionCommand,PlayEffectCommand]);
         addSubCommand(ReturnCommand);
         addSubCommand(CounterCommand);
         addSubCommand(AfterSequentialAttackCommand);
         super.initializeMacroCommand();
      }
   }
}

