package mmo.battle.command.playbattle
{
   import flash.display.Sprite;
   import flash.system.ApplicationDomain;
   import mmo.battle.util.BattleContentUtil;
   import mmo.common.object.ObjectCommon;
   import mmo.interfaces.ServiceContainer;
   import mmo.interfaces.battle.data.BattleInfo;
   import mmo.interfaces.battle.data.CardFaceResult;
   import mmo.interfaces.battle.data.PlayerInfo;
   import mmo.interfaces.battle.data.TeamInfo;
   import mmo.interfaces.battle.data.UseItemResult;
   import mmo.interfaces.material.battlecardface.IBattleCardFaceService;
   import mmo.util.command.SceneSimpleCommand;
   
   public class DownloadCardFaceCommand extends SceneSimpleCommand
   {
      
      private var _content:Object;
      
      private var _counter:int = 0;
      
      private var _cardFaceSvc:IBattleCardFaceService = ServiceContainer.getService(IBattleCardFaceService);
      
      public function DownloadCardFaceCommand()
      {
         super();
      }
      
      override public function execute(param1:Object) : void
      {
         this._content = param1;
         var _loc2_:Boolean = BattleContentUtil.getContentProperty(param1,BattleContentUtil.PN_IS_MULTIPLAYER);
         if(_loc2_)
         {
            this.succeed(this._content);
         }
         else
         {
            this.loadCardFaces();
         }
      }
      
      private function loadCardFaces() : void
      {
         var _loc7_:CardFaceResult = null;
         var _loc8_:PlayerInfo = null;
         var _loc1_:BattleInfo = BattleContentUtil.getContentProperty(this._content,BattleContentUtil.PN_BATTLE_INFO);
         var _loc2_:TeamInfo = _loc1_.teamInfos[0] as TeamInfo;
         var _loc3_:TeamInfo = _loc1_.teamInfos[1] as TeamInfo;
         var _loc4_:PlayerInfo = _loc2_.playerInfos[0];
         var _loc5_:PlayerInfo = _loc3_.playerInfos[0];
         var _loc6_:UseItemResult = BattleContentUtil.getContentProperty(this._content,BattleContentUtil.PN_ITEM_RESULT);
         if(_loc6_ != null)
         {
            this._counter = _loc6_.cardFaceResults.length;
            if(this._counter == 0)
            {
               this.tryFinishCommand();
            }
            else
            {
               for each(_loc7_ in _loc6_.cardFaceResults)
               {
                  _loc8_ = _loc1_.teamInfos[_loc7_.teamId].playerInfos[0];
                  this.loadCardFace(_loc8_,_loc7_,_loc8_.playerId == _loc4_.playerId);
               }
            }
         }
         else
         {
            this.tryFinishCommand();
         }
      }
      
      private function loadCardFace(param1:PlayerInfo, param2:CardFaceResult, param3:Boolean) : void
      {
         var playerInfo:PlayerInfo = param1;
         var cardFaceR:CardFaceResult = param2;
         var isLeft:Boolean = param3;
         this._cardFaceSvc.loadCardFaceRes(cardFaceR.serverId,ObjectCommon.assign({"v":cardFaceR.extData},{
            "isLeft":isLeft,
            "playerName":playerInfo.playerName
         }),function(param1:int, param2:Sprite, param3:ApplicationDomain):*
         {
            var _loc4_:String = isLeft ? BattleContentUtil.PN_PLAYER_AVATAR_L : BattleContentUtil.PN_PLAYER_AVATAR_R;
            BattleContentUtil.setContentProperty(_content,_loc4_,param2);
            tryFinishCommand();
         },BattleContentUtil.getContentProperty(this._content,BattleContentUtil.PN_DOMAIN));
      }
      
      private function tryFinishCommand() : void
      {
         --this._counter;
         if(this._counter <= 0)
         {
            this.succeed(this._content);
         }
      }
   }
}

