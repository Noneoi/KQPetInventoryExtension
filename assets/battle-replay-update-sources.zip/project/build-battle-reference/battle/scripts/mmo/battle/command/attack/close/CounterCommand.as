package mmo.battle.command.attack.close
{
   import mmo.battle.entity.BattleBase;
   import mmo.battle.util.BattleContentUtil;
   import mmo.interfaces.battle.data.RoundResult;
   import mmo.interfaces.battle.data.SkillResult;
   import mmo.interfaces.battle.fighter.IBattleFighter;
   import mmo.interfaces.battle.player.IBattlePlayer;
   import mmo.util.command.ISceneCommand;
   import mmo.util.command.SceneSimpleCommand;
   
   public class CounterCommand extends SceneSimpleCommand implements ISceneCommand
   {
      
      private var _content:Object;
      
      private var _battle:BattleBase;
      
      private var _result:RoundResult;
      
      private var _targetPlayer:IBattlePlayer;
      
      private var _targetFighter:IBattleFighter;
      
      public function CounterCommand()
      {
         super();
      }
      
      override public function execute(param1:Object) : void
      {
         var _loc4_:String = null;
         this._content = param1;
         this._result = BattleContentUtil.getContentProperty(param1,BattleContentUtil.PN_ROUND_RESULT);
         if(this._result.targetSkillResults.length == 0)
         {
            this.succeed(this._content);
            this._content = null;
            return;
         }
         if(this.getEffectSkillResultNum(this._result.targetSkillResults) > 1)
         {
            _loc4_ = "Unexpected target number in CLOSE_ATTACK !";
            BattleContentUtil.setContentProperty(param1,BattleContentUtil.PN_ERROR_MSG,_loc4_);
            this.fail(this._content);
            this._content = null;
            return;
         }
         var _loc2_:SkillResult = this.getEffectSkillResult(this._result.targetSkillResults);
         if(_loc2_ == null || !_loc2_.counter)
         {
            this.succeed(this._content);
            this._content = null;
            return;
         }
         this._battle = BattleContentUtil.getContentProperty(param1,BattleContentUtil.PN_BATTLE);
         this._targetPlayer = this._battle.getPlayerByName(_loc2_.targetPlayerName);
         this._targetFighter = this._targetPlayer.getFighterById(_loc2_.targetCharacterId);
         var _loc3_:RoundResult = this._result.reverseToCounterResult(this._targetFighter.info.normalSkill);
         this._targetFighter.counterAttack(_loc3_,this.onCounterCallback);
      }
      
      private function getEffectSkillResult(param1:Array) : SkillResult
      {
         var _loc2_:int = 0;
         while(_loc2_ < param1.length)
         {
            if(SkillResult(param1[_loc2_]).effect)
            {
               return param1[_loc2_];
            }
            _loc2_++;
         }
         return null;
      }
      
      private function getEffectSkillResultNum(param1:Array) : int
      {
         var _loc2_:int = 0;
         var _loc3_:int = 0;
         while(_loc3_ < param1.length)
         {
            if(SkillResult(param1[_loc3_]).effect)
            {
               _loc2_++;
            }
            _loc3_++;
         }
         return _loc2_;
      }
      
      private function onCounterCallback() : void
      {
         this.succeed(this._content);
         this._content = null;
      }
   }
}

