package mmo.battle.avatar.ext
{
   import flash.geom.Point;
   import mmo.battle.avatar.BattleAvatar;
   import mmo.interfaces.battle.avatar.AvatarPosTypes;
   import mmo.interfaces.battle.data.FighterInfo;
   
   public class BattleAvatar312 extends BattleAvatar
   {
      
      private static const BLOOD_BAR_Y:Number = -146;
      
      public function BattleAvatar312(param1:FighterInfo, param2:Object, param3:Boolean = false)
      {
         super(param1,param2,param3);
      }
      
      override protected function getBubblePos() : Point
      {
         var _loc1_:Number = (this.avatarBound.left + this.avatarBound.right) / 2;
         return new Point(this._avatarLayer.scaleX > 0 ? _loc1_ : -_loc1_,BLOOD_BAR_Y);
      }
      
      override protected function getBloodBarPos() : Point
      {
         return new Point(this.x,BLOOD_BAR_Y);
      }
      
      override public function getAvatarPos(param1:int) : Point
      {
         if(param1 == AvatarPosTypes.TOP)
         {
            return this.getBubblePos();
         }
         return super.getAvatarPos(param1);
      }
   }
}

