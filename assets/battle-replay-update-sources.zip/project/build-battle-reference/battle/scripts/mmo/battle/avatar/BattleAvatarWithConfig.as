package mmo.battle.avatar
{
   import flash.display.MovieClip;
   import flash.display.Sprite;
   import flash.events.Event;
   import flash.geom.Point;
   import mmo.battle.tips.FighterTipsPanel;
   import mmo.battle.tips.FighterTipsPanelForBoss;
   import mmo.common.DisplayUtil;
   import mmo.interfaces.battle.avatar.AvatarPosTypes;
   import mmo.interfaces.battle.data.FighterInfo;
   import mmo.interfaces.battleconfig.IBattleConfig;
   import mmo.interfaces.battleconfig.define.BattleAvatarDefine;
   import mmo.interfaces.battleconfig.define.BufferDefine;
   import mmo.loader.layer.LayerManager;
   
   public class BattleAvatarWithConfig extends BattleAvatar
   {
      
      private static const AVATAR_POS_HEAD:int = 99;
      
      private static const REMOTE_SKILL_DELTA_X:int = -50;
      
      private static const REMOTE_SKILL_DELTA_Y:int = -190;
      
      private static const POWER_FULL_BUFF_ID2:int = 10002;
      
      private var _bloodRes:Sprite;
      
      private var _bloodMc:MovieClip;
      
      private var _define:BattleAvatarDefine;
      
      public function BattleAvatarWithConfig(param1:BattleAvatarDefine, param2:FighterInfo, param3:Object, param4:Boolean = false)
      {
         this._define = param1;
         super(param2,param3,param4);
      }
      
      override protected function initAvatar() : void
      {
         var _loc2_:int = 0;
         super.initAvatar();
         var _loc1_:Boolean = false;
         var _loc3_:int = 0;
         while(_loc3_ < POWER_FULL_BUFF_ID2_PRIMARY_DATA.length)
         {
            _loc2_ = int(POWER_FULL_BUFF_ID2_PRIMARY_DATA[_loc3_]);
            if(_info.initBufferIds.indexOf(_loc2_) != -1)
            {
               _loc1_ = true;
               break;
            }
            _loc3_++;
         }
         if(_loc1_)
         {
            return;
         }
         var _loc4_:Sprite = super.getBufferById(POWER_FULL_BUFF_ID2);
         this._bufferLayer2.addChild(_loc4_);
         this._mapBuffId2Buff.add(POWER_FULL_BUFF_ID2,_loc4_);
         this._buffIdArray.push(POWER_FULL_BUFF_ID2);
      }
      
      override public function getAvatarPos(param1:int) : Point
      {
         var _loc2_:Point = new Point();
         switch(param1)
         {
            case AvatarPosTypes.REGISTER_POINT:
               _loc2_.x = this._define.registerPointX;
               _loc2_.y = this._define.registerPointY;
               break;
            case AvatarPosTypes.TOP_FRONT:
               _loc2_.x = this._avatarLayer.scaleX > 0 ? Number(this._define.frontX) : -this._define.frontX;
               _loc2_.y = this._define.topY;
               break;
            case AvatarPosTypes.TOP:
               _loc2_.x = this._avatarLayer.scaleX > 0 ? Number(this._define.centerX) : -this._define.centerX;
               _loc2_.y = this._define.topY;
               break;
            case AvatarPosTypes.TOP_BACK:
               _loc2_.x = this._avatarLayer.scaleX > 0 ? Number(this._define.backX) : -this._define.backX;
               _loc2_.y = this._define.topY;
               break;
            case AvatarPosTypes.FRONT:
               _loc2_.x = this._avatarLayer.scaleX > 0 ? Number(this._define.frontX) : -this._define.frontX;
               _loc2_.y = this._define.centerY;
               break;
            case AvatarPosTypes.CENTER:
               _loc2_.x = this._avatarLayer.scaleX > 0 ? Number(this._define.centerX) : -this._define.centerX;
               _loc2_.y = this._define.centerY;
               break;
            case AvatarPosTypes.BACK:
               _loc2_.x = this._avatarLayer.scaleX > 0 ? Number(this._define.backX) : -this._define.backX;
               _loc2_.y = this._define.centerY;
               break;
            case AvatarPosTypes.BUTTOM_FRONT:
               _loc2_.x = this._avatarLayer.scaleX > 0 ? Number(this._define.frontX) : -this._define.frontX;
               _loc2_.y = this._define.buttomY;
               break;
            case AvatarPosTypes.BUTTOM:
               _loc2_.x = this._avatarLayer.scaleX > 0 ? Number(this._define.centerX) : -this._define.centerX;
               _loc2_.y = this._define.buttomY;
               break;
            case AvatarPosTypes.BUTTOM_BACK:
               _loc2_.x = this._avatarLayer.scaleX > 0 ? Number(this._define.backX) : -this._define.backX;
               _loc2_.y = this._define.buttomY;
               break;
            case AVATAR_POS_HEAD:
               _loc2_.x = REMOTE_SKILL_DELTA_X;
               _loc2_.y = REMOTE_SKILL_DELTA_Y;
               break;
            case AvatarPosTypes.FULL_SCREEN_BACK:
               _loc2_.x = 0;
               _loc2_.y = 0;
               break;
            case AvatarPosTypes.FULL_SCREEN_FRONT:
               _loc2_.x = 0;
               _loc2_.y = 0;
         }
         return _loc2_;
      }
      
      override protected function getBloodBarPos() : Point
      {
         return super.getBloodBarPos().add(new Point(0,this._define.offsetBloodY));
      }
      
      override protected function getPowerBarPos() : Point
      {
         return super.getPowerBarPos().add(new Point(0,this._define.offsetBloodY));
      }
      
      override protected function initBloodBar() : void
      {
         var _loc1_:Class = null;
         switch(this._define.addBlood)
         {
            case 0:
               super.initBloodBar();
               break;
            case 1:
               _loc1_ = this._domain.getDefinition(BLOOD_BAR_CLS + this._info.raceId) as Class;
               this._bloodRes = new _loc1_() as MovieClip;
               this._bloodMc = this._bloodRes["bloodMC"] as MovieClip;
               LayerManager.getFightingControl().addChild(this._bloodRes);
               this.addEventListener(Event.REMOVED_FROM_STAGE,this.onAvatarRemoved);
               break;
            case 2:
               super.initBloodBar();
               break;
            default:
               super.initBloodBar();
         }
      }
      
      override public function set hpPersentage(param1:Number) : void
      {
         var _loc2_:int = 0;
         switch(this._define.addBlood)
         {
            case 1:
               _loc2_ = Math.floor(param1 * this._bloodMc.totalFrames) + 1;
               this._bloodMc.gotoAndStop(_loc2_);
               break;
            case 0:
            case 2:
               super.hpPersentage = param1;
               break;
            default:
               super.hpPersentage = param1;
         }
      }
      
      override public function set spPersentage(param1:Number) : void
      {
      }
      
      private function onAvatarRemoved(param1:Event) : void
      {
         this.removeEventListener(Event.REMOVED_FROM_STAGE,this.onAvatarRemoved);
         if(this._bloodRes != null)
         {
            DisplayUtil.stopAndRemove(this._bloodRes);
            this._bloodRes = null;
         }
      }
      
      override protected function getBufferById(param1:int) : MovieClip
      {
         var _loc2_:BufferDefine = this._battleConfig.getBufferDefineById(param1);
         var _loc3_:int = int(_loc2_.posId);
         var _loc4_:MovieClip = super.getBufferById(param1);
         if(_loc3_ != AvatarPosTypes.FULL_SCREEN_BACK && _loc3_ != AvatarPosTypes.FULL_SCREEN_FRONT)
         {
            _loc4_.scaleX *= this._define.bufferScale;
            _loc4_.scaleY *= this._define.bufferScale;
         }
         return _loc4_;
      }
      
      override public function addBuff(param1:int, param2:Function = null) : void
      {
         if(POWER_FULL_BUFF_ID2_PRIMARY_DATA.indexOf(param1) >= 0 || param1 != this._battleConfig.getPowerFullBuffId(this._info.raceId))
         {
            super.addBuff(param1,param2);
            return;
         }
         if(this._mapBuffId2Buff.containsKey(param1))
         {
            return;
         }
         var _loc3_:Sprite = super.getBufferById(param1);
         if(POWER_FULL_BUFF_ID2_PRIMARY_DATA.indexOf(param1) < 0)
         {
            this._bufferLayer.addChild(_loc3_);
         }
         else
         {
            this._bufferLayer2.addChild(_loc3_);
         }
         this._mapBuffId2Buff.add(param1,_loc3_);
         this._buffIdArray.push(param1);
      }
      
      override public function removeBuff(param1:int) : void
      {
         super.removeBuff(param1);
      }
      
      override protected function getSkillEffectMC(param1:int, param2:Boolean) : MovieClip
      {
         var _loc3_:MovieClip = super.getSkillEffectMC(param1,param2);
         _loc3_.scaleX *= this._define.skillScale;
         _loc3_.scaleY *= this._define.skillScale;
         return _loc3_;
      }
      
      override protected function setBloodLayerVisible(param1:Boolean) : void
      {
         switch(this._define.addBlood)
         {
            case 1:
               break;
            case 0:
            case 2:
               super.setBloodLayerVisible(param1);
               break;
            default:
               super.setBloodLayerVisible(param1);
         }
      }
      
      override protected function getFighterTips(param1:Sprite, param2:FighterInfo, param3:IBattleConfig) : FighterTipsPanel
      {
         switch(this._define.addBlood)
         {
            case 0:
               return super.getFighterTips(param1,param2,param3);
            case 1:
            case 2:
               return new FighterTipsPanelForBoss(param1,param2,param3);
            default:
               return super.getFighterTips(param1,param2,param3);
         }
      }
   }
}

