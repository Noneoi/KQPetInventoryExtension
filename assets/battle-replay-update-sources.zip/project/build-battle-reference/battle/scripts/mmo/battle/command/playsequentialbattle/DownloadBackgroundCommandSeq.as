package mmo.battle.command.playsequentialbattle
{
   import mmo.battle.util.BattleContentUtil;
   import mmo.interfaces.battle.data.BattleInfo;
   import mmo.interfaces.battle.entity.IBattle;
   import mmo.interfaces.battleconfig.IBattleConfig;
   import mmo.util.command.ISceneCommand;
   import mmo.util.command.SceneSimpleCommand;
   
   public class DownloadBackgroundCommandSeq extends SceneSimpleCommand implements ISceneCommand
   {
      
      public static const BACKGROUND_FILE_PREFIX:String = "battlebg/";
      
      public static const DEFAULT_BACKGROUND_POSTFIX:String = "default";
      
      public static const DEFAULT_BACKGROUND_FILE:String = BACKGROUND_FILE_PREFIX + DEFAULT_BACKGROUND_POSTFIX;
      
      private var _content:Object;
      
      public function DownloadBackgroundCommandSeq()
      {
         super();
      }
      
      override public function execute(param1:Object) : void
      {
         var _loc2_:IBattleConfig = BattleContentUtil.getContentProperty(param1,BattleContentUtil.PN_BATTLE_CONFIG);
         var _loc3_:Array = BattleContentUtil.getPreDownloadList(param1);
         var _loc4_:Array = BattleContentUtil.getContentProperty(param1,BattleContentUtil.PN_BATTLES);
         var _loc5_:BattleInfo = (_loc4_[0] as IBattle).battleResult.battleInfo;
         var _loc6_:String = _loc5_.sceneName;
         if(_loc2_.backgroundScenes.indexOf(_loc6_) != -1)
         {
            _loc3_.push(BACKGROUND_FILE_PREFIX + _loc6_);
         }
         this.succeed(param1);
      }
   }
}

