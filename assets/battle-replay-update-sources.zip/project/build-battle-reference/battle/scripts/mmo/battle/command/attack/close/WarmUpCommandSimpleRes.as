package mmo.battle.command.attack.close
{
   import flash.display.MovieClip;
   import mmo.battle.command.attack.consts.ActionFrameLabels;
   import mmo.battle.container.BattleContainer;
   import mmo.battle.entity.BattleBase;
   import mmo.battle.fighter.BattleFighter;
   import mmo.battle.helper.BattleActionHelper;
   import mmo.battle.util.BattleContentUtil;
   import mmo.battle.util.BattleUtil;
   import mmo.common.CommonUtil;
   import mmo.interfaces.battle.consts.AvatarActionDefine;
   import mmo.interfaces.battle.data.RoundResult;
   import mmo.interfaces.battle.data.SkillResult;
   import mmo.interfaces.battle.fighter.IBattleFighter;
   import mmo.interfaces.battle.player.IBattlePlayer;
   import mmo.interfaces.battleconfig.define.SkillDefine;
   import mmo.util.command.ISceneCommand;
   import mmo.util.command.SceneSimpleCommand;
   
   public class WarmUpCommandSimpleRes extends SceneSimpleCommand implements ISceneCommand
   {
      
      private var _content:Object;
      
      private var _timeline:MovieClip;
      
      private var _targetAction_backgrounds:Array = [];
      
      private var _action_fullScreen_Background:MovieClip;
      
      private var _action_fullScreen_Foreground:MovieClip;
      
      private var _result:RoundResult;
      
      private var _battle:BattleBase;
      
      public function WarmUpCommandSimpleRes()
      {
         super();
      }
      
      override public function execute(param1:Object) : void
      {
         var _loc6_:int = 0;
         this._content = param1;
         this._result = BattleContentUtil.getContentProperty(param1,BattleContentUtil.PN_ROUND_RESULT);
         this._battle = BattleContentUtil.getContentProperty(param1,BattleContentUtil.PN_BATTLE);
         var _loc2_:BattleFighter = BattleContentUtil.getContentProperty(this._content,BattleContentUtil.PN_SOURCE_FIGHTER);
         if(BattleUtil.getEffectSkillResultNum(this._result.targetSkillResults) == 0)
         {
            _loc2_.doAction(AvatarActionDefine.STAND);
            this.succeed(this._content);
            this._content = null;
            return;
         }
         var _loc3_:SkillDefine = BattleContentUtil.getContentProperty(this._content,BattleContentUtil.PN_SKILLDEFINE);
         var _loc4_:int = int(_loc3_.actionFrame);
         var _loc5_:Boolean = true;
         this._timeline = _loc2_.doAction(_loc5_ ? 1 : _loc4_);
         BattleContentUtil.setContentProperty(param1,BattleContentUtil.PN_TIME_LINE,this._timeline);
         if(_loc5_)
         {
            this.onJumpFrame();
         }
         else
         {
            this.handleTargetActionBackground(_loc2_,_loc4_);
            this.handleAction_FullScreen_BackGround(_loc2_,_loc4_);
            this.handleAction_FullScreen_ForeGround(_loc2_,_loc4_);
            this.handleBattleActionHelper();
            _loc6_ = int(CommonUtil.getFrameByName(this._timeline,ActionFrameLabels.JUMP));
            if(_loc6_ == -1)
            {
               _loc6_ = BattleContentUtil.getContentProperty(param1,BattleContentUtil.PN_JUMP_FRAME);
            }
            if(_loc6_ <= 0)
            {
               throw new Error("当前攻击类型是：近身，jumpFrame不能是0或者空！技能id:" + _loc3_.id);
            }
            this._timeline.addFrameScript(_loc6_ - 1,this.onJumpFrame);
            this._timeline.gotoAndPlay(1);
         }
      }
      
      private function handleAction_FullScreen_BackGround(param1:BattleFighter, param2:int) : void
      {
         var _loc3_:BattleContainer = null;
         var _loc4_:BattleActionHelper = null;
         this._action_fullScreen_Background = param1.getAction_FullScreen_BackGround(param2);
         if(this._action_fullScreen_Background != null)
         {
            _loc3_ = BattleContentUtil.getContentProperty(this._content,BattleContentUtil.PN_CONTAINER);
            _loc4_ = new BattleActionHelper();
            _loc4_.handleFrameLabel(this._action_fullScreen_Background,this._content);
            _loc3_.movieLayerBelow.addChild(this._action_fullScreen_Background);
         }
         BattleContentUtil.setContentProperty(this._content,BattleContentUtil.PN_ACTION_FULLSCREEN_BACKGROUD,this._action_fullScreen_Background);
      }
      
      private function handleAction_FullScreen_ForeGround(param1:BattleFighter, param2:int) : void
      {
         var _loc3_:BattleContainer = null;
         var _loc4_:BattleActionHelper = null;
         this._action_fullScreen_Foreground = param1.getAction_FullScreen_ForeGround(param2);
         if(this._action_fullScreen_Foreground != null)
         {
            _loc3_ = BattleContentUtil.getContentProperty(this._content,BattleContentUtil.PN_CONTAINER);
            _loc4_ = new BattleActionHelper();
            _loc4_.handleFrameLabel(this._action_fullScreen_Foreground,this._content);
            _loc3_.movieLayerAbove.addChild(this._action_fullScreen_Foreground);
         }
         BattleContentUtil.setContentProperty(this._content,BattleContentUtil.PN_ACTION_FULLSCREEN_FOREGROUD,this._action_fullScreen_Foreground);
      }
      
      private function handleTargetActionBackground(param1:BattleFighter, param2:int) : void
      {
         var _loc3_:SkillResult = null;
         var _loc4_:MovieClip = null;
         var _loc5_:IBattlePlayer = null;
         var _loc6_:IBattleFighter = null;
         if(param1.getTargetAction_BackGround(param2) != null)
         {
            for each(_loc3_ in this._result.targetSkillResults)
            {
               if(_loc3_.effect)
               {
                  _loc4_ = param1.getTargetAction_BackGround(param2);
                  _loc5_ = this._battle.getPlayerByName(_loc3_.targetPlayerName);
                  _loc6_ = _loc5_.getFighterById(_loc3_.targetCharacterId);
                  _loc6_.avatar.getBufferLayer2().addChild(_loc4_);
                  this._targetAction_backgrounds.push(_loc4_);
               }
            }
         }
         BattleContentUtil.setContentProperty(this._content,BattleContentUtil.PN_TARGETACTION_BACKGROUND_ARRAY,this._targetAction_backgrounds);
      }
      
      private function handleBattleActionHelper() : void
      {
         var _loc1_:BattleActionHelper = new BattleActionHelper();
         _loc1_.handleFrameLabel(this._timeline,this._content);
      }
      
      private function onJumpFrame() : void
      {
         var _loc1_:int = 0;
         while(_loc1_ < this._targetAction_backgrounds.length)
         {
            this._targetAction_backgrounds[_loc1_].stop();
            _loc1_++;
         }
         if(this._action_fullScreen_Background != null)
         {
            this._action_fullScreen_Background.stop();
         }
         this._timeline.stop();
         this.succeed(this._content);
         this._content = null;
      }
   }
}

