package mmo.battle.pvpinvite
{
   import flash.display.SimpleButton;
   import flash.display.Sprite;
   import flash.events.Event;
   import flash.events.MouseEvent;
   import flash.events.TimerEvent;
   import flash.system.ApplicationDomain;
   import flash.text.TextField;
   import flash.utils.Timer;
   import flash.utils.getDefinitionByName;
   import mmo.common.ProgressFullSprite;
   import mmo.common.dialog.NewDialog;
   import mmo.common.utils.panel.modaldialog.ModalDialogManager;
   import mmo.interfaces.ServiceContainer;
   import mmo.interfaces.battle.service.IBattleService;
   import mmo.loader.scheduler.ResScheduler;
   
   public class PvpInvitePanel
   {
      
      private static const MAX_PVP_INVITE_TIME:Number = 30000;
      
      private static const RES_FILE:String = "battle/invite_res";
      
      private static const RES_CLS:String = "mmo.battle.common.PvpWaitPanelRes";
      
      private var _battleService:IBattleService;
      
      private var _tarUserId:String;
      
      private var _tarNickname:String;
      
      private var _res:Sprite;
      
      private var _txtTarName:TextField;
      
      private var _btnClose:SimpleButton;
      
      private var _btnCancel:SimpleButton;
      
      private var _inviteTimer:Timer;
      
      private var _bIsCancel:Boolean = false;
      
      public function PvpInvitePanel(param1:String, param2:String)
      {
         super();
         this._tarUserId = param1;
         this._tarNickname = param2;
         this.initService();
      }
      
      public function show() : void
      {
         this.downloadResource();
      }
      
      public function close() : void
      {
         this._bIsCancel = false;
         ModalDialogManager.getInstance().removeModalDialog(this._res);
      }
      
      private function initService() : void
      {
         this._battleService = ServiceContainer.getService(IBattleService) as IBattleService;
      }
      
      private function downloadResource() : void
      {
         var _loc1_:Class = null;
         var _loc2_:Sprite = null;
         if(ApplicationDomain.currentDomain.hasDefinition(RES_CLS))
         {
            _loc1_ = getDefinitionByName(RES_CLS) as Class;
            _loc2_ = new _loc1_() as Sprite;
            this.initComponent(_loc2_);
            this.initData();
            this.initListener();
            this.addToStage();
            this.startInviteCount();
         }
         else
         {
            ProgressFullSprite.show();
            ResScheduler.getResource(RES_FILE,this.onGetResource,RES_CLS);
         }
      }
      
      private function onGetResource(param1:Sprite) : void
      {
         ProgressFullSprite.close();
         this.initComponent(param1);
         this.initData();
         this.initListener();
         this.addToStage();
         this.startInviteCount();
      }
      
      private function initComponent(param1:Sprite) : void
      {
         this._res = param1;
         this._txtTarName = this._res.getChildByName("tarname") as TextField;
         this._btnClose = this._res.getChildByName("close") as SimpleButton;
         this._btnCancel = this._res.getChildByName("cancel") as SimpleButton;
      }
      
      private function initData() : void
      {
         this._txtTarName.text = this._tarNickname;
      }
      
      private function initListener() : void
      {
         this._res.addEventListener(Event.REMOVED_FROM_STAGE,this.onRemoveFromStage);
         this._btnCancel.addEventListener(MouseEvent.CLICK,this.onCancel);
         this._btnClose.addEventListener(MouseEvent.CLICK,this.onCancel);
      }
      
      private function addToStage() : void
      {
         ModalDialogManager.getInstance().addModalDialog(this._res);
      }
      
      private function onCancel(param1:MouseEvent) : void
      {
         this._bIsCancel = true;
         ModalDialogManager.getInstance().removeModalDialog(this._res);
      }
      
      private function onRemoveFromStage(param1:Event) : void
      {
         this._res.removeEventListener(Event.REMOVED_FROM_STAGE,this.onCancel);
         this._btnCancel.removeEventListener(MouseEvent.CLICK,this.onCancel);
         this._btnClose.removeEventListener(MouseEvent.CLICK,this.onCancel);
         if(this._inviteTimer != null)
         {
            this._inviteTimer.stop();
            this._inviteTimer.removeEventListener(TimerEvent.TIMER_COMPLETE,this.onMaxPvpInviteTime);
            this._inviteTimer = null;
         }
         if(this._bIsCancel)
         {
            this._battleService.cancelPvpInvite(this._tarUserId);
         }
      }
      
      private function startInviteCount() : void
      {
         this._inviteTimer = new Timer(MAX_PVP_INVITE_TIME,1);
         this._inviteTimer.addEventListener(TimerEvent.TIMER_COMPLETE,this.onMaxPvpInviteTime);
         this._inviteTimer.start();
      }
      
      private function onMaxPvpInviteTime(param1:TimerEvent) : void
      {
         this._bIsCancel = true;
         NewDialog.showFailMessage(this._tarNickname + "可能很忙哦！过一会儿再向他发起挑战吧！");
         ModalDialogManager.getInstance().removeModalDialog(this._res);
      }
   }
}

