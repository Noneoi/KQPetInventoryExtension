package mmo.battle.consts
{
   public class BubbleConsts
   {
      
      public static const BUBBLE_INTERVAL:int = 100;
      
      public static const POWER_INTERVAL:int = 100;
      
      public function BubbleConsts()
      {
         super();
      }
   }
}

