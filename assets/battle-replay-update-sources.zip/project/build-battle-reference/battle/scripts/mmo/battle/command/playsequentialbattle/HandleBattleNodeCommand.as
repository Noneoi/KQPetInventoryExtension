package mmo.battle.command.playsequentialbattle
{
   import flash.display.Sprite;
   import flash.events.IEventDispatcher;
   import flash.events.TimerEvent;
   import flash.geom.Point;
   import flash.system.ApplicationDomain;
   import flash.utils.Timer;
   import mmo.battle.command.embed.EmbedEffectCmdFactory;
   import mmo.battle.command.embed.sub.EmbedCommandBase;
   import mmo.battle.container.BattleContainer;
   import mmo.battle.entity.BattleBaseSequential;
   import mmo.battle.entity.BattleFlowManager;
   import mmo.battle.fighter.BattleFighter;
   import mmo.battle.player.BattlePlayer;
   import mmo.battle.util.BattleContentUtil;
   import mmo.interfaces.ServiceContainer;
   import mmo.interfaces.battle.consts.FormationConsts;
   import mmo.interfaces.battle.data.BattleInfo;
   import mmo.interfaces.battle.data.FighterInfo;
   import mmo.interfaces.battle.data.PlayerInfo;
   import mmo.interfaces.battle.data.TeamInfo;
   import mmo.interfaces.battle.entity.IBattle;
   import mmo.interfaces.battle.events.BattleEvent;
   import mmo.interfaces.battle.events.BattleSeqEvent;
   import mmo.interfaces.battle.fighter.IBattleFighter;
   import mmo.interfaces.battle.player.IBattlePlayer;
   import mmo.interfaces.battle.service.IBattleService;
   import mmo.interfaces.battleconfig.IBattleConfig;
   import mmo.interfaces.battleconfig.define.EmbedEffectDefine;
   import mmo.loader.CustomLoader;
   import mmo.util.command.ISceneCommand;
   import mmo.util.command.SceneSimpleCommand;
   
   public class HandleBattleNodeCommand extends SceneSimpleCommand implements ISceneCommand
   {
      
      private static const FIGHTER_TIPS_CLS:String = "mmo.battle.common.FighterTipsRes";
      
      private static const DELAY_TIME_AFTER_FLOW:int = 1000;
      
      private var _content:Object;
      
      private var _battles:Array;
      
      private var _battleBase:BattleBaseSequential;
      
      private var _dispatcher:IEventDispatcher;
      
      private var _config:IBattleConfig;
      
      private var _domain:ApplicationDomain;
      
      private var _container:BattleContainer;
      
      private var _curNode:IBattle;
      
      private var _curBattleInfo:BattleInfo;
      
      private var _flowManager:BattleFlowManager;
      
      private var _nodePassCount:int;
      
      private var _battleService:IBattleService;
      
      public function HandleBattleNodeCommand()
      {
         super();
      }
      
      override public function execute(param1:Object) : void
      {
         this._content = param1;
         var _loc2_:Array = BattleContentUtil.getContentProperty(param1,BattleContentUtil.PN_BATTLES);
         this._battles = _loc2_.concat();
         this._dispatcher = BattleContentUtil.getContentProperty(param1,BattleContentUtil.PN_EVENT_DISPATCHER);
         this._config = BattleContentUtil.getContentProperty(param1,BattleContentUtil.PN_BATTLE_CONFIG);
         this._domain = BattleContentUtil.getContentProperty(param1,BattleContentUtil.PN_DOMAIN);
         this._container = BattleContentUtil.getContentProperty(param1,BattleContentUtil.PN_CONTAINER);
         this._battleBase = BattleContentUtil.getContentProperty(param1,BattleContentUtil.PN_BATTLE_SEQ);
         this._battleService = ServiceContainer.getService(IBattleService) as IBattleService;
         var _loc3_:CustomLoader = BattleContentUtil.getContentProperty(param1,BattleContentUtil.PN_LOADER);
         _loc3_.close();
         if(this._dispatcher.hasEventListener(BattleEvent.ON_BATTLE_PLAY))
         {
            this._dispatcher.dispatchEvent(new BattleEvent(BattleEvent.ON_BATTLE_PLAY,{}));
         }
         this.handleNextNode(false);
      }
      
      private function handleNextNode(param1:Boolean) : void
      {
         var _loc2_:Timer = new Timer(DELAY_TIME_AFTER_FLOW,1);
         _loc2_.addEventListener(TimerEvent.TIMER_COMPLETE,this.afterDelay);
         if(param1)
         {
            _loc2_.start();
         }
         else
         {
            _loc2_.dispatchEvent(new TimerEvent(TimerEvent.TIMER_COMPLETE));
         }
      }
      
      private function afterDelay(param1:TimerEvent) : void
      {
         var _loc2_:Timer = param1.currentTarget as Timer;
         _loc2_.removeEventListener(TimerEvent.TIMER_COMPLETE,this.afterDelay);
         this._curNode = this._battles.shift();
         if(this._curNode == null)
         {
            this.succeed(this._content);
            if(this._dispatcher.hasEventListener(BattleEvent.ON_BATTLE_END))
            {
               this._dispatcher.dispatchEvent(new BattleEvent(BattleEvent.ON_BATTLE_END,{}));
            }
         }
         else
         {
            this._curBattleInfo = this._curNode.battleResult.battleInfo;
            this._battleService.dispatchEvent(new BattleSeqEvent(BattleSeqEvent.ON_BATTLE_NODE_START,{
               "nodePass":this._nodePassCount,
               "nodeLeft":this._battles.length + 1
            }));
            if(this._dispatcher.hasEventListener(BattleSeqEvent.ON_BATTLE_NODE_START))
            {
               this._dispatcher.dispatchEvent(new BattleSeqEvent(BattleSeqEvent.ON_BATTLE_NODE_START,{
                  "nodePass":this._nodePassCount,
                  "nodeLeft":this._battles.length + 1,
                  "callback":this.onNodeStartCallback
               }));
            }
            else
            {
               this.onNodeStartCallback();
            }
         }
      }
      
      private function clearFighters() : void
      {
         var _loc1_:Sprite = BattleContentUtil.getContentProperty(this._content,BattleContentUtil.PN_LOCATOR);
         this.clearTeam(this._curBattleInfo.getTeamInfoById(0),_loc1_.getChildByName("t0") as Sprite);
         this.clearTeam(this._curBattleInfo.getTeamInfoById(1),_loc1_.getChildByName("t1") as Sprite);
      }
      
      private function setupFighters() : void
      {
         var _loc1_:Sprite = BattleContentUtil.getContentProperty(this._content,BattleContentUtil.PN_LOCATOR);
         this.setupTeam(this._curBattleInfo.getTeamInfoById(0),_loc1_.getChildByName("t0") as Sprite,false);
         this.setupTeam(this._curBattleInfo.getTeamInfoById(1),_loc1_.getChildByName("t1") as Sprite,true);
         this._battleBase.reorderAllPlayer();
         if(this._dispatcher.hasEventListener(BattleEvent.FIGHTERS_SETUP_COMPLETE))
         {
            this._dispatcher.dispatchEvent(new BattleEvent(BattleEvent.FIGHTERS_SETUP_COMPLETE,null));
         }
      }
      
      private function playBattleFlow() : void
      {
         this._flowManager = new BattleFlowManager(this._curNode.battleResult.battleFlow,this._content,this.onBattleFlowEnd);
         this._flowManager.startBattleFlow();
      }
      
      private function onBattleFlowEnd(param1:int) : void
      {
         ++this._nodePassCount;
         if(param1 == BattleFlowManager.REACH_THE_END)
         {
            this._battleService.dispatchEvent(new BattleSeqEvent(BattleSeqEvent.ON_BATTLE_NODE_END,{
               "nodePass":this._nodePassCount,
               "nodeLeft":this._battles.length,
               "winnerTeamId":this._curNode.battleResult.winerTeamId
            }));
            if(this._dispatcher.hasEventListener(BattleSeqEvent.ON_BATTLE_NODE_END))
            {
               this._dispatcher.dispatchEvent(new BattleSeqEvent(BattleSeqEvent.ON_BATTLE_NODE_END,{
                  "nodePass":this._nodePassCount,
                  "nodeLeft":this._battles.length,
                  "winnerTeamId":this._curNode.battleResult.winerTeamId,
                  "callback":this.onNodeEndCallback
               }));
            }
            else
            {
               this.onNodeEndCallback();
            }
         }
         else
         {
            BattleContentUtil.setContentProperty(this._content,BattleContentUtil.PN_ERROR_MSG,"战斗流程执行错误，请重试。");
            this.fail(this._content);
            this._content = null;
            this._flowManager.dispose();
            this._flowManager = null;
         }
      }
      
      private function onNodeStartCallback() : void
      {
         this.clearFighters();
         this.setupFighters();
         this.playBattleFlow();
      }
      
      private function onNodeEndCallback() : void
      {
         this.handleNextNode(true);
      }
      
      private function setupTeam(param1:TeamInfo, param2:Sprite, param3:Boolean) : void
      {
         var _loc6_:PlayerInfo = null;
         var _loc7_:int = 0;
         var _loc8_:Sprite = null;
         var _loc9_:Array = null;
         var _loc10_:IBattlePlayer = null;
         var _loc11_:FighterInfo = null;
         var _loc12_:int = 0;
         var _loc13_:Sprite = null;
         var _loc14_:Point = null;
         var _loc15_:IBattleFighter = null;
         var _loc16_:int = 0;
         var _loc17_:Sprite = null;
         var _loc4_:Class = this._domain.getDefinition(FIGHTER_TIPS_CLS) as Class;
         var _loc5_:Array = param1.playerInfos;
         for each(_loc6_ in _loc5_)
         {
            _loc7_ = _loc6_.initPosX + _loc6_.initPosY * FormationConsts.MAX_ROW_COUNT;
            _loc8_ = param2.getChildByName("p" + _loc7_) as Sprite;
            _loc9_ = _loc6_.fighterInfos;
            _loc10_ = new BattlePlayer(_loc6_,this._content,param2);
            for each(_loc11_ in _loc9_)
            {
               _loc12_ = _loc11_.initPosX + _loc11_.initPosY * FormationConsts.MAX_ROW_COUNT;
               _loc13_ = _loc8_.getChildByName("f" + _loc12_) as Sprite;
               _loc14_ = _loc8_.localToGlobal(new Point(_loc13_.x,_loc13_.y));
               _loc15_ = new BattleFighter(_loc11_,this._content,param3);
               _loc15_.addToStage(this._container.fighterLayer,_loc14_.x,_loc14_.y);
               for each(_loc16_ in _loc11_.initBufferIds)
               {
                  _loc15_.addBuff(_loc16_);
               }
               _loc17_ = new _loc4_() as Sprite;
               _loc15_.showTips(_loc17_);
               this.setupFighterEmbedEffect(_loc15_);
               _loc10_.registerFighter(_loc15_);
            }
            this._battleBase.registerPlayer(_loc10_);
         }
      }
      
      private function setupFighterEmbedEffect(param1:IBattleFighter) : void
      {
         var _loc4_:EmbedEffectDefine = null;
         var _loc5_:Array = null;
         var _loc6_:EmbedCommandBase = null;
         var _loc2_:Array = this._config.getEmbedEffectDefines(param1.info.raceId);
         if(_loc2_ == null)
         {
            return;
         }
         var _loc3_:int = 0;
         while(_loc3_ < _loc2_.length)
         {
            _loc4_ = _loc2_[_loc3_];
            _loc5_ = _loc4_.timing;
            _loc6_ = EmbedEffectCmdFactory.getEmbedCommand(_loc4_);
            param1.embedCommand(_loc6_,_loc5_);
            _loc3_++;
         }
      }
      
      private function clearTeam(param1:TeamInfo, param2:Sprite) : void
      {
         var _loc5_:PlayerInfo = null;
         var _loc6_:IBattlePlayer = null;
         var _loc3_:Class = this._domain.getDefinition(FIGHTER_TIPS_CLS) as Class;
         var _loc4_:Array = param1.playerInfos;
         for each(_loc5_ in _loc4_)
         {
            _loc6_ = this._battleBase.getPlayerByName(_loc5_.playerName);
            if(_loc6_ != null)
            {
               this._battleBase.removePlayer(_loc6_);
               _loc6_.fadeOut();
            }
         }
      }
   }
}

