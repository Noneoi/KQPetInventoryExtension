package mmo.battle.command.attack.consts
{
   public class EffectFrameLabels
   {
      
      public static const BUBBLE:String = "bubble";
      
      public static const SCALE:String = "scale";
      
      public function EffectFrameLabels()
      {
         super();
      }
   }
}

