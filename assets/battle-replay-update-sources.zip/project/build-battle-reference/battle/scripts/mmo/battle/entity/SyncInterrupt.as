package mmo.battle.entity
{
   import flash.events.Event;
   
   public class SyncInterrupt extends Event
   {
      
      public static const OVER_ROUND_LIMIT_WARNING:String = "over_round_limit";
      
      public static const ONE_BATTLELINE_END:String = "one_battleline_end";
      
      private var _params:Object;
      
      public function SyncInterrupt(param1:String, param2:Object)
      {
         super(param1);
         this._params = param2;
      }
      
      public function get params() : Object
      {
         return this._params;
      }
   }
}

