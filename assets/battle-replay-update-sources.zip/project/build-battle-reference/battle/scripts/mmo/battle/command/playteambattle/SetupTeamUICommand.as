package mmo.battle.command.playteambattle
{
   import flash.display.Sprite;
   import flash.events.IEventDispatcher;
   import flash.system.ApplicationDomain;
   import mmo.battle.container.BattleContainer;
   import mmo.battle.entity.BattleBase;
   import mmo.battle.ui.BattleTeamUI;
   import mmo.battle.util.BattleContentUtil;
   import mmo.interfaces.battle.data.BattleInfo;
   import mmo.interfaces.battle.data.NpcBlessResult;
   import mmo.interfaces.battle.entity.IBattle;
   import mmo.util.command.ISceneCommand;
   import mmo.util.command.SceneSimpleCommand;
   
   public class SetupTeamUICommand extends SceneSimpleCommand implements ISceneCommand
   {
      
      private static const UI_RES_CLS:String = "mmo.battle.common.BattleTeamUIRes";
      
      private var _content:Object;
      
      private var _battle:IBattle;
      
      private var _battleInfo:BattleInfo;
      
      private var _npcBlessResult:NpcBlessResult;
      
      private var _domain:ApplicationDomain;
      
      private var _dispatcher:IEventDispatcher;
      
      private var _battles:Array;
      
      public function SetupTeamUICommand()
      {
         super();
      }
      
      override public function execute(param1:Object) : void
      {
         this._content = param1;
         this._battle = BattleContentUtil.getContentProperty(param1,BattleContentUtil.PN_BATTLE);
         this._battleInfo = BattleContentUtil.getContentProperty(param1,BattleContentUtil.PN_BATTLE_INFO);
         this._npcBlessResult = BattleContentUtil.getContentProperty(param1,BattleContentUtil.PN_NPC_BLESS_RESULT);
         this._domain = BattleContentUtil.getContentProperty(param1,BattleContentUtil.PN_DOMAIN);
         this._dispatcher = BattleContentUtil.getContentProperty(param1,BattleContentUtil.PN_EVENT_DISPATCHER);
         this._battles = BattleContentUtil.getContentProperty(param1,BattleContentUtil.PN_TEAM_BATTLES);
         this.setupUI();
      }
      
      private function setupUI() : void
      {
         var _loc1_:Class = this._domain.getDefinition(UI_RES_CLS) as Class;
         var _loc2_:Sprite = new _loc1_() as Sprite;
         var _loc3_:BattleTeamUI = new BattleTeamUI(_loc2_,this._domain,this._dispatcher,this._battles);
         _loc3_.setInfo(this._battleInfo,this._npcBlessResult,BattleBase(this._battle));
         var _loc4_:BattleContainer = BattleContentUtil.getContentProperty(this._content,BattleContentUtil.PN_CONTAINER);
         _loc3_.show(_loc4_.uiLayer);
         BattleContentUtil.setContentProperty(this._content,BattleContentUtil.PN_UI,_loc3_);
         this.succeed(this._content);
         this._content = null;
      }
   }
}

