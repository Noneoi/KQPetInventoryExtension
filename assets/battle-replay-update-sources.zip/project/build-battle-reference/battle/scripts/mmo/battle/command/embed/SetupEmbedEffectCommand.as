package mmo.battle.command.embed
{
   import flash.system.ApplicationDomain;
   import mmo.battle.command.embed.sub.EmbedCommandBase;
   import mmo.battle.util.BattleContentUtil;
   import mmo.interfaces.battle.data.BattleInfo;
   import mmo.interfaces.battle.data.FighterInfo;
   import mmo.interfaces.battle.data.PlayerInfo;
   import mmo.interfaces.battle.data.TeamInfo;
   import mmo.interfaces.battle.entity.IBattle;
   import mmo.interfaces.battle.fighter.IBattleFighter;
   import mmo.interfaces.battle.player.IBattlePlayer;
   import mmo.interfaces.battleconfig.IBattleConfig;
   import mmo.interfaces.battleconfig.define.EmbedEffectDefine;
   import mmo.util.command.ISceneCommand;
   import mmo.util.command.SceneSimpleCommand;
   
   public class SetupEmbedEffectCommand extends SceneSimpleCommand implements ISceneCommand
   {
      
      private var _battleConfig:IBattleConfig;
      
      private var _domain:ApplicationDomain;
      
      public function SetupEmbedEffectCommand()
      {
         super();
      }
      
      override public function execute(param1:Object) : void
      {
         var _loc4_:TeamInfo = null;
         var _loc5_:PlayerInfo = null;
         var _loc6_:IBattlePlayer = null;
         var _loc7_:FighterInfo = null;
         var _loc8_:IBattleFighter = null;
         this._battleConfig = BattleContentUtil.getContentProperty(param1,BattleContentUtil.PN_BATTLE_CONFIG);
         this._domain = BattleContentUtil.getContentProperty(param1,BattleContentUtil.PN_DOMAIN);
         var _loc2_:BattleInfo = BattleContentUtil.getContentProperty(param1,BattleContentUtil.PN_BATTLE_INFO);
         var _loc3_:IBattle = BattleContentUtil.getContentProperty(param1,BattleContentUtil.PN_BATTLE);
         for each(_loc4_ in _loc2_.teamInfos)
         {
            for each(_loc5_ in _loc4_.playerInfos)
            {
               _loc6_ = _loc3_.getPlayerByName(_loc5_.playerName);
               for each(_loc7_ in _loc5_.fighterInfos)
               {
                  _loc8_ = _loc6_.getFighterById(_loc7_.id);
                  this.setupFighterEmbedEffect(_loc8_);
               }
            }
         }
         this.succeed(param1);
      }
      
      private function setupFighterEmbedEffect(param1:IBattleFighter) : void
      {
         var _loc4_:EmbedEffectDefine = null;
         var _loc5_:Array = null;
         var _loc6_:EmbedCommandBase = null;
         var _loc2_:Array = this._battleConfig.getEmbedEffectDefines(param1.info.raceId);
         if(_loc2_ == null)
         {
            return;
         }
         var _loc3_:int = 0;
         while(_loc3_ < _loc2_.length)
         {
            _loc4_ = _loc2_[_loc3_];
            _loc5_ = _loc4_.timing;
            _loc6_ = EmbedEffectCmdFactory.getEmbedCommand(_loc4_);
            param1.embedCommand(_loc6_,_loc5_);
            _loc3_++;
         }
      }
   }
}

