package mmo.battle.command.attack.close
{
   import flash.geom.Point;
   import mmo.battle.entity.BattleBase;
   import mmo.battle.entity.BattleSimpleResManager;
   import mmo.battle.util.BattleContentUtil;
   import mmo.battle.util.BattleUtil;
   import mmo.interfaces.battle.avatar.AvatarPosTypes;
   import mmo.interfaces.battle.data.BattleInfo;
   import mmo.interfaces.battle.data.PlayerInfo;
   import mmo.interfaces.battle.data.RoundResult;
   import mmo.interfaces.battle.data.SkillResult;
   import mmo.interfaces.battle.fighter.IBattleFighter;
   import mmo.interfaces.battle.player.IBattlePlayer;
   import mmo.util.command.ISceneCommand;
   import mmo.util.command.SceneSimpleCommand;
   
   public class ApproachCommand extends SceneSimpleCommand implements ISceneCommand
   {
      
      private var _content:Object;
      
      private var _battle:BattleBase;
      
      private var _result:RoundResult;
      
      private var _sourceFighter:IBattleFighter;
      
      public function ApproachCommand()
      {
         super();
      }
      
      override public function execute(param1:Object) : void
      {
         this._content = param1;
         this._battle = BattleContentUtil.getContentProperty(param1,BattleContentUtil.PN_BATTLE);
         this._result = BattleContentUtil.getContentProperty(param1,BattleContentUtil.PN_ROUND_RESULT);
         this._sourceFighter = BattleContentUtil.getContentProperty(param1,BattleContentUtil.PN_SOURCE_FIGHTER);
         var _loc2_:Array = this._result.targetSkillResults;
         var _loc3_:int = BattleUtil.getEffectSkillResultNum(_loc2_);
         if(_loc3_ == 0)
         {
            this.succeed(this._content);
            this._content = null;
            return;
         }
         if(_loc3_ != 1)
         {
            throw new Error("Unexpected target number in CLOSE_ATTACK !");
         }
         var _loc4_:SkillResult = this.getEffectSkillResult(_loc2_);
         var _loc5_:String = _loc4_.targetPlayerName;
         var _loc6_:int = int(_loc4_.targetCharacterId);
         var _loc7_:IBattlePlayer = this._battle.getPlayerByName(_loc5_);
         var _loc8_:IBattleFighter = _loc7_.getFighterById(_loc6_);
         if(_loc8_ == null)
         {
            this.failWithReason("Can\'t locate target figter with id = " + _loc6_);
            return;
         }
         this.recordOriginalPosition();
         this.approachFighterToEnemy(this._sourceFighter,_loc8_);
      }
      
      private function getEffectSkillResult(param1:Array) : SkillResult
      {
         var _loc2_:int = 0;
         while(_loc2_ < param1.length)
         {
            if(SkillResult(param1[_loc2_]).effect)
            {
               return param1[_loc2_];
            }
            _loc2_++;
         }
         return null;
      }
      
      private function recordOriginalPosition() : void
      {
         BattleContentUtil.setContentProperty(this._content,BattleContentUtil.PN_FIGHTER_ORG_X,this._sourceFighter.x);
         BattleContentUtil.setContentProperty(this._content,BattleContentUtil.PN_FIGHTER_ORG_Y,this._sourceFighter.y);
      }
      
      private function approachFighterToEnemy(param1:IBattleFighter, param2:IBattleFighter) : void
      {
         if(param1 == param2)
         {
            this.onJumpEnd();
            return;
         }
         var _loc3_:BattleSimpleResManager = BattleContentUtil.getContentProperty(this._content,BattleContentUtil.SIMPLE_RES_DATA);
         var _loc4_:BattleInfo = BattleContentUtil.getContentProperty(this._content,BattleContentUtil.PN_BATTLE_INFO);
         var _loc5_:int = int(param1.info.belong2PlayerIndex);
         var _loc6_:PlayerInfo = _loc4_.teamInfos[param1.needFlip ? 1 : 0].playerInfos[_loc5_];
         var _loc7_:Boolean = _loc3_.checkShouldBeSimpleResBySourceFighter(this._content,param1,_loc6_.playerName);
         var _loc8_:Point = param1.avatar.getAvatarPos(AvatarPosTypes.BUTTOM_FRONT);
         var _loc9_:Point = param2.avatar.getAvatarPos(AvatarPosTypes.BUTTOM_FRONT);
         var _loc10_:Point = _loc9_.add(new Point(param2.x,param2.y));
         if(_loc7_)
         {
            param1.jumpTo(_loc10_.x,param2.avatar.y - 1,this.onJumpEnd);
         }
         else
         {
            param1.jumpTo(_loc10_.x - _loc8_.x,param2.avatar.y - 1,this.onJumpEnd);
         }
      }
      
      private function onJumpEnd() : void
      {
         this._battle.reorderAllPlayer();
         this.succeed(this._content);
         this._content = null;
      }
      
      private function failWithReason(param1:String) : void
      {
         BattleContentUtil.setContentProperty(this._content,BattleContentUtil.PN_ERROR_MSG,param1);
         this.fail(this._content);
         this._content = null;
      }
   }
}

