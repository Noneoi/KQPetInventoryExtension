package mmo.battle.command.playbattle
{
   import flash.system.ApplicationDomain;
   import mmo.battle.container.BattleContainer;
   import mmo.battle.ui.BattleRoundUI;
   import mmo.battle.util.BattleContentUtil;
   import mmo.interfaces.battle.data.BattleInfo;
   import mmo.interfaces.battle.data.FighterInfo;
   import mmo.interfaces.battle.data.PlayerInfo;
   import mmo.interfaces.battle.entity.IBattle;
   import mmo.interfaces.battle.service.BattleResultVersion;
   import mmo.loader.common.datastructures.HashMap;
   import mmo.util.command.ISceneCommand;
   import mmo.util.command.SceneSimpleCommand;
   
   public class SetupNumCommand extends SceneSimpleCommand implements ISceneCommand
   {
      
      private static const ROUND_UI_RES_CLS:String = "mmo.battle.common.RoundRes";
      
      private var _content:Object;
      
      private var _battleInfo:BattleInfo;
      
      private var _domain:ApplicationDomain;
      
      private var _container:BattleContainer;
      
      private var _battle:IBattle;
      
      public function SetupNumCommand()
      {
         super();
      }
      
      override public function execute(param1:Object) : void
      {
         this._content = param1;
         this._battleInfo = BattleContentUtil.getContentProperty(param1,BattleContentUtil.PN_BATTLE_INFO);
         this._container = BattleContentUtil.getContentProperty(param1,BattleContentUtil.PN_CONTAINER);
         this._battle = BattleContentUtil.getContentProperty(param1,BattleContentUtil.PN_BATTLE);
         this._domain = BattleContentUtil.getContentProperty(param1,BattleContentUtil.PN_DOMAIN);
         this.addBattleRoundUI();
         this.succeed(this._content);
         this._content = null;
      }
      
      private function addBattleRoundUI() : void
      {
         if(this._battle.battleResult.version < BattleResultVersion.VER_20251226)
         {
            return;
         }
         var _loc1_:Class = this._domain.getDefinition(ROUND_UI_RES_CLS) as Class;
         var _loc2_:BattleRoundUI = new BattleRoundUI(new _loc1_(),[this.getMapId2Race(0),this.getMapId2Race(1)],this._content);
         _loc2_.setXY(480,0);
         _loc2_.show(this._container.uiLayer);
         BattleContentUtil.setContentProperty(this._content,BattleContentUtil.PN_BATTLE_ROUND_UI,_loc2_);
      }
      
      private function getMapId2Race(param1:int) : HashMap
      {
         var _loc4_:FighterInfo = null;
         var _loc2_:HashMap = new HashMap();
         var _loc3_:PlayerInfo = this._battleInfo.getTeamInfoById(param1).playerInfos[0];
         for each(_loc4_ in _loc3_.fighterInfos)
         {
            _loc2_.add(_loc4_.id,_loc4_.originalRaceId);
         }
         return _loc2_;
      }
   }
}

