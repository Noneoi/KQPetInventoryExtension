package mmo.battle.resultpanel
{
   import flash.display.MovieClip;
   import flash.display.SimpleButton;
   import flash.display.Sprite;
   import flash.events.MouseEvent;
   import flash.system.ApplicationDomain;
   import flash.text.TextField;
   import mmo.battle.util.BattleContentUtil;
   import mmo.common.utils.panel.modaldialog.ModalDialogManager;
   import mmo.interfaces.ServiceContainer;
   import mmo.interfaces.battle.consts.GainExpState;
   import mmo.interfaces.battle.data.ExtExpResult;
   import mmo.interfaces.battle.data.GainExpInfo;
   import mmo.interfaces.battle.data.GainExpResult;
   import mmo.interfaces.battle.entity.IBattle;
   import mmo.interfaces.chat.IChatService;
   
   public class GainExpTeamPanel
   {
      
      private static const GAIN_EXP_PANEL_CLS:String = "mmo.battle.common.GainExpTeamPanelRes";
      
      private var _content:Object;
      
      private var _callback:Function;
      
      private var _winPanelCls:String;
      
      private var _res:Sprite;
      
      private var _btnOk:SimpleButton;
      
      private var _arrExpCard:Array = [[0,0],[0,0],[0,0]];
      
      private var _dropItemPanelArray:Array = [];
      
      private var _mcLeaderArray:Array = [];
      
      private var _btnReplay:SimpleButton;
      
      private var _evolutionInfos:Array;
      
      public function GainExpTeamPanel(param1:Object, param2:Function, param3:String)
      {
         super();
         this._content = param1;
         this._callback = param2;
         this._winPanelCls = param3;
         this.initComponent();
         this.initData();
         this.initListener();
      }
      
      public function show() : void
      {
         ModalDialogManager.getInstance().addModalDialog(this._res);
      }
      
      private function initComponent() : void
      {
         var _loc2_:String = null;
         var _loc5_:int = 0;
         var _loc6_:Sprite = null;
         var _loc7_:ApplicationDomain = null;
         var _loc8_:DropItemPanel = null;
         var _loc9_:MovieClip = null;
         var _loc10_:ExpCard = null;
         var _loc11_:IBattle = null;
         var _loc1_:ApplicationDomain = BattleContentUtil.getContentProperty(this._content,BattleContentUtil.PN_DOMAIN);
         if(this._winPanelCls == "")
         {
            _loc2_ = GAIN_EXP_PANEL_CLS;
         }
         else
         {
            _loc2_ = this._winPanelCls;
         }
         var _loc3_:Class = _loc1_.getDefinition(_loc2_) as Class;
         this._res = new _loc3_() as Sprite;
         this._btnOk = this._res.getChildByName("btnOk") as SimpleButton;
         var _loc4_:int = 0;
         while(_loc4_ < 3)
         {
            _loc5_ = 0;
            while(_loc5_ < 2)
            {
               _loc9_ = this._res.getChildByName("card" + _loc4_ + _loc5_) as MovieClip;
               _loc10_ = new ExpCard(_loc9_);
               _loc10_.setGainExpInfo(null);
               this._arrExpCard[_loc4_][_loc5_] = _loc10_;
               _loc5_++;
            }
            _loc6_ = this._res.getChildByName("dires" + _loc4_) as Sprite;
            _loc7_ = this._content["Domain"];
            _loc8_ = new DropItemPanel(_loc6_,_loc7_);
            this._dropItemPanelArray.push(_loc8_);
            this._mcLeaderArray.push(this._res.getChildByName("leader" + _loc4_) as MovieClip);
            _loc4_++;
         }
         this._btnReplay = this._res.getChildByName("btnReplay") as SimpleButton;
         if(this._btnReplay != null)
         {
            _loc11_ = BattleContentUtil.getContentProperty(this._content,BattleContentUtil.PN_BATTLE);
            if(_loc11_.battleResult.replay)
            {
               this._btnReplay.addEventListener(MouseEvent.CLICK,this.onReplay);
            }
            else
            {
               this._btnReplay.visible = false;
            }
         }
      }
      
      private function onReplay(param1:MouseEvent) : void
      {
         var _loc2_:IChatService = ServiceContainer.getService(IChatService);
         var _loc3_:IBattle = BattleContentUtil.getContentProperty(this._content,BattleContentUtil.PN_BATTLE);
         _loc2_.showSharePanel(3,{"battleId":_loc3_.battleResult.battleId});
      }
      
      private function initData() : void
      {
         var _loc3_:IBattle = null;
         var _loc4_:GainExpResult = null;
         var _loc5_:Array = null;
         var _loc6_:int = 0;
         var _loc7_:GainExpInfo = null;
         var _loc8_:ExpCard = null;
         var _loc9_:ExtExpResult = null;
         var _loc10_:int = 0;
         var _loc1_:Array = BattleContentUtil.getContentProperty(this._content,BattleContentUtil.PN_TEAM_BATTLES);
         var _loc2_:int = 0;
         while(_loc2_ < _loc1_.length)
         {
            _loc3_ = _loc1_[_loc2_];
            _loc4_ = _loc3_.battleResult.gainExpResult;
            if(_loc4_ != null)
            {
               this._evolutionInfos = new Array();
               _loc6_ = 0;
               while(_loc6_ < _loc4_.gainExpInfoList.length)
               {
                  _loc7_ = _loc4_.gainExpInfoList[_loc6_];
                  _loc8_ = this._arrExpCard[_loc2_][_loc6_];
                  _loc8_.setGainExpInfo(_loc7_);
                  if(_loc7_.state == GainExpState.EVOLUTION)
                  {
                     this._evolutionInfos.push(_loc7_);
                  }
                  _loc6_++;
               }
            }
            _loc5_ = _loc3_.battleResult.dropItemDatas;
            DropItemPanel(this._dropItemPanelArray[_loc2_]).setGainItemList(_loc5_);
            if(_loc3_.battleResult.userName == _loc3_.battleResult.teamLeaderName)
            {
               MovieClip(this._mcLeaderArray[_loc2_]).gotoAndStop(2);
               _loc9_ = _loc3_.battleResult.extraExpResult;
               _loc10_ = 0;
               while(_loc10_ < _loc1_.length)
               {
                  if(_loc9_ != null)
                  {
                     TextField(this._res["mcTxt" + _loc10_]["vipext"]).text = _loc9_.vipExtraExp + "%";
                     TextField(this._res["mcTxt" + _loc10_]["timeext"]).text = _loc9_.timeExtraExp + "%";
                     TextField(this._res["mcTxt" + _loc10_]["itemext"]).text = _loc9_.itemExtraExp + "%";
                     TextField(this._res["mcTxt" + _loc10_]["familyext"]).text = _loc9_.familyExtraExp + "%";
                     if(_loc10_ == _loc2_)
                     {
                        TextField(this._res["mcTxt" + _loc10_]["teamtxt"]).text = 10 * _loc1_.length - 10 + "%";
                     }
                     else
                     {
                        TextField(this._res["mcTxt" + _loc10_]["teamtxt"]).text = "0%";
                     }
                  }
                  else
                  {
                     TextField(this._res["mcTxt" + _loc10_]["vipext"]).text = "0%";
                     TextField(this._res["mcTxt" + _loc10_]["timeext"]).text = "0%";
                     TextField(this._res["mcTxt" + _loc10_]["itemext"]).text = "0%";
                     TextField(this._res["mcTxt" + _loc10_]["familyext"]).text = "0%";
                     TextField(this._res["mcTxt" + _loc10_]["teamtxt"]).text = "0%";
                  }
                  _loc10_++;
               }
            }
            _loc2_++;
         }
      }
      
      private function initListener() : void
      {
         this._btnOk.addEventListener(MouseEvent.CLICK,this.onCloseClick);
      }
      
      private function removeListener() : void
      {
         this._btnOk.removeEventListener(MouseEvent.CLICK,this.onCloseClick);
      }
      
      private function onCloseClick(param1:MouseEvent) : void
      {
         this.close();
      }
      
      public function close() : void
      {
         ModalDialogManager.getInstance().removeModalDialog(this._res);
         this.removeListener();
         this._callback.apply();
      }
   }
}

