package mmo.battle.catchpanel
{
   import flash.display.SimpleButton;
   import flash.display.Sprite;
   import flash.events.MouseEvent;
   import flash.system.ApplicationDomain;
   import mmo.common.utils.panel.modaldialog.ModalDialogManager;
   
   public class CatchHelpPanel
   {
      
      private static const HELP_PANEL_CLS:String = "mmo.battle.common.CatchHelpPanelRes";
      
      private var _content:Object;
      
      private var _res:Sprite;
      
      private var _btnClose:SimpleButton;
      
      public function CatchHelpPanel(param1:Object)
      {
         super();
         this._content = param1;
         this.initComponent();
         this.initListener();
      }
      
      public function show() : void
      {
         ModalDialogManager.getInstance().addModalDialog(this._res);
      }
      
      private function initComponent() : void
      {
         var _loc1_:ApplicationDomain = this._content["Domain"];
         var _loc2_:Class = _loc1_.getDefinition(HELP_PANEL_CLS) as Class;
         this._res = new _loc2_() as Sprite;
         this._btnClose = this._res.getChildByName("close") as SimpleButton;
      }
      
      private function initListener() : void
      {
         this._btnClose.addEventListener(MouseEvent.CLICK,this.onCloseClick);
      }
      
      private function onCloseClick(param1:MouseEvent) : void
      {
         ModalDialogManager.getInstance().removeModalDialog(this._res);
         this._btnClose.removeEventListener(MouseEvent.CLICK,this.onCloseClick);
      }
   }
}

