package mmo.battle.command.playbattle
{
   import mmo.battle.util.BattleContentUtil;
   import mmo.common.sound.SoundManager;
   import mmo.util.command.ISceneCommand;
   import mmo.util.command.SceneSimpleCommand;
   
   public class SetupBattleMusicCommand extends SceneSimpleCommand implements ISceneCommand
   {
      
      private static const FIGHT_MUSIC_URL:String = "music/ms_fight";
      
      public function SetupBattleMusicCommand()
      {
         super();
      }
      
      override public function execute(param1:Object) : void
      {
         BattleContentUtil.setContentProperty(param1,BattleContentUtil.PN_ORG_MUSIC,SoundManager.instance.currentMusic);
         SoundManager.instance.playBackgroundMusic(FIGHT_MUSIC_URL);
         this.succeed(param1);
      }
   }
}

