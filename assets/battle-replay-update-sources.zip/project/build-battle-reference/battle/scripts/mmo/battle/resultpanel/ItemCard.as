package mmo.battle.resultpanel
{
   import flash.display.Sprite;
   import flash.text.TextField;
   import mmo.common.DisplayUtil;
   import mmo.common.utils.tips.TipsManager;
   import mmo.interfaces.ServiceContainer;
   import mmo.interfaces.material.IMaterialService;
   import mmo.interfaces.material.Material;
   import mmo.interfaces.material.MaterialCommonData;
   import mmo.interfaces.material.MaterialViewContainer;
   import mmo.interfaces.material.view.IMaterialViewLoader;
   
   public class ItemCard
   {
      
      private var _res:Sprite;
      
      private var _iconContainer:Sprite;
      
      private var _txtQuantity:TextField;
      
      public function ItemCard(param1:Sprite)
      {
         super();
         this._res = param1;
         this.initComponent();
      }
      
      public function setMaterialData(param1:MaterialCommonData) : void
      {
         this._txtQuantity.text = "x" + param1.num;
         var _loc2_:IMaterialViewLoader = ServiceContainer.getService(IMaterialViewLoader) as IMaterialViewLoader;
         var _loc3_:MaterialViewContainer = _loc2_.getView(param1.type,param1.id,45,45,this.callback);
         this._iconContainer.addChild(_loc3_);
         var _loc4_:IMaterialService = ServiceContainer.getMaterialService(param1.type);
         var _loc5_:Material = _loc4_.getMaterialById(param1.id);
         TipsManager.getInstance().addTips(this._iconContainer,_loc5_.name);
      }
      
      public function get resSprite() : Sprite
      {
         return this._res;
      }
      
      private function initComponent() : void
      {
         this._iconContainer = this._res.getChildByName("ic") as Sprite;
         this._txtQuantity = this._res.getChildByName("quantity") as TextField;
      }
      
      private function callback(param1:MaterialViewContainer) : void
      {
         DisplayUtil.middleDisplay(param1,45,45);
      }
   }
}

