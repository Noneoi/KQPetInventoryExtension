package mmo.battle.command.attack.common
{
   import mmo.battle.entity.BattleBase;
   import mmo.battle.util.BattleContentUtil;
   import mmo.battle.util.BattleUtil;
   import mmo.interfaces.battle.consts.AvatarActionDefine;
   import mmo.interfaces.battle.consts.AvatarEffectIds;
   import mmo.interfaces.battle.data.RoundResult;
   import mmo.interfaces.battle.data.SkillNumResult;
   import mmo.interfaces.battle.data.SkillResult;
   import mmo.interfaces.battle.fighter.IBattleFighter;
   import mmo.interfaces.battle.player.IBattlePlayer;
   import mmo.interfaces.battleconfig.IBattleConfig;
   import mmo.interfaces.battleconfig.define.SkillExecuteDefine;
   import mmo.util.command.ISceneCommand;
   import mmo.util.command.SceneSimpleCommand;
   
   public class BeforeAttackCommand extends SceneSimpleCommand implements ISceneCommand
   {
      
      private var _content:Object;
      
      private var _battle:BattleBase;
      
      private var _battleConfig:IBattleConfig;
      
      private var _result:RoundResult;
      
      private var _sourcePlayer:IBattlePlayer;
      
      private var _sourceFighter:IBattleFighter;
      
      private var _curHitActionSemaphore:int;
      
      private var _curWaitBuffSemaphore:int;
      
      private var _allSkillResultNumSemaphore:int;
      
      public function BeforeAttackCommand()
      {
         super();
      }
      
      override public function execute(param1:Object) : void
      {
         this._content = param1;
         this._battle = BattleContentUtil.getContentProperty(param1,BattleContentUtil.PN_BATTLE);
         this._battleConfig = BattleContentUtil.getContentProperty(param1,BattleContentUtil.PN_BATTLE_CONFIG);
         this._result = BattleContentUtil.getContentProperty(param1,BattleContentUtil.PN_ROUND_RESULT);
         this.setupSourceFighter();
         this.onSourceSkillBeHitActionEnd();
      }
      
      private function setupSourceFighter() : void
      {
         this._sourcePlayer = this._battle.getPlayerByName(this._result.sourcePlayerName);
         this._sourceFighter = this._sourcePlayer.getFighterById(this._result.sourceCharacterId);
         BattleContentUtil.setContentProperty(this._content,BattleContentUtil.PN_SOURCE_PLAYER,this._sourcePlayer);
         BattleContentUtil.setContentProperty(this._content,BattleContentUtil.PN_SOURCE_FIGHTER,this._sourceFighter);
      }
      
      private function onSourceSkillBeHitActionEnd() : void
      {
         this._allSkillResultNumSemaphore = this.calculateAllSkillResultNum(this._result.targetSkillResults) + this.calculateAllSkillResultNum(this._result.targetRepresenterResults);
         if(this._result.sourceSkillNumResult != null)
         {
            ++this._allSkillResultNumSemaphore;
         }
         var _loc1_:Boolean = BattleUtil.checkHasWaitTypeBuff(this._result.sourceSkillNumResult.beforeDisplayBuff);
         if(this.checkHasWaitTypeBuffInTargetSkillResults(this._result.targetSkillResults) || this.checkHasWaitTypeBuffInTargetSkillResults(this._result.targetRepresenterResults) || _loc1_)
         {
            BattleUtil.handleDisplayBuffChangesSingle(this._result.sourceSkillNumResult.beforeDisplayBuff,this._sourceFighter,this.onWaitBuffEnd);
            this.handleBuffChanges(this._result.targetSkillResults,this.onWaitBuffEnd);
            this.handleBuffChanges(this._result.targetRepresenterResults,this.onWaitBuffEnd);
         }
         else
         {
            BattleUtil.handleHpChangesSingle(this._result.sourceSkillNumResult.beforeHps,this._result.sourceSkillNumResult.beforeSps,this._sourceFighter,AvatarActionDefine.STAND,this.onBeHitActionEnd);
            this.handleSkillTargetHpChanges(this._result.targetSkillResults,this.onBeHitActionEnd);
            this.handleSkillTargetHpChanges(this._result.targetRepresenterResults,this.onBeHitActionEnd);
         }
      }
      
      private function checkHasWaitTypeBuffInTargetSkillResults(param1:Array) : Boolean
      {
         var _loc2_:SkillResult = null;
         for each(_loc2_ in param1)
         {
            if(_loc2_.numResult != null)
            {
               if(BattleUtil.checkHasWaitTypeBuff(_loc2_.numResult.beforeDisplayBuff))
               {
                  return true;
               }
            }
         }
         return false;
      }
      
      private function calculateAllSkillResultNum(param1:Array) : int
      {
         var _loc3_:SkillResult = null;
         var _loc4_:IBattlePlayer = null;
         var _loc5_:IBattleFighter = null;
         var _loc2_:int = 0;
         for each(_loc3_ in param1)
         {
            if(_loc3_.numResult != null)
            {
               _loc4_ = this._battle.getPlayerByName(_loc3_.targetPlayerName);
               _loc5_ = _loc4_.getFighterById(_loc3_.targetCharacterId);
               _loc2_++;
            }
         }
         if(param1.length == 0)
         {
            _loc2_++;
         }
         return _loc2_;
      }
      
      private function handleSourceFighterChanges() : void
      {
         BattleUtil.handlePowerChangesSingle(this._result.sourceSkillNumResult.beforePowers,this._sourceFighter);
         var _loc1_:SkillNumResult = this._result.sourceSkillNumResult;
         BattleUtil.handleDisplayBuffChangesSingle(_loc1_.beforeDisplayBuff,this._sourceFighter);
      }
      
      private function handleSkillTargetHpChanges(param1:Array, param2:Function) : void
      {
         var _loc3_:SkillResult = null;
         var _loc4_:IBattlePlayer = null;
         var _loc5_:IBattleFighter = null;
         for each(_loc3_ in param1)
         {
            if(_loc3_.numResult != null)
            {
               _loc4_ = this._battle.getPlayerByName(_loc3_.targetPlayerName);
               _loc5_ = _loc4_.getFighterById(_loc3_.targetCharacterId);
               if((Boolean(_loc5_)) && _loc5_ != this._sourceFighter)
               {
                  BattleUtil.handleHpChangesSingle(_loc3_.numResult.beforeHps,_loc3_.numResult.beforeSps,_loc5_,AvatarActionDefine.STAND,param2);
               }
               else
               {
                  param2.apply();
               }
            }
         }
         if(param1.length == 0)
         {
            param2.apply();
         }
      }
      
      private function onWaitBuffEnd() : void
      {
         ++this._curWaitBuffSemaphore;
         this.checkTargetBuffSemaphore();
      }
      
      private function onBeHitActionEnd() : void
      {
         ++this._curHitActionSemaphore;
         this.checkTargetHpSemaphore();
      }
      
      private function checkTargetHpSemaphore() : void
      {
         var _loc1_:Array = null;
         if(this._curHitActionSemaphore >= this._allSkillResultNumSemaphore)
         {
            _loc1_ = this._result.sourceSkillNumResult.beforePowers;
            BattleUtil.handlePowerChangesSingle(_loc1_,this._sourceFighter);
            BattleUtil.handleDisplayBuffChangesSingle(this._result.sourceSkillNumResult.beforeDisplayBuff,this._sourceFighter);
            this.handlePowerChanges(this._result.targetSkillResults);
            this.handleBuffChanges(this._result.targetSkillResults);
            this.handlePowerChanges(this._result.targetRepresenterResults);
            this.handleBuffChanges(this._result.targetRepresenterResults);
            this.handleSkillExecuteCode();
         }
      }
      
      private function checkTargetBuffSemaphore() : void
      {
         if(this._curWaitBuffSemaphore >= this._allSkillResultNumSemaphore)
         {
            BattleUtil.handleHpChangesSingle(this._result.sourceSkillNumResult.beforeHps,this._result.sourceSkillNumResult.beforeSps,this._sourceFighter,AvatarActionDefine.STAND,this.onAfterBuffAndHpActionEnd);
            this.handleSkillTargetHpChanges(this._result.targetSkillResults,this.onAfterBuffAndHpActionEnd);
            this.handleSkillTargetHpChanges(this._result.targetRepresenterResults,this.onAfterBuffAndHpActionEnd);
         }
      }
      
      private function onAfterBuffAndHpActionEnd() : void
      {
         ++this._curHitActionSemaphore;
         this.checkAfterBuffAndHpSemaphore();
      }
      
      private function checkAfterBuffAndHpSemaphore() : void
      {
         var _loc1_:Array = null;
         if(this._curHitActionSemaphore >= this._allSkillResultNumSemaphore)
         {
            _loc1_ = this._result.sourceSkillNumResult.beforePowers;
            BattleUtil.handlePowerChangesSingle(_loc1_,this._sourceFighter);
            this.handlePowerChanges(this._result.targetSkillResults);
            this.handlePowerChanges(this._result.targetRepresenterResults);
            this.handleSkillExecuteCode();
         }
      }
      
      private function handlePowerChanges(param1:Array) : void
      {
         var _loc2_:SkillResult = null;
         var _loc3_:IBattlePlayer = null;
         var _loc4_:IBattleFighter = null;
         for each(_loc2_ in param1)
         {
            if(_loc2_.numResult != null)
            {
               _loc3_ = this._battle.getPlayerByName(_loc2_.targetPlayerName);
               _loc4_ = _loc3_.getFighterById(_loc2_.targetCharacterId);
               BattleUtil.handlePowerChangesSingle(_loc2_.numResult.beforePowers,_loc4_);
            }
         }
      }
      
      private function handleBuffChanges(param1:Array, param2:Function = null) : void
      {
         var _loc3_:SkillResult = null;
         var _loc4_:SkillNumResult = null;
         var _loc5_:IBattlePlayer = null;
         var _loc6_:IBattleFighter = null;
         for each(_loc3_ in param1)
         {
            if(_loc3_.numResult != null)
            {
               _loc4_ = _loc3_.numResult;
               _loc5_ = this._battle.getPlayerByName(_loc3_.targetPlayerName);
               _loc6_ = _loc5_.getFighterById(_loc3_.targetCharacterId);
               if(_loc6_)
               {
                  BattleUtil.handleDisplayBuffChangesSingle(_loc4_.beforeDisplayBuff,_loc6_,param2);
               }
               else if(param2 != null)
               {
                  param2.apply();
               }
            }
         }
         if(param1.length == 0)
         {
            if(param2 != null)
            {
               param2.apply();
            }
         }
      }
      
      private function handleSkillExecuteCode() : void
      {
         var battleConfig:IBattleConfig = BattleContentUtil.getContentProperty(this._content,BattleContentUtil.PN_BATTLE_CONFIG);
         var skillExecuteDefine:SkillExecuteDefine = battleConfig.getSkillExecutDefine(this._result.skillExecuteCode);
         if(skillExecuteDefine.type == SkillExecuteDefine.TYPE_ATTACK_DISABLE)
         {
            this._sourceFighter.showEffect(AvatarEffectIds.ATTACK_DISABLE,function():void
            {
               onBeforAttackEnd();
            });
         }
         else
         {
            this.onBeforAttackEnd();
         }
      }
      
      private function onBeforAttackEnd() : void
      {
         BattleContentUtil.setContentProperty(this._content,BattleContentUtil.PN_TIME_LINE,this._sourceFighter.curActionTimeline);
         this.succeed(this._content);
         this._content = null;
      }
   }
}

