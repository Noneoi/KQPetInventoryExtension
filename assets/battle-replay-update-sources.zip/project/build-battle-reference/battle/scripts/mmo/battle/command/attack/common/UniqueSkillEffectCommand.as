package mmo.battle.command.attack.common
{
   import flash.display.MovieClip;
   import flash.geom.Point;
   import flash.system.ApplicationDomain;
   import mmo.battle.avatar.BattleAvatar;
   import mmo.battle.avatar.BattleChaserAvatar;
   import mmo.battle.container.BattleContainer;
   import mmo.battle.entity.BattleBase;
   import mmo.battle.entity.BattleSimpleResManager;
   import mmo.battle.util.BattleContentUtil;
   import mmo.interfaces.battle.avatar.AvatarPosTypes;
   import mmo.interfaces.battle.consts.AvatarEffectIds;
   import mmo.interfaces.battle.data.BattleInfo;
   import mmo.interfaces.battle.data.PlayerInfo;
   import mmo.interfaces.battle.data.RoundResult;
   import mmo.interfaces.battle.data.SkillResult;
   import mmo.interfaces.battle.entity.IBattle;
   import mmo.interfaces.battle.fighter.IBattleFighter;
   import mmo.interfaces.battle.player.IBattlePlayer;
   import mmo.interfaces.battleconfig.IBattleConfig;
   import mmo.interfaces.battleconfig.define.SkillDefine;
   import mmo.interfaces.battleconfig.define.SkillExecuteDefine;
   import mmo.loader.LoaderContainer;
   import mmo.util.command.ISceneCommand;
   import mmo.util.command.SceneSimpleCommand;
   
   public class UniqueSkillEffectCommand extends SceneSimpleCommand implements ISceneCommand
   {
      
      protected static const EFFECT_CLS_PREFIX:String = "mmo.battle.common.Effect";
      
      private var _content:Object;
      
      private var _config:IBattleConfig;
      
      private var _isMulti:Boolean;
      
      private var _skillDefine:SkillDefine;
      
      private var _timeline:MovieClip;
      
      private var _container:BattleContainer;
      
      private var _result:RoundResult;
      
      private var _sourceFighter:IBattleFighter;
      
      public function UniqueSkillEffectCommand()
      {
         super();
      }
      
      override public function execute(param1:Object) : void
      {
         this._content = param1;
         this._config = BattleContentUtil.getContentProperty(param1,BattleContentUtil.PN_BATTLE_CONFIG);
         this._container = BattleContentUtil.getContentProperty(param1,BattleContentUtil.PN_CONTAINER);
         this._isMulti = BattleContentUtil.getContentProperty(param1,BattleContentUtil.PN_IS_MULTIPLAYER);
         this._result = BattleContentUtil.getContentProperty(param1,BattleContentUtil.PN_ROUND_RESULT);
         this._sourceFighter = BattleContentUtil.getContentProperty(param1,BattleContentUtil.PN_SOURCE_FIGHTER);
         this._skillDefine = BattleContentUtil.getContentProperty(this._content,BattleContentUtil.PN_SKILLDEFINE);
         if(this._result.targetSkillResults.length == 0 && this._result.skillExecuteCode != SkillExecuteDefine.TYPE_NORMAL)
         {
            this.succeed(this._content);
            this._content = null;
            return;
         }
         if(this._result.skillId == this._sourceFighter.info.uniqueSkill || this._result.skillId == this._sourceFighter.info.superUniqueSkill)
         {
            this.stopTimeLine();
            this.removeFullPowerBuff();
            if(!this._isMulti && Boolean(this._skillDefine.blackScreen))
            {
               this.renderForBlackScreen();
               this.playEffectMc(AvatarEffectIds.UNIQUE_SKILL_EFFECT_BLACK,this.onEffectEnd);
            }
            else
            {
               this.playEffectMc(AvatarEffectIds.UNIQUE_SKILL_EFFECT,this.onEffectEnd);
            }
         }
         else if(!this._isMulti && Boolean(this._skillDefine.blackScreen))
         {
            this.stopTimeLine();
            this.renderForBlackScreen();
            this.onEffectEnd();
         }
         else
         {
            this.onEffectEnd();
            this.succeed(param1);
            this._content = null;
         }
      }
      
      private function removeFullPowerBuff() : void
      {
         var _loc1_:int = int(this._config.getPowerFullBuffId(this._sourceFighter.info.raceId));
         this._sourceFighter.removeBuff(_loc1_);
      }
      
      private function stopTimeLine() : void
      {
         this._timeline = BattleContentUtil.getContentProperty(this._content,BattleContentUtil.PN_TIME_LINE);
         this._timeline.stop();
      }
      
      private function renderForBlackScreen() : void
      {
         this._container.movieLayerBelow.graphics.beginFill(0,0.8);
         this._container.movieLayerBelow.graphics.drawRect(0,0,LoaderContainer.stageWidth,LoaderContainer.stageHeight);
         this._container.movieLayerBelow.graphics.endFill();
      }
      
      private function playEffectMc(param1:int, param2:Function = null) : void
      {
         var _loc3_:String = EFFECT_CLS_PREFIX + param1;
         var _loc4_:ApplicationDomain = BattleContentUtil.getContentProperty(this._content,BattleContentUtil.PN_DOMAIN);
         var _loc5_:Class = _loc4_.getDefinition(_loc3_) as Class;
         var _loc6_:MovieClip = new _loc5_() as MovieClip;
         var _loc7_:Point = this._sourceFighter.avatar.getAvatarPos(AvatarPosTypes.CENTER);
         _loc6_.x = _loc7_.x;
         _loc6_.y = _loc7_.y;
         this._sourceFighter.showMovie(_loc6_,param2);
      }
      
      private function handleHideOtherAvatar() : void
      {
         var _loc6_:Array = null;
         var _loc7_:BattleBase = null;
         var _loc8_:IBattlePlayer = null;
         var _loc9_:Array = null;
         var _loc10_:SkillResult = null;
         var _loc11_:IBattlePlayer = null;
         var _loc12_:IBattleFighter = null;
         var _loc13_:Array = null;
         var _loc14_:IBattleFighter = null;
         var _loc15_:IBattleFighter = null;
         var _loc16_:IBattlePlayer = null;
         var _loc17_:IBattlePlayer = null;
         var _loc18_:IBattlePlayer = null;
         var _loc19_:IBattleFighter = null;
         var _loc1_:BattleSimpleResManager = BattleContentUtil.getContentProperty(this._content,BattleContentUtil.SIMPLE_RES_DATA);
         var _loc2_:BattleInfo = BattleContentUtil.getContentProperty(this._content,BattleContentUtil.PN_BATTLE_INFO);
         var _loc3_:int = int(this._sourceFighter.info.belong2PlayerIndex);
         var _loc4_:PlayerInfo = _loc2_.teamInfos[this._sourceFighter.needFlip ? 1 : 0].playerInfos[_loc3_];
         var _loc5_:Boolean = _loc1_.checkShouldBeSimpleResBySourceFighter(this._content,this._sourceFighter,_loc4_.playerName);
         if(!this._isMulti && (Boolean(this._skillDefine.isHideOtherAvatar) || _loc5_))
         {
            _loc6_ = [];
            _loc7_ = BattleContentUtil.getContentProperty(this._content,BattleContentUtil.PN_BATTLE);
            _loc9_ = [];
            for each(_loc10_ in this._result.targetSkillResults)
            {
               if(_loc10_.effect)
               {
                  _loc8_ = _loc7_.getPlayerByName(_loc10_.targetPlayerName);
                  _loc14_ = _loc8_.getFighterById(_loc10_.targetCharacterId);
                  _loc9_.push(_loc14_);
               }
            }
            if(_loc8_ != null)
            {
               for each(_loc15_ in _loc8_.fighterList)
               {
                  if(_loc9_.indexOf(_loc15_) == -1 && _loc9_.indexOf(this._sourceFighter) == -1 && BattleAvatar(_loc15_.avatar).visible && _loc15_ != this._sourceFighter)
                  {
                     BattleAvatar(_loc15_.avatar).visible = false;
                     _loc6_.push(_loc15_.avatar);
                  }
               }
            }
            _loc11_ = BattleContentUtil.getContentProperty(this._content,BattleContentUtil.PN_SOURCE_PLAYER);
            for each(_loc12_ in _loc11_.fighterList)
            {
               if(_loc12_ != this._sourceFighter && _loc9_.indexOf(_loc12_) == -1 && BattleAvatar(_loc12_.avatar).visible)
               {
                  BattleAvatar(_loc12_.avatar).visible = false;
                  _loc6_.push(_loc12_.avatar);
               }
            }
            _loc13_ = _loc7_.getPlayerList();
            if(_loc8_ == _loc11_)
            {
               _loc16_ = _loc13_[0];
               _loc17_ = _loc13_[1];
               if(_loc11_.playerInfo.playerId == _loc16_.playerInfo.playerId)
               {
                  _loc18_ = _loc17_;
               }
               else
               {
                  _loc18_ = _loc16_;
               }
               for each(_loc19_ in _loc18_.fighterList)
               {
                  if(_loc19_ != this._sourceFighter && _loc9_.indexOf(_loc19_) == -1 && BattleAvatar(_loc19_.avatar).visible)
                  {
                     BattleAvatar(_loc19_.avatar).visible = false;
                     _loc6_.push(_loc19_.avatar);
                  }
               }
            }
            this.handleUniqueSkillHideOthersLayer(false);
            BattleContentUtil.setContentProperty(this._content,BattleContentUtil.PN_HIDE_FIGHTERS,_loc6_);
         }
      }
      
      private function handleUniqueSkillHideOthersLayer(param1:Boolean) : void
      {
         this._container.uniqueSkillHideOtherLayer.visible = param1;
         this._container.floor.visible = param1;
      }
      
      private function handleHideOrgAvatarWhenIsChaser() : void
      {
         var _loc1_:IBattle = null;
         var _loc2_:IBattlePlayer = null;
         var _loc3_:Array = null;
         var _loc4_:int = 0;
         var _loc5_:IBattleFighter = null;
         if(this._sourceFighter.avatar is BattleChaserAvatar)
         {
            _loc1_ = BattleContentUtil.getContentProperty(this._content,BattleContentUtil.PN_BATTLE);
            _loc2_ = _loc1_.getPlayerByName(this._result.sourcePlayerName);
            _loc3_ = _loc2_.fighterList;
            _loc4_ = 0;
            while(_loc4_ < _loc3_.length)
            {
               _loc5_ = _loc3_[_loc4_];
               if(this._sourceFighter.info.id != _loc5_.info.id && _loc5_.info.initPosX == this._sourceFighter.info.initPosX && _loc5_.info.initPosY == this._sourceFighter.info.initPosY)
               {
                  BattleAvatar(_loc5_.avatar).visible = false;
               }
               _loc4_++;
            }
         }
      }
      
      private function onEffectEnd() : void
      {
         this.handleHideOrgAvatarWhenIsChaser();
         this.handleHideOtherAvatar();
         if(this._timeline != null)
         {
            this._timeline.play();
         }
         this.succeed(this._content);
      }
   }
}

