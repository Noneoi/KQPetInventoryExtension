package mmo.battle.command.attack.representer
{
   import mmo.battle.command.BattleCommand;
   import mmo.battle.command.attack.common.AfterSequentialAttackCommand;
   import mmo.battle.command.attack.common.BeforeSequentialAttackCommand;
   import mmo.interfaces.battle.command.IBattleCommand;
   
   public class RepresenterSimpleAttackCommand extends BattleCommand implements IBattleCommand
   {
      
      public function RepresenterSimpleAttackCommand()
      {
         super();
      }
      
      override protected function initializeMacroCommand() : void
      {
         addSubCommand(BeforeSequentialAttackCommand);
         addSubCommand(AfterSequentialAttackCommand);
         super.initializeMacroCommand();
      }
   }
}

