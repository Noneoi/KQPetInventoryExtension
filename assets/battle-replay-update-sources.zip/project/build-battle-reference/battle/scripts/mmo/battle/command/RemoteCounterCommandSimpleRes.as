package mmo.battle.command
{
   import mmo.battle.command.attack.common.AfterSequentialAttackCommand;
   import mmo.battle.command.attack.common.BeforeSequentialAttackCommand;
   import mmo.battle.command.attack.common.PlayEffectCommand;
   import mmo.battle.command.attack.remote.PlayRemoteActionCommandSimpleRes;
   import mmo.battle.command.attack.remote.RecoverActionCommand;
   import mmo.interfaces.battle.command.IBattleCommand;
   
   public class RemoteCounterCommandSimpleRes extends BattleCommand implements IBattleCommand
   {
      
      public function RemoteCounterCommandSimpleRes()
      {
         super();
      }
      
      override protected function initializeMacroCommand() : void
      {
         addSubCommand(BeforeSequentialAttackCommand);
         addParallelSubCommand([PlayRemoteActionCommandSimpleRes,PlayEffectCommand]);
         addSubCommand(RecoverActionCommand);
         addSubCommand(AfterSequentialAttackCommand);
         super.initializeMacroCommand();
      }
   }
}

