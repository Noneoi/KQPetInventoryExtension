package mmo.battle.command
{
   import mmo.battle.command.playbattle.ClearSceneCommand;
   import mmo.battle.command.playbattle.DelayCommand;
   import mmo.battle.command.playbattle.DisposeBattlefieldCommand;
   import mmo.battle.command.playbattle.JumpH5BattleCommand;
   import mmo.battle.command.playbattle.NotifyGainCoolPetStoneCommand;
   import mmo.battle.command.playbattle.NotifyRidingHungryCommand;
   import mmo.battle.command.playbattle.PickCaughtPetCommand;
   import mmo.battle.command.playbattle.SetupBattleMusicCommand;
   import mmo.interfaces.battle.command.IBattleCommand;
   
   public class PlayBattleH5Command extends BattleCommand implements IBattleCommand
   {
      
      public function PlayBattleH5Command()
      {
         super();
      }
      
      override protected function initializeMacroCommand() : void
      {
         addSubCommand(ClearSceneCommand);
         addSubCommand(DelayCommand);
         addSubCommand(SetupBattleMusicCommand);
         addSubCommand(JumpH5BattleCommand);
         addSubCommand(PickCaughtPetCommand);
         addSubCommand(NotifyRidingHungryCommand);
         addSubCommand(NotifyGainCoolPetStoneCommand);
         addSubCommand(DisposeBattlefieldCommand);
         super.initializeMacroCommand();
      }
   }
}

