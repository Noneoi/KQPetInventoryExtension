package mmo.battle.consts
{
   public class SkillPlayOrderType
   {
      
      public static const NORMAL_PLAY_ORDER_TYPE:int = 0;
      
      public static const SEQUENCE_PLAY_ORDER_TYPE:int = 1;
      
      public function SkillPlayOrderType()
      {
         super();
      }
   }
}

