package mmo.battle.command.playsequentialbattle
{
   import mmo.battle.entity.BattleBase;
   import mmo.battle.util.BattleContentUtil;
   import mmo.battle.util.BattleUtil;
   import mmo.interfaces.battle.data.BattleInfo;
   import mmo.interfaces.battle.data.BattleResult;
   import mmo.interfaces.battle.data.BattleUnit;
   import mmo.interfaces.battle.data.FighterInfo;
   import mmo.interfaces.battle.data.PlayerInfo;
   import mmo.interfaces.battle.data.RoundResult;
   import mmo.interfaces.battle.data.SkillNumResult;
   import mmo.interfaces.battle.data.SkillNumUnit;
   import mmo.interfaces.battle.data.SkillNumUnitTransform;
   import mmo.interfaces.battle.data.SkillResult;
   import mmo.interfaces.battle.data.TeamInfo;
   import mmo.interfaces.battle.entity.IBattle;
   import mmo.interfaces.battleconfig.IBattleConfig;
   import mmo.interfaces.battleconfig.consts.SkillTypes;
   import mmo.interfaces.battleconfig.define.BufferDefine;
   import mmo.util.command.ISceneCommand;
   import mmo.util.command.SceneSimpleCommand;
   
   public class DownloadFighterCommandSeq extends SceneSimpleCommand implements ISceneCommand
   {
      
      private static const PETTITLE_FILE_PREFIX:String = "pettitle/movie/pettitlemovie";
      
      private const ACTION_FILE_PREFIX:String = "battleaction/action";
      
      private const EFFECT_FILE_PREFIX:String = "battleeffect/effect";
      
      private const BUFFER_FILE_PREFIX:String = "battlebuffer/buffer";
      
      private const SUMMON_FILE_PREFIX:String = "battlesummon/summon";
      
      private const CHANGEAVATAR_FILE_PREFIX:String = "battlechangeavatar/battlechangeavatar";
      
      private var _content:Object;
      
      private var _config:IBattleConfig;
      
      public function DownloadFighterCommandSeq()
      {
         super();
      }
      
      override public function execute(param1:Object) : void
      {
         this._content = param1;
         this._config = BattleContentUtil.getContentProperty(param1,BattleContentUtil.PN_BATTLE_CONFIG);
         var _loc2_:Array = this.getDownloadFileList();
         BattleContentUtil.addToPreDownloadList(param1,_loc2_);
         this.succeed(param1);
      }
      
      private function getDownloadFileList() : Array
      {
         var _loc3_:IBattle = null;
         var _loc4_:Array = null;
         var _loc1_:Array = BattleContentUtil.getContentProperty(this._content,BattleContentUtil.PN_BATTLES);
         var _loc2_:Array = new Array();
         for each(_loc3_ in _loc1_)
         {
            _loc4_ = this.getFileListFromBattleInfo(_loc3_.battleResult);
            _loc2_ = BattleUtil.mergeArray(_loc2_,_loc4_);
         }
         return _loc2_;
      }
      
      private function getFileListFromBattleInfo(param1:BattleResult) : Array
      {
         var _loc17_:String = null;
         var _loc18_:BufferDefine = null;
         var _loc2_:BattleInfo = param1.battleInfo;
         var _loc3_:Object = this.getFileListFromTeam(_loc2_.getTeamInfoById(0));
         var _loc4_:Array = _loc3_["action"];
         var _loc5_:Array = _loc3_["effect"];
         var _loc6_:Array = _loc3_["pfbuff"];
         var _loc7_:Array = _loc3_["other"];
         var _loc8_:Object = this.getFileListFromTeam(_loc2_.getTeamInfoById(1));
         var _loc9_:Array = _loc8_["action"];
         var _loc10_:Array = _loc8_["effect"];
         var _loc11_:Array = _loc8_["pfbuff"];
         var _loc12_:Array = _loc8_["other"];
         var _loc13_:Array = BattleUtil.mergeArray(_loc4_,_loc9_);
         var _loc14_:Array = BattleUtil.mergeArray(_loc5_,_loc10_);
         var _loc15_:Array = BattleUtil.mergeArray(_loc7_,_loc12_);
         var _loc16_:Array = BattleUtil.mergeArray(_loc6_,_loc11_);
         for each(_loc17_ in param1.buffersNeeded)
         {
            _loc18_ = this._config.getBufferDefineById(int(_loc17_));
            if(!_loc18_.hidden)
            {
               _loc16_.push(this.BUFFER_FILE_PREFIX + _loc18_.displayId);
            }
         }
         _loc16_.push(this.BUFFER_FILE_PREFIX + this._config.getDefaultPowerFullBuffId());
         return _loc13_.concat(_loc14_).concat(_loc16_).concat(_loc7_);
      }
      
      private function getFileListFromTeam(param1:TeamInfo) : Object
      {
         var otherList:Array = null;
         var playerInfo:PlayerInfo = null;
         var battles:Array = null;
         var battleBase:BattleBase = null;
         var fighterInfo:FighterInfo = null;
         var actionFile:String = null;
         var pwBuffId:int = 0;
         var pwBufferDefine:BufferDefine = null;
         var pfBuffURL:String = null;
         var titleIds:Array = null;
         var battleUnit:BattleUnit = null;
         var roundResult:RoundResult = null;
         var numUnitList:Array = null;
         var srcNumResult:SkillNumResult = null;
         var skillId:int = 0;
         var skillUrl:String = null;
         var isSummon:Boolean = false;
         var skillResult:SkillResult = null;
         var numUnit:SkillNumUnit = null;
         var counterSkillResult:SkillResult = null;
         var fighter:FighterInfo = null;
         var counterSkillId:int = 0;
         var counterSkillUrl:String = null;
         var summonFighter:FighterInfo = null;
         var summonSkillUrl:String = null;
         var transform:SkillNumUnitTransform = null;
         var teamInfo:TeamInfo = param1;
         var actionFileList:Array = [];
         var effectFileList:Array = [];
         var powerFullList:Array = [];
         otherList = [];
         for each(playerInfo in teamInfo.playerInfos)
         {
            for each(fighterInfo in playerInfo.fighterInfos)
            {
               actionFile = this.ACTION_FILE_PREFIX + fighterInfo.faceId;
               this.addToArrayHelper(actionFileList,actionFile);
               pwBuffId = int(this._config.getPowerFullBuffId(fighterInfo.faceId));
               pwBufferDefine = this._config.getBufferDefineById(pwBuffId);
               pfBuffURL = this.BUFFER_FILE_PREFIX + pwBufferDefine.displayId;
               this.addToArrayHelper(powerFullList,pfBuffURL);
               if(fighterInfo.petTitleData)
               {
                  titleIds = fighterInfo.petTitleData.getTitleIds();
                  titleIds.forEach(function(param1:int, ... rest):*
                  {
                     var _loc3_:String = PETTITLE_FILE_PREFIX + param1;
                     addToArrayHelper(otherList,_loc3_);
                  });
               }
            }
         }
         battles = BattleContentUtil.getContentProperty(this._content,BattleContentUtil.PN_BATTLES);
         for each(battleBase in battles)
         {
            for each(battleUnit in battleBase.battleResult.battleFlow.battleUnits)
            {
               for each(roundResult in battleUnit.roundResults)
               {
                  numUnitList = [];
                  srcNumResult = roundResult.sourceSkillNumResult;
                  numUnitList = numUnitList.concat(srcNumResult.allBeforeNumUnit);
                  numUnitList = numUnitList.concat(srcNumResult.allAfterNumUnit);
                  skillId = int(roundResult.skillId);
                  skillUrl = this.EFFECT_FILE_PREFIX + skillId;
                  if(this._config.getSkillDefineById(skillId) == null)
                  {
                     isSummon = false;
                  }
                  else
                  {
                     isSummon = this._config.getSkillDefineById(skillId).type2 == SkillTypes.SUMMON ? true : false;
                  }
                  if(roundResult.skillExecuteCode > 0 && !isSummon)
                  {
                     this.addToArrayHelper(effectFileList,skillUrl);
                  }
                  for each(skillResult in roundResult.targetSkillResults)
                  {
                     if(skillResult.counter)
                     {
                        counterSkillResult = SkillResult.genCounterResult(skillResult.targetTeamId,skillResult.targetPlayerName,skillResult.targetCharacterId,skillResult.numResult);
                        fighter = battleBase.battleResult.battleInfo.getTeamInfoById(counterSkillResult.targetTeamId).getPlayerInfoByName(counterSkillResult.targetPlayerName).getFighterInfoById(counterSkillResult.targetCharacterId);
                        counterSkillId = int(fighter.normalSkill);
                        counterSkillUrl = this.EFFECT_FILE_PREFIX + counterSkillId;
                        this.addToArrayHelper(effectFileList,counterSkillUrl);
                     }
                     if(isSummon)
                     {
                        summonFighter = battleBase.battleResult.battleInfo.getTeamInfoById(skillResult.targetTeamId).getPlayerInfoByName(skillResult.targetPlayerName).getFighterInfoById(skillResult.targetCharacterId);
                        summonSkillUrl = this.SUMMON_FILE_PREFIX + summonFighter.raceId;
                        this.addToArrayHelper(effectFileList,summonSkillUrl);
                     }
                     numUnitList = numUnitList.concat(skillResult.numResult.allBeforeNumUnit);
                     numUnitList = numUnitList.concat(skillResult.numResult.allAfterNumUnit);
                  }
                  for each(numUnit in numUnitList)
                  {
                     transform = numUnit as SkillNumUnitTransform;
                     if(transform != null)
                     {
                        this.addToArrayHelper(actionFileList,this.ACTION_FILE_PREFIX + transform.curFaceId);
                        pwBuffId = int(this._config.getPowerFullBuffId(transform.curFaceId));
                        pwBufferDefine = this._config.getBufferDefineById(pwBuffId);
                        this.addToArrayHelper(powerFullList,this.BUFFER_FILE_PREFIX + pwBufferDefine.displayId);
                        if(this._config.changeAvatarIds.indexOf(transform.curFaceId) != -1)
                        {
                           this.addToArrayHelper(otherList,this.CHANGEAVATAR_FILE_PREFIX + transform.curFaceId);
                        }
                        else
                        {
                           this.addToArrayHelper(otherList,this.CHANGEAVATAR_FILE_PREFIX + "_default");
                        }
                     }
                  }
               }
            }
         }
         return {
            "action":actionFileList,
            "effect":effectFileList,
            "pfbuff":powerFullList,
            "other":otherList
         };
      }
      
      private function addToArrayHelper(param1:Array, param2:String) : void
      {
         if(param1.indexOf(param2) == -1)
         {
            param1.push(param2);
         }
      }
   }
}

