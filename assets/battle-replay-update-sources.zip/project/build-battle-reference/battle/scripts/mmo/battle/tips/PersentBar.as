package mmo.battle.tips
{
   import flash.display.MovieClip;
   import flash.display.Sprite;
   import flash.text.TextField;
   
   public class PersentBar
   {
      
      protected var _res:Sprite;
      
      protected var _persentBar:MovieClip;
      
      protected var _persentTxt:TextField;
      
      protected var _maxValue:Number = 100;
      
      protected var _curValue:Number = 100;
      
      private var _boundless:Boolean;
      
      public function PersentBar(param1:Sprite, param2:Boolean = false)
      {
         super();
         this._res = param1;
         this._boundless = param2;
         this.initComponent();
      }
      
      public function setMaxValue(param1:Number) : void
      {
         this._maxValue = param1;
         this.refreash();
      }
      
      public function setCurValue(param1:Number) : void
      {
         if(param1 < 0)
         {
            param1 = 0;
         }
         this._curValue = param1;
         this.refreash();
      }
      
      public function refreash() : void
      {
         this.refreashPersentText();
         this.refreashPersentBar();
      }
      
      protected function refreashPersentText() : void
      {
         this._persentTxt.text = "" + this._curValue + (this._boundless ? "" : "/" + this._maxValue);
      }
      
      protected function refreashPersentBar() : void
      {
         var _loc1_:int = Number(this._curValue) / this._maxValue * 100;
         if(_loc1_ < 1)
         {
            _loc1_ = 1;
         }
         else if(_loc1_ > 100)
         {
            _loc1_ = 100;
         }
         this._persentBar.gotoAndStop(_loc1_);
      }
      
      protected function initComponent() : void
      {
         this._persentBar = this._res.getChildByName("bar") as MovieClip;
         this._persentTxt = this._res.getChildByName("txt") as TextField;
      }
   }
}

