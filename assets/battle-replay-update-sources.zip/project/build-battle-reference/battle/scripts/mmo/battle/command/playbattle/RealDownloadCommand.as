package mmo.battle.command.playbattle
{
   import flash.display.BitmapData;
   import flash.display.Sprite;
   import flash.geom.Matrix;
   import flash.system.ApplicationDomain;
   import flash.text.TextField;
   import flash.text.TextFormat;
   import flash.text.TextFormatAlign;
   import flash.utils.setTimeout;
   import mmo.battle.container.BattleContainer;
   import mmo.battle.util.BattleContentUtil;
   import mmo.common.DisplayUtil;
   import mmo.common.EventBinder;
   import mmo.common.user.UserInfo;
   import mmo.interfaces.ServiceContainer;
   import mmo.interfaces.battle.data.BattleInfo;
   import mmo.interfaces.battle.data.FighterInfo;
   import mmo.interfaces.battle.data.PlayerInfo;
   import mmo.interfaces.battle.data.TeamInfo;
   import mmo.interfaces.battle.entity.IBattle;
   import mmo.interfaces.battle.service.BattleResultVersion;
   import mmo.interfaces.material.ridepetcard.IRidePetCardService;
   import mmo.interfaces.pet.peticon.PetIconContainer;
   import mmo.interfaces.pet.peticon.PetIconEvent;
   import mmo.interfaces.pet.peticon.PetIconType;
   import mmo.interfaces.pet.ride.IRideService;
   import mmo.interfaces.pet.ride.IRideServiceV2;
   import mmo.interfaces.pet.ride.IRideV2PetCardInfo;
   import mmo.loader.CustomLoader;
   import mmo.loader.CustomLoaderEvent;
   import mmo.loader.FileType;
   import mmo.loader.LoadingSpriteType;
   import mmo.loader.SpineLoader;
   import mmo.loader.loadingsprite.ILoadingSprite;
   import mmo.loader.scheduler.ResPriority;
   import mmo.loader.scheduler.VersManager;
   import mmo.util.command.ISceneCommand;
   import mmo.util.command.SceneSimpleCommand;
   import web.Promise;
   
   public class RealDownloadCommand extends SceneSimpleCommand implements ISceneCommand
   {
      
      public static const CHANGEAVATAR_FILE_PREFIX:String = "battlechangeavatar/battlechangeavatar";
      
      public static const DEFAULT_CHANGEAVATAR_POSTFIX:String = "_default";
      
      public static const DEFAULT_CHANGEAVATAR_FILE:String = CHANGEAVATAR_FILE_PREFIX + DEFAULT_CHANGEAVATAR_POSTFIX;
      
      private static const LOADING_MSG:String = "正在加载战斗资源...";
      
      private const ACTION_FILE_PREFIX:String = "battleaction/action";
      
      private const EFFECT_FILE_PREFIX:String = "battleeffect/effect";
      
      private const DEFAULT_ACTION_FILE:String = this.ACTION_FILE_PREFIX + "_default";
      
      private const DEFAULT_EFFECT_FILE:String = this.EFFECT_FILE_PREFIX + "_default";
      
      private var _content:Object;
      
      private var _loader:CustomLoader;
      
      private var _downloadDefaultBgFlag:Boolean = true;
      
      private var _downloadCompleteFlag:Boolean = false;
      
      private var defaultDownLoadList:Array = [];
      
      private var _error2Need2Notify:Array = [];
      
      private var _downloadList:Array;
      
      private var _rideV2Svc:IRideServiceV2 = ServiceContainer.getService(IRideService);
      
      private var _ridePetCardSvc:IRidePetCardService = ServiceContainer.getService(IRidePetCardService);
      
      public function RealDownloadCommand()
      {
         super();
      }
      
      override public function execute(param1:Object) : void
      {
         this._content = param1;
         var _loc2_:* = BattleContentUtil.getContentProperty(param1,BattleContentUtil.PN_DOMAIN);
         this._loader = new CustomLoader(ResPriority.HIGHEST,true,_loc2_);
         this._loader.addEventListener(CustomLoaderEvent.onLoadCompleted,this.onLoadComplete);
         this._loader.addEventListener(CustomLoaderEvent.onError,this.onLoadError);
         BattleContentUtil.setContentProperty(param1,BattleContentUtil.PN_LOADER,this._loader);
         this._downloadList = BattleContentUtil.getPreDownloadList(param1);
         var _loc3_:ILoadingSprite = BattleContentUtil.getContentProperty(param1,BattleContentUtil.PN_LOADING_STYLE);
         this._loader.LoadC(this._downloadList,_loc3_,false,LOADING_MSG);
         this.addPlayerAvatar();
      }
      
      private function addPlayerAvatar() : void
      {
         var _loc1_:Sprite = this._loader.loadingSprite.mainRes();
         var _loc2_:Sprite = _loc1_["spLAvatar"];
         var _loc3_:Sprite = _loc1_["spRAvatar"];
         var _loc4_:Sprite = _loc1_["spLRidePet"];
         var _loc5_:Sprite = _loc1_["spRRidePet"];
         var _loc6_:Sprite = BattleContentUtil.getContentProperty(this._content,BattleContentUtil.PN_PLAYER_AVATAR_L);
         var _loc7_:Sprite = BattleContentUtil.getContentProperty(this._content,BattleContentUtil.PN_PLAYER_AVATAR_R);
         var _loc8_:BattleInfo = BattleContentUtil.getContentProperty(this._content,BattleContentUtil.PN_BATTLE_INFO);
         var _loc9_:TeamInfo = _loc8_.teamInfos[0] as TeamInfo;
         var _loc10_:TeamInfo = _loc8_.teamInfos[1] as TeamInfo;
         if(Boolean(_loc2_) && Boolean(_loc6_))
         {
            _loc2_.addChild(_loc6_);
            this.checkAddRidePet(_loc4_,_loc9_.playerInfos[0]);
         }
         if(Boolean(_loc3_) && Boolean(_loc7_))
         {
            _loc3_.addChild(_loc7_);
            this.checkAddRidePet(_loc5_,_loc10_.playerInfos[0],true);
         }
      }
      
      private function checkAddRidePet(param1:Sprite, param2:PlayerInfo, param3:Boolean = false) : void
      {
         var _loc4_:IRideV2PetCardInfo = null;
         var _loc5_:ApplicationDomain = null;
         var _loc6_:Sprite = null;
         if(param2.playerName == UserInfo.nickName)
         {
            if(this._rideV2Svc.ridingPetId > 0)
            {
               _loc4_ = this._rideV2Svc.getRidePetCardInfoByOwnId(this._rideV2Svc.ridingPetId);
               _loc5_ = BattleContentUtil.getContentProperty(this._content,BattleContentUtil.PN_DOMAIN);
               _loc6_ = this._ridePetCardSvc.getView(_loc4_.materialId,120,120,true,_loc5_);
               if(param3)
               {
                  _loc6_.scaleX = -1;
               }
               if(param1)
               {
                  param1.addChild(_loc6_);
               }
            }
         }
      }
      
      override public function cancel() : void
      {
         super.cancel();
         if(this._loader != null)
         {
            this._loader.cancel();
            this._loader.close();
         }
      }
      
      private function onLoadError(param1:CustomLoaderEvent) : void
      {
         if(VersManager.version.length > 0)
         {
            this.onLoadDefaultComplete(null);
            return;
         }
         if(param1.file.indexOf(DownloadBackgroundCommand.BACKGROUND_FILE_PREFIX) != -1 && param1.file != DownloadBackgroundCommand.DEFAULT_BACKGROUND_FILE)
         {
            this.defaultDownLoadList.push(DownloadBackgroundCommand.DEFAULT_BACKGROUND_FILE);
         }
         else if(param1.file.indexOf(CHANGEAVATAR_FILE_PREFIX) != -1 && param1.file != DEFAULT_CHANGEAVATAR_FILE)
         {
            if(this.defaultDownLoadList.indexOf(DEFAULT_CHANGEAVATAR_FILE) == -1)
            {
               this.defaultDownLoadList.push(DEFAULT_CHANGEAVATAR_FILE);
            }
         }
         else if(param1.file.indexOf(this.ACTION_FILE_PREFIX) != -1 && param1.file != this.DEFAULT_ACTION_FILE)
         {
            if(this.defaultDownLoadList.indexOf(this.DEFAULT_ACTION_FILE) == -1)
            {
               this.defaultDownLoadList.push(this.DEFAULT_ACTION_FILE);
            }
            this._error2Need2Notify.push("缺少战斗动作资源【" + param1.file + "】");
         }
         else if(param1.file.indexOf(this.EFFECT_FILE_PREFIX) != -1 && param1.file != this.DEFAULT_EFFECT_FILE)
         {
            if(this.defaultDownLoadList.indexOf(this.DEFAULT_EFFECT_FILE) == -1)
            {
               this.defaultDownLoadList.push(this.DEFAULT_EFFECT_FILE);
            }
            this._error2Need2Notify.push("缺少战斗特效资源【" + param1.file + "】");
         }
         else
         {
            BattleContentUtil.setContentProperty(this._content,BattleContentUtil.PN_ERROR_MSG,"战斗资源【" + param1.file + "】加载失败，请重试。");
            this.fail(this._content);
            this._content = null;
            this._loader = null;
         }
         this._downloadDefaultBgFlag = false;
      }
      
      private function onLoadComplete(param1:CustomLoaderEvent) : void
      {
         var e:CustomLoaderEvent = param1;
         var ps:Array = this._downloadList.filter(function(param1:*, param2:int, param3:Array):Boolean
         {
            return "type" in param1 && param1.type == FileType.AQZ;
         }).map(function(param1:*, param2:int, param3:Array):Promise
         {
            return SpineLoader.load(String(param1.url).replace("." + FileType.AQZ,""));
         });
         Promise.all(ps).then(function(param1:Array):void
         {
            _downloadCompleteFlag = true;
            preparePetIcons();
         });
      }
      
      private function onLoadDefaultComplete(param1:CustomLoaderEvent) : void
      {
         if(param1 != null)
         {
            param1.currentTarget.removeEventListener(CustomLoaderEvent.onLoadCompleted,this.onLoadDefaultComplete);
         }
         this._downloadDefaultBgFlag = true;
         this.preparePetIcons();
      }
      
      private function preparePetIcons() : void
      {
         var i:int;
         var matrix:Matrix = null;
         var battleInfo:* = undefined;
         var raceIds:Array = null;
         var raceId2BitmapDataMap:Object = null;
         var scanPlayerT:Function = function(param1:int):void
         {
            var _loc3_:FighterInfo = null;
            var _loc2_:PlayerInfo = battleInfo.getTeamInfoById(param1).playerInfos[0];
            for each(_loc3_ in _loc2_.fighterInfos)
            {
               if(raceIds.indexOf(_loc3_.originalRaceId) == -1)
               {
                  raceIds.push(_loc3_.originalRaceId);
               }
            }
         };
         var loadPetIconT:Function = function(param1:int):void
         {
            var bitmapData:BitmapData = null;
            var petIcon:PetIconContainer = null;
            var binder:EventBinder = null;
            var raceId:int = param1;
            bitmapData = new BitmapData(48,48,true,0);
            petIcon = new PetIconContainer(raceId,PetIconType.FIGHT,0,0,false,false,1,null,true,null,false);
            binder = new EventBinder();
            var onIconLoadedT:Function = function(param1:PetIconEvent):*
            {
               binder.unBindAll();
               bitmapData.draw(petIcon,matrix);
               raceId2BitmapDataMap[raceId.toString()] = bitmapData;
               checkAllLoadedT();
            };
            var onFailLoadIconT:Function = function(param1:PetIconEvent):*
            {
               binder.unBindAll();
               raceId2BitmapDataMap[raceId.toString()] = bitmapData;
               checkAllLoadedT();
            };
            binder.bind(petIcon,PetIconEvent.ON_ICON_LOADED,onIconLoadedT);
            binder.bind(petIcon,PetIconEvent.FAIL_LOAD_ICON,onFailLoadIconT);
            petIcon.startLoad();
         };
         var checkAllLoadedT:Function = function():void
         {
            var _loc1_:int = 0;
            while(_loc1_ < raceIds.length)
            {
               if(!raceId2BitmapDataMap.hasOwnProperty(raceIds[_loc1_].toString()))
               {
                  return;
               }
               _loc1_++;
            }
            BattleContentUtil.setContentProperty(_content,BattleContentUtil.PN_RACE_ID_2_BITMAP_DATA_MAP,raceId2BitmapDataMap);
            tryFinishCommand();
         };
         var battle:IBattle = BattleContentUtil.getContentProperty(this._content,BattleContentUtil.PN_BATTLE);
         if(battle.battleResult.version < BattleResultVersion.VER_20251226)
         {
            this.tryFinishCommand();
            return;
         }
         matrix = new Matrix(1,0,0,1,24,24);
         battleInfo = BattleContentUtil.getContentProperty(this._content,BattleContentUtil.PN_BATTLE_INFO);
         raceIds = [];
         raceId2BitmapDataMap = {};
         scanPlayerT(0);
         scanPlayerT(1);
         i = 0;
         while(i < raceIds.length)
         {
            loadPetIconT(raceIds[i]);
            i++;
         }
      }
      
      private function tryFinishCommand() : void
      {
         var _loc1_:* = undefined;
         var _loc2_:CustomLoader = null;
         if(this._downloadCompleteFlag && this._downloadDefaultBgFlag)
         {
            this.notifyErrors();
            this._loader.removeEventListener(CustomLoaderEvent.onLoadCompleted,this.onLoadComplete);
            this._loader.removeEventListener(CustomLoaderEvent.onError,this.onLoadError);
            this.succeed(this._content);
            this._content = null;
            this._loader = null;
         }
         else
         {
            _loc1_ = BattleContentUtil.getContentProperty(this._content,BattleContentUtil.PN_DOMAIN);
            _loc2_ = new CustomLoader(ResPriority.NORMAL,true,_loc1_);
            _loc2_.addEventListener(CustomLoaderEvent.onLoadCompleted,this.onLoadDefaultComplete);
            _loc2_.load(this.defaultDownLoadList,LoadingSpriteType.NONE);
         }
      }
      
      private function notifyErrors() : void
      {
         var container:BattleContainer = null;
         var errorMsg:String = null;
         var txt:TextField = null;
         var tf:TextFormat = null;
         container = BattleContentUtil.getContentProperty(this._content,BattleContentUtil.PN_CONTAINER);
         var i:int = 0;
         while(i < this._error2Need2Notify.length)
         {
            errorMsg = this._error2Need2Notify[i];
            txt = new TextField();
            tf = new TextFormat();
            tf.size = 13;
            tf.bold = true;
            tf.align = TextFormatAlign.CENTER;
            txt.text = errorMsg;
            txt.x = 0;
            txt.y = 30 + 20 * i;
            txt.multiline = false;
            txt.width = 960;
            txt.setTextFormat(tf);
            txt.textColor = 16711680;
            txt.name = "notifyError_" + i;
            container.uiLayer.addChild(txt);
            i++;
         }
         setTimeout(function():void
         {
            var _loc1_:int = 0;
            while(_loc1_ < _error2Need2Notify.length)
            {
               DisplayUtil.removeChildByName(container.uiLayer,"notifyError_" + _loc1_);
               _loc1_++;
            }
         },3000);
      }
   }
}

