package mmo.battle.resultpanel
{
   import flash.display.MovieClip;
   import flash.display.SimpleButton;
   import flash.display.Sprite;
   import flash.events.MouseEvent;
   import flash.system.ApplicationDomain;
   import mmo.battle.util.BattleContentUtil;
   import mmo.common.AlignType;
   import mmo.common.ProgressFullSprite;
   import mmo.common.utils.panel.helper.ClickHelper;
   import mmo.common.utils.panel.modaldialog.ModalDialogManager;
   import mmo.interfaces.IService;
   import mmo.interfaces.ServiceContainer;
   import mmo.interfaces.battle.entity.IBattle;
   import mmo.interfaces.catalog.CatalogNames;
   import mmo.interfaces.catalog.IBookService;
   import mmo.interfaces.chat.IChatService;
   import mmo.interfaces.commonhud.ICommonHud;
   import mmo.interfaces.interacthelper.IInteractHelper;
   import mmo.interfaces.newactivity.INewActivityService;
   import mmo.interfaces.task.ITaskService;
   import mmo.play.scene.SceneManager;
   
   public class BattleFailPanel
   {
      
      private static const DEFAULT_LOSE_PANEL_CLS:String = "mmo.battle.common.BattleLosePanelRes";
      
      private var _content:Object;
      
      private var _resSprite:Sprite;
      
      private var _callback:Function;
      
      private var _btnOk:SimpleButton;
      
      private var _losePanelCls:String;
      
      private var _btnReplay:SimpleButton;
      
      public function BattleFailPanel(param1:Object, param2:Function, param3:String)
      {
         super();
         this._content = param1;
         this._callback = param2;
         this._losePanelCls = param3;
         this.initComponent();
         this.initListener();
         this.setIsChangeScene();
      }
      
      public function show() : void
      {
         ModalDialogManager.getInstance().addModalDialog(this._resSprite,AlignType.NONE);
      }
      
      private function initComponent() : void
      {
         var _loc2_:String = null;
         var _loc5_:ITaskService = null;
         var _loc6_:IBattle = null;
         var _loc1_:ApplicationDomain = this._content["Domain"];
         if(this._losePanelCls == "")
         {
            _loc2_ = DEFAULT_LOSE_PANEL_CLS;
         }
         else
         {
            _loc2_ = this._losePanelCls;
         }
         var _loc3_:Class = _loc1_.getDefinition(_loc2_) as Class;
         this._resSprite = new _loc3_() as Sprite;
         this._btnOk = this._resSprite.getChildByName("ok") as SimpleButton;
         var _loc4_:MovieClip = this._resSprite["mcMessage"];
         if(_loc4_ != null)
         {
            _loc5_ = ServiceContainer.getService(ITaskService);
            _loc4_.gotoAndStop(_loc5_.isUserTaskFinish(1) ? 1 : 2);
         }
         this._btnReplay = this._resSprite.getChildByName("btnReplay") as SimpleButton;
         if(this._btnReplay != null)
         {
            _loc6_ = BattleContentUtil.getContentProperty(this._content,BattleContentUtil.PN_BATTLE);
            if(_loc6_.battleResult.replay)
            {
               this._btnReplay.addEventListener(MouseEvent.CLICK,this.onReplay);
            }
            else
            {
               this._btnReplay.visible = false;
            }
         }
      }
      
      private function onReplay(param1:MouseEvent) : void
      {
         var _loc2_:IChatService = ServiceContainer.getService(IChatService);
         var _loc3_:IBattle = BattleContentUtil.getContentProperty(this._content,BattleContentUtil.PN_BATTLE);
         _loc2_.showSharePanel(3,{"battleId":_loc3_.battleResult.battleId});
      }
      
      private function initListener() : void
      {
         this._btnOk.addEventListener(MouseEvent.CLICK,this.onResultConfirm);
         var _loc1_:ClickHelper = new ClickHelper(this._resSprite);
         _loc1_.regRegexFunc("btnArrow_*",this.onClickArrow);
         _loc1_.regRegexFunc("btnGo_*",this.onClickGo);
         _loc1_.regRegexFunc("btnHud_*",this.onClickHud);
         _loc1_.regClickFunc("btnUbp",this.onClickUBP);
         _loc1_.regClickFunc("btnImproveBattleSkill",this.onImproveBattleSkill);
         _loc1_.regRegexFunc("btnGetService_[A-z]+(_[0-9]+)*",this.onClickGetService);
         _loc1_.regRegexFunc("btnNewAct_[A-z]+(_[0-9]+)*",this.onClickNewAct);
      }
      
      private function onImproveBattleSkill() : void
      {
         this.onResultConfirm(null);
         var _loc1_:INewActivityService = ServiceContainer.getService(INewActivityService);
         _loc1_.loadAndInitNormalActivity("battleintroducev1","showMainPanel");
      }
      
      private function removeListener() : void
      {
         this._btnOk.removeEventListener(MouseEvent.CLICK,this.onResultConfirm);
      }
      
      private function onClickUBP() : void
      {
         this.onResultConfirm(null);
         ProgressFullSprite.show();
         ServiceContainer.instance.tryGetService(IBookService,function(param1:IBookService, param2:Object):void
         {
            ProgressFullSprite.close();
            param1.showCatalogAt(CatalogNames.PET_CATALOG,8,1);
         });
      }
      
      private function onClickArrow(param1:String) : void
      {
         this.setIsChangeScene(true);
         this.onResultConfirm(null);
         var _loc2_:String = param1.split("_")[1];
         var _loc3_:IInteractHelper = ServiceContainer.getService(IInteractHelper);
         _loc3_.addGuideArrowByKey(_loc2_,true);
      }
      
      private function onClickGo(param1:String) : void
      {
         this.setIsChangeScene(true);
         this.onResultConfirm(null);
         var _loc2_:String = param1.split("_")[1];
         SceneManager.getInstance().loadScene(_loc2_);
      }
      
      private function onClickHud(param1:String) : void
      {
         var key:String = null;
         var targetName:String = param1;
         this.setIsChangeScene(true);
         this.onResultConfirm(null);
         key = targetName.split("_")[1];
         ServiceContainer.tryGetService(ICommonHud,function(param1:ICommonHud, param2:Object):void
         {
            param1.showHudPanel(key);
         });
      }
      
      private function onClickGetService(param1:String) : void
      {
         var serviceName:String;
         var argArray:Array = null;
         var functionName:String = null;
         var targetName:String = param1;
         this.onResultConfirm(null);
         argArray = targetName.split("_");
         argArray.shift();
         serviceName = argArray.shift();
         functionName = argArray.shift();
         ProgressFullSprite.show();
         ServiceContainer.tryGetService(serviceName,function(param1:IService, param2:Object):void
         {
            ProgressFullSprite.close();
            var _loc3_:Function = param1[functionName] as Function;
            _loc3_.apply(null,argArray);
         });
      }
      
      private function onClickNewAct(param1:String) : void
      {
         this.onResultConfirm(null);
         var _loc2_:Array = param1.split("_");
         var _loc3_:INewActivityService = ServiceContainer.getService(INewActivityService);
         _loc3_.loadAndInitNormalActivity(_loc2_[1],_loc2_[2]);
      }
      
      private function setIsChangeScene(param1:Boolean = false) : void
      {
         this._content["isChangeScene"] = param1;
      }
      
      private function onResultConfirm(param1:MouseEvent) : void
      {
         ModalDialogManager.getInstance().removeModalDialog(this._resSprite);
         this.removeListener();
         this._callback.apply();
      }
   }
}

