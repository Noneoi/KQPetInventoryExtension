package mmo.battle.command.embed
{
   import mmo.battle.command.embed.sub.EmbedCommandBase;
   import mmo.battle.command.embed.sub.EmbedCommandCode;
   import mmo.battle.command.embed.sub.EmbedCommandMovie;
   import mmo.battle.command.embed.sub.EmbedCommandNpcDialog;
   import mmo.interfaces.battleconfig.consts.EmbedEffectTypes;
   import mmo.interfaces.battleconfig.define.EmbedEffectDefine;
   
   public class EmbedEffectCmdFactory
   {
      
      private static var TYPE_2_ClS:Object = {};
      
      TYPE_2_ClS[EmbedEffectTypes.MOVIE] = EmbedCommandMovie;
      TYPE_2_ClS[EmbedEffectTypes.NPC_DIALOG] = EmbedCommandNpcDialog;
      TYPE_2_ClS[EmbedEffectTypes.CODE] = EmbedCommandCode;
      
      public function EmbedEffectCmdFactory()
      {
         super();
      }
      
      public static function getEmbedCommand(param1:EmbedEffectDefine) : EmbedCommandBase
      {
         var _loc2_:Class = TYPE_2_ClS[param1.type];
         return new _loc2_(param1);
      }
   }
}

