package mmo.interfaces.petbadge
{
   public class PetBadgeConst
   {
      
      public static const BUFF_TYPE_JOB:int = 0;
      
      public static const BUFF_TYPE_EXCLUSIVE:int = 1;
      
      public static const BUFF_TYPE_ALL:Array = [BUFF_TYPE_JOB,BUFF_TYPE_EXCLUSIVE];
      
      public static const BUFF_TYPE_NUM:int = BUFF_TYPE_ALL.length;
      
      public static const ID_NULL:int = 0;
      
      public static const BADGE_MAX_IN_PET:int = 2;
      
      public static const JOB_LEVEL_MAX_OPEN:int = 5;
      
      public function PetBadgeConst()
      {
         super();
      }
   }
}

