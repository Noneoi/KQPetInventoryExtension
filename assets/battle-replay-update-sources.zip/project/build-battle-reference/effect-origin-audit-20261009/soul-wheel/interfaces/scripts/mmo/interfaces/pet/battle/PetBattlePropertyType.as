package mmo.interfaces.pet.battle
{
   import mmo.interfaces.battleconfig.consts.JobAttackType;
   
   public class PetBattlePropertyType
   {
      
      public static var _allValues:Array = [];
      
      public static var _allContainers:Array = [];
      
      private static var _id2PropertyType:Object = {};
      
      private static var _name2PropertyType:Object = {};
      
      public static const UNKNOWN:PetBattlePropertyType = PetBattlePropertyType.create(-1,"未知");
      
      public static const RACE_MAX_HP:PetBattlePropertyType = PetBattlePropertyType.create(0,"生命种族");
      
      public static const RACE_PHYSICAL_ATTACK:PetBattlePropertyType = PetBattlePropertyType.create(1,"物攻种族",false,JobAttackType.PHYSICS);
      
      public static const RACE_PHYSICAL_DEFENCE:PetBattlePropertyType = PetBattlePropertyType.create(2,"物防种族");
      
      public static const RACE_MAGIC_ATTACK:PetBattlePropertyType = PetBattlePropertyType.create(3,"魔攻种族",false,JobAttackType.MAGIC);
      
      public static const RACE_MAGIC_DEFENCE:PetBattlePropertyType = PetBattlePropertyType.create(4,"魔防种族");
      
      public static const RACE_ULTIMATE_ATTACK:PetBattlePropertyType = PetBattlePropertyType.create(5,"超攻种族");
      
      public static const RACE_ULTIMATE_DEFENCE:PetBattlePropertyType = PetBattlePropertyType.create(6,"超防种族");
      
      public static const RACE_SPEED:PetBattlePropertyType = PetBattlePropertyType.create(7,"速度种族");
      
      public static const RACE_SUPER_PHYSICAL_ATTACK:PetBattlePropertyType = PetBattlePropertyType.create(1001,"超物攻种族",false,JobAttackType.SUPER_PHYSICS);
      
      public static const RACE_SUPER_PHYSICAL_DEFENCE:PetBattlePropertyType = PetBattlePropertyType.create(1002,"超物防种族");
      
      public static const RACE_SUPER_MAGIC_ATTACK:PetBattlePropertyType = PetBattlePropertyType.create(1003,"超魔攻种族",false,JobAttackType.SUPER_MAGIC);
      
      public static const RACE_SUPER_MAGIC_DEFENCE:PetBattlePropertyType = PetBattlePropertyType.create(1004,"超魔防种族");
      
      public static const INDIVIDUAL_MAX_HP:PetBattlePropertyType = PetBattlePropertyType.create(10,"生命个体");
      
      public static const INDIVIDUAL_PHYSICAL_ATTACK:PetBattlePropertyType = PetBattlePropertyType.create(11,"物攻个体",false,JobAttackType.PHYSICS);
      
      public static const INDIVIDUAL_PHYSICAL_DEFENCE:PetBattlePropertyType = PetBattlePropertyType.create(12,"物防个体");
      
      public static const INDIVIDUAL_MAGIC_ATTACK:PetBattlePropertyType = PetBattlePropertyType.create(13,"魔攻个体",false,JobAttackType.MAGIC);
      
      public static const INDIVIDUAL_MAGIC_DEFENCE:PetBattlePropertyType = PetBattlePropertyType.create(14,"魔防个体");
      
      public static const INDIVIDUAL_ULTIMATE_ATTACK:PetBattlePropertyType = PetBattlePropertyType.create(15,"超攻个体");
      
      public static const INDIVIDUAL_ULTIMATE_DEFENCE:PetBattlePropertyType = PetBattlePropertyType.create(16,"超防个体");
      
      public static const INDIVIDUAL_SPEED:PetBattlePropertyType = PetBattlePropertyType.create(17,"速度个体");
      
      public static const INDIVIDUAL_SUPER_PHYSICAL_ATTACK:PetBattlePropertyType = PetBattlePropertyType.create(1101,"超物攻个体",false,JobAttackType.SUPER_PHYSICS);
      
      public static const INDIVIDUAL_SUPER_PHYSICAL_DEFENCE:PetBattlePropertyType = PetBattlePropertyType.create(1102,"超物防个体");
      
      public static const INDIVIDUAL_SUPER_MAGIC_ATTACK:PetBattlePropertyType = PetBattlePropertyType.create(1103,"超魔攻个体",false,JobAttackType.SUPER_MAGIC);
      
      public static const INDIVIDUAL_SUPER_MAGIC_DEFENCE:PetBattlePropertyType = PetBattlePropertyType.create(1104,"超魔防个体");
      
      public static const LEARN_MAX_HP:PetBattlePropertyType = PetBattlePropertyType.create(20,"生命学习");
      
      public static const LEARN_PHYSICAL_ATTACK:PetBattlePropertyType = PetBattlePropertyType.create(21,"物攻学习",false,JobAttackType.PHYSICS);
      
      public static const LEARN_PHYSICAL_DEFENCE:PetBattlePropertyType = PetBattlePropertyType.create(22,"物防学习");
      
      public static const LEARN_MAGIC_ATTACK:PetBattlePropertyType = PetBattlePropertyType.create(23,"魔攻学习",false,JobAttackType.MAGIC);
      
      public static const LEARN_MAGIC_DEFENCE:PetBattlePropertyType = PetBattlePropertyType.create(24,"魔防学习");
      
      public static const LEARN_ULTIMATE_ATTACK:PetBattlePropertyType = PetBattlePropertyType.create(25,"超攻学习");
      
      public static const LEARN_ULTIMATE_DEFENCE:PetBattlePropertyType = PetBattlePropertyType.create(26,"超防学习");
      
      public static const LEARN_SPEED:PetBattlePropertyType = PetBattlePropertyType.create(27,"速度学习");
      
      public static const EQUIPMENTS_MAX_HP:PetBattlePropertyType = PetBattlePropertyType.create(1201,"生命装备");
      
      public static const EQUIPMENTS_PHYSICAL_ATTACK:PetBattlePropertyType = PetBattlePropertyType.create(1202,"物攻装备",false,JobAttackType.PHYSICS);
      
      public static const EQUIPMENTS_PHYSICAL_DEFENCE:PetBattlePropertyType = PetBattlePropertyType.create(1203,"物防装备");
      
      public static const EQUIPMENTS_MAGIC_ATTACK:PetBattlePropertyType = PetBattlePropertyType.create(1204,"魔攻装备",false,JobAttackType.MAGIC);
      
      public static const EQUIPMENTS_MAGIC_DEFENCE:PetBattlePropertyType = PetBattlePropertyType.create(1205,"魔防装备");
      
      public static const EQUIPMENTS_ULTIMATE_ATTACK:PetBattlePropertyType = PetBattlePropertyType.create(1206,"超攻装备");
      
      public static const EQUIPMENTS_ULTIMATE_DEFENCE:PetBattlePropertyType = PetBattlePropertyType.create(1207,"超防装备");
      
      public static const EQUIPMENTS_SPEED:PetBattlePropertyType = PetBattlePropertyType.create(1208,"速度装备");
      
      public static const EQUIPMENTS_SUPER_PHYSICAL_ATTACK:PetBattlePropertyType = PetBattlePropertyType.create(1209,"超物攻装备",false,JobAttackType.SUPER_PHYSICS);
      
      public static const EQUIPMENTS_SUPER_PHYSICAL_DEFENCE:PetBattlePropertyType = PetBattlePropertyType.create(1210,"超物防装备");
      
      public static const EQUIPMENTS_SUPER_MAGIC_ATTACK:PetBattlePropertyType = PetBattlePropertyType.create(1211,"超魔攻装备",false,JobAttackType.SUPER_MAGIC);
      
      public static const EQUIPMENTS_SUPER_MAGIC_DEFENCE:PetBattlePropertyType = PetBattlePropertyType.create(1212,"超魔防装备");
      
      public static const EQUIPMENTS_SPEED_RATE:PetBattlePropertyType = PetBattlePropertyType.create(1213,"速度装备率");
      
      public static const EQUIPMENTS_STRENGTHEN_POWER:PetBattlePropertyType = PetBattlePropertyType.create(1214,"强化之力装备");
      
      public static const EQUIPMENTS_RESIST_POWER:PetBattlePropertyType = PetBattlePropertyType.create(1215,"抵抗之力装备");
      
      public static const EXT_MAX_HP:PetBattlePropertyType = PetBattlePropertyType.create(30,"生命",true);
      
      public static const EXT_PHYSICAL_ATTACK:PetBattlePropertyType = PetBattlePropertyType.create(31,"物攻",true,JobAttackType.PHYSICS);
      
      public static const EXT_PHYSICAL_DEFENCE:PetBattlePropertyType = PetBattlePropertyType.create(32,"物防",true);
      
      public static const EXT_MAGIC_ATTACK:PetBattlePropertyType = PetBattlePropertyType.create(33,"魔攻",true,JobAttackType.MAGIC);
      
      public static const EXT_MAGIC_DEFENCE:PetBattlePropertyType = PetBattlePropertyType.create(34,"魔防",true);
      
      public static const EXT_ULTIMATE_ATTACK:PetBattlePropertyType = PetBattlePropertyType.create(35,"超攻",true);
      
      public static const EXT_ULTIMATE_DEFENCE:PetBattlePropertyType = PetBattlePropertyType.create(36,"超防",true);
      
      public static const EXT_HIT_RATE:PetBattlePropertyType = PetBattlePropertyType.create(37,"命中率");
      
      public static const EXT_EVASION_RATE:PetBattlePropertyType = PetBattlePropertyType.create(38,"闪避率");
      
      public static const EXT_STRIKE_RATE:PetBattlePropertyType = PetBattlePropertyType.create(39,"破击率");
      
      public static const EXT_BLOCK_RATE:PetBattlePropertyType = PetBattlePropertyType.create(40,"格挡率");
      
      public static const EXT_CRITICAL_RATE:PetBattlePropertyType = PetBattlePropertyType.create(41,"暴击率");
      
      public static const EXT_ANTI_CRITICAL_RATE:PetBattlePropertyType = PetBattlePropertyType.create(42,"防暴率");
      
      public static const EXT_ORIGINAL_VIGOUR:PetBattlePropertyType = PetBattlePropertyType.create(43,"起始气势");
      
      public static const EXT_MIN_VIGOUR:PetBattlePropertyType = PetBattlePropertyType.create(44,"最小气势");
      
      public static const EXT_CRITICAL_DAMAGE_RATE:PetBattlePropertyType = PetBattlePropertyType.create(45,"暴击伤害");
      
      public static const EXT_SPEED:PetBattlePropertyType = PetBattlePropertyType.create(46,"速度",true);
      
      public static const EXT_STRENGTHEN_POWER:PetBattlePropertyType = PetBattlePropertyType.create(47,"强化之力",true);
      
      public static const EXT_RESIST_POWER:PetBattlePropertyType = PetBattlePropertyType.create(48,"抵抗之力",true);
      
      public static const EXT_SUPER_PHYSICAL_ATTACK:PetBattlePropertyType = PetBattlePropertyType.create(1347,"超物攻",true,JobAttackType.SUPER_PHYSICS);
      
      public static const EXT_SUPER_PHYSICAL_DEFENCE:PetBattlePropertyType = PetBattlePropertyType.create(1348,"超物防",true);
      
      public static const EXT_SUPER_MAGIC_ATTACK:PetBattlePropertyType = PetBattlePropertyType.create(1349,"超魔攻",true,JobAttackType.SUPER_MAGIC);
      
      public static const EXT_SUPER_MAGIC_DEFENCE:PetBattlePropertyType = PetBattlePropertyType.create(1350,"超魔防",true);
      
      public static const PERCENT_MAX_HP:PetBattlePropertyType = PetBattlePropertyType.create(110,"生命率");
      
      public static const PERCENT_PHYSICAL_ATTACK:PetBattlePropertyType = PetBattlePropertyType.create(111,"物攻率",false,JobAttackType.PHYSICS);
      
      public static const PERCENT_PHYSICAL_DEFENCE:PetBattlePropertyType = PetBattlePropertyType.create(112,"物防率");
      
      public static const PERCENT_MAGIC_ATTACK:PetBattlePropertyType = PetBattlePropertyType.create(113,"魔攻率",false,JobAttackType.MAGIC);
      
      public static const PERCENT_MAGIC_DEFENCE:PetBattlePropertyType = PetBattlePropertyType.create(114,"魔防率");
      
      public static const PERCENT_ULTIMATE_ATTACK:PetBattlePropertyType = PetBattlePropertyType.create(115,"超攻率");
      
      public static const PERCENT_ULTIMATE_DEFENCE:PetBattlePropertyType = PetBattlePropertyType.create(116,"超防率");
      
      public static const PERCENT_SPEED:PetBattlePropertyType = PetBattlePropertyType.create(117,"速度率");
      
      public static const PERCENT_SUPER_PHYSICAL_ATTACK:PetBattlePropertyType = PetBattlePropertyType.create(1418,"超物攻率",false,JobAttackType.SUPER_PHYSICS);
      
      public static const PERCENT_SUPER_PHYSICAL_DEFENCE:PetBattlePropertyType = PetBattlePropertyType.create(1419,"超物防率");
      
      public static const PERCENT_SUPER_MAGIC_ATTACK:PetBattlePropertyType = PetBattlePropertyType.create(1420,"超魔攻率",false,JobAttackType.SUPER_MAGIC);
      
      public static const PERCENT_SUPER_MAGIC_DEFENCE:PetBattlePropertyType = PetBattlePropertyType.create(1421,"超魔防率");
      
      public static const ALL_BASE_EXT:PetBattlePropertyType = PetBattlePropertyType.createContainer(203,"全属性",[EXT_PHYSICAL_ATTACK,EXT_PHYSICAL_DEFENCE,EXT_MAGIC_ATTACK,EXT_MAGIC_DEFENCE,EXT_ULTIMATE_ATTACK,EXT_ULTIMATE_DEFENCE,EXT_SUPER_PHYSICAL_ATTACK,EXT_SUPER_PHYSICAL_DEFENCE,EXT_SUPER_MAGIC_ATTACK,EXT_SUPER_MAGIC_DEFENCE]);
      
      public static const ALL_BASE_PERCENT:PetBattlePropertyType = PetBattlePropertyType.createContainer(204,"全属性率",[PERCENT_MAX_HP,PERCENT_PHYSICAL_ATTACK,PERCENT_PHYSICAL_DEFENCE,PERCENT_MAGIC_ATTACK,PERCENT_MAGIC_DEFENCE,PERCENT_ULTIMATE_ATTACK,PERCENT_ULTIMATE_DEFENCE,PERCENT_SUPER_PHYSICAL_ATTACK,PERCENT_SUPER_PHYSICAL_DEFENCE,PERCENT_SUPER_MAGIC_ATTACK,PERCENT_SUPER_MAGIC_DEFENCE]);
      
      private var _id:int;
      
      private var _name:String;
      
      private var _needCalculate:Boolean = false;
      
      private var _attackType:int = 0;
      
      private var _effecting:Array = [];
      
      public function PetBattlePropertyType()
      {
         super();
      }
      
      public static function getById(param1:int) : PetBattlePropertyType
      {
         return _id2PropertyType[param1.toString()];
      }
      
      public static function getByName(param1:String) : PetBattlePropertyType
      {
         if(!_name2PropertyType.hasOwnProperty(param1))
         {
            return UNKNOWN;
         }
         return _name2PropertyType[param1];
      }
      
      private static function create(param1:int, param2:String, param3:Boolean = false, param4:int = 0, param5:Array = null) : PetBattlePropertyType
      {
         var _loc6_:PetBattlePropertyType = new PetBattlePropertyType();
         _loc6_._id = param1;
         _loc6_._name = param2;
         _loc6_._needCalculate = param3;
         _loc6_._attackType = param4;
         _allValues.push(_loc6_);
         _id2PropertyType[param1.toString()] = _loc6_;
         _name2PropertyType[param2] = _loc6_;
         return _loc6_;
      }
      
      private static function createContainer(param1:int, param2:String, param3:Array) : PetBattlePropertyType
      {
         var v:PetBattlePropertyType = null;
         var id:int = param1;
         var name:String = param2;
         var includes:Array = param3;
         v = new PetBattlePropertyType();
         v._id = id;
         v._name = name;
         _allValues.push(v);
         _id2PropertyType[id.toString()] = v;
         includes.forEach(function(param1:PetBattlePropertyType, ... rest):void
         {
            param1._effecting.push(v);
         });
         _name2PropertyType[name] = v;
         return v;
      }
      
      public function get id() : int
      {
         return this._id;
      }
      
      public function get name() : String
      {
         return this._name;
      }
      
      public function get needCalculate() : Boolean
      {
         return this._needCalculate;
      }
      
      public function get effecting() : Array
      {
         return this._effecting;
      }
   }
}

