package mmo.interfaces.pet.battle
{
   public class BattlePropertySource implements IBattlePropertySource
   {
      
      private var _values:Object;
      
      public function BattlePropertySource()
      {
         super();
         this._values = {};
      }
      
      private static function fixRate(param1:Number) : Number
      {
         return Math.round(param1 * 100) / 100;
      }
      
      public function addByStandardString(param1:String) : void
      {
         var propsStr:String = param1;
         propsStr.split("#").forEach(function(param1:String, ... rest):void
         {
            addSingle(param1);
         });
      }
      
      public function addByEquipmentStyleString(param1:String) : void
      {
         var propsStr:String = param1;
         propsStr.split("#").forEach(function(param1:String, ... rest):void
         {
            var pStr:String = param1;
            var _:Array = rest;
            addSingle(pStr,function(param1:String):String
            {
               return param1.indexOf("率") != -1 ? param1 : param1 + "装备";
            });
         });
      }
      
      protected function addSingle(param1:String, param2:Function = null) : void
      {
         var _loc3_:Array = null;
         var _loc4_:String = null;
         var _loc5_:Number = NaN;
         if(param1.indexOf("-") != -1)
         {
            _loc3_ = param1.split("-");
            _loc4_ = _loc3_[0].replace("+","");
            _loc5_ = -parseFloat(_loc3_[1]);
         }
         else
         {
            _loc3_ = param1.split("+");
            _loc4_ = _loc3_[0];
            _loc5_ = parseFloat(_loc3_[1]);
         }
         if(Boolean(param2))
         {
            _loc4_ = param2(_loc4_);
         }
         this.addInto(PetBattlePropertyType.getByName(_loc4_),_loc5_);
      }
      
      public function getValue(param1:PetBattlePropertyType, param2:Boolean = false) : Number
      {
         var value:Number = NaN;
         var propType:PetBattlePropertyType = param1;
         var fixRated:Boolean = param2;
         value = 0;
         value += this._getValue(propType);
         propType.effecting.forEach(function(param1:PetBattlePropertyType, ... rest):void
         {
            value += _getValue(param1);
         });
         return fixRated ? fixRate(value) : value;
      }
      
      private function _getValue(param1:PetBattlePropertyType) : Number
      {
         return this._values.hasOwnProperty(param1.id.toString()) ? Number(this._values[param1.id.toString()]) : 0;
      }
      
      public function addInto(param1:PetBattlePropertyType, param2:Number) : void
      {
         this._values[param1.id.toString()] = this._getValue(param1) + param2;
      }
      
      public function doEach(param1:Function) : void
      {
         var _loc2_:String = null;
         for(_loc2_ in this._values)
         {
            param1(PetBattlePropertyType.getById(parseInt(_loc2_)),this._values[_loc2_]);
         }
      }
      
      public function addUp(param1:IBattlePropertySource) : void
      {
         param1.doEach(this.addInto);
      }
   }
}

