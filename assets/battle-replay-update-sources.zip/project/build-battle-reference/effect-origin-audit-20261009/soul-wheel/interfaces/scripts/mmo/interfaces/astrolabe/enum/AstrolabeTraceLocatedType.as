package mmo.interfaces.astrolabe.enum
{
   public class AstrolabeTraceLocatedType
   {
      
      private static const SPECIAL_CONSTRUCTORS:Object = {};
      
      private static var sLock:Boolean = true;
      
      private static var sIndex:int = 0;
      
      private static var sValue:AstrolabeTraceLocatedType = null;
      
      private static var sValues:Vector.<AstrolabeTraceLocatedType> = new Vector.<AstrolabeTraceLocatedType>();
      
      public static const CENTER:AstrolabeTraceLocatedType = enum__(0,"星迹");
      
      public static const JUNIOR:AstrolabeTraceLocatedType = enum__(1,"星迹");
      
      public static const SENIOR:AstrolabeTraceLocatedType = enum__(2,"星迹");
      
      private var _index:int;
      
      private var _id:int;
      
      private var _name:String;
      
      public function AstrolabeTraceLocatedType(param1:Object = null)
      {
         var _loc2_:String = null;
         var _loc3_:Function = null;
         super();
         if(sLock)
         {
            throw new Error("Can\'t not construct outer.");
         }
         if(param1 != null)
         {
            for(_loc2_ in param1)
            {
               _loc3_ = SPECIAL_CONSTRUCTORS[_loc2_];
               if(_loc3_ != null)
               {
                  if(_loc3_.length == 1)
                  {
                     this["_" + _loc2_] = _loc3_(param1[_loc2_]);
                  }
                  else
                  {
                     if(_loc3_.length != 2)
                     {
                        throw new Error("Not support constructor with params length: " + _loc3_.length);
                     }
                     this["_" + _loc2_] = _loc3_(this,param1[_loc2_]);
                  }
               }
               else
               {
                  this["_" + _loc2_] = param1[_loc2_];
               }
            }
         }
      }
      
      public static function values() : Vector.<AstrolabeTraceLocatedType>
      {
         return sValues.concat();
      }
      
      public static function valueOfId(param1:int) : AstrolabeTraceLocatedType
      {
         if(param1 >= 0 && param1 < sValues.length)
         {
            return sValues[param1];
         }
         return null;
      }
      
      private static function enum__(param1:int, param2:String) : AstrolabeTraceLocatedType
      {
         sLock = false;
         sValue = new AstrolabeTraceLocatedType();
         sValue._index = sIndex;
         sValue._id = param1;
         sValue._name = param2;
         sLock = true;
         sValues.push(sValue);
         ++sIndex;
         return sValue;
      }
      
      public function get index() : int
      {
         return this._index;
      }
      
      public function get id() : int
      {
         return this._id;
      }
      
      public function get name() : String
      {
         return this._name;
      }
      
      public function get isCenter() : Boolean
      {
         return this == CENTER;
      }
      
      public function get isJunior() : Boolean
      {
         return this == JUNIOR;
      }
      
      public function get isSenior() : Boolean
      {
         return this == SENIOR;
      }
      
      public function toString() : String
      {
         return "[AstrolabeTraceLocatedType index: " + this._index + ", name: " + this._name + "]";
      }
   }
}

