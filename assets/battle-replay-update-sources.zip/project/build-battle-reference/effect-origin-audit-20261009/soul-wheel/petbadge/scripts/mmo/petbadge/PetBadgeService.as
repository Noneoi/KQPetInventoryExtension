package mmo.petbadge
{
   import flash.display.Sprite;
   import flash.events.EventDispatcher;
   import mmo.interfaces.InitServiceEvent;
   import mmo.interfaces.pet.battle.BattlePropertySource;
   import mmo.interfaces.pet.battle.IBattlePropertySource;
   import mmo.interfaces.pet.data.PetBadge;
   import mmo.interfaces.pet.data.PetBadgeSlot;
   import mmo.interfaces.petbadge.IPetBadgeService;
   import mmo.petbadge.config.PetBadgeConfig;
   import mmo.petbadge.controller.PetBadgeController;
   
   public class PetBadgeService extends EventDispatcher implements IPetBadgeService
   {
      
      public function PetBadgeService()
      {
         super();
      }
      
      public function init() : void
      {
         PetBadgeConfig.initStatic();
         this.dispatchEvent(new InitServiceEvent(InitServiceEvent.onInited,{}));
      }
      
      public function showMainPanel(param1:int, param2:int = 0, param3:int = 0) : void
      {
         PetBadgeController.instance().showMainPanel(param1,param2,param3);
      }
      
      public function showJobLevelEffect(param1:int) : void
      {
         PetBadgeController.instance().showJobLevelEffect(param1);
      }
      
      public function getBadgeIcon(param1:PetBadgeSlot, param2:Boolean) : Sprite
      {
         return PetBadgeController.instance().getIcon(param1,param2);
      }
      
      public function getBadgeJobNameWithLevel(param1:PetBadgeSlot) : String
      {
         return PetBadgeHelper.getBadgeJobNameWithLevel(param1);
      }
      
      public function getBadgeName(param1:int) : String
      {
         return PetBadgeHelper.getBadgeName(param1);
      }
      
      public function getBadgeDescWithColor(param1:PetBadgeSlot) : String
      {
         return PetBadgeHelper.getBadgeDescWithColor(param1);
      }
      
      public function getMaxBattlePower(param1:PetBadge) : int
      {
         return PetBadgeHelper.getMaxBattlePower(param1);
      }
      
      public function getBattlePower(param1:PetBadge) : int
      {
         return PetBadgeHelper.getBattlePower(param1);
      }
      
      public function isPerfect(param1:PetBadge) : Boolean
      {
         return PetBadgeHelper.isPerfect(param1);
      }
      
      public function getMaxLevel(param1:int) : int
      {
         return PetBadgeHelper.getMaxLevel(param1);
      }
      
      public function isAvailableId(param1:int) : Boolean
      {
         return PetBadgeHelper.isAvailableId(param1);
      }
      
      public function getUpgradeMaterial(param1:int) : Array
      {
         return PetBadgeHelper.getUpgradeMaterial(param1);
      }
      
      public function getBattleProperty(param1:PetBadge) : IBattlePropertySource
      {
         var battleProperty:BattlePropertySource = null;
         var petBadge:PetBadge = param1;
         battleProperty = new BattlePropertySource();
         petBadge.slots.forEach(function(param1:PetBadgeSlot, ... rest):void
         {
            battleProperty.addByEquipmentStyleString(PetBadgeConfig.getBadgeJobLevelDefine(param1.jobId,param1.jobLevel).propsStr);
            if(param1.isActivateExclusive)
            {
               battleProperty.addByEquipmentStyleString(PetBadgeConfig.getBadgeExclusiveDefine(param1.exclusiveId).propsStr);
            }
         });
         return battleProperty;
      }
   }
}

