package mmo.astrolabe
{
   import flash.display.Sprite;
   import flash.events.EventDispatcher;
   import flash.events.IEventDispatcher;
   import mmo.astrolabe.config.AstrolabeConfig;
   import mmo.astrolabe.controller.AstrolabeController;
   import mmo.astrolabe.helper.AstrolabeLightHelper;
   import mmo.interfaces.InitServiceEvent;
   import mmo.interfaces.astrolabe.IAstrolabeService;
   import mmo.interfaces.astrolabe.IAstrolabeTraceDefine;
   import mmo.interfaces.pet.battle.BattlePropertySource;
   import mmo.interfaces.pet.battle.IBattlePropertySource;
   import mmo.interfaces.pet.data.PetAstrolabe;
   import mmo.interfaces.pet.data.PetAstrolabeTraceSlot;
   import mmo.interfaces.pet.data.PetBriefInfo;
   
   public class AstrolabeService extends EventDispatcher implements IAstrolabeService
   {
      
      public function AstrolabeService(param1:IEventDispatcher = null)
      {
         super(param1);
      }
      
      public function init() : void
      {
         AstrolabeConfig.initStatic();
         AstrolabeController.instance.init();
         this.dispatchEvent(new InitServiceEvent(InitServiceEvent.onInited,{}));
      }
      
      public function showGuidePanel() : void
      {
         AstrolabeController.instance.showBookGuidePanel();
      }
      
      public function showOperationPanel(param1:int) : void
      {
         AstrolabeController.instance.showOperationPanel(param1);
      }
      
      public function getTraceDefine(param1:int) : IAstrolabeTraceDefine
      {
         return AstrolabeConfig.getTraceDefine(param1);
      }
      
      public function getTraceSlotIcon(param1:PetAstrolabeTraceSlot, param2:Boolean = true) : Sprite
      {
         return AstrolabeController.instance.getTraceIcon(param1,param2);
      }
      
      public function getAstrolabeView(param1:PetAstrolabe, param2:PetBriefInfo = null, param3:Boolean = false) : Sprite
      {
         return AstrolabeController.instance.getAstrolabeView(param1,param2,param3);
      }
      
      public function showLightAllPanel(param1:PetBriefInfo) : void
      {
         AstrolabeController.instance.tryTraceLightAll(param1);
      }
      
      public function showBreakthroughPanel(param1:PetBriefInfo) : void
      {
         AstrolabeController.instance.tryTraceBreakthrough(param1);
      }
      
      public function isPetNeedLightAll(param1:PetBriefInfo) : Boolean
      {
         return AstrolabeLightHelper.getUnlightedTraces(param1.petAstrolabe).length > 0;
      }
      
      public function isPetAlreadyLightAll(param1:PetBriefInfo, param2:Boolean = false) : Boolean
      {
         return AstrolabeLightHelper.getUnlightedTraces(param1.petAstrolabe,param2).length > 0;
      }
      
      public function getBattleProperty(param1:PetAstrolabe) : IBattlePropertySource
      {
         var battleProperty:BattlePropertySource = null;
         var astrolabe:PetAstrolabe = param1;
         battleProperty = new BattlePropertySource();
         astrolabe.filter(PetAstrolabe.FT_TRACE_LIGHT).findTraces().forEach(function(param1:PetAstrolabeTraceSlot, ... rest):void
         {
            battleProperty.addByEquipmentStyleString(param1.getTraceDefine().basicProps);
            if(param1.isTwinkled)
            {
               battleProperty.addByEquipmentStyleString(param1.getTraceDefine().twinkleProps);
            }
         });
         return battleProperty;
      }
   }
}

