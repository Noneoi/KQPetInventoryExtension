package mmo.astrolabe.config
{
   import mmo.astrolabe.helper.AstrolabeTipsHelper;
   import mmo.interfaces.astrolabe.IAstrolabeTraceDefine;
   import mmo.interfaces.astrolabe.enum.AstrolabeTraceLocatedType;
   
   public class AstrolabeTraceDefine implements IAstrolabeTraceDefine
   {
      
      private var _defineId:int;
      
      private var _iconId:int;
      
      private var _name:String;
      
      private var _isTBD:Boolean;
      
      private var _allSigns:String;
      
      private var _locatedTypeId:int;
      
      private var _isExclusive:Boolean;
      
      private var _lightUpCost:String;
      
      private var _basicBuff:String;
      
      private var _twinkleBuff:String;
      
      private var _battlePower:int;
      
      private var _twinkleProps:String;
      
      public function AstrolabeTraceDefine()
      {
         super();
      }
      
      public static function valueFrom(param1:XML) : AstrolabeTraceDefine
      {
         var _loc2_:AstrolabeTraceDefine = new AstrolabeTraceDefine();
         _loc2_._defineId = parseInt(param1["defineId"]);
         _loc2_._iconId = param1["iconId"] == "" ? -1 : int(parseInt(param1["iconId"]));
         _loc2_._name = param1["name"];
         _loc2_._isTBD = param1["isTBD"] == "1";
         _loc2_._allSigns = param1["allSigns"];
         _loc2_._locatedTypeId = parseInt(param1["locatedTypeId"]);
         _loc2_._isExclusive = param1["exclusive"] == "1";
         _loc2_._lightUpCost = param1["lightUpCost"];
         _loc2_._basicBuff = param1["basicBuff"];
         _loc2_._twinkleBuff = param1["twinkleBuff"];
         _loc2_._battlePower = parseInt(param1["battlePower"]);
         _loc2_._twinkleProps = param1["twinkleProps"];
         return _loc2_;
      }
      
      public function get defineId() : int
      {
         return this._defineId;
      }
      
      public function get iconId() : int
      {
         return this._iconId == -1 ? this.defineId : this._iconId;
      }
      
      public function get name() : String
      {
         return this._name;
      }
      
      public function get isTBD() : Boolean
      {
         return this._isTBD;
      }
      
      public function findSign(param1:String) : Boolean
      {
         return this._allSigns.split(",").indexOf(param1) != -1;
      }
      
      public function get locatedType() : AstrolabeTraceLocatedType
      {
         return AstrolabeTraceLocatedType.valueOfId(this._locatedTypeId);
      }
      
      public function get isExclusive() : Boolean
      {
         return this._isExclusive;
      }
      
      public function get basicBuff() : String
      {
         return this._basicBuff;
      }
      
      public function get lightUpCost() : String
      {
         return this._lightUpCost;
      }
      
      public function get lightUpCostMaterials() : Array
      {
         return this._lightUpCost == "" ? [] : this._lightUpCost.split("#");
      }
      
      public function get twinkleBuff() : String
      {
         return this._twinkleBuff;
      }
      
      public function get battlePower() : int
      {
         return this._battlePower;
      }
      
      public function get basicProps() : String
      {
         return this.basicBuff;
      }
      
      public function get twinkleProps() : String
      {
         return this._twinkleProps;
      }
      
      public function decorateWithColor(param1:String) : String
      {
         var str:String = param1;
         var decorated:String = str;
         AstrolabeConfig.SPECIALITY_TYPE.forEach(function(param1:String, param2:int, ... rest):void
         {
            if(findSign(param1))
            {
               decorated = AstrolabeTipsHelper.textColor(str,AstrolabeConfig.SPECIALITY_COLOR[param2]);
            }
         });
         return decorated;
      }
   }
}

