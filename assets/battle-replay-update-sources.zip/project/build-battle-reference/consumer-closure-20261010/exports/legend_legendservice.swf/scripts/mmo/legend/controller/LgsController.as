package mmo.legend.controller
{
   import flash.display.MovieClip;
   import flash.display.Sprite;
   import flash.system.ApplicationDomain;
   import flash.utils.getQualifiedClassName;
   import mmo.common.InstanceUtil;
   import mmo.common.ProgressFullSprite;
   import mmo.common.shareobject.OnceKeyUtil;
   import mmo.common.utils.dt.mvc.Controller;
   import mmo.interfaces.ServiceContainer;
   import mmo.interfaces.battleconfig.IBattleConfig;
   import mmo.interfaces.dianfengperfect.IDianFengPerfectPetService;
   import mmo.interfaces.legend.ILegendItem;
   import mmo.interfaces.legend.ILegendItemDefine;
   import mmo.interfaces.legend.ILegendItemLevelDefine;
   import mmo.interfaces.legend.ILegendStone;
   import mmo.interfaces.newactivity.INewActivityService;
   import mmo.interfaces.pet.data.IPetDataService;
   import mmo.interfaces.pet.data.PetBriefInfo;
   import mmo.interfaces.pet.data.PetDataType;
   import mmo.interfaces.pet.data.PetLegendStoneSlot;
   import mmo.interfaces.petwarehouse.IPetWarehouseService;
   import mmo.interfaces.petwarehouse.PetWarehouseInfo;
   import mmo.interfaces.secondpassword.ISecondPasswordService;
   import mmo.interfaces.secondpassword.SecondPasswordParams;
   import mmo.legend.model.LgsIModel;
   import mmo.legend.model.LgsModel;
   import mmo.legend.other.LgsConfig;
   import mmo.legend.other.LgsUtil;
   import mmo.legend.other.enumerations.LgsMode;
   import mmo.legend.other.enumerations.LgsPerfect;
   import mmo.legend.other.enumerations.LgsPetLoc;
   import mmo.legend.other.structures.LgsItemDefine;
   import mmo.legend.other.structures.LgsItemLevelDefine;
   import mmo.legend.other.structures.LgsItemTipsInfo;
   import mmo.legend.other.structures.LgsPet;
   import mmo.legend.other.structures.LgsStone;
   import mmo.legend.other.structures.LgsUpgradeResultWrapper;
   import mmo.legend.view.LgsCheerBonusPanel;
   import mmo.legend.view.LgsDialog;
   import mmo.legend.view.LgsMainPanel;
   import mmo.legend.view.LgsMainPanelPre;
   import mmo.legend.view.LgsOneKeyInstallPanel;
   import mmo.legend.view.LgsPerfectPanel;
   import mmo.legend.view.LgsSelectLegendStonesForUpgradePanel;
   import mmo.legend.view.LgsSelectPetPanel;
   import mmo.legend.view.LgsUpgradeBonusPanel;
   import mmo.legend.view.components.LgsNoWorldWrapTips;
   import mmo.legend.view.components.LgsRecommendStone;
   import mmo.legend.view.components.LgsSkillTips;
   import mmo.play.dialog.InteractUtil;
   import mmo.play.scene.SceneManager;
   import mmo.play.scene.SceneManagerEvent;
   
   public class LgsController extends Controller
   {
      
      private static var sInstance:LgsController = null;
      
      private var _sceneMgr:SceneManager;
      
      private var _model:LgsModel;
      
      private var _client:LgsClient;
      
      public function LgsController()
      {
         var disposedSceneT:Function = null;
         this._sceneMgr = SceneManager.getInstance();
         disposedSceneT = function(param1:SceneManagerEvent):void
         {
            releaseResources();
         };
         super(LgsConfig.url,LgsConfig.cls,LgsDialog);
         this._model = new LgsModel();
         this._client = new LgsClient();
         this._sceneMgr.addEventListener(SceneManagerEvent.DISPOSED_SCENE,disposedSceneT);
      }
      
      public static function instance() : LgsController
      {
         if(sInstance == null)
         {
            sInstance = new LgsController();
         }
         return sInstance;
      }
      
      public function init(param1:Function) : void
      {
         var bindNotificationT:Function = null;
         var callback:Function = param1;
         bindNotificationT = function():void
         {
            _client.onItemsChanged = _model.invalidateItems;
            _client.onStonesChanged = _model.invalidateStones;
         };
         this._client.getInfo(false,this._model.init,bindNotificationT,callback);
      }
      
      private function prepare(param1:Function) : void
      {
         var andThen:Function = param1;
         LgsUtil.loadSvc(IBattleConfig,function(... rest):*
         {
            var params0:Array = rest;
            LgsUtil.loadSvc(IDianFengPerfectPetService,function(... rest):*
            {
               andThen();
            });
         });
      }
      
      public function showMainPanelWithChecking(param1:int = -1, param2:LgsMode = null, param3:int = -1, param4:Function = null) : void
      {
         var doShowMainPanelWithChecking:Function = null;
         var petDataSvc:IPetDataService = null;
         var petInfo:PetBriefInfo = null;
         var petId:int = param1;
         var mode:LgsMode = param2;
         var slotIndex:int = param3;
         var closeCallback:Function = param4;
         doShowMainPanelWithChecking = function():void
         {
            _model.invalidatePets();
            if(petId == -1)
            {
               showMainPanelPre();
            }
            else
            {
               syncPets(LgsPetLoc.PACKAGE);
               showMainPanel(_model.getPets(LgsPetLoc.PACKAGE,function(... rest):Boolean
               {
                  return LgsPet(rest[0]).id == petId;
               })[0],mode,slotIndex,closeCallback);
            }
         };
         if(_iHelper.isVeryTiredWithTips())
         {
            return;
         }
         if(petId == int.MIN_VALUE)
         {
            petDataSvc = LgsUtil.getSvc(IPetDataService);
            for each(petInfo in petDataSvc.getMyPets(PetDataType.TOTAL,false))
            {
               if(!petInfo.dictData.isShenYun() && Boolean(petInfo.dictData.isLegend()))
               {
                  petId = int(petInfo.id);
                  break;
               }
            }
         }
         if(this._model.hasInited())
         {
            doShowMainPanelWithChecking();
            return;
         }
         this._client.getInfo(true,this._model.init,doShowMainPanelWithChecking);
      }
      
      public function showLegendStonePreviewPanel() : void
      {
         if(!OnceKeyUtil.getKey("legendstone_announcement_20190315"))
         {
            this.showAnnouncementPanel(function():void
            {
               showDialog(LgsDialog.DT_LEGEND_STONE_PREVIEW);
            });
         }
         else
         {
            showDialog(LgsDialog.DT_LEGEND_STONE_PREVIEW,null,function():void
            {
               showAnnouncementPanel();
            });
         }
      }
      
      public function showAnnouncementPanel(param1:Function = null) : void
      {
         var callback:Function = param1;
         showDialog(LgsDialog.DT_LEGEND_ANNOUNCEMENT,null,null,function(param1:LgsDialog):void
         {
            if(param1 != null)
            {
               param1.closeCallback = null;
               param1.close();
            }
            InteractUtil.applyCallback(callback);
         });
      }
      
      public function showMainPanelPre() : void
      {
         showPanel(LgsMainPanelPre);
      }
      
      public function showMainPanel(param1:LgsPet, param2:LgsMode = null, param3:int = -1, param4:Function = null) : void
      {
         var selectedPet:LgsPet = param1;
         var mode:LgsMode = param2;
         var slotIndex:int = param3;
         var closeCallback:Function = param4;
         this.prepare(function():*
         {
            showPanel(function():LgsMainPanel
            {
               return new LgsMainPanel(selectedPet,mode,slotIndex,closeCallback);
            });
         });
      }
      
      public function showPerfectPanelWithChecking() : void
      {
         if(_iHelper.isVeryTiredWithTips())
         {
            return;
         }
         this._model.invalidatePets();
         this.showPerfectPanel();
      }
      
      public function showPerfectPanel() : void
      {
         this.prepare(function():*
         {
            showPanel(function():LgsPerfectPanel
            {
               return new LgsPerfectPanel();
            });
         });
      }
      
      public function showSelectPetPanel(param1:Function) : void
      {
         var confirmSelection:Function = param1;
         showPanel(function():LgsSelectPetPanel
         {
            return new LgsSelectPetPanel(confirmSelection);
         });
      }
      
      public function showRuleOfUpgradePanel() : void
      {
         showDialog(LgsDialog.DT_RULE_OF_UPGRADE_OR_INSTALLATION_ONCE,{"mode":LgsMode.UPGRADE});
      }
      
      public function showRuleOfInstallationPanel() : void
      {
         showDialog(LgsDialog.DT_RULE_OF_UPGRADE_OR_INSTALLATION_ONCE,{"mode":LgsMode.INSTALLATION});
      }
      
      public function showLegendSkillIntroPanel() : void
      {
         showDialog(LgsDialog.DT_LEGEND_SKILL_INTRO);
      }
      
      public function showOneKeyInstallPanel(param1:LgsPet, param2:LgsPerfect) : void
      {
         var selectedPet:LgsPet = param1;
         var perfect:LgsPerfect = param2;
         showPanel(function():LgsOneKeyInstallPanel
         {
            return new LgsOneKeyInstallPanel(selectedPet,perfect);
         });
      }
      
      public function showSelectLegendStonesForUpgradePanel(param1:PetLegendStoneSlot, param2:Function) : void
      {
         var slot:PetLegendStoneSlot = param1;
         var callback:Function = param2;
         showPanel(function():LgsSelectLegendStonesForUpgradePanel
         {
            return new LgsSelectLegendStonesForUpgradePanel(slot,callback);
         });
      }
      
      public function syncPets(param1:LgsPetLoc) : void
      {
         var petLoc:LgsPetLoc = param1;
         var syncPetsOfPackageT:Function = function():void
         {
            var _loc1_:IPetDataService = LgsUtil.getSvc(IPetDataService);
            var _loc2_:Array = _loc1_.getMyPets(PetDataType.TOTAL,false);
            _model.setPets(petLoc,LgsPet.valuesFrom(_loc2_));
         };
         var syncPetsOfWarehouseT:Function = function():void
         {
            LgsUtil.loadSvc(IPetWarehouseService,function(param1:IPetWarehouseService):*
            {
               var petWareSvc:IPetWarehouseService = param1;
               ProgressFullSprite.show();
               petWareSvc.viewAllPetInWarehouse(function(param1:Array):*
               {
                  ProgressFullSprite.close();
                  _model.setPets(petLoc,LgsPet.valuesFrom(param1));
               });
            });
         };
         switch(petLoc)
         {
            case LgsPetLoc.PACKAGE:
               syncPetsOfPackageT();
               break;
            case LgsPetLoc.WAREHOUSE:
               syncPetsOfWarehouseT();
               break;
            default:
               throw new Error("Invalid petLoc: " + petLoc);
         }
      }
      
      private function handleInstallationDone(param1:LgsPet, param2:int, param3:Object, param4:Function) : void
      {
         if(param1.loc == LgsPetLoc.WAREHOUSE)
         {
            if(param3["pao"]["ri"] == null)
            {
               param3["pao"]["ri"] = param3["pao"]["r"];
            }
            this._model.setPet(param1.loc,LgsPet.valueFrom(PetWarehouseInfo.parseInfo(param3["pao"])));
         }
         this._model.notifyStoneInstalled(param2,param4);
      }
      
      private function checkCanBeInstalled(param1:LgsPet, param2:LgsItemDefine) : Boolean
      {
         if(!param2.canBeInstalled(param1))
         {
            LgsUtil.msgFail("该精灵装备“" + param2.name + "”提升不了战斗力哦");
            return false;
         }
         return true;
      }
      
      public function tryPlayTutorial() : void
      {
         if(this._model.hasGotTutorialBonus())
         {
            return;
         }
         this.showUpgradeBonusPanel();
      }
      
      public function gainTutorialBonus() : void
      {
         this._client.gainTutorialBonus(function(param1:Object, param2:int):*
         {
            _model.markGotTutorialBonus();
            _iHelper.showBonus(param2);
         });
      }
      
      public function gainCheerBonus() : void
      {
         this._client.gainCheerBonus(function(param1:Object, param2:int):*
         {
            _model.markGotCheerBonus();
            _iHelper.showBonus(param2);
         });
      }
      
      public function showUpgradeBonusPanel() : void
      {
         showPanel(function():LgsUpgradeBonusPanel
         {
            return new LgsUpgradeBonusPanel();
         });
      }
      
      public function showCheerBonusPanel() : void
      {
         showPanel(function():LgsCheerBonusPanel
         {
            return new LgsCheerBonusPanel();
         });
      }
      
      public function tryShowOnceRule(param1:LgsMode) : void
      {
         if(param1 == null)
         {
            throw new Error("mode is null");
         }
         if(OnceKeyUtil.getKey("once_rule_20181102_" + param1))
         {
            return;
         }
         showDialog(LgsDialog.DT_RULE_OF_UPGRADE_OR_INSTALLATION_ONCE,{"mode":param1});
      }
      
      public function installStone(param1:LgsPet, param2:LgsStone, param3:int) : void
      {
         var secondPasswordService:ISecondPasswordService;
         var slot:PetLegendStoneSlot;
         var doIt:Function = null;
         var selectedPet:LgsPet = param1;
         var stone:LgsStone = param2;
         var slotIndex:int = param3;
         doIt = function(param1:LgsDialog = null):void
         {
            var dialog:LgsDialog = param1;
            _client.installStone(selectedPet.id,stone,slotIndex,function(param1:Object, param2:int):*
            {
               var respData:Object = param1;
               var changeSetId:int = param2;
               if(dialog != null)
               {
                  dialog.closeCallback = null;
                  dialog.close();
               }
               handleInstallationDone(selectedPet,slotIndex,respData,function():*
               {
                  _iHelper.showBonus(changeSetId);
               });
            },function(param1:Object):Boolean
            {
               _model.notifyStoneInstallationFailed();
               return false;
            });
         };
         if(_iHelper.isVeryTiredWithTips())
         {
            this._model.notifyStoneInstallationFailed();
            return;
         }
         if(!this.checkCanBeInstalled(selectedPet,stone.defineX))
         {
            this._model.notifyStoneInstallationFailed();
            return;
         }
         secondPasswordService = ServiceContainer.getService(ISecondPasswordService);
         if(secondPasswordService.isNeedValidate(SecondPasswordParams.LEGEND_STONE))
         {
            secondPasswordService.showMainPanel();
            return;
         }
         slot = selectedPet.legendStone.slots[slotIndex];
         if(slot.isEmpty())
         {
            doIt();
         }
         else
         {
            showDialog(LgsDialog.DT_SURE_INSTALLATION_WITH_REPLACEMENT,{
               "slot":slot,
               "stone":stone
            },doIt,this._model.notifyStoneInstallationFailed);
         }
      }
      
      public function installStonesOneKey(param1:LgsPerfect, param2:LgsPet, param3:Vector.<LgsItemLevelDefine>) : void
      {
         var foundLowLevel:Boolean;
         var slots:Vector.<PetLegendStoneSlot>;
         var i:int;
         var stoneDefineIds:Array = null;
         var doIt:Function = null;
         var perfect:LgsPerfect = param1;
         var selectedPet:LgsPet = param2;
         var levelDefines:Vector.<LgsItemLevelDefine> = param3;
         doIt = function(param1:LgsDialog = null):void
         {
            var dialog:LgsDialog = param1;
            _client.installStonesOneKey(perfect,selectedPet.id,stoneDefineIds,function(param1:Object):*
            {
               var _loc2_:INewActivityService = ServiceContainer.getService(INewActivityService);
               if(_loc2_.hasActivityConfig("anniversarydiscount"))
               {
                  _loc2_.loadAndInitNormalActivity("anniversarydiscount",{
                     "action":"addCnt",
                     "key":"legendperfect" + perfect.installLevel
                  });
               }
               _model.setInstalledStonesOneKeyTimes(_model.getInstalledStonesOneKeyTimes() + 1);
               _model.setInstalledStonesOneKeyArrayTimes(perfect.index,_model.getInstalledStonesOneKeyTimes());
               if(dialog != null)
               {
                  dialog.close();
               }
               handleInstallationDone(selectedPet,-1,param1,null);
               showDialog(LgsDialog.DT_INSTALLED_STONES_ONE_KEY);
            });
         };
         if(_iHelper.isVeryTiredWithTips())
         {
            return;
         }
         foundLowLevel = false;
         slots = selectedPet.legendStone.slots;
         stoneDefineIds = new Array();
         i = 0;
         while(i < levelDefines.length)
         {
            if(levelDefines[i] != null)
            {
               if(!slots[i].isEmpty() && slots[i].level > levelDefines[i].level)
               {
                  foundLowLevel = true;
               }
               stoneDefineIds.push(levelDefines[i].defineX.id);
            }
            i++;
         }
         if(foundLowLevel)
         {
            showDialog(LgsDialog.DT_INSTALLED_STONES_ONE_KEY_WITH_LOW_LEVEL,null,doIt);
         }
         else
         {
            doIt();
         }
      }
      
      private function checkUpgradeStoneNotCritical(param1:PetLegendStoneSlot, param2:LgsItemLevelDefine, param3:Function) : void
      {
         var doIt:Function = null;
         var slot:PetLegendStoneSlot = param1;
         var levelDefine:LgsItemLevelDefine = param2;
         var callback:Function = param3;
         doIt = function(param1:LgsDialog = null, param2:Object = null):void
         {
            if(param1 != null)
            {
               if(param2 != null && Boolean(param2["checked"]))
               {
                  _model.markDownConfirmUpgradeComboNotCritical();
               }
               param1.closeCallback = null;
               param1.close();
            }
            callback();
         };
         if(slot.getLegendItemLevelDefine().define == levelDefine.define)
         {
            doIt();
            return;
         }
         if(!this._model.shouldConfirmUpgradeNotCritical())
         {
            doIt();
            return;
         }
         showDialog(LgsDialog.DT_SURE_UPGRADE_STONE_NOT_CRITICAL,null,doIt,this._model.notifyStoneUpgradeFailed);
      }
      
      public function upgradeStoneCombo(param1:LgsPet, param2:LgsItemLevelDefine, param3:int) : void
      {
         var secondPasswordService:ISecondPasswordService;
         var dialogType:int;
         var pNum:int;
         var selectedPet:LgsPet = param1;
         var levelDefine:LgsItemLevelDefine = param2;
         var slotIndex:int = param3;
         if(_iHelper.isVeryTiredWithTips())
         {
            this._model.notifyStoneUpgradeFailed();
            return;
         }
         secondPasswordService = ServiceContainer.getService(ISecondPasswordService);
         if(secondPasswordService.isNeedValidate(SecondPasswordParams.LEGEND_STONE))
         {
            secondPasswordService.showMainPanel();
            return;
         }
         dialogType = -1;
         pNum = LgsUtil.getItemNum(LgsConfig.PROFICIENT_FRUIT_ID);
         if(pNum < levelDefine.proficientFruitOfUpgrade)
         {
            dialogType = LgsDialog.DT_NOT_ENOUGH_PROFICIENT_FRUITS_FOR_UPGRADE;
         }
         if(dialogType != -1)
         {
            showDialog(dialogType,null,null,this._model.notifyStoneUpgradeFailed);
            return;
         }
         this.checkUpgradeStoneNotCritical(selectedPet.legendStone.slots[slotIndex],levelDefine,function():*
         {
            var doIt:Function = null;
            doIt = function(param1:LgsDialog = null, param2:Object = null):void
            {
               var dialog:LgsDialog = param1;
               var paramsOut:Object = param2;
               _client.upgradeStoneCombo(selectedPet.id,levelDefine,slotIndex,function(param1:Object):*
               {
                  if(dialog != null)
                  {
                     if(paramsOut != null && Boolean(paramsOut["checked"]))
                     {
                        _model.markDownConfirmUpgradeCombo();
                     }
                     dialog.closeCallback = null;
                     dialog.close();
                  }
                  handleUpgradeDone(selectedPet,slotIndex,param1,null);
               },function(param1:Object):Boolean
               {
                  if(param1["r"] == -11)
                  {
                     if(dialog != null)
                     {
                        dialog.closeCallback = null;
                        dialog.close();
                     }
                     handleUpgradeDone(selectedPet,slotIndex,param1,null);
                     return true;
                  }
                  _model.notifyStoneUpgradeFailed();
                  return false;
               });
            };
            if(!_model.shouldConfirmUpgradeCombo())
            {
               doIt();
               return;
            }
            showDialog(LgsDialog.DT_UPGRADE_STONE_COMBO,null,doIt,_model.notifyStoneUpgradeFailed);
         });
      }
      
      public function upgradeStoneFull(param1:LgsPet, param2:LgsItemLevelDefine, param3:int) : void
      {
         var secondPasswordService:ISecondPasswordService;
         var dialogType:int;
         var pNum:int;
         var selectedPet:LgsPet = param1;
         var levelDefine:LgsItemLevelDefine = param2;
         var slotIndex:int = param3;
         if(_iHelper.isVeryTiredWithTips())
         {
            this._model.notifyStoneUpgradeFailed();
            return;
         }
         secondPasswordService = ServiceContainer.getService(ISecondPasswordService);
         if(secondPasswordService.isNeedValidate(SecondPasswordParams.LEGEND_STONE))
         {
            secondPasswordService.showMainPanel();
            return;
         }
         dialogType = -1;
         pNum = LgsUtil.getItemNum(LgsConfig.PROFICIENT_FRUIT_ID);
         if(pNum < levelDefine.proficientFruitOfUpgrade)
         {
            dialogType = LgsDialog.DT_NOT_ENOUGH_PROFICIENT_FRUITS_FOR_UPGRADE;
         }
         if(dialogType != -1)
         {
            showDialog(dialogType,null,null,this._model.notifyStoneUpgradeFailed);
            return;
         }
         this.checkUpgradeStoneNotCritical(selectedPet.legendStone.slots[slotIndex],levelDefine,function():*
         {
            var doIt:Function = null;
            doIt = function(param1:LgsDialog = null, param2:Object = null):void
            {
               var dialog:LgsDialog = param1;
               var paramsOut:Object = param2;
               _client.upgradeStoneFull(selectedPet.id,levelDefine,slotIndex,function(param1:Object):*
               {
                  if(dialog != null)
                  {
                     if(paramsOut != null && Boolean(paramsOut["checked"]))
                     {
                        _model.markDownConfirmUpgradeCombo();
                     }
                     dialog.closeCallback = null;
                     dialog.close();
                  }
                  handleUpgradeDone(selectedPet,slotIndex,param1,null);
               },function(param1:Object):Boolean
               {
                  if(param1["r"] == -11)
                  {
                     if(dialog != null)
                     {
                        dialog.closeCallback = null;
                        dialog.close();
                     }
                     handleUpgradeDone(selectedPet,slotIndex,param1,null);
                     return true;
                  }
                  _model.notifyStoneUpgradeFailed();
                  return false;
               });
            };
            if(!_model.shouldConfirmUpgradeCombo())
            {
               doIt();
               return;
            }
            showDialog(LgsDialog.DT_UPGRADE_STONE_COMBO,null,doIt,_model.notifyStoneUpgradeFailed);
         });
      }
      
      private function handleUpgradeDone(param1:LgsPet, param2:int, param3:Object, param4:Function) : void
      {
         var _loc5_:Vector.<LgsUpgradeResultWrapper> = null;
         if(param3["__STONE_ID__"] != null)
         {
            _loc5_ = LgsUpgradeResultWrapper.valuesFromSpecOne(param3["__STONE_ID__"],param3);
         }
         else
         {
            _loc5_ = LgsUpgradeResultWrapper.valuesFrom(param3);
         }
         if(param1.loc == LgsPetLoc.WAREHOUSE)
         {
            if(param3["pao"]["ri"] == null)
            {
               param3["pao"]["ri"] = param3["pao"]["r"];
            }
            this._model.setPet(param1.loc,LgsPet.valueFrom(PetWarehouseInfo.parseInfo(param3["pao"])));
         }
         this._model.notifyStoneUpgraded(param2,param4,_loc5_);
      }
      
      public function selectOneLegendStone(param1:LgsItemLevelDefine, param2:LgsItemLevelDefine, param3:LgsPerfect, param4:LgsPet, param5:Function) : void
      {
         var doIt:Function = null;
         var current:LgsItemLevelDefine = param1;
         var currentOfPet:LgsItemLevelDefine = param2;
         var perfect:LgsPerfect = param3;
         var selectedPet:LgsPet = param4;
         var confirmSelection:Function = param5;
         doIt = function(param1:LgsDialog, param2:Object):*
         {
            var _loc3_:LgsItemLevelDefine = param2["selection"];
            if(!checkCanBeInstalled(selectedPet,_loc3_.defineX))
            {
               _model.notifyStoneInstallationFailed();
               return;
            }
            param1.close();
            confirmSelection(_loc3_);
         };
         var paramsIn:Object = {
            "perfect":perfect,
            "current":current,
            "currentOfPet":currentOfPet
         };
         showDialog(LgsDialog.DT_SELECT_ONE_LEGEND_STONE,paramsIn,doIt);
      }
      
      public function getStoneIcon(param1:ILegendItemLevelDefine, param2:Object = null) : Sprite
      {
         var id:int;
         var counter:int;
         var checkIt:Function;
         var onResOk_0:Function;
         var onResOk_1:Function;
         var levelsVisible:Boolean = false;
         var usingProgress:Boolean = false;
         var container:Sprite = null;
         var progress:MovieClip = null;
         var resCache:Array = null;
         var levelDefine:ILegendItemLevelDefine = param1;
         var vars:Object = param2;
         levelsVisible = LgsUtil.getValue(vars,"levelsVisible",true);
         usingProgress = LgsUtil.getValue(vars,"usingProgress",false);
         container = new Sprite();
         progress = null;
         if(usingProgress)
         {
            progress = InstanceUtil.getInstance("mmo.common.viewloader.WaitingMovie",ApplicationDomain.currentDomain);
            if(progress != null)
            {
               progress.scaleX = 1.5;
               progress.scaleY = 1.5;
               container.addChild(progress);
            }
            else
            {
               usingProgress = false;
            }
         }
         id = int(levelDefine.define.id);
         resCache = new Array(2);
         counter = 0;
         checkIt = function():*
         {
            var _loc1_:MovieClip = null;
            if(++counter < resCache.length)
            {
               return;
            }
            if(usingProgress)
            {
               container.removeChild(progress);
            }
            _loc1_ = resCache[1];
            _loc1_.gotoAndStop(levelDefine.level);
            _loc1_.x = -54.15;
            _loc1_.y = 13.65;
            _loc1_.visible = levelsVisible;
            container.addChild(resCache[0]);
            container.addChild(resCache[1]);
         };
         onResOk_0 = function(param1:MovieClip):*
         {
            resCache[0] = param1;
            checkIt();
         };
         onResOk_1 = function(param1:MovieClip):*
         {
            resCache[1] = param1;
            checkIt();
         };
         loadRes("items/item" + id,"items.Item" + id,onResOk_0,true,true,false);
         loadRes("legendservice_res_mini","unit.Levels",onResOk_1,true,true,false);
         return container;
      }
      
      public function getRecommendStone(param1:int, param2:Object = null) : Sprite
      {
         return LgsRecommendStone.newInstance(param1,param2);
      }
      
      public function getAssignStone(param1:int, param2:Object = null) : Sprite
      {
         return LgsRecommendStone.newInstance(param1,param2,true);
      }
      
      public function getSkillTips(param1:int, param2:Object, param3:Boolean, param4:Object = null) : Sprite
      {
         return LgsSkillTips.newInstance(param1,param2,param3,param4);
      }
      
      public function getItemTips(param1:Object, param2:Object = null) : Sprite
      {
         var _loc4_:LgsItemTipsInfo = null;
         var _loc3_:Boolean = LgsUtil.getValue(param2,"nameWithColor",true);
         if(param1 is ILegendItemDefine || param1 is ILegendItemLevelDefine)
         {
            _loc4_ = param1 as LgsItemTipsInfo;
         }
         else if(param1 is ILegendItem)
         {
            _loc4_ = (param1 as ILegendItem).define as LgsItemTipsInfo;
         }
         else if(param1 is ILegendStone)
         {
            _loc4_ = (param1 as ILegendStone).levelDefine as LgsItemTipsInfo;
         }
         else
         {
            if(!(param1 is PetLegendStoneSlot))
            {
               throw new Error("Invalid info type: " + getQualifiedClassName(param1));
            }
            _loc4_ = (param1 as PetLegendStoneSlot).getLegendItemLevelDefine() as LgsItemTipsInfo;
         }
         var _loc5_:String = _loc4_.name;
         var _loc6_:String = _loc4_.desc;
         if(_loc3_)
         {
            _loc5_ = _loc4_.nameWithColor;
         }
         return LgsNoWorldWrapTips.newInstance(_loc5_,_loc6_);
      }
      
      public function getModel() : LgsIModel
      {
         return this._model;
      }
   }
}

