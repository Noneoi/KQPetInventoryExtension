package mmo.legend.other.structures
{
   import mmo.interfaces.formation.IFormationService;
   import mmo.interfaces.formation.LegendSkillDefine;
   import mmo.interfaces.pet.data.PetBriefInfo;
   import mmo.interfaces.pet.data.PetDictionaryDataItem;
   import mmo.interfaces.pet.data.PetLegendStone;
   import mmo.interfaces.pet.data.PetLegendStoneSlot;
   import mmo.interfaces.petwarehouse.PetWarehouseInfo;
   import mmo.legend.other.LgsConfig;
   import mmo.legend.other.LgsUtil;
   import mmo.legend.other.enumerations.LgsPetLoc;
   
   public class LgsPet
   {
      
      private static function FIX_MAPPER(... rest):LgsPet
      {
         return valueFrom(rest[0]);
      }
      private static function FIX_FILTER(... rest):Boolean
      {
         return LgsPet(rest[0]).dictData.legendSkillNo != 0 && !LgsPet(rest[0]).dictData.isShenYun();
      }
      public function LgsPet()
      {
         super();
      }
      
      public static function valueFrom(param1:Object) : LgsPet
      {
         if(param1 is PetBriefInfo)
         {
            return new PetOfPackage_LgsPet(param1 as PetBriefInfo);
         }
         if(param1 is PetWarehouseInfo)
         {
            return new PetOfWarehouse_LgsPet(param1 as PetWarehouseInfo);
         }
         throw new Error("Not support type of petInfo: " + typeof param1);
      }
      
      public static function valuesFrom(param1:Array) : Vector.<LgsPet>
      {
         return Vector.<LgsPet>(param1.map(FIX_MAPPER).filter(FIX_FILTER));
      }
      
      public function get id() : int
      {
         throw new Error("Override it.");
      }
      
      public function get loc() : LgsPetLoc
      {
         throw new Error("Override it.");
      }
      
      public function get legendStone() : PetLegendStone
      {
         throw new Error("Override it.");
      }
      
      public function get dictData() : PetDictionaryDataItem
      {
         throw new Error("Override it.");
      }
      
      public function get legendBattlePower() : int
      {
         var _loc5_:PetLegendStoneSlot = null;
         var _loc1_:IFormationService = LgsUtil.getSvc(IFormationService);
         var _loc2_:PetLegendStone = this.legendStone;
         var _loc3_:LegendSkillDefine = _loc1_.getLegendSkillDefineAvailable(this.dictData.legendSkillNo,_loc2_);
         var _loc4_:int = int(_loc3_.battlePower);
         for each(_loc5_ in _loc2_.slots)
         {
            if(!_loc5_.isEmpty())
            {
               _loc4_ += LgsConfig.getItemDefine(_loc5_.defineId).levelDefineX(_loc5_.level).getBattlePower(this);
            }
         }
         return _loc4_;
      }
      
      public function get legendBattlePowerMax() : int
      {
         if(this.dictData.isTianQi())
         {
            return 1850;
         }
         return 1350;
      }
   }
}

import mmo.interfaces.pet.data.IPetDictionaryDataService;
import mmo.interfaces.pet.data.PetBriefInfo;
import mmo.interfaces.pet.data.PetDictionaryDataItem;
import mmo.interfaces.pet.data.PetLegendStone;
import mmo.interfaces.petwarehouse.PetWarehouseInfo;
import mmo.legend.other.LgsUtil;
import mmo.legend.other.enumerations.LgsPetLoc;
import mmo.legend.other.structures.LgsPet;

class PetOfPackage_LgsPet extends LgsPet
{
   
   private var _petInfo:PetBriefInfo;
   
   public function PetOfPackage_LgsPet(param1:PetBriefInfo)
   {
      super();
      this._petInfo = param1;
   }
   
   override public function get id() : int
   {
      return this._petInfo.id;
   }
   
   override public function get loc() : LgsPetLoc
   {
      return LgsPetLoc.PACKAGE;
   }
   
   override public function get legendStone() : PetLegendStone
   {
      return this._petInfo.legendStone;
   }
   
   override public function get dictData() : PetDictionaryDataItem
   {
      return this._petInfo.dictData;
   }
}

class PetOfWarehouse_LgsPet extends LgsPet
{
   
   private var _petInfo:PetWarehouseInfo;
   
   private var _petDicDataCache:PetDictionaryDataItem = null;
   
   public function PetOfWarehouse_LgsPet(param1:PetWarehouseInfo)
   {
      super();
      this._petInfo = param1;
   }
   
   override public function get id() : int
   {
      return this._petInfo.id;
   }
   
   override public function get loc() : LgsPetLoc
   {
      return LgsPetLoc.WAREHOUSE;
   }
   
   override public function get legendStone() : PetLegendStone
   {
      return this._petInfo.legendStone;
   }
   
   override public function get dictData() : PetDictionaryDataItem
   {
      var _loc1_:int = 0;
      var _loc2_:IPetDictionaryDataService = null;
      var _loc3_:PetDictionaryDataItem = null;
      if(this._petDicDataCache == null)
      {
         _loc1_ = int((this._petInfo as PetWarehouseInfo).raceId);
         _loc2_ = LgsUtil.getSvc(IPetDictionaryDataService);
         _loc3_ = _loc2_.getDataItemByRaceId(_loc1_);
         return this._petDicDataCache = _loc3_;
      }
      return this._petDicDataCache;
   }
}
