package mmo.petpackage.module.info.infosub
{
   import com.adobe.utils.StringUtil;
   import flash.display.MovieClip;
   import flash.display.Sprite;
   import flash.text.TextField;
   import flash.text.TextFieldAutoSize;
   import flash.utils.getDefinitionByName;
   import mmo.common.utils.tips.TipsManager;
   import mmo.interfaces.ServiceContainer;
   import mmo.interfaces.formation.IFormationService;
   import mmo.interfaces.formation.SulingEffectDefine;
   import mmo.interfaces.pet.battle.IBattlePropertySource;
   import mmo.interfaces.pet.battle.PetBattlePropertyType;
   import mmo.interfaces.pet.data.IPetDataService;
   import mmo.interfaces.pet.data.PetBriefInfo;
   import mmo.petpackage.module.info.base.BaseSubModule;
   
   public class SpeAttrSubModule extends BaseSubModule
   {
      
      private static const SULING_TIPS_CLS:String = "mmo.petpackage.SulingTips";
      
      private static const NORMAL_ATTRS:Array = [PetBattlePropertyType.EXT_CRITICAL_RATE,PetBattlePropertyType.EXT_ANTI_CRITICAL_RATE,PetBattlePropertyType.EXT_HIT_RATE,PetBattlePropertyType.EXT_EVASION_RATE,PetBattlePropertyType.EXT_STRIKE_RATE,PetBattlePropertyType.EXT_BLOCK_RATE];
      
      private static const LINGCHU_ATTRS:Array = [PetBattlePropertyType.EXT_CRITICAL_RATE,PetBattlePropertyType.EXT_ANTI_CRITICAL_RATE,PetBattlePropertyType.EXT_HIT_RATE,PetBattlePropertyType.EXT_EVASION_RATE,PetBattlePropertyType.EXT_STRIKE_RATE,PetBattlePropertyType.EXT_BLOCK_RATE,PetBattlePropertyType.EQUIPMENTS_STRENGTHEN_POWER,PetBattlePropertyType.EQUIPMENTS_RESIST_POWER];
      
      private static const VALUES:Array = [PetBattlePropertyType.EQUIPMENTS_STRENGTHEN_POWER,PetBattlePropertyType.EQUIPMENTS_RESIST_POWER];
      
      private var _petInfo:PetBriefInfo;
      
      private var _values:Array;
      
      private var _arrTips:Array = [];
      
      private var _formationService:IFormationService;
      
      private var _petDataService:IPetDataService;
      
      public function SpeAttrSubModule(param1:Sprite)
      {
         super(param1);
      }
      
      override protected function initService() : void
      {
         super.initService();
         this._formationService = ServiceContainer.getService(IFormationService) as IFormationService;
         this._petDataService = ServiceContainer.getService(IPetDataService) as IPetDataService;
      }
      
      override protected function initComponent() : void
      {
      }
      
      private function writeValues() : void
      {
         this._values = [];
         this._values.push(this._petInfo.petBuild.battleProperty.criticalRate);
         this._values.push(this._petInfo.petBuild.battleProperty.antiCriticalRate);
         this._values.push(this._petInfo.petBuild.battleProperty.hitRate);
         this._values.push(this._petInfo.petBuild.battleProperty.evasionRate);
         this._values.push(this._petInfo.petBuild.battleProperty.strikeRate);
         this._values.push(this._petInfo.petBuild.battleProperty.blockRate);
         this._values.push(this._petInfo.petBuild.battleProperty.strengthenPower);
         this._values.push(this._petInfo.petBuild.battleProperty.resistPower);
      }
      
      private function setAboutNormal() : void
      {
         this._setResPacker.setFrame("",1);
         NORMAL_ATTRS.forEach(function(param1:PetBattlePropertyType, param2:int, ... rest):void
         {
            setProp(_setResPacker.getChild(["spProp_" + param2]),param2,_values[param2],param1);
         });
      }
      
      private function setAboutLinChu() : void
      {
         var suLingEffectDefine:SulingEffectDefine = null;
         this._setResPacker.setFrame("",2);
         suLingEffectDefine = this._formationService.getSuLingEffectDefineById(this._petInfo.dictData.qiYunType);
         LINGCHU_ATTRS.forEach(function(param1:PetBattlePropertyType, param2:int, ... rest):void
         {
            var _loc4_:String = suLingEffectDefine.getDescByValueAndNumKey(param2,_values[param2]);
            setProp(_setResPacker.getChild(["spProp_" + param2]),param2,_values[param2],param1,_loc4_);
         });
      }
      
      override public function setInfo(param1:PetBriefInfo) : void
      {
         if(param1 == null)
         {
            this.setNullInfo();
         }
         else
         {
            this._petInfo = param1;
            this.writeValues();
            if(this._petInfo.dictData.isLingChu())
            {
               this.setAboutLinChu();
            }
            else
            {
               this.setAboutNormal();
            }
         }
      }
      
      private function setNullInfo() : void
      {
         this._setResPacker.setVisible("",false);
      }
      
      private function setProp(param1:MovieClip, param2:int, param3:Number, param4:PetBattlePropertyType, param5:String = null) : void
      {
         var _loc7_:Sprite = null;
         var _loc8_:TextField = null;
         var _loc9_:Sprite = null;
         var _loc6_:IBattlePropertySource = this._petDataService.getPetDataItemByRaceId(this._petInfo.raceId).baseStatus.getBattleProperty();
         _setResPacker.setFrame([param1,"mcName"],param2 + 1);
         _setResPacker.setText([param1,"prop"],this.value2Desc(param3,param4,true));
         _setResPacker.setText([param1,"pet"],this.value2Desc(_loc6_.getValue(param4,true),param4));
         _setResPacker.setText([param1,"stargod"],this.value2Desc(this._petInfo.petBuild.pro_stargod.getBattleProperty().getValue(param4,true),param4));
         _setResPacker.setText([param1,"badge"],this.value2Desc(this._petInfo.petBuild.pro_badge.getBattleProperty().getValue(param4,true),param4));
         _setResPacker.setText([param1,"astrolabe"],this.value2Desc(this._petInfo.petBuild.pro_astrolabe.getBattleProperty().getValue(param4,true),param4));
         TipsManager.getInstance().removeTips(_setResPacker.getChild([param1,"btnMore"]));
         _setResPacker.setVisible([param1,"btnMore"]);
         if(!StringUtil.isNullOrEmpty(param5))
         {
            _loc7_ = this.getTips(param2);
            if(_loc7_ != null)
            {
               _loc8_ = _setResPacker.getChild([_loc7_,"txtDes"]);
               _loc9_ = _setResPacker.getChild([_loc7_,"spBack"]);
               _loc8_.wordWrap = true;
               _loc8_.autoSize = TextFieldAutoSize.LEFT;
               _loc8_.htmlText = param5;
               _loc9_.width = _loc8_.textWidth + (_loc8_.x - _loc9_.x) * 2;
               _loc9_.height = _loc8_.textHeight + (_loc8_.y - _loc9_.y) * 2;
               _setResPacker.setVisible([param1,"btnMore"],true);
               TipsManager.getInstance().addCustomTips(_setResPacker.getChild([param1,"btnMore"]),_loc7_);
            }
         }
      }
      
      private function value2Desc(param1:Number, param2:PetBattlePropertyType, param3:Boolean = false) : String
      {
         if(!param3 && param1 == 0)
         {
            return "";
         }
         if(VALUES.indexOf(param2) != -1)
         {
            return Math.floor(param1).toString();
         }
         return Math.floor(param1 * 100) + "%";
      }
      
      private function getTips(param1:int) : Sprite
      {
         var _loc2_:int = 0;
         var _loc3_:Class = null;
         var _loc4_:Sprite = null;
         if(param1 >= this._arrTips.length)
         {
            _loc2_ = int(this._arrTips.length);
            while(_loc2_ < param1 + 1)
            {
               _loc3_ = getDefinitionByName(SULING_TIPS_CLS) as Class;
               _loc4_ = new _loc3_();
               this._arrTips.push(_loc4_);
               _loc2_++;
            }
         }
         return this._arrTips[param1];
      }
   }
}

