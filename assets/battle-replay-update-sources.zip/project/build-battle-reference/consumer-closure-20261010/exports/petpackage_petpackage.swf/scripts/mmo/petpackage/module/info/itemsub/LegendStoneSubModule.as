package mmo.petpackage.module.info.itemsub
{
   import flash.display.MovieClip;
   import flash.display.SimpleButton;
   import flash.display.Sprite;
   import flash.events.Event;
   import flash.events.MouseEvent;
   import mmo.common.DisplayUtil;
   import mmo.common.EventBinder;
   import mmo.common.helper.ActUtil;
   import mmo.common.utils.panel.helper.ClickHelper;
   import mmo.common.utils.panel.modaldialog.ModalDialogManager;
   import mmo.common.utils.tips.TipsManager;
   import mmo.interfaces.ServiceContainer;
   import mmo.interfaces.formation.IFormationService;
   import mmo.interfaces.formation.LegendSkillDefine;
   import mmo.interfaces.legend.ILegendService;
   import mmo.interfaces.pet.data.PetBriefInfo;
   import mmo.interfaces.pet.data.PetLegendStone;
   import mmo.interfaces.pet.data.PetLegendStoneSlot;
   import mmo.interfaces.petpackage.IPetPackage;
   import mmo.petpackage.module.info.InfoSetter;
   import mmo.petpackage.module.info.base.BaseSubModule;
   import mmo.play.globalfunctions.forSvc;
   
   public class LegendStoneSubModule extends BaseSubModule
   {
      
      private static const SLOT_NUM:int = 5;
      
      private var _clickHelper:ClickHelper = null;
      
      private var _eventBinder:EventBinder = null;
      
      private var _info:PetBriefInfo;
      
      private var _overIndex:int = -1;
      
      public function LegendStoneSubModule(param1:Sprite)
      {
         super(param1);
      }
      
      private static function isStoneLevelMax(param1:PetLegendStoneSlot) : Boolean
      {
         return !param1.isEmpty() && param1.level >= param1.getLengedItemDefine().levels;
      }
      
      override protected function initComponent() : void
      {
         if(this._clickHelper == null)
         {
            this._clickHelper = new ClickHelper(_res);
            this._clickHelper.regClickFunc("btnInstall",this.onClickInstall);
            this._clickHelper.regClickFunc("btnUpgrade",this.onClickUpgrade);
            this._clickHelper.regClickFunc("btnGainStone",this.onClickGainStone);
            this._clickHelper.regClickFunc("btnPerfectStone",this.onClickPerfectStone);
            this._clickHelper.regClickFunc("btnWhatIsLegendSkill",this.onClickWhatIsLegendSkill);
         }
         if(this._eventBinder == null)
         {
            this._eventBinder = new EventBinder();
            if(_res.stage != null)
            {
               this._eventBinder.bind(_res.stage,MouseEvent.MOUSE_MOVE,this.onMouseMove);
            }
            else
            {
               this._eventBinder.bind(_res,Event.ADDED_TO_STAGE,this.onAddedToStage);
            }
         }
      }
      
      private function onAddedToStage(param1:Event) : void
      {
         this._eventBinder.unBindAll();
         this._eventBinder.bind(_res.stage,MouseEvent.MOUSE_MOVE,this.onMouseMove);
      }
      
      private function onMouseMove(param1:MouseEvent) : void
      {
         var _loc6_:Sprite = null;
         var _loc2_:MovieClip = _res["mcInstall"];
         if(this._info == null)
         {
            _loc2_.visible = false;
            return;
         }
         var _loc3_:Sprite = null;
         var _loc4_:int = -1;
         var _loc5_:int = 0;
         while(_loc5_ < SLOT_NUM)
         {
            _loc6_ = _res["spLegendStone_" + _loc5_];
            if(_loc6_.hitTestPoint(param1.stageX,param1.stageY,true))
            {
               _loc3_ = _loc6_;
               _loc4_ = _loc5_;
               break;
            }
            _loc5_++;
         }
         if(_loc4_ != -1)
         {
            if(!_loc2_.visible || _loc4_ != this._overIndex)
            {
               _loc2_.x = _loc3_.x + _loc3_.width / 2 - _loc2_.width / 2;
               _loc2_.y = _loc3_.y + _loc3_.height * (3 / 4);
            }
            _loc2_.visible = true;
            _loc2_.gotoAndStop(isStoneLevelMax(this._info.legendStone.slots[_loc4_]) ? 2 : 1);
         }
         else
         {
            if(_loc2_.visible && _loc2_.hitTestPoint(param1.stageX,param1.stageY,true))
            {
               return;
            }
            _loc2_.visible = false;
         }
         this._overIndex = _loc4_;
      }
      
      private function onClickInstall() : void
      {
         if(this._info == null)
         {
            return;
         }
         this.jumpLegendService(0,this._overIndex,this._info);
      }
      
      private function onClickUpgrade() : void
      {
         if(this._info == null)
         {
            return;
         }
         this.jumpLegendService(1,this._overIndex,this._info);
      }
      
      private function jumpLegendService(param1:int, param2:int, param3:PetBriefInfo) : void
      {
         var mode:int = param1;
         var overIndex:int = param2;
         var petInfo:PetBriefInfo = param3;
         ModalDialogManager.getInstance().clearAll();
         ServiceContainer.tryGetService(ILegendService,function(param1:ILegendService, param2:Object):*
         {
            var legendSvc:ILegendService = param1;
            var params:Object = param2;
            legendSvc.showMainPanel(petInfo.id,mode,overIndex,function():*
            {
               forSvc(IPetPackage,function(param1:IPetPackage):*
               {
                  if(petInfo == null)
                  {
                     param1.show();
                     return;
                  }
                  param1.show(petInfo.dictData.isBossPet() ? 1 : 0,petInfo.id,1,10006);
               });
            });
         });
      }
      
      private function onClickGainStone() : void
      {
         ActUtil.toShowNewAct("strengthguide2023","showMainPanel_4");
      }
      
      private function onClickPerfectStone() : void
      {
         ModalDialogManager.getInstance().clearAll();
         ServiceContainer.tryGetService(ILegendService,function(param1:ILegendService, param2:Object):*
         {
            param1.showPerfectPanel();
         });
      }
      
      private function onClickWhatIsLegendSkill() : void
      {
         ServiceContainer.tryGetService(ILegendService,function(param1:ILegendService, param2:Object):*
         {
            param1.showLegendSkillIntroPanel();
         });
      }
      
      override public function setInfo(param1:PetBriefInfo) : void
      {
         var _loc9_:PetLegendStoneSlot = null;
         if((this._info = param1) == null || !param1.dictData.isLegend())
         {
            return;
         }
         new InfoSetter(_res,param1).updateLegendStone();
         var _loc2_:ILegendService = ServiceContainer.getService(ILegendService);
         var _loc3_:PetLegendStone = param1.legendStone;
         var _loc4_:IFormationService = ServiceContainer.getService(IFormationService);
         var _loc5_:LegendSkillDefine = _loc4_.getLegendSkillDefineAvailable(param1.dictData.legendSkillNo,_loc3_);
         var _loc6_:int = 0;
         var _loc7_:Boolean = true;
         var _loc8_:Vector.<PetLegendStoneSlot> = _loc3_.slots;
         for each(_loc9_ in _loc8_)
         {
            if(_loc9_.state != PetLegendStoneSlot.SS_EMPTY)
            {
               if(_loc9_.level < _loc9_.getLegendItemLevelDefine().define.levels)
               {
                  _loc7_ = false;
               }
               _loc6_++;
            }
            else
            {
               _loc7_ = false;
            }
         }
         DisplayUtil.clearContainer(_res["spRecommendStones"]);
         Sprite(_res["spRecommendStones"]).addChild(_loc2_.getRecommendStone(param1.dictData.raceId));
         if(this._overIndex != -1)
         {
            MovieClip(_res["mcInstall"]).gotoAndStop(isStoneLevelMax(_loc8_[this._overIndex]) ? 2 : 1);
            MovieClip(_res["mcInstall"]).visible = true;
         }
         else
         {
            MovieClip(_res["mcInstall"]).visible = false;
         }
         MovieClip(_res["mcSkillIconW"]).gotoAndStop(param1.dictData.isTianQi() ? 2 : 1);
         MovieClip(_res["mcSkillIconW"]["mcSkillIcon"]).gotoAndStop(_loc5_.iconFrame);
         SimpleButton(_res["btnPerfectStone"]).visible = false;
         TipsManager.getInstance().removeTips(_res["mcSkillIconW"]);
         TipsManager.getInstance().addCustomTips(_res["mcSkillIconW"],_loc2_.getSkillTips(param1.dictData.legendSkillNo,param1.legendStone,true));
      }
      
      override public function dispose() : void
      {
         if(this._clickHelper != null)
         {
            this._clickHelper.dispose();
            this._clickHelper = null;
         }
         if(this._eventBinder != null)
         {
            this._eventBinder.unBindAll();
            this._eventBinder = null;
         }
         super.dispose();
      }
   }
}

