package mmo.interacthelper.skillicon
{
   import com.adobe.utils.StringUtil;
   import flash.display.DisplayObject;
   import flash.display.MovieClip;
   import flash.display.SimpleButton;
   import flash.display.Sprite;
   import flash.events.Event;
   import flash.events.MouseEvent;
   import flash.geom.Rectangle;
   import flash.system.ApplicationDomain;
   import flash.text.TextField;
   import flash.utils.ByteArray;
   import flash.utils.Dictionary;
   import flash.utils.getDefinitionByName;
   import mmo.common.DateUtil;
   import mmo.common.DisplayUtil;
   import mmo.common.InstanceUtil;
   import mmo.common.ProgressFullSprite;
   import mmo.common.aoqi.packer.SetResPacker;
   import mmo.common.helper.ActUtil;
   import mmo.common.utils.tips.TipsManager;
   import mmo.common.utils.tips.TipsType;
   import mmo.interfaces.ServiceContainer;
   import mmo.interfaces.battleconfig.IBattleConfig;
   import mmo.interfaces.battleconfig.consts.SkillTypes;
   import mmo.interfaces.battleconfig.define.AlmightySkillDefine;
   import mmo.interfaces.battleconfig.define.CarryDefine;
   import mmo.interfaces.battleconfig.define.HuanSkillDefine;
   import mmo.interfaces.battleconfig.define.SkillDefine;
   import mmo.interfaces.battleconfig.define.SummonDefine;
   import mmo.interfaces.carry.ICarryService;
   import mmo.interfaces.formation.FormationPetInfo;
   import mmo.interfaces.formation.IFormationService;
   import mmo.interfaces.formation.ITransformSkillDefine;
   import mmo.interfaces.formation.LegendSkillDefine;
   import mmo.interfaces.formation.PsychicsSkillDefine;
   import mmo.interfaces.formation.QiYunEffectDefine;
   import mmo.interfaces.formation.TransformSkillType;
   import mmo.interfaces.formationpanelv3.IFormationPanelServiceV3;
   import mmo.interfaces.interacthelper.IInteractHelper;
   import mmo.interfaces.interacthelper.NewSkillIconInfo;
   import mmo.interfaces.legend.ILegendService;
   import mmo.interfaces.newbie.NewbieEvent;
   import mmo.interfaces.newbie.NewbieEventDispatcher;
   import mmo.interfaces.pet.data.IPetDataService;
   import mmo.interfaces.pet.data.IPetDictionaryDataService;
   import mmo.interfaces.pet.data.PetBriefInfo;
   import mmo.interfaces.pet.data.PetDictionaryDataItem;
   import mmo.interfaces.pet.data.PetJob;
   import mmo.interfaces.pet.data.PetLegendStone;
   import mmo.interfaces.pet.peticon.IPetIcon;
   import mmo.interfaces.pet.peticon.PetIconContainer;
   import mmo.interfaces.pet.peticon.PetIconType;
   import mmo.loader.common.datastructures.HashMap;
   import mmo.play.globalfunctions.forSvc;
   import mmo.region.Translator;
   
   public class NewSkillIconHelperV2
   {
      
      private static var _domain:ApplicationDomain;
      
      private static var _formationServcie:IFormationService;
      
      private static var _petDataSvc:IPetDataService;
      
      private static const UPDATE_FUNC_MAP:Dictionary = new Dictionary();
      
      private static const CF_HERO:int = 1;
      
      private static const CF_SUMMON:int = 2;
      
      private static const CF_PSYCHICS:int = 3;
      
      private static const CF_LARGE:int = 4;
      
      private static const CF_DRAGON:int = 5;
      
      private static const CF_YUAN_LI:int = 6;
      
      private static const CF_LEGEND:int = 7;
      
      private static const CF_SUPER_HERO:int = 8;
      
      private static const CF_TRANSFORM:int = 9;
      
      private static const CF_TIAN_QI:int = 10;
      
      private static const CF_DOUBLE_HERO:int = 11;
      
      private static const CF_ENERGIZE:int = 12;
      
      private static const CF_CARRY:int = 13;
      
      private static const CF_HUAN:int = 14;
      
      private static const CF_ALMIGHTY:int = 15;
      
      private static const CF_YI_XING_ZU:int = 16;
      
      private static const CF_SWALLOW:int = 17;
      
      private static const CF_SHEN_YUN:int = 18;
      
      private static const CF_SELF_TRANSFORM:int = 19;
      
      private static const CF_LING_CHU:int = 20;
      
      private static var _summonMap:HashMap = new HashMap();
      
      private static var _carryMap:HashMap = new HashMap();
      
      private static var _isVer3:Boolean = false;
      
      private static var sAlmightyNewVerInit:Boolean = false;
      
      private static var sAlmightyNewVer:Boolean = false;
      
      private static var _rollDirection:Dictionary = new Dictionary(true);
      
      private static const DEFAULT_SKILL_TAG_FRAME:int = -1;
      
      private static const SKILL_TAG_FRAME_PHY:int = 1;
      
      private static const SKILL_TAG_FRAME_MAG:int = 2;
      
      private static const SKILL_TAG_FRAME_ULT:int = 3;
      
      private static const SKILL_TAG_FRAME_SPHY:int = 4;
      
      private static const SKILL_TAG_FRAME_SMAG:int = 5;
      
      initStatic();
      
      public function NewSkillIconHelperV2()
      {
         super();
      }
      
      internal static function addSkillIconWithBattleConfigAndIcon(param1:Sprite, param2:int, param3:Boolean, param4:int, param5:int, param6:IBattleConfig, param7:Sprite, param8:NewSkillIconInfo, param9:Boolean, param10:Boolean, param11:PetBriefInfo, param12:Boolean, param13:Boolean, param14:Boolean, param15:int, param16:ApplicationDomain, param17:Boolean = false) : void
      {
         var context:Context_NewSkillIconHelperV2 = null;
         var onAddedToStage:Function = null;
         var container:Sprite = param1;
         var raceId:int = param2;
         var isShowSummonPanel:Boolean = param3;
         var petId:int = param4;
         var summonedPetRaceId:int = param5;
         var battleConfig:IBattleConfig = param6;
         var mcIcon:Sprite = param7;
         var newSkillIconInfo:NewSkillIconInfo = param8;
         var addSkillTips:Boolean = param9;
         var hasRes:Boolean = param10;
         var petBriefInfo:PetBriefInfo = param11;
         var addPsychisSkillTip:Boolean = param12;
         var multilFormTip:Boolean = param13;
         var isShowCarryPanel:Boolean = param14;
         var carriedPetRaceId:int = param15;
         var domain:ApplicationDomain = param16;
         var innerTipsAvailable:Boolean = param17;
         _domain = domain;
         context = new Context_NewSkillIconHelperV2();
         var txtVersion:TextField = mcIcon.getChildByName("txtVersion") as TextField;
         _isVer3 = false;
         if(txtVersion.text == "ver.3")
         {
            _isVer3 = true;
         }
         else if(txtVersion.text != "ver.2")
         {
            return;
         }
         txtVersion.visible = false;
         _formationServcie = ServiceContainer.getService(IFormationService);
         _petDataSvc = ServiceContainer.getService(IPetDataService);
         context.container = container;
         context.raceId = raceId;
         context.isShowSummonPanel = isShowSummonPanel;
         context.petId = petId;
         context.summonedPetRaceId = summonedPetRaceId;
         context.battleConfig = battleConfig;
         context.mcIcon = mcIcon as MovieClip;
         context.newSkillIconInfo = newSkillIconInfo;
         context.addSkillTips = addSkillTips;
         context.hasRes = hasRes;
         context.multilFormTip = multilFormTip;
         context.petBriefInfo = petBriefInfo;
         context.addPsychisSkillTip = addPsychisSkillTip;
         context.dictionary = ServiceContainer.getService(IPetDictionaryDataService);
         context.dicData = context.dictionary.getDataItemByRaceId(raceId);
         context.isShowCarryPanel = isShowCarryPanel;
         context.carriedPetRaceId = carriedPetRaceId;
         context.innerTipsAvailable = innerTipsAvailable;
         if(context.container != null && !context.hasRes)
         {
            DisplayUtil.clearContainer(context.container);
            context.container.addChild(context.mcIcon);
         }
         if(context.mcIcon.stage == null)
         {
            DisplayUtil.stop(context.mcIcon);
            onAddedToStage = function(param1:Event):void
            {
               context.mcIcon.removeEventListener(Event.ADDED_TO_STAGE,onAddedToStage);
               addSkillIconJustStageStandby(context);
            };
            context.mcIcon.addEventListener(Event.ADDED_TO_STAGE,onAddedToStage);
         }
         else
         {
            addSkillIconJustStageStandby(context);
         }
      }
      
      private static function addSkillIconJustStageStandby(param1:Context_NewSkillIconHelperV2) : void
      {
         var _loc8_:ITransformSkillDefine = null;
         var _loc9_:int = 0;
         if(!sAlmightyNewVerInit)
         {
            sAlmightyNewVerInit = true;
            sAlmightyNewVer = DateUtil.getServerTimeInMS() >= new Date("2022/10/14" + DateUtil.getServerClosedTimeStr()).getTime();
         }
         var _loc2_:int = Boolean(param1.dicData.isLegend()) || Boolean(param1.dicData.isShenYun()) ? 1 : 0;
         var _loc3_:Boolean = param1.dicData.heroSkillNo > 0;
         var _loc4_:Boolean = param1.dicData.yuanLiSkillNo > 0;
         var _loc5_:Boolean = param1.dicData.psychicsSkillNo > 0;
         var _loc6_:Boolean = param1.dicData.transformSkillNo > 0;
         var _loc7_:Array = [];
         if(_loc5_)
         {
            _loc2_++;
            _loc7_.push(CF_PSYCHICS);
         }
         if(param1.summonedPetRaceId > 0 || Boolean(param1.dicData.isSummonerPet()))
         {
            _loc2_++;
            _loc7_.push(CF_SUMMON);
         }
         if((param1.carriedPetRaceId > 0 || Boolean(param1.dicData.isCarrier())) && !param1.dicData.needMarkCarryPetType(false))
         {
            _loc2_++;
            _loc7_.push(CF_CARRY);
         }
         if(_loc3_)
         {
            if(param1.dicData.isDoubleHeroSkill())
            {
               _loc7_.push(CF_DOUBLE_HERO);
            }
            else if(param1.dicData.jobE == PetJob.GOD_PHYSICS_SUPER_HERO || param1.dicData.jobE == PetJob.GOD_MAGIC_SUPER_HERO || param1.dicData.jobE2 == PetJob.GOD_PHYSICS_SUPER_HERO || param1.dicData.jobE2 == PetJob.GOD_MAGIC_SUPER_HERO)
            {
               _loc7_.push(CF_SUPER_HERO);
            }
            else
            {
               _loc7_.push(CF_HERO);
            }
            _loc2_++;
         }
         if(param1.dicData.isAlmighty())
         {
            _loc2_++;
            _loc7_.push(CF_ALMIGHTY);
         }
         if(param1.dicData.isSwallower())
         {
            _loc2_++;
            _loc7_.push(CF_SWALLOW);
         }
         if(_loc6_)
         {
            _loc8_ = _formationServcie.getTransformSkillDefineById(param1.dicData.transformSkillNo);
            if(_loc8_.skillType == TransformSkillType.ELEMENT_SKILL)
            {
               _loc7_.push(CF_TRANSFORM);
            }
            else if(_loc8_.skillType == TransformSkillType.ENERGIZE_SKILL)
            {
               _loc7_.push(CF_ENERGIZE);
            }
            else if(_loc8_.skillType == TransformSkillType.SELF_ELEMENT_SKILL)
            {
               _loc7_.push(CF_SELF_TRANSFORM);
            }
            _loc2_++;
         }
         if(param1.dicData.isLargePet())
         {
            _loc2_++;
            _loc7_.push(CF_LARGE);
         }
         if(param1.dicData.isDragonJob())
         {
            _loc2_++;
            _loc7_.push(CF_DRAGON);
         }
         if(_loc4_)
         {
            _loc2_++;
            _loc7_.push(CF_YUAN_LI);
         }
         if(param1.dicData.isHuan())
         {
            _loc2_++;
            _loc7_.push(CF_HUAN);
         }
         else if(param1.dicData.isYiXingZu())
         {
            _loc2_++;
            _loc7_.push(CF_YI_XING_ZU);
         }
         if(_loc7_.length == 0 && (Boolean(param1.dicData.isLegend()) || Boolean(param1.dicData.isShenYun())))
         {
            if(param1.dicData.isLingChu())
            {
               _loc7_.push(CF_LING_CHU);
            }
            else if(param1.dicData.isShenYun())
            {
               _loc7_.push(CF_SHEN_YUN);
            }
            else if(param1.dicData.isTianQi())
            {
               _loc7_.push(CF_TIAN_QI);
            }
            else
            {
               _loc7_.push(CF_LEGEND);
            }
         }
         if(_loc2_ == 0)
         {
            param1.mcIcon.gotoAndStop(1);
            param1.mcCenter.visible = false;
            param1.mcCenter.gotoAndStop(1);
            updateLeftAndRightLocation(param1,true);
         }
         else if(_isVer3)
         {
            param1.mcIcon.gotoAndStop(_loc2_);
            param1.mcCenter.visible = true;
            if(_loc7_.length > 0)
            {
               updateMultiCenterVer3(param1,_loc7_);
            }
            if(param1.dicData.isLingChu())
            {
               updateCenterOfLingChu(param1);
            }
            else if(param1.dicData.isShenYun())
            {
               updateCenterOfShenYun(param1);
            }
            else if(param1.dicData.isLegend())
            {
               updateCenterOfLegendOrTianQi(param1);
            }
         }
         else
         {
            param1.mcIcon.gotoAndStop(_loc2_);
            param1.mcCenter.visible = true;
            if(_loc7_.length > 0)
            {
               if(_loc7_.length == 1)
               {
                  _loc9_ = int(_loc7_[0]);
                  param1.mcCenter.gotoAndStop(param1.mcCenter.totalFrames);
                  param1.mcCenter.gotoAndStop(_loc9_);
                  updateLeftAndRightLocation(param1,false);
                  UPDATE_FUNC_MAP[_loc9_](param1);
               }
               else
               {
                  updateMultiCenter(param1,_loc7_);
               }
            }
            if(param1.dicData.isLingChu())
            {
               updateCenterOfLingChu(param1);
            }
            else if(param1.dicData.isShenYun())
            {
               updateCenterOfShenYun(param1);
            }
            else if(param1.dicData.isLegend())
            {
               updateCenterOfLegendOrTianQi(param1);
            }
         }
         updateLeftAndRight(param1);
      }
      
      private static function updateMultiCenter(param1:Context_NewSkillIconHelperV2, param2:Array) : void
      {
         var _loc3_:MovieClip = param1.mcCenter;
         var _loc4_:int = 0;
         while(_loc4_ < param2.length)
         {
            param1.replaceCenter(_loc3_["mcCenter" + _loc4_]);
            param1.mcCenter.gotoAndStop(param2[_loc4_]);
            UPDATE_FUNC_MAP[param2[_loc4_]](param1);
            _loc4_++;
         }
         param1.replaceCenter(_loc3_);
      }
      
      private static function updateMultiCenterVer3(param1:Context_NewSkillIconHelperV2, param2:Array) : void
      {
         var _loc4_:int = 0;
         var _loc5_:MovieClip = null;
         var _loc6_:Sprite = null;
         var _loc7_:String = null;
         var _loc3_:MovieClip = param1.mcCenter;
         var _loc8_:int = int(param2.length);
         var _loc9_:Number = 1;
         var _loc10_:int = 0;
         for(; _loc10_ < _loc8_; _loc10_++)
         {
            _loc5_ = _loc3_.getChildByName("mcCenter" + _loc10_) as MovieClip;
            if(_loc5_ == null)
            {
               _loc6_ = _loc3_["mcCenter" + _loc10_ + "Con"];
               _loc7_ = "SkillIcon_SplitHero_B";
               if(_loc6_ == null)
               {
                  _loc6_ = _loc3_["mcCenter" + _loc10_ + "ConMini"];
                  _loc7_ = "SkillIcon_SplitHero_Sec_Mini";
                  _loc9_ = 0.75;
               }
               if(_loc6_ == null)
               {
                  _loc6_ = _loc3_["mcCenter" + _loc10_ + "ConS"];
                  _loc7_ = "SkillIcon_SplitHero_S";
                  _loc9_ = 1;
               }
               if(_loc6_ == null)
               {
                  continue;
               }
               _loc5_ = getNewRes(_loc7_);
               _loc5_.name = "mcCenter" + _loc10_;
               _loc3_.addChildAt(_loc5_,_loc10_);
               _loc5_.x = _loc6_.x;
               _loc5_.y = _loc6_.y;
               _loc5_.scaleX = _loc5_.scaleY = _loc9_;
               _loc6_.visible = false;
            }
            param1.replaceCenter(_loc5_);
            _loc4_ = int(param2[_loc10_]);
            _loc5_.gotoAndStop(_loc5_.totalFrames);
            _loc5_.gotoAndStop(_loc4_);
            UPDATE_FUNC_MAP[_loc4_](param1);
         }
         param1.replaceCenter(_loc3_);
      }
      
      protected static function updateLeftAndRightLocation(param1:Context_NewSkillIconHelperV2, param2:Boolean) : void
      {
         var _loc3_:DisplayObject = param1.mcIcon.getChildByName(param2 ? "spMin" : "spMax");
         if(_loc3_ == null)
         {
            return;
         }
         var _loc4_:MovieClip = param1.mcIcon.getChildByName("mcLeft") as MovieClip;
         if(_loc4_ == null)
         {
            return;
         }
         var _loc5_:MovieClip = param1.mcIcon.getChildByName("mcRight") as MovieClip;
         var _loc6_:Rectangle = _loc3_.getBounds(_loc3_.parent);
         var _loc7_:Rectangle = _loc4_.getChildByName("spBound").getBounds(_loc4_);
         var _loc8_:Rectangle = _loc5_.getChildByName("spBound").getBounds(_loc5_);
         _loc4_.x = _loc6_.left - _loc7_.width - _loc7_.x;
         _loc4_.getChildByName("spBound").visible = false;
         _loc5_.x = _loc6_.right - _loc8_.x;
         _loc5_.getChildByName("spBound").visible = false;
         param1.mcIcon.getChildByName("spMin").visible = false;
         param1.mcIcon.getChildByName("spMax").visible = false;
      }
      
      private static function getNewRes(param1:String) : MovieClip
      {
         return InstanceUtil.getInstance("mmo.interacthelper.newskillIcon." + param1,_domain);
      }
      
      protected static function updateLeftAndRight(param1:Context_NewSkillIconHelperV2) : void
      {
         var _loc2_:Sprite = null;
         var _loc3_:String = null;
         var _loc16_:ByteArray = null;
         var _loc21_:int = 0;
         var _loc22_:ByteArray = null;
         var _loc23_:String = null;
         var _loc24_:String = null;
         var _loc25_:SkillDefine = null;
         var _loc4_:Number = 1;
         var _loc5_:int = param1.mcIcon.currentFrame;
         var _loc6_:Sprite = param1.mcIcon.getChildByName("mcLeft") as Sprite;
         _loc2_ = param1.mcIcon["mcLeftCon0"];
         _loc3_ = "SkillIcon_SplitLeft_0";
         if(_loc2_ == null)
         {
            _loc2_ = param1.mcIcon["mcLeftCon1"];
            _loc3_ = "SkillIcon_SplitLeft_0";
            _loc4_ = 0.9;
         }
         if(_loc2_ == null)
         {
            _loc2_ = param1.mcIcon["mcLeftCon2"];
            _loc3_ = "SkillIcon_SplitLeft_2";
         }
         if(_loc2_ == null)
         {
            _loc2_ = param1.mcIcon["mcLeftConMini"];
            _loc3_ = "SkillIcon_SplitLeft_Mini";
         }
         if(_loc6_ == null)
         {
            if(_loc2_ == null)
            {
               return;
            }
            _loc6_ = getNewRes(_loc3_);
            _loc6_.name = "mcLeft";
            _loc6_.scaleX = _loc6_.scaleY = _loc4_;
            param1.mcIcon.addChildAt(_loc6_,1);
         }
         if(_loc2_ != null)
         {
            _loc6_.x = _loc2_.x;
            _loc6_.y = _loc2_.y;
            _loc2_.visible = false;
         }
         var _loc7_:TextField = _loc6_["nsname"];
         var _loc8_:Sprite = _loc6_["nssign"];
         var _loc9_:MovieClip = _loc6_["nstype"];
         var _loc10_:Sprite = param1.mcIcon.getChildByName("mcRight") as Sprite;
         _loc2_ = param1.mcIcon["mcRightCon0"];
         _loc3_ = "SkillIcon_SplitRight_0";
         if(_loc2_ == null)
         {
            _loc2_ = param1.mcIcon["mcRightCon1"];
            _loc3_ = "SkillIcon_SplitRight_0";
            _loc4_ = 0.9;
         }
         if(_loc2_ == null)
         {
            _loc2_ = param1.mcIcon["mcRightCon2"];
            _loc3_ = "SkillIcon_SplitRight_2";
         }
         if(_loc2_ == null)
         {
            _loc2_ = param1.mcIcon["mcRightConMini"];
            _loc3_ = "SkillIcon_SplitRight_Mini";
         }
         if(_loc10_ == null)
         {
            if(_loc2_ == null)
            {
               return;
            }
            _loc10_ = getNewRes(_loc3_);
            _loc10_.name = "mcRight";
            _loc10_.scaleX = _loc10_.scaleY = _loc4_;
            param1.mcIcon.addChildAt(_loc10_,1);
         }
         if(_loc2_ != null)
         {
            _loc10_.x = _loc2_.x;
            _loc10_.y = _loc2_.y;
            _loc2_.visible = false;
         }
         var _loc11_:TextField = _loc10_["usname"];
         var _loc12_:Sprite = _loc10_["ussign"];
         var _loc13_:MovieClip = _loc10_["ustype"] as MovieClip;
         TipsManager.getInstance().removeTips(_loc6_);
         TipsManager.getInstance().removeTips(_loc10_);
         var _loc14_:SkillDefine = param1.battleConfig.getSkillDefineById(param1.dicData.norSkillNo);
         var _loc15_:int = 1;
         if(isMagicSkill(_loc14_))
         {
            _loc9_.gotoAndStop(param1.dicData.isGodJob() ? 3 : 1);
            _loc15_ = param1.dicData.isGodJob() ? SKILL_TAG_FRAME_SMAG : SKILL_TAG_FRAME_MAG;
         }
         else
         {
            _loc9_.gotoAndStop(param1.dicData.isGodJob() ? 4 : 2);
            _loc15_ = param1.dicData.isGodJob() ? SKILL_TAG_FRAME_SPHY : SKILL_TAG_FRAME_PHY;
         }
         _loc8_.visible = _loc14_.isBossSkill;
         if(_loc7_ != null)
         {
            _loc7_.text = _loc14_.name;
            _loc16_ = new ByteArray();
            _loc16_.writeUTFBytes(_loc14_.name);
            if(_loc16_.length > 15)
            {
               _loc7_.y = 12.6;
            }
            else
            {
               _loc7_.y = 19.6;
            }
         }
         var _loc17_:SkillDefine = null;
         var _loc18_:int = 1;
         var _loc19_:int = SKILL_TAG_FRAME_ULT;
         var _loc20_:Boolean = isMagicSkill(_loc14_);
         if(param1.dicData.isGodJob())
         {
            _loc21_ = 0;
            if(param1.dicData.ultSkillNo > 0)
            {
               _loc21_ = int(param1.dicData.ultSkillNo);
               _loc18_ = _loc20_ ? 2 : 3;
            }
            else
            {
               _loc21_ = int(param1.dicData.ultSuperSkillNo);
               _loc18_ = _loc20_ ? 4 : 5;
            }
            _loc19_ = _loc20_ ? SKILL_TAG_FRAME_SMAG : SKILL_TAG_FRAME_SPHY;
            _loc17_ = param1.battleConfig.getSkillDefineById(_loc21_);
         }
         else
         {
            _loc17_ = param1.battleConfig.getSkillDefineById(param1.dicData.ultSkillNo);
         }
         _loc13_.gotoAndStop(_loc18_);
         _loc12_.visible = _loc17_.isBossSkill;
         if(_loc11_ != null)
         {
            _loc11_.text = _loc17_.name;
            _loc22_ = new ByteArray();
            _loc22_.writeUTFBytes(_loc17_.name);
            if(_loc22_.length > 15)
            {
               _loc11_.y = 12.6;
            }
            else
            {
               _loc11_.y = 19.6;
            }
         }
         if(param1.addSkillTips)
         {
            _loc23_ = _loc14_.description;
            _loc24_ = _loc17_.description;
            if(param1.multilFormTip && Boolean(param1.dicData.isMultipleForm()))
            {
               _loc25_ = param1.battleConfig.getSkillDefineById(param1.dicData.norSkillNo + 9000000);
               if(_loc25_ != null && !StringUtil.isNullOrEmpty(_loc25_.description))
               {
                  _loc23_ = _loc25_.description;
               }
               _loc25_ = param1.battleConfig.getSkillDefineById(param1.dicData.ultSkillNo + 9000000);
               if(_loc25_ != null && !StringUtil.isNullOrEmpty(_loc25_.description))
               {
                  _loc24_ = _loc25_.description;
               }
            }
            TipsManager.getInstance().addBattleEntryRelatedComplexTips(_loc6_,_loc14_.name,removeHtml(_loc23_));
            TipsManager.getInstance().addBattleEntryRelatedComplexTips(_loc10_,_loc17_.name,removeHtml(_loc24_));
         }
      }
      
      protected static function updateCenterOfLegendOrTianQi(param1:Context_NewSkillIconHelperV2) : void
      {
         var _loc4_:Sprite = null;
         var _loc5_:String = null;
         var _loc11_:Array = null;
         var _loc12_:LegendSkillDefine = null;
         var _loc2_:TipsManager = TipsManager.getInstance();
         var _loc3_:MovieClip = param1.mcCenter.getChildByName("lgiconW") as MovieClip;
         var _loc6_:Number = 1;
         _loc4_ = param1.mcCenter["lgiconWCon"];
         _loc5_ = "SkillIcon_Split_LG";
         if(_loc4_ == null)
         {
            _loc4_ = param1.mcCenter["lgiconWConS"];
            _loc6_ = 0.75;
         }
         if(_loc4_ == null)
         {
            _loc4_ = param1.mcCenter["lgiconWConMini"];
            _loc5_ = "SkillIcon_Split_LG_Mini";
            _loc6_ = 0.75;
         }
         if(_loc3_ == null)
         {
            if(_loc4_ == null)
            {
               return;
            }
            _loc3_ = getNewRes(_loc5_);
            _loc3_.name = "lgiconW";
            _loc3_.scaleX = _loc3_.scaleY = _loc6_;
            param1.mcCenter.addChildAt(_loc3_,1);
         }
         if(_loc4_ != null)
         {
            _loc3_.x = _loc4_.x;
            _loc3_.y = _loc4_.y;
            _loc4_.visible = false;
         }
         _loc3_.gotoAndStop(param1.dicData.isTianQi() ? 2 : 1);
         var _loc7_:MovieClip = _loc3_["lgicon"];
         _loc2_.removeTips(_loc7_);
         var _loc8_:ILegendService = ServiceContainer.getService(ILegendService);
         var _loc9_:int = int(param1.dicData.legendSkillNo);
         var _loc10_:PetLegendStone = null;
         if(param1.petBriefInfo != null)
         {
            _loc10_ = param1.petBriefInfo.legendStone;
            _loc12_ = _formationServcie.getLegendSkillDefineAvailable(_loc9_,_loc10_);
         }
         else if(_petDataSvc.getPetByPetId(param1.petId) != null)
         {
            _loc10_ = _petDataSvc.getPetByPetId(param1.petId).legendStone;
            _loc12_ = _formationServcie.getLegendSkillDefineAvailable(_loc9_,_loc10_);
         }
         else
         {
            _loc11_ = _formationServcie.getLegendSkillDefinesById(_loc9_);
            _loc12_ = _loc11_[_loc11_.length - 1];
         }
         if(_loc12_ == null)
         {
            throw new Error("缺少传说技配置：" + _loc9_);
         }
         _loc7_.gotoAndStop(_loc12_.iconFrame);
         if(param1.addSkillTips)
         {
            _loc2_.addCustomTips(_loc7_,_loc8_.getSkillTips(_loc9_,_loc10_ != null ? _loc10_ : "last",_loc10_ != null));
         }
      }
      
      protected static function updateCenterOfShenYun(param1:Context_NewSkillIconHelperV2) : void
      {
         var _loc3_:Sprite = null;
         var _loc4_:String = null;
         var _loc2_:MovieClip = param1.mcCenter.getChildByName("lgiconW") as MovieClip;
         var _loc5_:Number = 1;
         _loc3_ = param1.mcCenter["lgiconWCon"];
         _loc4_ = "SkillIcon_Split_LG";
         if(_loc3_ == null)
         {
            _loc3_ = param1.mcCenter["lgiconWConS"];
            _loc5_ = 0.75;
         }
         if(_loc3_ == null)
         {
            _loc3_ = param1.mcCenter["lgiconWConMini"];
            _loc4_ = "SkillIcon_Split_LG_Mini";
         }
         if(_loc2_ == null)
         {
            if(_loc3_ == null)
            {
               return;
            }
            _loc2_ = getNewRes(_loc4_);
            _loc2_.name = "lgiconW";
            _loc2_.scaleX = _loc2_.scaleY = _loc5_;
            param1.mcCenter.addChildAt(_loc2_,1);
         }
         if(_loc3_ != null)
         {
            _loc2_.x = _loc3_.x;
            _loc2_.y = _loc3_.y;
            _loc3_.visible = false;
         }
         _loc2_.gotoAndStop(3);
         var _loc6_:MovieClip = _loc2_["syicon"];
         setShenYunTips(_loc6_,param1);
      }
      
      private static function setShenYunTips(param1:Sprite, param2:Context_NewSkillIconHelperV2) : void
      {
         var shenYunSkillNo:int;
         var qiYunType:int;
         var cls:Class;
         var mcTips:Sprite;
         var mcBack:Sprite;
         var shenYunSkillDefine:SkillDefine;
         var qiYunEffectDefine:QiYunEffectDefine;
         var txtDescribe:TextField;
         var hDesc:String;
         var mcQiYun:MovieClip;
         var spDetails:SimpleButton;
         var keys:Array;
         var noEffect:Boolean;
         var effectNum:int;
         var i:int = 0;
         var br:String = null;
         var lanes:Array = null;
         var intoSides:Boolean = false;
         var mainEffects:Array = null;
         var sideEffects:Array = null;
         var effect:String = null;
         var propValue:Number = NaN;
         var desc:String = null;
         var row:Sprite = null;
         var title:TextField = null;
         var prop:TextField = null;
         var bonus:TextField = null;
         var mcInnerTips:Sprite = null;
         var j:int = 0;
         var shenYunIcon:Sprite = param1;
         var context:Context_NewSkillIconHelperV2 = param2;
         var getTwoBitNum:Function = function(param1:Number):int
         {
            if(Math.ceil(param1) - param1 >= 0.5)
            {
               return int(param1);
            }
            return Math.ceil(param1);
         };
         var tipsMgr:TipsManager = TipsManager.getInstance();
         tipsMgr.removeTips(shenYunIcon);
         shenYunSkillNo = int(context.dicData.shenYunSkillNo);
         qiYunType = int(context.dicData.qiYunType);
         cls = getDefinitionByName("mmo.interacthelper.newskillIcon.Tips_res2") as Class;
         mcTips = new cls();
         mcBack = mcTips["mcBack"];
         shenYunSkillDefine = context.battleConfig.getSkillDefineById(shenYunSkillNo);
         assertSkillDefine(shenYunSkillDefine,shenYunSkillNo);
         qiYunEffectDefine = _formationServcie.getQiYunEffectDefineById(qiYunType);
         txtDescribe = mcTips["txtDescribe"];
         hDesc = Translator.translate(shenYunSkillDefine.description);
         txtDescribe.htmlText = Translator.translate(shenYunSkillDefine.description);
         if(txtDescribe.numLines >= 20)
         {
            br = "<br>";
            lanes = hDesc.split(br);
            intoSides = false;
            mainEffects = [];
            sideEffects = [];
            i = 0;
            while(i < lanes.length)
            {
               effect = lanes[i];
               if(effect.indexOf("<") == 0)
               {
                  intoSides = true;
               }
               if(!intoSides)
               {
                  mainEffects.push(effect);
               }
               else
               {
                  sideEffects.push(effect);
               }
               i++;
            }
            if(sideEffects.length > 0)
            {
               txtDescribe.htmlText = mainEffects.join(br);
               addSide(mcTips,sideEffects.join(br));
            }
         }
         txtDescribe.height = (txtDescribe.numLines - 1) * 14 + 16;
         mcQiYun = mcTips["mcQiYun"];
         spDetails = mcTips["spDetails"];
         if(context.petBriefInfo == null || context.petBriefInfo.ownership != 1)
         {
            mcQiYun.visible = false;
            spDetails.visible = false;
            mcBack.height = txtDescribe.height + 45 + 12;
            tipsMgr.addCustomTips(shenYunIcon,mcTips);
            return;
         }
         mcQiYun.y = txtDescribe.height + txtDescribe.y + 16;
         keys = ["bj","fb","mz","sb","pj","gd"];
         noEffect = true;
         mcQiYun.gotoAndStop(1);
         effectNum = 0;
         i = 0;
         while(i < 6)
         {
            propValue = Number(context.petBriefInfo.petBuild.battleProperty.getHidePropertyValueByOrderKey(i));
            desc = qiYunEffectDefine.getDescByValueAndNumKey(i,propValue);
            row = mcQiYun["txt_" + i];
            row.visible = false;
            if(desc != QiYunEffectDefine.NO_EFFECT_DESC)
            {
               noEffect = false;
               row = mcQiYun["txt_" + effectNum];
               row.visible = true;
               effectNum++;
               title = row["txtName"];
               title.text = QiYunEffectDefine.CN_KEYS[i];
               prop = row["txtProp"];
               prop.text = getTwoBitNum(propValue * 100) + "%";
               bonus = row["txtBonus"];
               setScrollText(bonus,qiYunEffectDefine.getDescByValueAndNumKey(i,propValue),shenYunIcon);
            }
            i++;
         }
         spDetails.y = txtDescribe.height + 45 + 12 + 123 + effectNum * 20;
         if(noEffect)
         {
            mcQiYun.gotoAndStop(2);
         }
         mcBack.height = txtDescribe.height + 45 + 12 + (noEffect ? 65 : 48 + 20 * effectNum + 25);
         if(context.innerTipsAvailable)
         {
            spDetails.y = mcBack.height - 27;
            tipsMgr.removeTips(spDetails);
            cls = getDefinitionByName("mmo.interacthelper.newskillIcon.Tips_qiyun") as Class;
            mcInnerTips = new cls();
            i = 0;
            while(i < 6)
            {
               setScrollText(mcInnerTips[keys[i] + "Prop"],getTwoBitNum(context.petBriefInfo.petBuild.battleProperty.getHidePropertyValueByOrderKey(i) * 100) + "%",shenYunIcon);
               j = 0;
               while(j < 2)
               {
                  setScrollText(mcInnerTips[keys[i] + "Prop_" + j],getTwoBitNum(qiYunEffectDefine.getThresholdByKey(i)[j] * 100) + "%",shenYunIcon);
                  setScrollText(mcInnerTips[keys[i] + "Bonus_" + j],qiYunEffectDefine.getDescByKey(i)[j],shenYunIcon);
                  j++;
               }
               i++;
            }
            tipsMgr.addCustomTips(spDetails,mcInnerTips);
            tipsMgr.addFocusedArtTips(shenYunIcon,mcTips);
         }
         else
         {
            spDetails.visible = false;
            tipsMgr.addCustomTips(shenYunIcon,mcTips);
         }
      }
      
      protected static function updateCenterOfLingChu(param1:Context_NewSkillIconHelperV2) : void
      {
         var _loc3_:Sprite = null;
         var _loc4_:String = null;
         var _loc2_:MovieClip = param1.mcCenter.getChildByName("lgiconW") as MovieClip;
         var _loc5_:Number = 1;
         _loc3_ = param1.mcCenter["lgiconWCon"];
         _loc4_ = "SkillIcon_Split_LG";
         if(_loc3_ == null)
         {
            _loc3_ = param1.mcCenter["lgiconWConS"];
            _loc5_ = 0.75;
         }
         if(_loc3_ == null)
         {
            _loc3_ = param1.mcCenter["lgiconWConMini"];
            _loc4_ = "SkillIcon_Split_LG_Mini";
         }
         if(_loc2_ == null)
         {
            if(_loc3_ == null)
            {
               return;
            }
            _loc2_ = getNewRes(_loc4_);
            _loc2_.name = "lgiconW";
            _loc2_.scaleX = _loc2_.scaleY = _loc5_;
            param1.mcCenter.addChildAt(_loc2_,1);
         }
         if(_loc3_ != null)
         {
            _loc2_.x = _loc3_.x;
            _loc2_.y = _loc3_.y;
            _loc3_.visible = false;
         }
         _loc2_.gotoAndStop(3);
         var _loc6_:MovieClip = _loc2_["syicon"];
         setLinchuTips(_loc6_,param1);
      }
      
      private static function setLinchuTips(param1:Sprite, param2:Context_NewSkillIconHelperV2) : void
      {
         var _loc3_:TipsManager = TipsManager.getInstance();
         _loc3_.removeTips(param1);
         var _loc4_:int = int(param2.dicData.shenYunSkillNo);
         var _loc5_:SkillDefine = param2.battleConfig.getSkillDefineById(_loc4_);
         assertSkillDefine(_loc5_,_loc4_);
         var _loc6_:String = removeHtml(Translator.translate(_loc5_.description));
         _loc3_.addBattleEntryRelatedComplexTips(param1,"神运技",_loc6_);
      }
      
      private static function addSide(param1:Sprite, param2:String) : void
      {
         var _loc3_:Class = getDefinitionByName("mmo.interacthelper.newskillIcon.Tips_res3") as Class;
         var _loc4_:Sprite = new _loc3_();
         var _loc5_:TextField = _loc4_["txtDescribe"];
         _loc5_.htmlText = param2;
         _loc5_.height = (_loc5_.numLines - 1) * 14 + 16;
         var _loc6_:Sprite = _loc4_["mcBack"];
         _loc6_.height = _loc5_.height + 20;
         _loc4_.x = param1.width + 5;
         param1.addChild(_loc4_);
      }
      
      private static function setScrollText(param1:TextField, param2:String, param3:Sprite) : void
      {
         var onATS:Function = null;
         var onEF:Function = null;
         var onRFST:Function = null;
         var onRFS:Function = null;
         var txt:TextField = param1;
         var textStr:String = param2;
         var rootContainer:Sprite = param3;
         onATS = function(param1:Event):void
         {
            _rollDirection[txt] = 1;
            txt.addEventListener(Event.ENTER_FRAME,onEF);
         };
         onEF = function(param1:Event):void
         {
            txt.scrollH += _rollDirection[txt];
            if(txt.scrollH >= txt.maxScrollH)
            {
               _rollDirection[txt] = -1;
            }
            else if(txt.scrollH <= 0)
            {
               _rollDirection[txt] = 1;
            }
         };
         onRFST = function(param1:Event):void
         {
            delete _rollDirection[txt];
            txt.removeEventListener(Event.ENTER_FRAME,onEF);
         };
         onRFS = function(param1:Event):void
         {
            rootContainer.removeEventListener(Event.REMOVED_FROM_STAGE,onRFS);
            txt.removeEventListener(Event.ADDED_TO_STAGE,onATS);
            txt.removeEventListener(Event.REMOVED_FROM_STAGE,onATS);
         };
         txt.htmlText = textStr;
         if(txt.width >= txt.textWidth)
         {
            return;
         }
         txt.addEventListener(Event.ADDED_TO_STAGE,onATS);
         txt.addEventListener(Event.REMOVED_FROM_STAGE,onRFST);
         rootContainer.addEventListener(Event.REMOVED_FROM_STAGE,onRFS);
      }
      
      protected static function updateCenterOfHero(param1:Context_NewSkillIconHelperV2) : void
      {
         var _loc5_:SkillDefine = null;
         var _loc2_:Sprite = param1.mcCenter["hsicon"];
         var _loc3_:TextField = _loc2_["hsname"];
         TipsManager.getInstance().removeTips(_loc2_);
         var _loc4_:int = int(param1.dicData.heroSkillNo);
         if(_loc4_ > 0)
         {
            _loc5_ = param1.battleConfig.getSkillDefineById(_loc4_);
            if(_loc3_ != null)
            {
               _loc3_.text = _loc5_.name;
            }
            if(param1.addSkillTips)
            {
               TipsManager.getInstance().addBattleEntryRelatedComplexTips(_loc2_,_loc5_.name,removeHtml(_loc5_.description));
            }
         }
      }
      
      protected static function updateCenterOfCarry(param1:Context_NewSkillIconHelperV2) : void
      {
         var btnCarry:SimpleButton;
         var define:CarryDefine = null;
         var petIcon:Sprite = null;
         var petContainer:PetIconContainer = null;
         var context:Context_NewSkillIconHelperV2 = param1;
         var spCarryIcon:Sprite = context.mcCenter["mcicon"];
         var mcCarry:MovieClip = spCarryIcon["mcCarry"];
         mcCarry.gotoAndStop(1);
         TipsManager.getInstance().removeTips(mcCarry);
         btnCarry = spCarryIcon["btnCarry"];
         if(context.carriedPetRaceId > 0)
         {
            mcCarry.gotoAndStop(2);
            TipsManager.getInstance().removeTips(mcCarry);
            define = context.battleConfig.getCarryDefine(context.raceId,context.carriedPetRaceId);
            if(define != null)
            {
               TipsManager.getInstance().addBattleEntryRelatedComplexTips(mcCarry,"携同效果",removeHtml(define.skillDescription));
            }
            else
            {
               TipsManager.getInstance().addBattleEntryRelatedComplexTips(mcCarry,"无效携同","当前携同处于无效状态");
            }
            petIcon = mcCarry["pet"]["container"];
            DisplayUtil.clearContainer(petIcon);
            ServiceContainer.instance.tryGetService(IPetIcon,function onGetService(param1:IPetIcon, param2:Object):void
            {
               petContainer = param1.getPetIcon(context.carriedPetRaceId,PetIconType.FIGHT);
               if(petIcon != null)
               {
                  petIcon.addChild(petContainer);
               }
            });
         }
         btnCarry.visible = context.isShowCarryPanel && context.petBriefInfo.ownership == 1;
         if(!_carryMap.containsKey(btnCarry))
         {
            btnCarry.addEventListener(MouseEvent.CLICK,onClickCarry);
            btnCarry.addEventListener(Event.REMOVED_FROM_STAGE,onRemoveCarry);
         }
         if(context.petBriefInfo != null)
         {
            _carryMap.add(btnCarry,context.petBriefInfo);
         }
         else
         {
            _carryMap.add(btnCarry,context.petId);
         }
      }
      
      private static function updateCenterOfHuan(param1:Context_NewSkillIconHelperV2) : void
      {
         var spHuanSkillIcon:MovieClip;
         var huanDefines:Array;
         var title:String;
         var desc:Array = null;
         var effectDefine:HuanSkillDefine = null;
         var context:Context_NewSkillIconHelperV2 = param1;
         if(!context.dicData.isHuan())
         {
            return;
         }
         spHuanSkillIcon = context.mcCenter["huanIcon"];
         desc = [];
         effectDefine = null;
         huanDefines = context.battleConfig.getHuanDefine(context.dicData.huanSkillNo);
         huanDefines.forEach(function(param1:HuanSkillDefine, ... rest):void
         {
            var _loc3_:int = 0;
            if(context.petBriefInfo == null)
            {
               desc.push(param1.tip);
               return;
            }
            if(param1.typeIsZdl)
            {
               _loc3_ = int(context.petBriefInfo.battlePower);
               if(_loc3_ >= param1.valueToTakeEffect && (effectDefine == null || param1.valueToTakeEffect >= effectDefine.valueToTakeEffect))
               {
                  effectDefine = param1;
               }
               if(_loc3_ >= param1.valueToTakeEffect)
               {
                  desc.push("<font color=\'#00FFFF\'>" + param1.tip + "(已激活)" + "</font>");
               }
               else
               {
                  desc.push("<font color=\'#999999\'>" + param1.tip + "(未激活)" + "</font>");
               }
            }
         });
         title = effectDefine == null ? "寰力量" : effectDefine.name;
         spHuanSkillIcon.gotoAndStop(effectDefine == null ? 1 : effectDefine.icon + 1);
         TipsManager.getInstance().addBattleEntryRelatedComplexTips(spHuanSkillIcon,title,removeHtml(desc.join("<br>")));
      }
      
      private static function updateCenterOfYiXingZu(param1:Context_NewSkillIconHelperV2) : void
      {
         var spHuanSkillIcon:MovieClip;
         var huanDefines:Array;
         var title:String;
         var desc:Array = null;
         var effectDefine:HuanSkillDefine = null;
         var context:Context_NewSkillIconHelperV2 = param1;
         if(!context.dicData.isYiXingZu())
         {
            return;
         }
         spHuanSkillIcon = context.mcCenter["yxzIcon"];
         desc = [];
         effectDefine = null;
         huanDefines = context.battleConfig.getHuanDefine(context.dicData.huanSkillNo);
         huanDefines.forEach(function(param1:HuanSkillDefine, ... rest):void
         {
            var _loc3_:int = 0;
            if(context.petBriefInfo == null)
            {
               desc.push(param1.tip);
               return;
            }
            if(param1.typeIsZdl)
            {
               _loc3_ = int(context.petBriefInfo.battlePower);
               if(_loc3_ >= param1.valueToTakeEffect && (effectDefine == null || param1.valueToTakeEffect >= effectDefine.valueToTakeEffect))
               {
                  effectDefine = param1;
               }
               if(_loc3_ >= param1.valueToTakeEffect)
               {
                  desc.push("<font color=\'#00FFFF\'>" + param1.tip + "(已激活)" + "</font>");
               }
               else
               {
                  desc.push("<font color=\'#999999\'>" + param1.tip + "(未激活)" + "</font>");
               }
            }
         });
         title = effectDefine == null ? "异族审判" : effectDefine.name;
         spHuanSkillIcon.gotoAndStop(effectDefine == null ? 1 : effectDefine.icon + 1);
         TipsManager.getInstance().addBattleEntryRelatedComplexTips(spHuanSkillIcon,title,removeHtml(desc.join("<br>")));
      }
      
      private static function updateCenterOfAlmighty(param1:Context_NewSkillIconHelperV2) : void
      {
         var spCarryIcon:Sprite;
         var mcCarry:MovieClip;
         var btnCarry:SimpleButton;
         var define:CarryDefine = null;
         var petIcon:Sprite = null;
         var petContainer:PetIconContainer = null;
         var context:Context_NewSkillIconHelperV2 = param1;
         var setResPacker:SetResPacker = new SetResPacker(context.mcCenter);
         setResPacker.setVisible("almightyIconV2",sAlmightyNewVer);
         setResPacker.setVisible("almightyIcon",!sAlmightyNewVer);
         if(!sAlmightyNewVer)
         {
            updateCenterOfAlmightyOld(context);
            return;
         }
         spCarryIcon = context.mcCenter["almightyIconV2"];
         mcCarry = spCarryIcon["mcCarry"];
         mcCarry.gotoAndStop(1);
         btnCarry = spCarryIcon["btnCarry"];
         if(context.carriedPetRaceId > 0)
         {
            mcCarry.gotoAndStop(2);
            define = context.battleConfig.getCarryDefine(context.raceId,context.carriedPetRaceId);
            petIcon = mcCarry["pet"]["container"];
            DisplayUtil.clearContainer(petIcon);
            ServiceContainer.instance.tryGetService(IPetIcon,function onGetService(param1:IPetIcon, param2:Object):void
            {
               petContainer = param1.getPetIcon(context.carriedPetRaceId,PetIconType.FIGHT);
               if(petIcon != null)
               {
                  petIcon.addChild(petContainer);
               }
            });
         }
         btnCarry.visible = context.isShowCarryPanel && context.petBriefInfo.ownership == 1;
         if(!_carryMap.containsKey(btnCarry))
         {
            btnCarry.addEventListener(MouseEvent.CLICK,onClickCarry);
            btnCarry.addEventListener(Event.REMOVED_FROM_STAGE,onRemoveCarry);
         }
         if(context.petBriefInfo != null)
         {
            _carryMap.add(btnCarry,context.petBriefInfo);
         }
         else
         {
            _carryMap.add(btnCarry,context.petId);
         }
         setAlmightyTips(mcCarry,context);
      }
      
      private static function updateCenterOfAlmightyOld(param1:Context_NewSkillIconHelperV2) : void
      {
         if(!param1.dicData.isAlmighty())
         {
            return;
         }
         if(param1.mcCenter == null)
         {
            return;
         }
         var _loc2_:SetResPacker = new SetResPacker(param1.mcCenter);
         var _loc3_:Sprite = _loc2_.getChild("almightyIcon");
         setAlmightyTips(_loc3_,param1);
      }
      
      private static function setAlmightyTips(param1:Sprite, param2:Context_NewSkillIconHelperV2) : void
      {
         var defines:Array;
         var almightySkillDefine:AlmightySkillDefine;
         var wrapDesc:String;
         var phsychicsTip:Sprite = null;
         var calletPetPddi:PetDictionaryDataItem = null;
         var calledPetInfoMc:MovieClip = null;
         var almightyIcon:Sprite = param1;
         var context:Context_NewSkillIconHelperV2 = param2;
         var wrapAsTitle:Function = function(param1:String):String
         {
            return "<font color=\'#FFFFFF\'>" + param1 + "</font>" + "\n";
         };
         var wrapAsDesc:Function = function(param1:String):String
         {
            param1 = param1.replace("\\n","\n");
            return param1 + "\n";
         };
         TipsManager.getInstance().removeTips(almightyIcon);
         defines = context.battleConfig.getAlmightyDefine(context.dicData.raceId);
         if(defines.length == 0)
         {
            throw new Error("can not find any AlmightyDefine that id(raceId) is:" + context.dicData.raceId);
         }
         almightySkillDefine = defines[0];
         wrapDesc = "";
         wrapDesc += (context.addPsychisSkillTip ? wrapAsTitle(almightySkillDefine.heroSkillName) : "") + wrapAsDesc(almightySkillDefine.heroSkillDesc);
         wrapDesc += wrapAsTitle(almightySkillDefine.summonSkillName) + wrapAsDesc(almightySkillDefine.summonSkillDesc);
         wrapDesc += wrapAsTitle(almightySkillDefine.psychicsSkillName) + wrapAsDesc(almightySkillDefine.psychicsSkillDesc);
         if(context.addSkillTips)
         {
            if(context.addPsychisSkillTip)
            {
               calletPetPddi = context.dictionary.getDataItemByRaceId(almightySkillDefine.psychicsCalledPetRaceId);
               calledPetInfoMc = getPsychicsCallPet(calletPetPddi);
               phsychicsTip = getMcTips("",wrapDesc,-1,65535,1,calledPetInfoMc);
               TipsManager.getInstance().addFocusedArtTips(almightyIcon,phsychicsTip,0,TipsType.NORMAL,false,null,function():void
               {
                  if(phsychicsTip)
                  {
                     setSkill(phsychicsTip,calletPetPddi.raceId);
                  }
               });
            }
            else
            {
               phsychicsTip = getMcTips(wrapAsTitle(almightySkillDefine.heroSkillName),wrapDesc,-1,65535,0);
               TipsManager.getInstance().addCustomTips(almightyIcon,phsychicsTip);
            }
         }
      }
      
      private static function updateCenterOfSwallow(param1:Context_NewSkillIconHelperV2) : void
      {
         var btnCarry:SimpleButton;
         var define:CarryDefine = null;
         var petIcon:Sprite = null;
         var petContainer:PetIconContainer = null;
         var context:Context_NewSkillIconHelperV2 = param1;
         var spCarryIcon:Sprite = context.mcCenter["swallowIcon"];
         var mcCarry:MovieClip = spCarryIcon["mcCarry"];
         mcCarry.gotoAndStop(1);
         TipsManager.getInstance().removeTips(mcCarry);
         btnCarry = spCarryIcon["btnCarry"];
         if(context.carriedPetRaceId > 0)
         {
            mcCarry.gotoAndStop(2);
            TipsManager.getInstance().removeTips(mcCarry);
            define = context.battleConfig.getCarryDefine(context.raceId,context.carriedPetRaceId);
            if(define != null)
            {
               TipsManager.getInstance().addBattleEntryRelatedComplexTips(mcCarry,"吞噬效果",removeHtml(define.skillDescription));
            }
            else
            {
               TipsManager.getInstance().addBattleEntryRelatedComplexTips(mcCarry,"无效吞噬","当前吞噬处于无效状态");
            }
            petIcon = mcCarry["pet"]["container"];
            DisplayUtil.clearContainer(petIcon);
            ServiceContainer.instance.tryGetService(IPetIcon,function onGetService(param1:IPetIcon, param2:Object):void
            {
               petContainer = param1.getPetIcon(context.carriedPetRaceId,PetIconType.FIGHT);
               if(petIcon != null)
               {
                  petIcon.addChild(petContainer);
               }
            });
         }
         btnCarry.visible = context.isShowCarryPanel && context.petBriefInfo.ownership == 1;
         if(!_carryMap.containsKey(btnCarry))
         {
            btnCarry.addEventListener(MouseEvent.CLICK,onClickCarry);
            btnCarry.addEventListener(Event.REMOVED_FROM_STAGE,onRemoveCarry);
         }
         if(context.petBriefInfo != null)
         {
            _carryMap.add(btnCarry,context.petBriefInfo);
         }
         else
         {
            _carryMap.add(btnCarry,context.petId);
         }
      }
      
      protected static function updateCenterOfSummon(param1:Context_NewSkillIconHelperV2) : void
      {
         var btnSummon:SimpleButton;
         var define:SummonDefine = null;
         var petIcon:Sprite = null;
         var petContainer:PetIconContainer = null;
         var battleConfig:IBattleConfig = null;
         var svc:IPetDataService = null;
         var summonpetList:Array = null;
         var linkMap:Object = null;
         var lastRMap:Object = null;
         var canSummonPetDesc:String = null;
         var linkMapKey:* = undefined;
         var petName:String = null;
         var context:Context_NewSkillIconHelperV2 = param1;
         var spSummonIcon:Sprite = context.mcCenter["msicon"];
         var mcSummon:MovieClip = spSummonIcon["mcSummon"];
         mcSummon.gotoAndStop(1);
         TipsManager.getInstance().removeTips(mcSummon);
         btnSummon = spSummonIcon["btnSummon"];
         if(context.summonedPetRaceId > 0)
         {
            mcSummon.gotoAndStop(2);
            TipsManager.getInstance().removeTips(mcSummon);
            define = context.battleConfig.getSummonDefine(context.raceId,context.summonedPetRaceId);
            if(define != null)
            {
               TipsManager.getInstance().addBattleEntryRelatedComplexTips(mcSummon,"召唤特效",removeHtml(define.skillDescription));
            }
            else
            {
               TipsManager.getInstance().addBattleEntryRelatedComplexTips(mcSummon,"无效契约","当前契约处于无效状态，将召唤师神属后即可生效");
            }
            petIcon = mcSummon["pet"]["container"];
            DisplayUtil.clearContainer(petIcon);
            ServiceContainer.instance.tryGetService(IPetIcon,function onGetService(param1:IPetIcon, param2:Object):void
            {
               petContainer = param1.getPetIcon(context.summonedPetRaceId,PetIconType.FIGHT);
               if(petIcon != null)
               {
                  petIcon.addChild(petContainer);
               }
            });
         }
         else if(context.raceId > 0)
         {
            battleConfig = forSvc(IBattleConfig);
            svc = ServiceContainer.getService(IPetDataService);
            summonpetList = battleConfig.getSummonedPetDefineArray(context.raceId);
            if(summonpetList.length > 0)
            {
               linkMap = {};
               lastRMap = {};
               summonpetList.forEach(function(param1:SummonDefine, param2:int, ... rest):*
               {
                  var linkArray:Array = null;
                  var lastR:int = 0;
                  var key:String = null;
                  var filterMuti:Function = null;
                  var summonPet:SummonDefine = param1;
                  var sindex:int = param2;
                  var _:Array = rest;
                  if(!context.dictionary.getDataItemByRaceId(summonPet.summonedPetRaceId).isSkin() && Boolean(summonPet.isShow))
                  {
                     linkArray = svc.getPetOrderEvoLink(summonPet.summonedPetRaceId);
                     lastR = int(linkArray[linkArray.length - 1]);
                     key = linkArray.toString();
                     filterMuti = function():*
                     {
                        if(lastRMap.hasOwnProperty(lastR.toString()))
                        {
                           if(summonPet.summonedPetRaceId > lastRMap[lastR.toString()])
                           {
                              lastRMap[lastR.toString()] = summonPet.summonedPetRaceId;
                              linkMap[key] = summonPet.summonedPetRaceId;
                           }
                        }
                        else
                        {
                           lastRMap[lastR.toString()] = summonPet.summonedPetRaceId;
                           linkMap[key] = summonPet.summonedPetRaceId;
                        }
                     };
                     if(!linkMap.hasOwnProperty(key))
                     {
                        filterMuti();
                     }
                     else if(linkMap[key] < summonPet.summonedPetRaceId)
                     {
                        filterMuti();
                     }
                  }
               });
               canSummonPetDesc = "";
               for(linkMapKey in linkMap)
               {
                  petName = ActUtil.getPetNameByRaceId(linkMap[linkMapKey]);
                  canSummonPetDesc += petName;
                  canSummonPetDesc += "\n";
               }
               TipsManager.getInstance().addComplexTips(mcSummon,"可契约:",canSummonPetDesc.slice(0,-1));
            }
         }
         btnSummon.visible = context.isShowSummonPanel && context.petBriefInfo.ownership == 1;
         if(!_summonMap.containsKey(btnSummon))
         {
            _summonMap.add(btnSummon,context.petId);
            btnSummon.addEventListener(MouseEvent.CLICK,onClickSummon);
            btnSummon.addEventListener(Event.REMOVED_FROM_STAGE,onRemoveSummon);
            NewbieEventDispatcher.getInstance().addEventListener(NewbieEvent.TRY_SELECT_CURRENT_PET_SUMMON,onSetSummon);
         }
         else
         {
            _summonMap.add(btnSummon,context.petId);
         }
      }
      
      private static function onSetSummon(param1:NewbieEvent) : void
      {
         var petId:int = 0;
         var e:NewbieEvent = param1;
         petId = int(e.params["id"]);
         TipsManager.getInstance().clearAllTips();
         forSvc(IFormationPanelServiceV3,function(param1:IFormationPanelServiceV3):*
         {
            param1.showSummonSelectPanel(petId);
         });
      }
      
      protected static function updateCenterOfPsychics(param1:Context_NewSkillIconHelperV2) : void
      {
         var psychicsSkillId:int;
         var psychicsSkillDefine:SkillDefine = null;
         var psychicsSkillIdDefine:PsychicsSkillDefine = null;
         var calledPetRaceId:int = 0;
         var calletPetPddi:PetDictionaryDataItem = null;
         var calledPetInfoMc:MovieClip = null;
         var phsychicsTip:Sprite = null;
         var context:Context_NewSkillIconHelperV2 = param1;
         var spPsychicsSkillIcon:Sprite = context.mcCenter["pcsicon"];
         var txtPsychicsSkillName:TextField = spPsychicsSkillIcon.getChildByName("pcsname") as TextField;
         TipsManager.getInstance().removeTips(spPsychicsSkillIcon);
         psychicsSkillId = int(context.dicData.psychicsSkillNo);
         if(psychicsSkillId > 0)
         {
            psychicsSkillDefine = context.battleConfig.getSkillDefineById(psychicsSkillId);
            if(txtPsychicsSkillName != null)
            {
               txtPsychicsSkillName.text = psychicsSkillDefine.name;
            }
            if(context.addSkillTips && context.addPsychisSkillTip)
            {
               psychicsSkillIdDefine = _formationServcie.getPsychicsSkillDefinesById(psychicsSkillId)[0];
               if(psychicsSkillIdDefine == null)
               {
                  throw new Error("PsychicsSkillConfig 未配置：" + psychicsSkillId);
               }
               calledPetRaceId = int(psychicsSkillIdDefine.psychicsCalledPetRaceId);
               calletPetPddi = context.dictionary.getDataItemByRaceId(calledPetRaceId);
               calledPetInfoMc = getPsychicsCallPet(calletPetPddi);
               phsychicsTip = getMcTips(psychicsSkillDefine.name,psychicsSkillDefine.description,-1,65535,1,calledPetInfoMc);
               TipsManager.getInstance().addFocusedArtTips(spPsychicsSkillIcon,phsychicsTip,0,TipsType.NORMAL,false,null,function():void
               {
                  if(phsychicsTip)
                  {
                     setSkill(phsychicsTip,calledPetRaceId);
                  }
               });
            }
         }
      }
      
      private static function setSkill(param1:Sprite, param2:int) : void
      {
         var _loc3_:MovieClip = param1.getChildByName("mcPet") as MovieClip;
         if(!_loc3_)
         {
            return;
         }
         var _loc4_:Sprite = _loc3_.getChildByName("skillIcontainer") as Sprite;
         if(!_loc4_)
         {
            return;
         }
         var _loc5_:IInteractHelper = ServiceContainer.getService(IInteractHelper);
         _loc5_.addNewSkillIcon(_loc4_,param2);
      }
      
      protected static function updateCenterOfLarge(param1:Context_NewSkillIconHelperV2) : void
      {
         var _loc5_:SkillDefine = null;
         var _loc6_:MovieClip = null;
         var _loc2_:Sprite = param1.mcCenter["lsicon"];
         var _loc3_:TextField = _loc2_.getChildByName("lsname") as TextField;
         var _loc4_:int = int(param1.dicData.largeSkillNo);
         if(_loc4_ > 0)
         {
            _loc5_ = param1.battleConfig.getSkillDefineById(_loc4_);
            if(_loc3_ != null)
            {
               _loc3_.text = _loc5_.name;
            }
            _loc6_ = getShowLargeMc(param1.dicData);
            TipsManager.getInstance().addCustomTips(_loc2_,getMcTips(_loc5_.name,_loc5_.description,-1,65535,0,_loc6_));
         }
      }
      
      protected static function updateCenterOfDragon(param1:Context_NewSkillIconHelperV2) : void
      {
         var _loc5_:SkillDefine = null;
         var _loc2_:Sprite = param1.mcCenter["dsicon"];
         var _loc3_:TextField = _loc2_.getChildByName("dsname") as TextField;
         TipsManager.getInstance().removeTips(_loc2_);
         var _loc4_:int = int(param1.dicData.dragonJobSkillNo);
         if(_loc4_ > 0)
         {
            _loc5_ = param1.battleConfig.getSkillDefineById(_loc4_);
            if(_loc3_ != null)
            {
               _loc3_.text = _loc5_.name;
            }
            TipsManager.getInstance().addCustomTips(_loc2_,getMcTips(_loc5_.name,_loc5_.description,-1,65535));
         }
      }
      
      protected static function updateCenterOfYuanLi(param1:Context_NewSkillIconHelperV2) : void
      {
         var _loc9_:PetBriefInfo = null;
         var _loc2_:Sprite = param1.mcCenter["ysicon"];
         var _loc3_:TextField = _loc2_.getChildByName("ysname") as TextField;
         var _loc4_:Sprite = _loc2_["spYuanSkillNotOpen"];
         var _loc5_:IPetDataService = ServiceContainer.getService(IPetDataService);
         if(param1.petBriefInfo != null)
         {
            if(StringUtil.isNullOrEmpty(param1.petBriefInfo.equipmentSlotSequence))
            {
               _loc4_.visible = true;
            }
            else
            {
               _loc4_.visible = !_loc5_.isYuanliSkillOpen(param1.petBriefInfo);
            }
         }
         else
         {
            _loc9_ = _loc5_.getMyPetByPetId(param1.petId);
            if(_loc9_ != null)
            {
               _loc4_.visible = !_loc5_.isYuanliSkillOpen(_loc9_);
            }
            else
            {
               _loc4_.visible = false;
            }
         }
         var _loc6_:SkillDefine = param1.battleConfig.getSkillDefineById(param1.dicData.yuanLiSkillNo);
         if(_loc3_ != null)
         {
            _loc3_.text = _loc6_.name;
         }
         var _loc7_:String = _loc6_.description.split("@")[0];
         var _loc8_:String = _loc6_.description.split("@")[1];
         if(_loc4_.visible)
         {
            TipsManager.getInstance().removeTips(_loc2_);
            TipsManager.getInstance().addCustomTips(_loc2_,getMcTips(_loc6_.name,_loc7_,-1,65535));
         }
         else
         {
            TipsManager.getInstance().removeTips(_loc2_);
            TipsManager.getInstance().addCustomTips(_loc2_,getMcTips(_loc6_.name,_loc8_,-1,65535));
         }
      }
      
      protected static function updateCenterOfTransform(param1:Context_NewSkillIconHelperV2) : void
      {
         var _loc5_:SkillDefine = null;
         var _loc2_:Sprite = param1.mcCenter["trsicon"];
         var _loc3_:TextField = _loc2_["trsname"];
         TipsManager.getInstance().removeTips(_loc2_);
         var _loc4_:int = int(param1.dicData.transformSkillNo);
         if(_loc4_ > 0)
         {
            _loc5_ = param1.battleConfig.getSkillDefineById(_loc4_);
            if(_loc3_ != null)
            {
               _loc3_.text = _loc5_.name;
            }
            if(param1.addSkillTips)
            {
               TipsManager.getInstance().addBattleEntryRelatedComplexTips(_loc2_,_loc5_.name,removeHtml(_loc5_.description));
            }
         }
      }
      
      protected static function updateCenterOfDoubleHeroSkill(param1:Context_NewSkillIconHelperV2) : void
      {
         var _loc4_:SkillDefine = null;
         var _loc2_:Sprite = param1.mcCenter["doubleheroicon"];
         TipsManager.getInstance().removeTips(_loc2_);
         var _loc3_:int = int(param1.dicData.heroSkillNo);
         if(_loc3_ > 0)
         {
            _loc4_ = param1.battleConfig.getSkillDefineById(_loc3_);
            if(param1.addSkillTips)
            {
               TipsManager.getInstance().addCustomTips(_loc2_,getMcTips(_loc4_.name,_formationServcie.getHeroSkillTips(_loc3_,param1.battleConfig),-1,65535));
            }
         }
      }
      
      protected static function updateCenterOfSuperHero(param1:Context_NewSkillIconHelperV2) : void
      {
         var _loc5_:SkillDefine = null;
         var _loc2_:Sprite = param1.mcCenter["shsicon"];
         var _loc3_:TextField = _loc2_["shsname"];
         TipsManager.getInstance().removeTips(_loc2_);
         var _loc4_:int = int(param1.dicData.heroSkillNo);
         if(_loc4_ > 0)
         {
            _loc5_ = param1.battleConfig.getSkillDefineById(_loc4_);
            if(_loc3_ != null)
            {
               _loc3_.text = _loc5_.name;
            }
            if(param1.addSkillTips)
            {
               TipsManager.getInstance().addBattleEntryRelatedComplexTips(_loc2_,_loc5_.name,removeHtml(_loc5_.description));
            }
         }
      }
      
      private static function getMcTips(param1:String, param2:String, param3:int = -1, param4:uint = 0, param5:int = 0, param6:MovieClip = null) : Sprite
      {
         var _loc7_:Class = getDefinitionByName("mmo.interacthelper.newskillIcon.Tips_res" + param5) as Class;
         var _loc8_:Sprite = new _loc7_();
         var _loc9_:Sprite = _loc8_["mcBack"];
         var _loc10_:MovieClip = _loc8_["mcSkillTag"];
         if(param3 == DEFAULT_SKILL_TAG_FRAME)
         {
            _loc10_.visible = false;
         }
         else
         {
            _loc10_.gotoAndStop(param3);
         }
         var _loc11_:TextField = _loc8_["txtTitle"];
         var _loc12_:TextField = _loc8_["txtDescribe"];
         _loc11_.htmlText = param1;
         _loc12_.htmlText = Translator.translate(param2);
         _loc12_.height = (_loc12_.numLines - 1) * 25 + 18;
         if(param5 == 1)
         {
            _loc12_.height = (_loc12_.numLines - 1) * 20 + 18;
         }
         var _loc13_:Number = 0;
         if(param6 != null)
         {
            _loc8_.addChild(param6);
            DisplayUtil.alignDisplay(param6,_loc8_,"01");
            param6.y = _loc12_.y + _loc12_.height + 10;
            _loc13_ = param6.height + 5;
         }
         if(param5 == 1)
         {
            _loc9_.height = _loc12_.numLines * 20 + 27 + _loc13_;
         }
         else
         {
            _loc9_.height = _loc12_.numLines * 18 + 27 + _loc13_;
         }
         _loc9_.y = 0;
         return _loc8_;
      }
      
      private static function getShowLargeMc(param1:PetDictionaryDataItem) : MovieClip
      {
         var _loc2_:Class = getDefinitionByName("mmo.interacthelper.newskillIcon.LargeIcon_res") as Class;
         var _loc3_:MovieClip = new _loc2_();
         _loc3_.gotoAndStop(param1.gridType);
         var _loc4_:IPetIcon = ServiceContainer.getService(IPetIcon);
         Sprite(_loc3_["ic"]).addChild(_loc4_.getPetIcon(param1.raceId,PetIconType.NO_POSTER,60,120));
         return _loc3_;
      }
      
      private static function getPsychicsCallPet(param1:PetDictionaryDataItem) : MovieClip
      {
         var _loc2_:Class = getDefinitionByName("mmo.interacthelper.newskillIcon.PsychicsCalledPet_res") as Class;
         var _loc3_:MovieClip = new _loc2_();
         var _loc4_:Sprite = _loc3_["skillIcontainer"];
         var _loc5_:TextField = _loc3_["txtPetName"];
         _loc5_.text = "";
         _loc5_.y = 0;
         var _loc6_:IInteractHelper = ServiceContainer.getService(IInteractHelper);
         _loc6_.addNewSkillIcon(_loc4_,param1.raceId);
         _loc4_.scaleX = _loc4_.scaleY = 0.8;
         _loc4_.y = 30;
         Sprite(_loc3_["ic"]).y = 0;
         _loc3_.name = "mcPet";
         return _loc3_;
      }
      
      private static function isMagicSkill(param1:SkillDefine) : Boolean
      {
         return param1.type2 == SkillTypes.MAGIC || param1.type2 == SkillTypes.SUPER_MAGIC;
      }
      
      private static function onClickSummon(param1:MouseEvent) : void
      {
         var petId:int = 0;
         var evt:MouseEvent = param1;
         var btnSummon:SimpleButton = evt.currentTarget as SimpleButton;
         if(btnSummon)
         {
            petId = int(_summonMap.getValue(btnSummon));
            TipsManager.getInstance().clearAllTips();
            forSvc(IFormationPanelServiceV3,function(param1:IFormationPanelServiceV3):*
            {
               param1.showSummonSelectPanel(petId);
            });
         }
      }
      
      private static function onRemoveSummon(param1:Event) : void
      {
         NewbieEventDispatcher.getInstance().removeEventListener(NewbieEvent.TRY_SELECT_CURRENT_PET_SUMMON,onSetSummon);
         var _loc2_:SimpleButton = param1.currentTarget as SimpleButton;
         _loc2_.removeEventListener(MouseEvent.CLICK,onClickSummon);
         _loc2_.removeEventListener(Event.REMOVED_FROM_STAGE,onRemoveSummon);
         _summonMap.remove(_loc2_);
      }
      
      private static function onClickCarry(param1:MouseEvent) : void
      {
         var carryValue:* = undefined;
         var petBriefInfo:PetBriefInfo = null;
         var petDataSvc:IPetDataService = null;
         var petId:int = 0;
         var evt:MouseEvent = param1;
         var btnCarry:SimpleButton = evt.currentTarget as SimpleButton;
         if(btnCarry)
         {
            carryValue = _carryMap.getValue(btnCarry);
            if(typeof carryValue === "number")
            {
               petDataSvc = forSvc(IPetDataService);
               petId = carryValue;
               petBriefInfo = petDataSvc.getPetByPetId(petId);
            }
            else
            {
               petBriefInfo = carryValue;
            }
            ProgressFullSprite.show();
            ServiceContainer.instance.tryGetService(ICarryService,function(param1:ICarryService, param2:Object):void
            {
               ProgressFullSprite.close();
               param1.showSwitchCarriedPetPanel(FormationPetInfo.petBriefInfo2FormationPetInfo(petBriefInfo));
            });
         }
      }
      
      private static function onRemoveCarry(param1:Event) : void
      {
         var _loc2_:SimpleButton = param1.currentTarget as SimpleButton;
         _loc2_.removeEventListener(MouseEvent.CLICK,onClickCarry);
         _loc2_.removeEventListener(Event.REMOVED_FROM_STAGE,onRemoveCarry);
         _carryMap.remove(_loc2_);
      }
      
      private static function assertSkillDefine(param1:SkillDefine, param2:int) : void
      {
         if(param1 == null)
         {
            throw new Error("Can not find skill define, id: " + param2);
         }
      }
      
      private static function initStatic() : void
      {
         UPDATE_FUNC_MAP[CF_HERO] = updateCenterOfHero;
         UPDATE_FUNC_MAP[CF_SUMMON] = updateCenterOfSummon;
         UPDATE_FUNC_MAP[CF_PSYCHICS] = updateCenterOfPsychics;
         UPDATE_FUNC_MAP[CF_LARGE] = updateCenterOfLarge;
         UPDATE_FUNC_MAP[CF_DRAGON] = updateCenterOfDragon;
         UPDATE_FUNC_MAP[CF_YUAN_LI] = updateCenterOfYuanLi;
         UPDATE_FUNC_MAP[CF_LEGEND] = updateCenterOfLegendOrTianQi;
         UPDATE_FUNC_MAP[CF_SUPER_HERO] = updateCenterOfSuperHero;
         UPDATE_FUNC_MAP[CF_TRANSFORM] = updateCenterOfTransform;
         UPDATE_FUNC_MAP[CF_TIAN_QI] = updateCenterOfLegendOrTianQi;
         UPDATE_FUNC_MAP[CF_DOUBLE_HERO] = updateCenterOfDoubleHeroSkill;
         UPDATE_FUNC_MAP[CF_ENERGIZE] = updateCenterOfTransform;
         UPDATE_FUNC_MAP[CF_CARRY] = updateCenterOfCarry;
         UPDATE_FUNC_MAP[CF_HUAN] = updateCenterOfHuan;
         UPDATE_FUNC_MAP[CF_ALMIGHTY] = updateCenterOfAlmighty;
         UPDATE_FUNC_MAP[CF_YI_XING_ZU] = updateCenterOfYiXingZu;
         UPDATE_FUNC_MAP[CF_SWALLOW] = updateCenterOfSwallow;
         UPDATE_FUNC_MAP[CF_SHEN_YUN] = updateCenterOfShenYun;
         UPDATE_FUNC_MAP[CF_SELF_TRANSFORM] = updateCenterOfTransform;
         UPDATE_FUNC_MAP[CF_LING_CHU] = updateCenterOfLingChu;
      }
      
      private static function removeHtml(param1:String) : String
      {
         return param1.replace(/<(?!br\b)[^>]*>/gi,"");
      }
   }
}

import flash.display.MovieClip;
import flash.display.Sprite;
import mmo.interfaces.battleconfig.IBattleConfig;
import mmo.interfaces.interacthelper.NewSkillIconInfo;
import mmo.interfaces.pet.data.IPetDictionaryDataService;
import mmo.interfaces.pet.data.PetBriefInfo;
import mmo.interfaces.pet.data.PetDictionaryDataItem;

class Context_NewSkillIconHelperV2
{
   
   public var container:Sprite;
   
   public var raceId:int;
   
   public var isShowSummonPanel:Boolean;
   
   public var petId:int;
   
   public var summonedPetRaceId:int;
   
   public var battleConfig:IBattleConfig;
   
   public var mcIcon:MovieClip;
   
   public var newSkillIconInfo:NewSkillIconInfo;
   
   public var addSkillTips:Boolean;
   
   public var hasRes:Boolean;
   
   public var petBriefInfo:PetBriefInfo;
   
   public var addPsychisSkillTip:Boolean;
   
   public var dictionary:IPetDictionaryDataService;
   
   public var dicData:PetDictionaryDataItem;
   
   public var multilFormTip:Boolean;
   
   public var isShowCarryPanel:Boolean;
   
   public var carriedPetRaceId:int;
   
   public var innerTipsAvailable:Boolean;
   
   private var center:MovieClip;
   
   public function Context_NewSkillIconHelperV2()
   {
      super();
   }
   
   public function get mcCenter() : MovieClip
   {
      if(this.center == null)
      {
         this.center = this.mcIcon["mcCenter"];
      }
      return this.center;
   }
   
   public function replaceCenter(param1:MovieClip) : void
   {
      this.center = param1;
   }
}
