package mmo.formation.config
{
   import mmo.interfaces.formation.SulingEffectDefine;
   
   public class LingChuSkillSulingConfig
   {
      
      private static const DEFINES:Array = [new SulingEffectDefine(11,"1.5","2","0.1","0.1","0.1","0.1","0.1","0.1","触发暴击的概率；触发暴击可令本次造成的攻击伤害翻倍；<br>进入战斗时，暴击率<font color=\'#00FFFF\'>≥150%</font>，则在第10、20个双方完整回合结束后，永久获得暴击率提升20%","抵抗敌人的暴击率；<br>进入战斗时，防暴率<font color=\'#00FFFF\'>≥200%</font>，则获得生命值与生命上限提升25%","抵抗敌人的闪避率","触发闪避的概率；触发闪避可令本次受到的攻击无效","破击率可提升自身造成的<font color=\'#00FFFF\'>攻击伤害</font>和<font color=\'#00FFFF\'>毁灭伤害</font>（伤害提升数值=破击率*伤害倍率*1100；且该数值不受暴击、格挡等效果影响）","用于触发格挡；触发格挡可令本次受到的攻击伤害减半；<br>进入战斗时，获得<font color=\'#00FFFF\'>#V1#</font>点[格挡之力]（[格挡之力]点数=格挡率*600）；<br>受到攻击前，可消耗[格挡之力]触发格挡（消耗数值=本次受到攻击的伤害倍率）","自身获得部分<font color=\'#00FFFF\'>“灵初正面”</font>效果时，需消耗一定[强化之力]，否则该效果失效；<br>（原名：[辉跃之力]，现改名：[强化之力]）","自身获得部分<font color=\'#00FFFF\'>“灵初负面”</font>效果时，可消耗一定[抵抗之力]令该效果无效；<br>每个大回合开始时，自身拥有的[抵抗之力]恢复至基础值；<br>（原名：[咒缚之力]，现改名：[抵抗之力]）","","","","","破击率*11","格挡率*6","","","触发暴击的概率；触发暴击可令本次造成的攻击伤害翻倍；<br>进入战斗时，暴击率<font color=\'#00FFFF\'>≥150%</font>，则在第10、20个双方完整回合结束后，永久获得暴击率提升20%","抵抗敌人的暴击率；<br>进入战斗时，防暴率<font color=\'#00FFFF\'>≥200%</font>，则获得生命值与生命上限提升25%"
      ,"抵抗敌人的闪避率","触发闪避的概率；触发闪避可令本次受到的攻击无效","破击率可提升自身造成的<font color=\'#00FFFF\'>攻击伤害</font>和<font color=\'#00FFFF\'>毁灭伤害</font>（伤害提升数值=破击率*伤害倍率*1100；且该数值不受暴击、格挡等效果影响）","用于触发格挡；触发格挡可令本次受到的攻击伤害减半；<br>进入战斗时，获得<font color=\'#00FFFF\'>#V1#</font>点[格挡之力]（[格挡之力]点数=格挡率*600）；<br>受到攻击前，可消耗[格挡之力]触发格挡（消耗数值=本次受到攻击的伤害倍率）","自身获得部分<font color=\'#00FFFF\'>“灵初正面”</font>效果时，需消耗一定[强化之力]，否则该效果失效；<br>（原名：[辉跃之力]，现改名：[强化之力]）","自身获得部分<font color=\'#00FFFF\'>“灵初负面”</font>效果时，可消耗一定[抵抗之力]令该效果无效；<br>每个大回合开始时，自身拥有的[抵抗之力]恢复至基础值；<br>（原名：[咒缚之力]，现改名：[抵抗之力]）")];
      
      private static const RULE_STRS:Array = ["","","","","","修改触发格挡的方式：受到攻击前，可消耗等于本次攻击伤害倍率的[格挡之力]令本次受击触发格挡"];
      
      public function LingChuSkillSulingConfig()
      {
         super();
      }
      
      public static function getSuLingDefinesById(param1:int) : SulingEffectDefine
      {
         var _loc3_:SulingEffectDefine = null;
         var _loc2_:int = 0;
         while(_loc2_ < DEFINES.length)
         {
            _loc3_ = DEFINES[_loc2_];
            if(_loc3_.id == param1)
            {
               return _loc3_;
            }
            _loc2_++;
         }
         return null;
      }
      
      public static function getSuLingDesc() : Array
      {
         return RULE_STRS;
      }
   }
}

