package mmo.formation.formationtips
{
   import com.adobe.utils.StringUtil;
   import flash.display.MovieClip;
   import flash.display.SimpleButton;
   import flash.display.Sprite;
   import flash.events.Event;
   import flash.system.ApplicationDomain;
   import flash.text.TextField;
   import mmo.common.DisplayUtil;
   import mmo.common.InstanceUtil;
   import mmo.common.aoqi.packer.SetResPacker;
   import mmo.common.loader.LoadResUtil;
   import mmo.common.utils.panel.helper.ClickHelper;
   import mmo.common.utils.tips.TipsManager;
   import mmo.common.utils.tips.TipsType;
   import mmo.interfaces.IDispose;
   import mmo.interfaces.ServiceContainer;
   import mmo.interfaces.astrolabe.IAstrolabeService;
   import mmo.interfaces.battleconfig.IBattleConfig;
   import mmo.interfaces.equipment4pet.IEquipment4PetService;
   import mmo.interfaces.formation.FormationPetInfo;
   import mmo.interfaces.formation.IFormationService;
   import mmo.interfaces.formation.SulingEffectDefine;
   import mmo.interfaces.legend.ILegendService;
   import mmo.interfaces.pet.data.IPetDataService;
   import mmo.interfaces.pet.data.IPetDictionaryDataService;
   import mmo.interfaces.pet.data.PetAstrolabe;
   import mmo.interfaces.pet.data.PetAstrolabeTraceSlot;
   import mmo.interfaces.pet.data.PetBadgeSlot;
   import mmo.interfaces.pet.data.PetBriefInfo;
   import mmo.interfaces.pet.data.PetDictionaryDataItem;
   import mmo.interfaces.pet.data.PetLegendStoneSlot;
   import mmo.interfaces.pet.data.PetSacredEquipmentSlot;
   import mmo.interfaces.pet.data.PetStarGodSlot;
   import mmo.interfaces.petbadge.IPetBadgeService;
   import mmo.interfaces.sacredequipment.ISacredEquipmentService;
   import mmo.interfaces.stargod.IStarGodService;
   import mmo.play.dialog.InteractUtil;
   import mmo.play.globalfunctions.forSvc;
   
   public class NewFormationTipsSprite extends Sprite implements IDispose
   {
      
      private static const STARGOD_NUM:int = 8;
      
      private static const EQUIPMENT_NUM:int = 3;
      
      private static const MODULE_GAP:Number = 2;
      
      private static const DETAIL_DESC_LINE_HEIGHT:Number = 15;
      
      private static const ITEM_MODULE_HEIGHT:Number = 30;
      
      private static const SKILL_MODULE_HEIGHT:Number = 90;
      
      private var _res:MovieClip;
      
      private var _setResPacker:SetResPacker;
      
      private var _clickHelper:ClickHelper;
      
      private var _formationPetInfo:FormationPetInfo;
      
      private var _spBg:Sprite;
      
      private var _increasingHeight:Number = 0.35;
      
      private var _increasingWidth:Number = 262;
      
      private var _spDetailModule:Sprite;
      
      private var _spStarGodModule:Sprite;
      
      private var _spEquipmentModule:Sprite;
      
      private var _spLegendStoneModule:Sprite;
      
      private var _spBadgeModule:Sprite;
      
      private var _spSacredEquipmentModule:Sprite;
      
      private var _mcSkillIcon:MovieClip;
      
      private var _skillShowing:Boolean = true;
      
      private var _extraAttribute:int;
      
      private var _isShowCarryPanel:Boolean = false;
      
      private var _isShowPsychicsTips:Boolean = true;
      
      private var _spSulinSkillModule:Sprite;
      
      private var _spAstrolabeModule:Sprite;
      
      public function NewFormationTipsSprite()
      {
         super();
         this._res = InstanceUtil.getInstance("mmo.formation.NewFormationTipRes",ApplicationDomain.currentDomain);
         this._spBg = this._res["spBg"];
         this.addChild(this._res);
         this._res.gotoAndStop(1);
         this._setResPacker = new SetResPacker(this._res);
      }
      
      public function setSkillShowing(param1:Boolean) : void
      {
         this._skillShowing = param1;
      }
      
      public function setFormationPetInfo(param1:FormationPetInfo, param2:int, param3:Boolean = false, param4:Boolean = true) : void
      {
         this._formationPetInfo = param1;
         this._extraAttribute = param2;
         this._isShowCarryPanel = param3;
         this._isShowPsychicsTips = param4;
         this.onAdd2Stage(null);
      }
      
      private function onAdd2Stage(param1:Event) : void
      {
         this.dispose();
         this.initTip();
         this.addListeners();
      }
      
      private function initTip() : void
      {
         this._increasingHeight = 0.35;
         this.clearAllChildren();
         this.setTextInfos();
         this.setSulingSkill();
         this.setAstrolabe();
         this.setStargod();
         this.setEquipment();
         this.setLegendStone();
         this.setSacredEquipment();
         this.setBadge();
         this.setSkill();
         this.adjustHeight();
      }
      
      private function addListeners() : void
      {
         if(this._clickHelper)
         {
            this._clickHelper.dispose();
            this._clickHelper = null;
         }
         this._clickHelper = new ClickHelper(this);
         this._clickHelper.regRegexFunc(/btnSwitchStarGod_[0-9]/,this.tryChangeStarGod);
         this._clickHelper.regClickFunc("btnSwitchAstrolabe",this.tryChangeAstrolabe);
      }
      
      private function tryChangeStarGod(param1:String) : void
      {
         var pet:PetBriefInfo = null;
         var slotIdx:int = 0;
         var name:String = param1;
         TipsManager.getInstance().clearAllTips();
         pet = PetBriefInfo.parseInfo(this._formationPetInfo.toCacheObj());
         slotIdx = parseInt(name.split("_")[1]);
         forSvc(IStarGodService,function(param1:IStarGodService):void
         {
            param1.selectChangeableMapping(pet,slotIdx);
         });
      }
      
      private function tryChangeAstrolabe() : void
      {
         TipsManager.getInstance().clearAllTips();
         forSvc(IAstrolabeService,function(param1:IAstrolabeService):void
         {
            param1.showOperationPanel(_formationPetInfo.id);
         });
      }
      
      private function clearAllChildren() : void
      {
         this.removeChildFromThis(this._spDetailModule);
         this.removeChildFromThis(this._spStarGodModule);
         this.removeChildFromThis(this._spEquipmentModule);
         this.removeChildFromThis(this._spLegendStoneModule);
         this.removeChildFromThis(this._spBadgeModule);
         this.removeChildFromThis(this._spSacredEquipmentModule);
         this.removeChildFromThis(this._mcSkillIcon);
         this.removeChildFromThis(this._spSulinSkillModule);
         this.removeChildFromThis(this._spAstrolabeModule);
      }
      
      private function removeChildFromThis(param1:Sprite) : void
      {
         if(Boolean(param1) && this.contains(param1))
         {
            this.removeChild(param1);
         }
      }
      
      private function adjustHeight() : void
      {
         this._spBg.height = this._increasingHeight;
      }
      
      private function setTextInfos() : void
      {
         if(this._spDetailModule == null)
         {
            this._spDetailModule = InstanceUtil.getInstance("mmo.formation.tip.DetialModuleRes",ApplicationDomain.currentDomain);
         }
         var _loc1_:String = FormationPetInfo.getFormationPetInfoDetailTip(this._formationPetInfo,false,this._extraAttribute);
         this._setResPacker.setFrame(this._spDetailModule,1);
         this._setResPacker.setFrame(this._spDetailModule,this._formationPetInfo.customName == null ? 3 : 2);
         var _loc2_:Number = Number(this._setResPacker.getChild([this._spDetailModule,"txtDescribe"]).y);
         this._setResPacker.setHtmlText([this._spDetailModule,"txtDescribe"],_loc1_);
         this._spDetailModule.x = 13.05;
         this._spDetailModule.y = this._increasingHeight;
         this._increasingHeight += _loc2_ + DETAIL_DESC_LINE_HEIGHT * this._setResPacker.getChild([this._spDetailModule,"txtDescribe"]).numLines + MODULE_GAP * 2;
         if(this._formationPetInfo.customName != null)
         {
            this._setResPacker.setHtmlText([this._spDetailModule,"txtPetName"],"（" + this._formationPetInfo.name + "）");
            this._setResPacker.setHtmlText([this._spDetailModule,"txtCustomName"],this._formationPetInfo.customName);
         }
         else
         {
            this._setResPacker.setHtmlText([this._spDetailModule,"txtPetName"],this._formationPetInfo.name);
         }
         var _loc3_:Sprite = this._spDetailModule["spLine"];
         _loc3_.height = DETAIL_DESC_LINE_HEIGHT * this._setResPacker.getChild([this._spDetailModule,"txtDescribe"]).numLines + MODULE_GAP * 2;
         this.addChild(this._spDetailModule);
      }
      
      private function isMyPackagePet(param1:FormationPetInfo) : Boolean
      {
         var _loc2_:IPetDataService = null;
         if(param1.ownership != 1)
         {
            return false;
         }
         _loc2_ = forSvc(IPetDataService);
         return _loc2_.getMyPetByPetId(param1.id,false,false) != null;
      }
      
      private function setStargod() : void
      {
         var _loc3_:Sprite = null;
         var _loc4_:PetStarGodSlot = null;
         var _loc5_:SimpleButton = null;
         if(!this._formationPetInfo.petBuild.pro_stargod.effective)
         {
            return;
         }
         if(this._spStarGodModule == null)
         {
            this._spStarGodModule = InstanceUtil.getInstance("mmo.formation.tip.StarGodModuleRes",ApplicationDomain.currentDomain);
         }
         var _loc1_:IStarGodService = ServiceContainer.getService(IStarGodService);
         var _loc2_:int = 0;
         while(_loc2_ < STARGOD_NUM)
         {
            _loc3_ = this._spStarGodModule["spStarGod_" + _loc2_];
            DisplayUtil.clearContainer(_loc3_);
            this._setResPacker.setVisible(_loc3_,true);
            if(_loc2_ < this._formationPetInfo.petBuild.pro_stargod.stargod.slots.length)
            {
               _loc4_ = this._formationPetInfo.petBuild.pro_stargod.stargod.slots[_loc2_];
               if(!_loc4_.isEmpty())
               {
                  _loc3_.addChild(_loc1_.getStarGod(_loc4_.toString(),_loc2_,true,null,false));
                  if(Boolean(_loc4_.isChangeable()) && this.isMyPackagePet(this._formationPetInfo))
                  {
                     _loc5_ = InstanceUtil.getInstance("mmo.formation.tip.ButtonSwitch",ApplicationDomain.currentDomain);
                     _loc5_.name = "btnSwitchStarGod_" + _loc2_;
                     _loc5_.x = 0;
                     _loc5_.y = 30;
                     _loc5_.scaleX = _loc5_.scaleY = 1.5;
                     _loc3_.addChild(_loc5_);
                  }
               }
               else
               {
                  this._setResPacker.setVisible(_loc3_,false);
               }
            }
            else
            {
               this._setResPacker.setVisible(_loc3_,false);
            }
            _loc2_++;
         }
         this._spStarGodModule.x = 13;
         this._spStarGodModule.y = this._increasingHeight + MODULE_GAP * 2;
         this._increasingHeight += ITEM_MODULE_HEIGHT + MODULE_GAP * 2;
         this.addChild(this._spStarGodModule);
      }
      
      private function setEquipment() : void
      {
         var _loc2_:Array = null;
         var _loc7_:Sprite = null;
         if(!this._formationPetInfo.petBuild.pro_equipment.effective)
         {
            return;
         }
         if(this._spEquipmentModule == null)
         {
            this._spEquipmentModule = InstanceUtil.getInstance("mmo.formation.tip.EquipmentModuleRes",ApplicationDomain.currentDomain);
         }
         var _loc1_:IEquipment4PetService = ServiceContainer.getService(IEquipment4PetService);
         var _loc3_:Sprite = this._spEquipmentModule["spEquipment"];
         var _loc4_:PetBriefInfo = PetBriefInfo.parseInfo(this._formationPetInfo.toCacheObj());
         var _loc5_:Vector.<Sprite> = _loc1_.getIconByString(this._formationPetInfo.petBuild.pro_equipment.sequence,true,0,0,0,_loc4_,true);
         var _loc6_:int = 0;
         while(_loc6_ < EQUIPMENT_NUM)
         {
            _loc7_ = _loc3_["spEquipment_" + _loc6_];
            DisplayUtil.clearContainer(_loc7_);
            if(_loc6_ < _loc5_.length)
            {
               _loc7_.addChild(_loc5_[_loc6_]);
               this._setResPacker.setVisible(_loc3_["spEquipment_" + _loc6_],true);
            }
            else
            {
               this._setResPacker.setVisible(_loc3_["spEquipment_" + _loc6_],false);
            }
            _loc6_++;
         }
         this._setResPacker.setVisible([this._spEquipmentModule,"spNoEquipment"],false);
         this._setResPacker.setVisible([this._spEquipmentModule,"spEquipment"],true);
         this._spEquipmentModule.x = 13;
         this._spEquipmentModule.y = this._increasingHeight + MODULE_GAP * 2;
         this._increasingHeight += ITEM_MODULE_HEIGHT + MODULE_GAP * 2;
         this.addChild(this._spEquipmentModule);
      }
      
      private function setLegendStone() : void
      {
         var _loc1_:ILegendService = null;
         var _loc2_:int = 0;
         var _loc3_:PetLegendStoneSlot = null;
         var _loc4_:Sprite = null;
         if(!this._formationPetInfo.petBuild.pro_stone.effective)
         {
            return;
         }
         if(this._spLegendStoneModule == null)
         {
            this._spLegendStoneModule = InstanceUtil.getInstance("mmo.formation.tip.LegendStoneModuleRes",ApplicationDomain.currentDomain);
         }
         if(this._formationPetInfo.petBuild.pro_stone.effective)
         {
            _loc1_ = ServiceContainer.getService(ILegendService);
            _loc2_ = 0;
            for each(_loc3_ in this._formationPetInfo.petBuild.pro_stone.stone.slots)
            {
               _loc4_ = this._spLegendStoneModule["spLegendStone_" + _loc3_.index];
               if(_loc4_ != null)
               {
                  if(_loc4_.getChildByName("spIconCore") != null)
                  {
                     _loc4_ = _loc4_.getChildByName("spIconCore") as Sprite;
                  }
                  TipsManager.getInstance().removeTips(_loc4_);
                  DisplayUtil.clearContainer(_loc4_);
                  if(!_loc3_.isEmpty())
                  {
                     _loc2_++;
                     Sprite(_loc4_).addChild(_loc1_.getStoneIcon(_loc3_.getLegendItemLevelDefine()));
                     TipsManager.getInstance().addComplexTips(_loc4_,_loc3_.getLegendItemLevelDefine().nameWithColor,_loc3_.getLegendItemLevelDefine().desc,0,TipsType.NORMAL,true);
                  }
               }
            }
            this._setResPacker.setVisible([this._spLegendStoneModule,"spNoLegendStone"],_loc2_ == 0);
         }
         this._spLegendStoneModule.x = 13;
         this._spLegendStoneModule.y = this._increasingHeight + MODULE_GAP * 2;
         this._increasingHeight += ITEM_MODULE_HEIGHT + MODULE_GAP * 2;
         this.addChild(this._spLegendStoneModule);
      }
      
      private function setBadge() : void
      {
         var _loc3_:Sprite = null;
         var _loc4_:PetBadgeSlot = null;
         if(!this._formationPetInfo.petBuild.pro_badge.effective)
         {
            return;
         }
         if(this._spBadgeModule == null)
         {
            this._spBadgeModule = InstanceUtil.getInstance("mmo.formation.tip.BadgeModuleRes",ApplicationDomain.currentDomain);
         }
         var _loc1_:IPetBadgeService = ServiceContainer.getService(IPetBadgeService);
         var _loc2_:int = 0;
         while(_loc2_ < 2)
         {
            _loc3_ = this._spBadgeModule["spBadge_" + _loc2_];
            if(_loc3_ != null && _loc3_.getChildByName("spIconCore") != null)
            {
               _loc3_ = _loc3_.getChildByName("spIconCore") as Sprite;
            }
            if(_loc3_ != null)
            {
               TipsManager.getInstance().removeTips(_loc3_);
               DisplayUtil.clearContainer(_loc3_);
               _loc4_ = this._formationPetInfo.petBuild.pro_badge.badge.getSlot(_loc2_);
               if(_loc4_ != null)
               {
                  Sprite(_loc3_).addChild(_loc1_.getBadgeIcon(_loc4_,true));
               }
            }
            _loc2_++;
         }
         this._setResPacker.setVisible([this._spBadgeModule,"spNoBadge"],this._formationPetInfo.petBuild.pro_badge.badge.slotLength == 0);
         this._spBadgeModule.x = 13;
         this._spBadgeModule.y = this._increasingHeight + MODULE_GAP * 2;
         this._increasingHeight += ITEM_MODULE_HEIGHT + MODULE_GAP * 2;
         this.addChild(this._spBadgeModule);
      }
      
      private function setSacredEquipment() : void
      {
         if(!this._formationPetInfo.petBuild.pro_sacredEquipment.effective)
         {
            return;
         }
         if(this._spSacredEquipmentModule == null)
         {
            this._spSacredEquipmentModule = InstanceUtil.getInstance("mmo.formation.tip.SacredEquipmentModuleRes",ApplicationDomain.currentDomain);
         }
         var _loc1_:ISacredEquipmentService = ServiceContainer.getService(ISacredEquipmentService);
         var _loc2_:Sprite = this._spSacredEquipmentModule;
         var _loc3_:PetSacredEquipmentSlot = this._formationPetInfo.petBuild.pro_sacredEquipment.sacredEquipment.getSlot();
         var _loc4_:String = _loc1_.getSacredEquipmentNameWithLevel(_loc3_);
         var _loc5_:String = _loc1_.getSacredEquipmentDescWithColor(_loc3_);
         var _loc6_:Sprite = _loc2_["spSacredEquipmentStage"];
         if(_loc6_)
         {
            DisplayUtil.clearContainer(_loc6_);
            _loc6_.addChild(_loc1_.getStageIcon(_loc3_.stageLevel));
            TipsManager.getInstance().addComplexTips(_loc6_,_loc4_,_loc5_);
         }
         var _loc7_:Sprite = _loc2_["spSacredEquipmentStar"];
         if(_loc7_)
         {
            DisplayUtil.clearContainer(_loc7_);
            _loc7_.addChild(_loc1_.getStarIcon(_loc3_.starLevel));
            TipsManager.getInstance().addComplexTips(_loc7_,_loc4_,_loc5_);
         }
         this._spSacredEquipmentModule.x = 13;
         this._spSacredEquipmentModule.y = this._increasingHeight + MODULE_GAP * 2;
         this._increasingHeight += ITEM_MODULE_HEIGHT + MODULE_GAP * 2;
         this.addChild(this._spSacredEquipmentModule);
      }
      
      private function setAstrolabe() : void
      {
         var allTwinkles:Vector.<PetAstrolabeTraceSlot>;
         var aSvc:IAstrolabeService = null;
         var btnSwitchAstrolabe:SimpleButton = null;
         if(!this._formationPetInfo.petBuild.pro_astrolabe.effective)
         {
            return;
         }
         if(this._spAstrolabeModule == null)
         {
            this._spAstrolabeModule = InstanceUtil.getInstance("mmo.formation.tip.AstrolabeModuleRes",ApplicationDomain.currentDomain);
         }
         allTwinkles = this._formationPetInfo.petBuild.pro_astrolabe.astrolabe.filter(PetAstrolabe.FT_TRACE_TWINKLE).findTraces();
         aSvc = ServiceContainer.getService(IAstrolabeService);
         DisplayUtil.clearContainer(this._spAstrolabeModule.getChildByName("spSlot_" + 0));
         DisplayUtil.clearContainer(this._spAstrolabeModule.getChildByName("spSlot_" + 1));
         DisplayUtil.clearContainer(this._spAstrolabeModule.getChildByName("spSlot_" + 2));
         if(allTwinkles.length > 0)
         {
            allTwinkles.forEach(function(param1:PetAstrolabeTraceSlot, param2:int, param3:*):void
            {
               var _loc4_:MovieClip = _spAstrolabeModule.getChildByName("spSlot_" + param2) as MovieClip;
               var _loc5_:* = aSvc.getTraceSlotIcon(param1);
               _loc5_.x = -60 / 2;
               _loc5_.y = -60 / 2;
               _loc4_.addChild(_loc5_);
            });
            this._spAstrolabeModule["spNoEquip"].visible = false;
            this._setResPacker.setVisible([this._spAstrolabeModule,"spNoEquip"],false);
         }
         else
         {
            this._setResPacker.setVisible([this._spAstrolabeModule,"spNoEquip"],true);
         }
         if(this.isMyPackagePet(this._formationPetInfo))
         {
            btnSwitchAstrolabe = InstanceUtil.getInstance("mmo.formation.tip.ButtonSwitch",ApplicationDomain.currentDomain);
            btnSwitchAstrolabe.name = "btnSwitchAstrolabe";
            btnSwitchAstrolabe.scaleX = btnSwitchAstrolabe.scaleY = (DETAIL_DESC_LINE_HEIGHT - 4) / DETAIL_DESC_LINE_HEIGHT;
            btnSwitchAstrolabe.x = 230;
            btnSwitchAstrolabe.y = 15;
            this._spAstrolabeModule.addChild(btnSwitchAstrolabe);
         }
         this._spAstrolabeModule.x = 13;
         this._spAstrolabeModule.y = this._increasingHeight + MODULE_GAP * 2;
         this._increasingHeight += ITEM_MODULE_HEIGHT + MODULE_GAP * 2;
         this.addChild(this._spAstrolabeModule);
      }
      
      private function setSkill() : void
      {
         var petBriInfo:PetBriefInfo = null;
         var addSkillT:Function = null;
         addSkillT = function():void
         {
            ServiceContainer.tryGetService(IBattleConfig,function(... rest):*
            {
               var _loc2_:int = _formationPetInfo.summonedPetFormationPetInfo != null ? int(_formationPetInfo.summonedPetFormationPetInfo.raceId) : -1;
               var _loc3_:int = _formationPetInfo.carriedFormationPetInfo != null ? int(_formationPetInfo.carriedFormationPetInfo.raceId) : -1;
               InteractUtil.interactHelper.addNewSkillIcon(_mcSkillIcon,_formationPetInfo.raceId,true,_formationPetInfo.id,_loc2_,null,null,null,true,petBriInfo,_isShowPsychicsTips,true,false,_isShowCarryPanel,_loc3_);
            });
         };
         if(!this._skillShowing)
         {
            return;
         }
         if(this._mcSkillIcon == null)
         {
            this._mcSkillIcon = new MovieClip();
         }
         this._mcSkillIcon.x = 152;
         this._mcSkillIcon.y = this._increasingHeight + SKILL_MODULE_HEIGHT / 2 + 5;
         this._increasingHeight += SKILL_MODULE_HEIGHT + MODULE_GAP * 2 + 12;
         petBriInfo = PetBriefInfo.parseInfo(this._formationPetInfo.toCacheObj());
         this.addChild(this._mcSkillIcon);
         if(ApplicationDomain.currentDomain.hasDefinition("mmo.interacthelper.newskillIcon.Skill_res"))
         {
            addSkillT();
         }
         else
         {
            LoadResUtil.loadRes("interact/newskillicon_res","mmo.interacthelper.newskillIcon.Skill_res",addSkillT,ApplicationDomain.currentDomain,false);
         }
      }
      
      private function setSulingSkill() : void
      {
         var formationServcie:*;
         var propValues:Array;
         var propLanes:Array;
         var i:int;
         var suLingEffectDefine:SulingEffectDefine = null;
         var txt:TextField = null;
         var icon:MovieClip = null;
         var title:String = null;
         var petDictionaryDataService:IPetDictionaryDataService = ServiceContainer.getService(IPetDictionaryDataService);
         var pddi:PetDictionaryDataItem = petDictionaryDataService.getDataItemByRaceId(this._formationPetInfo.raceId);
         if(!pddi.isLingChu())
         {
            return;
         }
         if(this._formationPetInfo.petBuild == null)
         {
            return;
         }
         if(this._spSulinSkillModule == null)
         {
            this._spSulinSkillModule = InstanceUtil.getInstance("mmo.formation.tip.SulingSkillModuleRes",ApplicationDomain.currentDomain);
         }
         formationServcie = ServiceContainer.getService(IFormationService) as IFormationService;
         suLingEffectDefine = formationServcie.getSuLingEffectDefineById(pddi.qiYunType);
         propValues = [this._formationPetInfo.petBuild.battleProperty.criticalRate,this._formationPetInfo.petBuild.battleProperty.antiCriticalRate,this._formationPetInfo.petBuild.battleProperty.hitRate,this._formationPetInfo.petBuild.battleProperty.evasionRate,this._formationPetInfo.petBuild.battleProperty.strikeRate,this._formationPetInfo.petBuild.battleProperty.blockRate,this._formationPetInfo.petBuild.battleProperty.strengthenPower,this._formationPetInfo.petBuild.battleProperty.resistPower];
         propLanes = propValues.map(function(param1:Number, param2:int, ... rest):Array
         {
            return [value2Desc(param1,param2),suLingEffectDefine.getDescByValueAndNumKey(param2,param1)];
         });
         i = 0;
         while(i < propValues.length)
         {
            txt = this._spSulinSkillModule["skill_" + i];
            txt.text = propLanes[i][0];
            icon = this._spSulinSkillModule.getChildByName("spIcon_" + i) as MovieClip;
            title = SulingEffectDefine.CN_KEYS[i];
            icon.mouseChildren = false;
            icon.graphics.beginFill(0,0);
            icon.graphics.drawRect(0,0,100,100);
            icon.graphics.endFill();
            TipsManager.getInstance().removeTips(icon);
            if(!StringUtil.isNullOrEmpty(propLanes[i][1]))
            {
               TipsManager.getInstance().addComplexTips(icon,title,propLanes[i][1],0,TipsType.NORMAL,true);
            }
            i++;
         }
         this._spSulinSkillModule.x = 13;
         this._spSulinSkillModule.y = this._increasingHeight + MODULE_GAP * 2;
         this._increasingHeight += 40 + MODULE_GAP * 2;
         this.addChild(this._spSulinSkillModule);
      }
      
      private function value2Desc(param1:Number, param2:int) : String
      {
         if(param2 >= 6)
         {
            return Math.floor(param1).toString();
         }
         return Math.floor(param1 * 100) + "%";
      }
      
      public function dispose() : void
      {
         this.removeEventListener(Event.ADDED_TO_STAGE,this.onAdd2Stage);
      }
   }
}

