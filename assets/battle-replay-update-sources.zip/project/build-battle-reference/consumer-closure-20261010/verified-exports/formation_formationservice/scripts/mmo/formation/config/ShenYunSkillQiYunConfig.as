package mmo.formation.config
{
   import mmo.interfaces.formation.QiYunEffectDefine;
   
   public class ShenYunSkillQiYunConfig
   {
      
      private static const DEFINES:Array = [new QiYunEffectDefine(1,"0.7|1.0","0.9|1.2","1.2|1.6","0.7|1.0","0.9|1.2","0.9|1.2","战斗中每次攻击后，暴击率提升<font color=\'#00FFFF\'>9%</font>（可叠加5次）|战斗中每次攻击后，暴击率提升<font color=\'#00FFFF\'>12%</font>（可叠加5次）","战斗中防暴率额外提升<font color=\'#00FFFF\'>60%</font>，每次受击后增幅衰减10%|战斗中防暴率额外提升<font color=\'#00FFFF\'>80%</font>，每次受击后增幅衰减10%","战斗中每次攻击后，命中率额外提升<font color=\'#00FFFF\'>12%</font>（可叠加5次）|战斗中每次攻击后，命中率额外提升<font color=\'#00FFFF\'>16%</font>（可叠加5次）","战斗中闪避率额外提升<font color=\'#00FFFF\'>100%</font>，每次闪避后增幅衰减40%|战斗中闪避率额外提升<font color=\'#00FFFF\'>120%</font>，每次闪避后增幅衰减40%","战斗中每次攻击后，破击率额外提升<font color=\'#00FFFF\'>18%</font>（可叠加5次）|战斗中每次攻击后，破击率额外提升<font color=\'#00FFFF\'>24%</font>（可叠加5次）","战斗中格挡率额外提升<font color=\'#00FFFF\'>90%</font>，每次格挡后增幅衰减30%|战斗中格挡率额外提升<font color=\'#00FFFF\'>120%</font>，每次格挡后增幅衰减30%")];
      
      public function ShenYunSkillQiYunConfig()
      {
         super();
      }
      
      public static function getQiYunDefinesById(param1:int) : QiYunEffectDefine
      {
         var _loc3_:QiYunEffectDefine = null;
         var _loc2_:int = 0;
         while(_loc2_ < DEFINES.length)
         {
            _loc3_ = DEFINES[_loc2_];
            if(_loc3_.id == param1)
            {
               return _loc3_;
            }
            _loc2_++;
         }
         return null;
      }
   }
}

