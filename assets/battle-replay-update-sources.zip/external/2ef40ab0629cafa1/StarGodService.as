package mmo.stargodv3
{
   import com.fairygui.GComponent;
   import flash.display.Sprite;
   import mmo.interfaces.InitServiceEvent;
   import mmo.interfaces.pet.battle.BattlePropertySource;
   import mmo.interfaces.pet.battle.IBattlePropertySource;
   import mmo.interfaces.pet.data.IPetDataService;
   import mmo.interfaces.pet.data.PetBriefInfo;
   import mmo.interfaces.pet.data.PetStarGod;
   import mmo.interfaces.pet.data.PetStarGodSlot;
   import mmo.play.globalfunctions.forSvc;
   import mmo.stargod.StarGodInfoPool;
   import mmo.stargodv2.StarGodService;
   import mmo.stargodv3.controller.Sgsv3Controller;
   import mmo.stargodv3.other.Sgsv3Config;
   import mmo.stargodv3.other.Sgsv3StarGodInfoPool;
   import mmo.stargodv3.view.units.Sgsv3StarGodSlot;
   import mmo.stargodv3.view.units.Sgsv3StarGodSlotSeparated;
   
   public class StarGodService extends mmo.stargodv2.StarGodService
   {
      
      public function StarGodService()
      {
         super();
      }
      
      override public function init() : void
      {
         var initNextService:Function = null;
         if(Sgsv3Config.ENABLED)
         {
            initNextService = function():*
            {
               dispatchEvent(new InitServiceEvent(InitServiceEvent.onInited,{}));
            };
            Sgsv3StarGodInfoPool.instance = new Sgsv3StarGodInfoPool();
            Sgsv3Controller.instance().init(initNextService);
            StarGodInfoPool.instance = Sgsv3StarGodInfoPool.instance;
         }
         else
         {
            super.init();
         }
      }
      
      override public function showStarGodPanel(param1:Function = null) : void
      {
         if(Sgsv3Config.ENABLED)
         {
            Sgsv3Controller.instance().showMainPanel(param1);
         }
         else
         {
            super.showStarGodPanel();
         }
      }
      
      override public function showStarGodPackage(param1:int = -1, param2:Function = null) : void
      {
         if(Sgsv3Config.ENABLED)
         {
            Sgsv3Controller.instance().showPackagePanel(param1,param2);
         }
         else
         {
            super.showStarGodPackage();
         }
      }
      
      override public function showOperationPanel(param1:int, param2:int, param3:int, param4:Function = null) : void
      {
         var petId:int = param1;
         var slotIndex:int = param2;
         var forWhat:int = param3;
         var closeCallback:Function = param4;
         forSvc(IPetDataService,function(param1:IPetDataService):*
         {
            Sgsv3Controller.instance().showOperationPanelByPet(param1.getMyPetByPetId(petId),slotIndex,closeCallback);
         });
      }
      
      override public function getStarGodInHuntUpBin() : Array
      {
         if(Sgsv3Config.ENABLED)
         {
            return [];
         }
         return super.getStarGodInHuntUpBin();
      }
      
      override public function getPackageArray() : Array
      {
         return [];
      }
      
      override public function getCollectionArray() : Array
      {
         return [];
      }
      
      override public function getStarGod(param1:String, param2:int = 0, param3:Boolean = true, param4:* = undefined, param5:Boolean = true) : Sprite
      {
         return Sgsv3StarGodSlot.newInstance(param1,param2,param3,false,param5);
      }
      
      override public function getStarGodG(param1:String, param2:int = 0, param3:Boolean = true, param4:* = undefined) : GComponent
      {
         return Sgsv3StarGodSlot.newInstance(param1,param2,param3,true);
      }
      
      override public function getStargodById(param1:int, param2:int = 0, param3:Boolean = true) : Sprite
      {
         return Sgsv3StarGodSlotSeparated.newInstance(param1,param2,param3);
      }
      
      override public function getStargodByIdG(param1:int, param2:int = 0, param3:Boolean = true) : GComponent
      {
         return Sgsv3StarGodSlotSeparated.newInstance(param1,param2,param3,true);
      }
      
      override public function getPetStarGodIcons(param1:String, param2:* = undefined, param3:int = 3, param4:Boolean = false, param5:int = 0, param6:Function = null, param7:Array = null) : Sprite
      {
         return new Sprite();
      }
      
      override public function getPetStarGodIconsX(param1:PetBriefInfo, param2:int = 3, param3:Boolean = false, param4:Function = null) : Sprite
      {
         return new Sprite();
      }
      
      override public function selectChangeableMapping(param1:PetBriefInfo, param2:int) : void
      {
         Sgsv3Controller.instance().selectChangeableMapping(param1,param2);
      }
      
      override public function getLevelMaxExp(param1:int) : int
      {
         return 0;
      }
      
      override public function setBlockControlUnit(param1:*) : Function
      {
         var view:* = param1;
         return function():*
         {
         };
      }
      
      override public function showStarGodBookPanel() : void
      {
         Sgsv3Controller.instance().showBookPanel();
      }
      
      override public function getBattlePower(param1:PetStarGod) : int
      {
         var bp:int = 0;
         var petStarGod:PetStarGod = param1;
         bp = 0;
         petStarGod.slots.forEach(function(param1:PetStarGodSlot, ... rest):void
         {
            if(param1.isAvailable())
            {
               bp += Sgsv3Config.getStarGodExtInfo(param1.defineId).levelInfo(param1.level).battlePower;
            }
         });
         return bp;
      }
      
      override public function getBattleProperty(param1:PetStarGod) : IBattlePropertySource
      {
         var battleProp:BattlePropertySource = null;
         var petStarGod:PetStarGod = param1;
         battleProp = new BattlePropertySource();
         petStarGod.slots.forEach(function(param1:PetStarGodSlot, ... rest):void
         {
            if(param1.isAvailable())
            {
               battleProp.addByStandardString(Sgsv3Config.getStarGodExtInfo(param1.defineId).levelInfo(param1.level).battleProperties);
            }
         });
         return battleProp;
      }
      
      override public function setStopLoadMovieClipState(param1:Boolean) : void
      {
         Sgsv3Controller.instance().isStopLoadRes = param1;
      }
      
      override public function isStopLoadMovieClip() : Boolean
      {
         return Sgsv3Controller.instance().isStopLoadRes;
      }
   }
}

