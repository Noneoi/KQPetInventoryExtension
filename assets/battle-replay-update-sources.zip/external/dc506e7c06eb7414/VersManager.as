package mmo.loader.scheduler
{
   import flash.net.URLRequest;
   import mmo.loader.FlashJSConnector;
   
   public class VersManager
   {
      
      public static var version:String;
      
      private static const DEFAULT_VERSION:String = "2000";
      
      private static const LOCAL_NAME:String = "aoqifv";
      
      private static const CHARACTER_LIST:Array = ["a"];
      
      private static const EXTENSION_NAMES:Array = ["swf","mp3","fui","html","js","css","png","jpg","gif"];
      
      public static var versionMap:Object = {};
      
      public static var sizeMap:Object = {};
      
      public static var md5Map:Object = {};
      
      public static var testFileMap:Object = {};
      
      public static var testFileZone:Object = {};
      
      public static var zoneId:int = -1;
      
      public function VersManager()
      {
         super();
      }
      
      public static function initMd5Map(param1:XML) : void
      {
         var _loc2_:XML = null;
         for each(_loc2_ in param1.m.f)
         {
            md5Map[_loc2_.@n] = _loc2_.@m;
            sizeMap[_loc2_.@n] = _loc2_.@s;
         }
         handleForJs();
      }
      
      public static function setVersionXml(param1:String, param2:XML, param3:XML) : void
      {
         var _loc4_:XML = null;
         version = param1;
         for each(_loc4_ in param3.f)
         {
            versionMap[_loc4_.@n] = _loc4_.@v;
            md5Map[_loc4_.@n] = _loc4_.@m;
            sizeMap[_loc4_.@n] = _loc4_.@s;
         }
         setTempVersion(param2);
      }
      
      public static function setTempVersion(param1:XML) : void
      {
         var _loc2_:XML = null;
         var _loc3_:String = null;
         var _loc4_:Array = null;
         for each(_loc2_ in param1.u.f)
         {
            versionMap[_loc2_.@n] = _loc2_.@v;
            md5Map[_loc2_.@n] = _loc2_.@m;
            sizeMap[_loc2_.@n] = _loc2_.@s;
            if(_loc2_.@rn != null && String(_loc2_.@rn).length > 0)
            {
               testFileMap[_loc2_.@n] = _loc2_.@rn;
               _loc3_ = _loc2_.@z;
               if(_loc3_.indexOf(";") >= 0)
               {
                  _loc4_ = String(_loc2_.@z).split(";");
               }
               else
               {
                  _loc4_ = [_loc3_];
               }
               testFileZone[_loc2_.@n] = _loc4_;
            }
         }
      }
      
      public static function setZoneId(param1:int) : void
      {
         zoneId = param1;
      }
      
      public static function getVerURLRequest(param1:String, param2:String = "swf") : URLRequest
      {
         var _loc5_:String = null;
         var _loc6_:Array = null;
         var _loc3_:int = param1.lastIndexOf(".");
         if(_loc3_ >= 0)
         {
            param2 = param1.substr(_loc3_ + 1);
            param1 = param1.substr(0,_loc3_);
         }
         var _loc4_:String = getVersion(param1,param2);
         if(testFileMap[param1] != null)
         {
            _loc6_ = testFileZone[param1];
            if(_loc6_.indexOf(zoneId.toString()) >= 0)
            {
               param1 = testFileMap[param1];
            }
         }
         if(_loc4_.length > 0)
         {
            _loc5_ = param1 + _loc4_ + "." + param2;
         }
         else
         {
            _loc5_ = param1 + "." + param2;
         }
         return new URLRequest(_loc5_);
      }
      
      private static function handleForJs() : void
      {
         if(FlashJSConnector.isAvailable())
         {
            FlashJSConnector.getVerURLRequestForJs(getVerURLRequestForJs);
         }
      }
      
      private static function getVerURLRequestForJs(param1:String, param2:String = "js") : String
      {
         return getVerURLRequest(param1,param2).url;
      }
      
      public static function checkCanChangeVersion(param1:String) : Boolean
      {
         var _loc3_:String = null;
         if(CHARACTER_LIST.length == 0 || version.length == 0)
         {
            return false;
         }
         var _loc2_:String = versionMap[param1];
         if(_loc2_ != null && _loc2_.length > 0)
         {
            _loc3_ = _loc2_.charAt(_loc2_.length - 1);
            if(CHARACTER_LIST.indexOf(_loc3_) == CHARACTER_LIST.length - 1)
            {
               return false;
            }
         }
         return true;
      }
      
      public static function checkHasChangedVersion(param1:String) : Boolean
      {
         var _loc3_:String = null;
         var _loc2_:String = versionMap[param1];
         if(_loc2_ != null && _loc2_.length > 0)
         {
            _loc3_ = _loc2_.charAt(_loc2_.length - 1);
            return CHARACTER_LIST.indexOf(_loc3_) != -1;
         }
         return false;
      }
      
      public static function changeVersion(param1:String) : void
      {
         var _loc2_:String = versionMap[param1];
         if(_loc2_ == null || _loc2_.length == 0)
         {
            _loc2_ = DEFAULT_VERSION;
         }
         var _loc3_:String = _loc2_.charAt(_loc2_.length - 1);
         var _loc4_:int = CHARACTER_LIST.indexOf(_loc3_);
         if(_loc4_ != -1)
         {
            _loc2_ = _loc2_.substr(0,_loc2_.length - 1);
         }
         _loc4_++;
         _loc2_ += CHARACTER_LIST[_loc4_];
         versionMap[param1] = _loc2_;
      }
      
      private static function getVersion(param1:String, param2:String = "swf") : String
      {
         var _loc4_:String = null;
         if(version.length == 0)
         {
            return "";
         }
         var _loc3_:String = "~";
         if(EXTENSION_NAMES.indexOf(param2) != -1)
         {
            _loc4_ = versionMap[param1];
            if(_loc4_ != null && _loc4_.length > 0)
            {
               return _loc3_ + _loc4_;
            }
            return _loc3_ + DEFAULT_VERSION;
         }
         return "~" + version;
      }
   }
}

