package mmo.loader
{
   import com.fairygui.GRoot;
   import com.fairygui.UIConfig;
   import flash.display.Bitmap;
   import flash.display.BitmapData;
   import flash.display.Loader;
   import flash.display.LoaderInfo;
   import flash.display.Sprite;
   import flash.events.Event;
   import flash.events.IOErrorEvent;
   import flash.geom.Rectangle;
   import flash.net.LocalConnection;
   import flash.net.SharedObject;
   import flash.net.URLLoader;
   import flash.net.URLLoaderDataFormat;
   import flash.net.URLRequest;
   import flash.system.ApplicationDomain;
   import flash.system.LoaderContext;
   import flash.text.Font;
   import flash.utils.ByteArray;
   import flash.utils.getDefinitionByName;
   import flash.utils.getTimer;
   import mmo.config.ConfigReadEvent;
   import mmo.config.ConfigReader;
   import mmo.loader.common.datastructures.HashMap;
   import mmo.loader.encrpyt.EncryptFile;
   import mmo.loader.error.HttpCollectClientLogService;
   import mmo.loader.error.InspectorErrorWatch;
   import mmo.loader.httpclient.HttpClient;
   import mmo.loader.layer.LayerManager;
   import mmo.loader.scheduler.ResPriority;
   import mmo.loader.scheduler.ResScheduler;
   import mmo.loader.scheduler.VersManager;
   import mmo.loader.util.MD5Util;
   import mmo.region.RegionInfo;
   
   [SWF(width="960", height="560", backgroundColor="#999999", frameRate="25")]
   public class LoaderContainer extends Sprite
   {
      
      public static var instance:LoaderContainer;
      
      public static const stageWidth:int = 960;
      
      public static const stageHeight:int = 560;
      
      public static const designWidth:int = 1136;
      
      public static const designHeight:int = 640;
      
      public static var isStartDog:Boolean = false;
      
      private var customLoader:CustomLoader;
      
      private var versionXML:XML;
      
      private var version:String;
      
      private var frameStartTime:int;
      
      private var tempDomain:ApplicationDomain;
      
      private var _syncCount:int;
      
      private var httpClient:HttpClient = HttpClient.instance;
      
      public function LoaderContainer()
      {
         super();
         instance = this;
         this.addEventListener(Event.ADDED_TO_STAGE,this.addToStage);
      }
      
      public static function copyStage() : Bitmap
      {
         var _loc1_:Rectangle = new Rectangle(0,0,stageWidth,stageHeight);
         var _loc2_:BitmapData = new BitmapData(stageWidth,stageHeight,true,0);
         _loc2_.draw(instance.stage,null,null,null,_loc1_);
         return new Bitmap(_loc2_);
      }
      
      public static function GC() : void
      {
         try
         {
            new LocalConnection().connect("pjx");
            new LocalConnection().connect("pjx");
         }
         catch(er:Error)
         {
         }
      }
      
      public static function getFrameTime() : int
      {
         return getTimer() - instance.frameStartTime;
      }
      
      private function addToStage(param1:Event) : *
      {
         this.removeEventListener(Event.ADDED_TO_STAGE,this.addToStage);
         this.initZoneId();
         this.stage.addEventListener(Event.ENTER_FRAME,this.onFrame);
         LayerManager.init();
         EncryptFile.isLocal = this.stage.loaderInfo.url.indexOf("file://") == 0 || this.stage.loaderInfo.url.indexOf("http://127.0.0.1") == 0;
         InspectorErrorWatch.instance.watch(this.loaderInfo);
         this.loadVersion();
      }
      
      private function loadVersion() : void
      {
         var _loc3_:URLRequest = null;
         this.versionXML = XML((this.parent as Object).version);
         VersManager.initMd5Map(this.versionXML);
         var _loc1_:ByteArray = ByteArray((this.parent as Object).loaderSwfBtyes);
         if((this.parent as Object).flashStartTime != undefined)
         {
            HttpCollectClientLogService.flashStartTime = (this.parent as Object).flashStartTime;
         }
         var _loc2_:String = "loader.swf";
         MD5Util.validateFileContentAndLog(_loc2_,_loc1_);
         this.version = this.versionXML.v;
         if(this.version.length > 0)
         {
            _loc3_ = new URLRequest("versiondata~" + this.version + ".swf");
         }
         else
         {
            _loc3_ = new URLRequest("versiondata.swf");
         }
         var _loc4_:URLLoader = new URLLoader();
         _loc4_.dataFormat = URLLoaderDataFormat.BINARY;
         _loc4_.addEventListener(Event.COMPLETE,this.onVersionLoadSuccess);
         _loc4_.addEventListener(IOErrorEvent.IO_ERROR,this.onVersionLoadFailure);
         _loc4_.load(_loc3_);
      }
      
      private function onVersionLoadSuccess(param1:Event) : void
      {
         var _loc2_:URLLoader = param1.target as URLLoader;
         _loc2_.removeEventListener(Event.COMPLETE,this.onVersionLoadSuccess);
         _loc2_.removeEventListener(IOErrorEvent.IO_ERROR,this.onVersionLoadFailure);
         this.loadByte(_loc2_.data);
      }
      
      private function onVersionLoadFailure(param1:IOErrorEvent) : void
      {
         this.loadVersion();
      }
      
      private function loadByte(param1:ByteArray) : void
      {
         var _loc2_:flash.display.Loader = new flash.display.Loader();
         MD5Util.validateFileContentAndLog("versiondata.swf",param1);
         _loc2_.contentLoaderInfo.addEventListener(Event.COMPLETE,this.onLoadBytesSuccess);
         _loc2_.loadBytes(param1,new LoaderContext(false,ApplicationDomain.currentDomain));
      }
      
      private function onLoadBytesSuccess(param1:Event) : void
      {
         var _loc2_:LoaderInfo = param1.target as LoaderInfo;
         _loc2_.removeEventListener(Event.COMPLETE,this.onLoadBytesSuccess);
         var _loc3_:Class = getDefinitionByName("mmo.versiondata.DocClass") as Class;
         var _loc4_:XML = new XML(_loc3_["vconfig"]);
         VersManager.setVersionXml(this.version,this.versionXML,_loc4_);
         this.loadConfig();
         HttpCollectClientLogService.collectAllUserEvent("501075");
      }
      
      private function loadConfig() : void
      {
         HttpCollectClientLogService.webSite = this.getWebSite();
         ConfigReader.instance.addEventListener(ConfigReadEvent.onConfigLoadSuccess,this.onConfigLoadSuccess);
         ConfigReader.instance.preloadConfig();
         ConfigReader.instance.fileSite = this.stage.loaderInfo.url;
      }
      
      private function onConfigLoadSuccess(param1:ConfigReadEvent) : void
      {
         if(RegionInfo.isChinaInland)
         {
            HttpCollectClientLogService.collectPVData(this.getIsNewMachine(),this.loadExtRes);
         }
         else
         {
            this.loadExtRes();
         }
      }
      
      private function loadExtRes() : void
      {
         ResScheduler.getResource("loader_ext",function(param1:Sprite = null):void
         {
            loadBgImage();
         },"");
      }
      
      private function loadBgImage() : void
      {
         ResScheduler.getResource(this.loaderBgPath,function(param1:Sprite):void
         {
            onCollectPVData();
         },"mmo.loader.loadingsprite.Bg");
      }
      
      private function get loaderBgPath() : String
      {
         return "loader_bg";
      }
      
      private function onCollectPVData() : void
      {
         LayerManager.instance.clearStage();
         if(RegionInfo.isChinaInland && new WebLoginChecker().checkAndGotoWebLog())
         {
            return;
         }
         this.customLoader = new CustomLoader(ResPriority.NORMAL,true,null,true);
         var _loc1_:Array = ConfigReader.instance.libs;
         this.customLoader.addEventListener(CustomLoaderEvent.onLoadCompleted,this.onLoadCompleted);
         this.customLoader.addEventListener(CustomLoaderEvent.onError,this.onError);
         this.customLoader.load(_loc1_,LoadingSpriteType.fullScreen,false,"正在进入奥奇传说……");
      }
      
      private function onLoadCompleted(param1:CustomLoaderEvent) : void
      {
         this.customLoader.removeEventListener(CustomLoaderEvent.onLoadCompleted,this.onLoadCompleted);
         this.customLoader.removeEventListener(CustomLoaderEvent.onError,this.onError);
         GC();
         this.stage.addChild(GRoot.inst.displayObject);
         UIConfig.buttonUseHandCursor = true;
         this._syncCount = 2;
         this.loadPreloadRes();
         this.loadLoginService();
      }
      
      private function registerFont(param1:*, param2:String) : void
      {
         var _loc3_:* = getDefinitionByName(param1);
         Font.registerFont(_loc3_);
         var _loc4_:Font = new _loc3_() as Font;
         UIConfig.fontNameMap[param2] = _loc4_.fontName;
      }
      
      private function onError(param1:CustomLoaderEvent) : void
      {
         this.addChild(new ErrorPanel());
      }
      
      private function loadLoginService() : void
      {
         var svcContainer:Object = getDefinitionByName("mmo.interfaces.ServiceContainer");
         if(svcContainer != null)
         {
            svcContainer["instance"]["tryGetService"]("LoginService",function onGetService(param1:*, param2:Object = null):void
            {
               param1["startPlay"]();
               onCompleted();
            });
         }
      }
      
      private function loadPreloadRes() : void
      {
         mmo.loader.Loader.load(ConfigReader.instance.preloadRes,this.onCompleted);
      }
      
      private function onFrame(param1:Event) : void
      {
         this.frameStartTime = getTimer();
      }
      
      private function onCompleted() : void
      {
         --this._syncCount;
         if(this._syncCount == 0)
         {
            this.tempDomain = null;
            this.customLoader.close();
            this.customLoader = null;
            GC();
         }
      }
      
      private function compileMe() : void
      {
         var _loc1_:ResScheduler = null;
         var _loc2_:HashMap = null;
         var _loc3_:ErrorThrower = null;
         var _loc4_:HttpCollectClientLogService = null;
         var _loc5_:FGUILoader = null;
         var _loc6_:SpineLoader = null;
         var _loc7_:mmo.loader.Loader = null;
         var _loc8_:SceneDomain = null;
      }
      
      private function initZoneId() : void
      {
         var _loc2_:int = 0;
         var _loc1_:String = WebLoginChecker.callJS("getQS","debug","debug");
         if(_loc1_ != "debug")
         {
            _loc2_ = parseInt(_loc1_);
            if(_loc2_ >= 100000)
            {
               VersManager.setZoneId(_loc2_);
            }
         }
      }
      
      private function getWebSite() : String
      {
         var _loc1_:String = WebLoginChecker.callJS("getQS","","src");
         if(_loc1_ != null && _loc1_.length > 0)
         {
            return _loc1_;
         }
         return WebLoginChecker.callJS("getLoginSrc","");
      }
      
      private function getIsNewMachine() : Boolean
      {
         var _loc1_:SharedObject = SharedObject.getLocal("aoqiso","/");
         var _loc2_:String = "isOldMachine";
         var _loc3_:Boolean = _loc1_.data[_loc2_] == null ? true : false;
         if(_loc3_)
         {
            _loc1_.data[_loc2_] = true;
            try
            {
               _loc1_.flush();
            }
            catch(error:Error)
            {
            }
         }
         return _loc3_;
      }
   }
}

