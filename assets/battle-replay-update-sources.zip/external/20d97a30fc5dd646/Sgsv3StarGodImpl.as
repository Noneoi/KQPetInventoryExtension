package mmo.stargodv3.other.structs
{
   import mmo.interfaces.ServiceContainer;
   import mmo.interfaces.material.stargod.IStarGodItemService;
   import mmo.interfaces.material.stargod.StarGodItem;
   import mmo.interfaces.pet.data.PetStarGodSlot;
   import mmo.stargodv3.other.Sgsv3Config;
   
   public class Sgsv3StarGodImpl implements Sgsv3StarGod
   {
      
      protected static var sStarGodItemSvc:IStarGodItemService = null;
      
      protected var _defineId:int;
      
      protected var _level:int = 1;
      
      private var _item:StarGodItem = null;
      
      private var _qualityWeightCache:int = -1;
      
      public function Sgsv3StarGodImpl()
      {
         super();
      }
      
      public static function valueFrom(param1:PetStarGodSlot) : Sgsv3StarGodImpl
      {
         var _loc2_:Sgsv3StarGodImpl = new Sgsv3StarGodImpl();
         _loc2_._defineId = param1.defineId;
         _loc2_._level = param1.level;
         return _loc2_;
      }
      
      public static function valueOf(param1:Object) : Sgsv3StarGodImpl
      {
         var _loc2_:Sgsv3StarGodImpl = new Sgsv3StarGodImpl();
         _loc2_._defineId = param1["di"];
         return _loc2_;
      }
      
      public static function valueBy(param1:int, param2:int = 1) : Sgsv3StarGodImpl
      {
         var _loc3_:Sgsv3StarGodImpl = new Sgsv3StarGodImpl();
         _loc3_._defineId = param1;
         _loc3_._level = param2;
         return _loc3_;
      }
      
      public static function valuesOf(param1:Array) : Vector.<Sgsv3StarGodImpl>
      {
         var _loc2_:Vector.<Sgsv3StarGodImpl> = new Vector.<Sgsv3StarGodImpl>(param1.length);
         var _loc3_:int = 0;
         while(_loc3_ < param1.length)
         {
            _loc2_[_loc3_] = valueOf(param1[_loc3_]);
            _loc3_++;
         }
         return _loc2_;
      }
      
      public function get id() : int
      {
         return 0;
      }
      
      public function get defineId() : int
      {
         return this._defineId;
      }
      
      public function get level() : int
      {
         return this._level;
      }
      
      public function get curExp() : int
      {
         return 0;
      }
      
      public function get supExp() : int
      {
         return Sgsv3Config.getStarGodExtInfo(this._defineId).supplyExp;
      }
      
      public function get expAtNextLevel() : int
      {
         return 0;
      }
      
      public function get place() : int
      {
         return 0;
      }
      
      public function get item() : StarGodItem
      {
         if(sStarGodItemSvc == null)
         {
            sStarGodItemSvc = ServiceContainer.getService(IStarGodItemService);
         }
         if(this._item == null)
         {
            this._item = sStarGodItemSvc.getStarGodItemById(this._defineId);
         }
         return this._item;
      }
      
      public function get name() : String
      {
         return this.item.name;
      }
      
      public function get pinYinChain() : String
      {
         return Sgsv3Config.getStarGodExtInfo(this._defineId).pinYinChain;
      }
      
      public function get qualityWeight() : int
      {
         if(this._qualityWeightCache != -1)
         {
            return this._qualityWeightCache;
         }
         var _loc1_:int = int(this.item.quality);
         var _loc2_:int = Sgsv3Config.STAR_GOD_DEFINE_IDS_OF_SPEC_QUALITY_WEIGHT.indexOf(this._defineId) + 1;
         return this._qualityWeightCache = _loc1_ * 1000 + _loc2_ * 100 + this.defineId;
      }
      
      public function isChangeable() : Boolean
      {
         return this.item.changeable;
      }
   }
}

