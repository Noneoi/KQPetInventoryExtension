package mmo.stargodv3.other.structs
{
   public class Sgsv3StarGodLevelInfo
   {
      
      private var _level:int;
      
      private var _battlePower:int;
      
      private var _battleProperties:String;
      
      private var _desc:String;
      
      public function Sgsv3StarGodLevelInfo()
      {
         super();
      }
      
      public static function valueFromElement(param1:XML) : Sgsv3StarGodLevelInfo
      {
         var _loc2_:Sgsv3StarGodLevelInfo = new Sgsv3StarGodLevelInfo();
         _loc2_._level = param1["level"];
         _loc2_._battlePower = param1["battlePower"];
         _loc2_._battleProperties = param1["battleProperty"];
         _loc2_._desc = param1["desc"];
         return _loc2_;
      }
      
      public static function valuesFromElement(param1:XMLList) : Vector.<Sgsv3StarGodLevelInfo>
      {
         var _loc2_:int = 0;
         if(param1 != null)
         {
            _loc2_ = param1.length();
         }
         var _loc3_:Vector.<Sgsv3StarGodLevelInfo> = new Vector.<Sgsv3StarGodLevelInfo>(_loc2_);
         var _loc4_:int = 0;
         while(_loc4_ < _loc3_.length)
         {
            _loc3_[_loc4_] = valueFromElement(param1[_loc4_]);
            _loc4_++;
         }
         return _loc3_;
      }
      
      public function get battlePower() : int
      {
         return this._battlePower;
      }
      
      public function get battleProperties() : String
      {
         return this._battleProperties;
      }
      
      public function get desc() : String
      {
         return this._desc;
      }
   }
}

